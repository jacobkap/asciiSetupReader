PROC FORMAT ; 
   VALUE ER30000F
         1 = 'Release number 1, February 2019'
         2 = 'Release number 2, May 2019'
   ;
   VALUE ER30003F
         1 = 'Head'
         2 = 'Wife/"Wife"'
         3 = 'Son or daughter'
         4 = 'Brother or sister'
         5 = 'Father or mother'
         6 = 'Grandchild, niece, nephew, other relatives under 18'
         7 = 'Other, including in-laws, other adult relatives'
         8 = 'Husband or Wife of Head who moved out or died in the year prior to the 1968 interview'
         9 = 'NA'
         0 = 'Individual from core sample who was born or moved in after the 1968 interview; individual from Immigrant or Latino samples (ER30001=3001-3511, 4001-4462,7001-9308)'
   ;
   VALUE ER30005F
         1 = 'Spouse in couple numbered 1'
         2 = 'Spouse in couple numbered 2'
         3 = 'Spouse in couple numbered 3'
         0 = 'Inap.:  not married; spouse was not in FU in 1968; born or moved in after the 1968 interview or individual from Immigrant or Latino samples (ER30003=0)'
   ;
   VALUE ER30006F
         1 = 'Moved in during the year preceding the 1968 interview'
         9 = 'NA; DK'
         0 = 'Lived in the FU for a year or more preceding the 1968 interview; in an institution in 1968 (ER30001=1-2930, 5001-6872 and ER30002=20-26); spouse of 1968 Head who died or moved out in the year prior to'
             ' the interview (ER30001=1-2930, 5001-6872 and ER30002=227-228); born or moved in after the 1968 interview or individual from Immigrant or Latino samples (ER30003=0)'
   ;
   VALUE ER30009F
         1 = 'Yes (includes college, trade school)'
         5 = 'No'
         9 = 'NA; DK'
         0 = 'Born or moved in after the 1968 interview or individual from Immigrant or Latino samples (ER30003=0)'
   ;
   VALUE ER30010F
    1 - 16 = 'Highest grade or year of schooling completed'
        17 = 'At least one year of postgraduate work'
        99 = 'NA; DK'
         0 = 'Preschool; born or moved in after the 1968 interview or individual from Immigrant or Latino samples (ER30003=0); still in school (ER30009=1 or 9)'
   ;
   VALUE ER30011F
         1 = 'Labor income only'
         2 = 'Transfer income only'
         3 = 'Asset income only'
         4 = 'Combination of labor, transfer, and/or asset'
         9 = 'NA; DK'
         0 = 'Inap.:  no income; born or moved in after the 1968 interview or individual from Immigrant or Latino samples (ER30003=0); under 14 years old in 1968 (ER30004=1-13)'
   ;
   VALUE ER30014F
         1 = 'Yes, unqualified'
         3 = 'Yes, qualified'
         5 = 'No'
         9 = 'NA; DK'
         0 = 'Inap.:  born or moved in after the 1968 interview or individual from Immigrant or Latino samples (ER30003=0); under 14 years old in 1968 (ER30004=1-13); no income (ER30011=0)'
   ;
   VALUE ER30016F
     1 - 5 = 'Extra earner number'
         9 = 'NA; DK'
         0 = 'Inap.:  no labor income; born or moved in after the 1968 interview or individual from Immigrant or Latino samples (ER30003=0); Head or Wife in 1968 (ER30003=1-02)'
   ;
   VALUE ER30017F
         5 = 'This sample individual, although connected with a response family, was in an institution in 1968 (ER30002=20-26 and ER30003>0)'
         8 = 'This nonsample individual from core sample left the FU in the year prior to the 1968 wave, including the deceased (ER30001=1-2930, 5001-6872 and ER30002=227-228)'
         9 = 'This individual from core sample had not moved in or been born by the time of the 1968 interview (ER30001=1-2930, 5001-6872 and ER30002=030-226), or was erroneously not included in the 1968 FU (ER3000'
             '1=1-2930, 5001-6872 and ER30002=001-026 and ER30003=0); individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        99 = 'NA; DK'
         0 = 'Individual in a panel family in 1968 (ER30002=001-019 and ER30003>0)'
   ;
   VALUE ER30018F
        11 = 'This individual was in the armed forces.'
        12 = 'This individual was in an educational institution.'
        13 = 'This individual was in a health care facility.'
        14 = 'This individual was in jail or prison.'
        19 = 'This individual was in some other type of institution, for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        41 = 'This spouse from core sample died in the year prior to the 1968 interview (ER30001=1-2930, 5001-6872 and ER30002=228)'
        92 = 'This ex-spouse from core sample was not eligible for interviewing at the time he/she moved out (ER30001=1-2930, 5001-6872 and ER30002=227)'
        97 = 'This individual from core sample had not been born or moved into the panel by 1968 (ER30001=1-2930, 5001-6872 and ER30002=030-226), or was erroneously not included in the 1968 FU (ER30001=1-2930, 5001'
             '-6872 and ER30002=1-026 and ER30003=0); individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        99 = 'NA; DK'
         0 = 'Inap.:  individual in a panel family in 1968 (ER30002=001-019 and ER30003>0)'
   ;
   VALUE ER30021F
    1 - 20 = 'Individuals in the family at the time of the 1969 interview'
   51 - 59 = 'Individuals in institutions at the time of the 1969 interview'
   71 - 80 = 'Individuals who moved out of the FU or out of institutions between the 1968 and 1969 interviews but who were not included in another responding FU for 1969. All such individuals were nonresponse.'
   81 - 89 = 'Individuals living in 1968 but who died by the time of the 1969 interview'
         0 = 'Born or moved in after the 1969 interview; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse for 1969 or mover-out nonresponse in 1968 (ER30020=0)'
   ;
   VALUE ER30022F
         1 = 'Head in 1969; 1968 Head who was mover-out nonresponse by the time of the 1969 interview'
         2 = 'Wife in 1969; 1968 Wife who was mover-out nonresponse by the time of the 1969 interview'
         3 = 'Son or daughter, including stepchildren and foster children'
         4 = 'Brother or sister of Head'
         5 = 'Father or mother of Head'
         6 = 'Grandchild or great-grandchild'
         7 = 'Other relative, including in-laws'
         8 = 'Nonrelative'
         9 = 'Husband of Head'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1969 interview (ER30020>0 and ER30021=0); main family nonresponse for 1969 or mover-out non'
             'response from 1968 (ER30020=0)'
   ;
   VALUE ER30024F
         1 = 'Spouse in couple numbered 1'
         2 = 'Spouse in couple numbered 2'
         3 = 'Spouse in couple numbered 3'
         0 = 'Inap.:  not married; spouse was not in FU in 1969; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1969 interview (ER30020>0 and ER30021=0); main f'
             'amily nonresponse for 1969 or mover-out nonresponse from 1968 (ER30020=0)'
   ;
   VALUE ER30025F
         1 = 'Moved in or born between 1968 and 1969 interviews; splitoff in 1969'
         2 = 'Appeared; moved in by the time the 1968 interview was taken but not included in FU for 1968 (usually a 1968 listing error)'
         5 = 'Moved out of FU or institution between the 1968 and 1969 interviews and was not included in a 1969 panel FU'
         6 = 'Moved out of FU and into institution between the 1968 and 1969 interviews'
         7 = 'Living in 1968 but died by the time of the 1969 interview'
         8 = 'Disappeared; moved out prior to the 1968 interview but included in FU for 1968 (usually a listing error)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); in main family in both 1968 and 1969 (ER30003=1-9 and ER30021=1-20); in an institution in both 1968 and 1969 (ER30002='
             '20-26 and ER30021=51-59); born or moved in after the 1969 interview (ER30020>0 and ER30021=0); main family nonresponse for 1969 or mover-out nonresponse from 1968 (ER30020=0)'
   ;
   VALUE ER30028F
         1 = 'Yes, stopped going to school'
         5 = 'No, did not stop'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1969 interview (ER30020>0 and ER30021=0); main family nonresponse for 1969 or mover-out non'
             'response from 1968 (ER30020=0)'
   ;
   VALUE ER30029F
    1 - 97 = 'Actual hours spent'
        98 = 'Ninety-eight hours or more'
        99 = 'NA; DK'
         0 = 'Inap.:  none; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); in an institution in both 1968 and 1969 (ER30021=51-59 and ER30025=0); born or moved in after the 1969 interview'
             ' (ER30020>0 and ER30021=0); main family nonresponse for 1969 or mover-out nonresponse from 1968 (ER30020=0)'
   ;
   VALUE ER30030F
         1 = 'Yes, is disabled'
         2 = 'Yes, requires extra care'
         5 = 'No; in an institution at time of 1969 interview or mover-out nonresponse from 1969 (ER30021=51-89)'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1969 interview (ER30020>0 and ER30021=0); main family nonresponse for 1969 or mover-out non'
             'response from 1968 (ER30020=0)'
   ;
   VALUE ER30031F
         1 = 'This individual was respondent'
         5 = 'This individual was not respondent; in an institution in 1969 (ER30021=51-59)'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1969 interview (ER30020>0 and ER30021=0); main family nonresponse for 1969 or mover-out non'
             'response from 1968 (ER30020=0)'
   ;
   VALUE ER30032F
         1 = 'Labor income only'
         2 = 'Transfer income only'
         3 = 'Asset income only'
         4 = 'Combination of labor, transfer, and/or asset'
         9 = 'NA; DK'
         0 = 'Inap.:  no income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1969 interview (ER30020>0 and ER30021=0); main family nonresponse for 1969 or mo'
             'ver-out nonresponse from 1968 (ER30020=0); in an institution in both 1968 and 1969 (ER30021=51-59 and ER30025=0)'
   ;
   VALUE ER30035F
         1 = 'Yes, unqualified'
         3 = 'Yes, qualified; a little; less than $10 a week; sometimes'
         5 = 'No'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); Head or Wife in 1969 (ER30021=1-20 and ER30022=1 or 02); born or moved in after the 1969 interview (ER30020>0 and ER30'
             '021=0); main family nonresponse for 1969 or mover-out nonresponse from 1968 (ER30020=0); in an institution in both 1968 and 1969 (ER30021=51-59 and ER30025=0); no income (ER30032=0)'
   ;
   VALUE ER30040F
         1 = 'This sample member was 18 years old or older at the time of main family nonresponse and had been in the FU in 1968.'
         2 = 'This sample member was less than 18 at the time of main family nonresponse and had been in the FU in 1968.'
         3 = 'This sample member had been living in a panel family in 1968 but who subsequently died or moved out and was not followed. The individual records contain zeros for the years after these members left. T'
             'heir weights are also zero. These individuals should be used only to generate 1968 family composition variables (e.g. the number of pre-school children)'
         4 = 'This sample member had been in an institution in 1968 but his or her main family became nonresponse in 1969.'
         5 = 'This sample member, although connected with a 1969 response family, was in an institution at the time of the 1969 interview.'
         6 = 'This sample member was 18 years old or older and moved out or died between the 1968 and 1969 interviews.'
         7 = 'This sample member was less than 18 and moved out or died between the 1968 and 1969 interviews.'
         9 = 'This individual had not been born or moved in by the time of the 1969 interview (ER30020>0 and ER30021=0); individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        10 = 'This spouse had moved out and not returned or died by the time of the 1968 interview (ER30002=228 or ER30002=227 and ER30020=0)'
        99 = 'NA; DK'
         0 = 'Inap.:  in a panel family in 1969 (ER30021=1-20)'
   ;
   VALUE ER30041F
         1 = 'Wave refusal by all eligible/available FU members.'
         2 = 'No-one at home for contact during the interviewing period'
         3 = 'Respondent absent; some FU member contacted, but not the appropriate respondent.'
         4 = 'Lost; unable to locate any member of the FU at all.'
         5 = 'FU is located too far away for interviewer contact.'
        11 = 'This individual was in the armed forces.'
        12 = 'This individual was in an educational institution.'
        13 = 'This individual was in a health care facility.'
        14 = 'This individual was in jail or prison.'
        19 = 'This individual was in some other type of institution, for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        21 = 'This individual was not eligible for the interview and the Head or the Wife, whichever is the sample member, became main family nonresponse because he/she was institutionalized by joining the armed fo'
             'rces.'
        22 = 'This individual was not eligible for the interview and the Head or Wife, whichever is sample, became main family nonresponse because he/she was institutionalized by entering an educational institution'
             '.'
        23 = 'This individual was not eligible for the interview and the Head or Wife, whichever is the sample member, became main family nonresponse because he/she was institutionalized by entering a health care f'
             'acility.'
        24 = 'This individual was not eligible for the interview and the Head or Wife, whichever is the sample member, became main family nonresponse because he/she was imprisoned.'
        29 = 'This individual was not eligible for the interview and the Head or Wife, whichever is sample, became main family nonresponse because he/she was institutionalized by some means other than the above; fo'
             'r example, he/she may have entered a religious order. Cases in which the type of institution is unknown are included here, also.'
        31 = 'This individual was unable to cooperate through disability.'
        32 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, was unable to cooperate through disability.'
        41 = 'This individual died between the 1968 and 1969 interviews.'
        42 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, died.'
        51 = 'This individual, although followed for interview, was discovered to be nonsample: office error.'
        52 = 'This individual should have been followed but was not: office error.'
        53 = 'This individual was mistakenly included in two or more response families at once; this record is the duplicate, or erroneous, one.'
        54 = 'Listing error: this individual never existed or was not really living in the FU.'
        59 = 'Other office error'
        91 = 'This sample individual moved out of the 1969 main family and was eligible for interviewing but the reason for nonresponse is NA.'
        92 = 'This sample individual was not eligible for interviewing at the time he/she moved out because he/she was too young to be followed.'
        93 = 'The Head or Wife of this FU, whichever is sample, united with another FU; this individual was not eligible for the interview and therefore became nonresponse.'
        97 = 'This individual had not been born or moved in by the time of the 1969 interview (ER30020>0 and ER30021=0); individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        98 = 'This spouse had moved out and not returned or died in the year preceding the 1968 interview (ER30002=228 or ER30002=227 and ER30020=0)'
        99 = 'NA; DK'
         0 = 'Inap.:  in a panel family in 1969 (ER30021=1-20)'
   ;
   VALUE ER30044F
    1 - 20 = 'Individuals in the family at the time of the 1970 interview'
   51 - 59 = 'Individuals in institutions at the time of the 1970 interview'
   71 - 80 = 'Individuals who moved out of the FU or out of institutions between the 1969 and 1970 interviews but who were not included in another responding FU for 1970. All such individuals were nonresponse.'
   81 - 89 = 'Individuals who were living in 1969 but who died by the time of the 1970 interview'
         0 = 'Inap.:  born or moved in after the 1970 interview; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1970 or mover-out nonresponse by 1969 (ER30043=0'
             ')'
   ;
   VALUE ER30045F
         1 = 'Head in 1970; 1969 Head who was mover-out nonresponse by the time of the 1970 interview'
         2 = 'Wife in 1970; 1969 Wife who was mover-out nonresponse by the time of the 1970 interview'
         3 = 'Child, stepchild'
         4 = 'Sibling'
         5 = 'Parent'
         6 = 'Grandchild, great-grandchild'
         7 = 'In-law or other relative'
         8 = 'Nonrelative'
         9 = 'Husband of Head'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1970 interview (ER30043>0 and ER30044=0); main family nonresponse by 1970 or mover-out nonr'
             'esponse by 1969 (ER30043=0)'
   ;
   VALUE ER30047F
         1 = 'Spouse in couple numbered 1'
         2 = 'Spouse in couple numbered 2'
         3 = 'Spouse in couple numbered 3'
         0 = 'Inap.:  not married; spouse was not in FU in 1970; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1970 interview (ER30043>0 and ER30044=0); main f'
             'amily nonresponse by 1970 or mover-out nonresponse in 1969 (ER30043=0)'
   ;
   VALUE ER30048F
         1 = 'Moved in or born between 1969 and 1970 interviews; splitoff in 1970'
         2 = 'Appeared; moved in by the time the 1969 interview was taken but not included in FU on previous interviews (usually a listing error)'
         5 = 'Moved out of FU or institution between the 1969 and 1970 interviews and was not included in a 1970 panel FU'
         6 = 'Moved out of FU and into an institution between the 1969 and 1970 interviews'
         7 = 'Living in 1969 but died by the time of the 1970 interview'
         8 = 'Disappeared; moved out prior to the 1969 interview but included in FU for 1969'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); in main family in both 1969 and 1970 (ER30021=1-20 and ER30044=1-20); in an institution in both 1969 and 1970 (ER30021'
             '=51-59 and ER30044=51-59); born or moved in after the 1970 interview (ER30043>0 and ER30044=0); main family nonresponse by 1970 or mover-out nonresponse by 1969 (ER30043=0)'
   ;
   VALUE ER30051F
         1 = 'Yes, stopped going to school'
         5 = 'No, did not stop; was age 25 or older (ER30046=025-999)'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1970 interview (ER30043>0 and ER30044=0); main family nonresponse by 1970 or mover-out nonr'
             'esponse by 1969 (ER30043=0)'
   ;
   VALUE ER30052F
    1 - 17 = 'Highest grade or year of school completed'
        99 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1970 interview (ER30043>0 and ER30044=0); main family nonresponse by 1970 or mover-out nonr'
             'esponse by 1969 (ER30043=0); Head or Wife in 1970 (ER30044=1-20 and ER30045=1 or 02); did not stop school or individual was age 25 or older (ER30051=5 or 9)'
   ;
   VALUE ER30053F
    1 - 97 = 'Actual hours spent'
        98 = 'Ninety-eight hours or more'
        99 = 'NA; DK'
         0 = 'Inap.:  none; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1970 interview (ER30043>0 and ER30044=0); main family nonresponse by 1970 or mover-ou'
             't nonresponse by 1969 (ER30043=0); in an institution at time of 1970 interview or mover-out nonresponse from 1970 (ER30044=51-89)'
   ;
   VALUE ER30054F
         1 = 'Yes, is disabled'
         2 = 'Yes, requires extra care'
         5 = 'No; in an institution at time of 1970 interview or mover-out nonresponse from 1970 (ER30044=51-89)'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1970 interview (ER30043>0 and ER30044=0); main family nonresponse by 1970 or mover-out nonr'
             'esponse by 1969 (ER30043=0)'
   ;
   VALUE ER30055F
         1 = 'This individual was respondent'
         5 = 'This individual was not respondent; includes institutionalized individuals and mover-out nonresponse from 1970 (ER30044=51-89)'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1970 interview (ER30043>0 and ER30044=0); main family response by 1970 or mover-out nonresp'
             'onse by 1969 (ER30043=0)'
   ;
   VALUE ER30056F
         1 = 'Labor income only'
         2 = 'Transfer income only'
         3 = 'Asset income only'
         4 = 'Combination of labor, transfer and/or asset'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); no income; born or moved in after the 1970 interview (ER30043>0 and ER30044=0); main family nonresponse by 1970 or mov'
             'er-out nonresponse by 1969 (ER30043=0); in institution in both 1969 and 1970 (ER30044=51-59 and ER30048=0)'
   ;
   VALUE ER30059F
         1 = 'Yes, unqualified'
         3 = 'Yes, qualified; a little; less than $10 per week; sometimes'
         5 = 'No'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); Head or Wife in 1970 (ER30044=1-20 and ER30045=1 or 02); born or moved in after the 1970 interview (ER30043>0 and ER30'
             '044=0); main family nonresponse by 1970 or mover-out nonresponse by 1969 (ER30043=0); in institution in both 1969 and 1970 (ER30044=51-59 and ER30048=0); no income (ER30056=0)'
   ;
   VALUE ER30064F
         1 = 'This sample member was 18 years old or older at the time of main family nonresponse and had been in the FU in 1969.'
         2 = 'This sample member was less than 18 at the time of main family nonresponse and had been in the FU in 1969.'
         3 = 'This nonsample individual had been in the 1969 FU, and this FU became nonresponse in 1970.'
         4 = 'This sample member had been in an institution in 1969 but his or her main family became nonresponse in 1970.'
         5 = 'This sample member, although connected with a 1970 response family, was in an institution at the time of the 1970 interview.'
         6 = 'This sample member was 18 years old or older and moved out or died between the 1969 and 1970 interviews.'
         7 = 'This sample member was less than 18 and moved out or died between the 1969 and 1970 interviews.'
         8 = 'This nonsample individual moved out or died between the 1969 and 1970 interviews.'
         9 = 'This individual had not been born or moved in for the first time by the time of the 1970 interview; individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        10 = 'This individual had become nonresponse by the time of the 1969 interview'
        99 = 'NA; DK'
         0 = 'Inap.:  in a panel family in 1970 (ER30044=1-20)'
   ;
   VALUE ER30065F
         1 = 'Wave refusal by all eligible/available FU members.'
         2 = 'No-one at home for contact during the interviewing period.'
         3 = 'Respondent absent; some FU member contacted, but not the appropriate respondent.'
         4 = 'Lost; unable to locate any member of the FU at all.'
         5 = 'FU is located too far away for interviewer contact.'
        11 = 'This individual was in the armed forces.'
        12 = 'This individual was in an educational institution.'
        13 = 'This individual was in a health care facility'
        14 = 'This individual was in jail or prison'
        19 = 'This individual was in some other type of institution, for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        21 = 'This individual was not eligible for the interview and the Head or the Wife, whichever is the sample member, became main family nonresponse because he/she was institutionalized by joining the armed fo'
             'rces.'
        22 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by entering an educational institution.'
        23 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized by entering a health care facil'
             'ity.'
        24 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized through imprisonment.'
        29 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by some means other than the above; for ex'
             'ample, he/she may have entered a religious order. Cases in which the type of institution is unknown are included here, also.'
        31 = 'This individual was unable to cooperate through disability.'
        32 = 'This individual was not eligible for the interview and the Head or Wife, whichever is sample, was unable to cooperate through disability.'
        41 = 'This individual died between the 1969 and 1970 interviews.'
        42 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, died.'
        51 = 'This individual, although followed for interview, was discovered to be nonsample: office error.'
        52 = 'This individual should have been followed but was not: office error.'
        53 = 'This individual was mistakenly included in two or more response families at once; this record is the duplicate, or erroneous, one.'
        54 = 'Listing error: this individual never existed or was not really living in the FU.'
        59 = 'Other office error'
        91 = 'This sample individual moved out of the 1970 main family and was eligible for interviewing but the reason for nonresponse is NA.'
        92 = 'Individual moved out of the 1970 main family and was not eligible for interviewing because he/she was either nonsample or too young.'
        93 = 'The Head or Wife of this FU, whichever is sample, united with another FU; this individual was not eligible for the interview and therefore became nonresponse.'
        97 = 'This individual had not been born or moved in by the time of the 1970 interview (ER30043>0 and ER30044=0); individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        98 = 'This individual became main family or mover-out nonresponse by 1969 (ER30020=0 and ER30043=0 or ER30020>0 and ER30021=71-89 and ER30043=0)'
        99 = 'NA; DK'
         0 = 'Inap.:  in a panel family in 1970 (ER30044=1-20)'
   ;
   VALUE ER30068F
    1 - 20 = 'Individuals in the family at the time of the 1971 interview'
   51 - 59 = 'Individuals in institutions at the time of the 1971 interview'
   71 - 80 = 'Individuals who moved out of the FU or out of institutions between the 1970 and 1971 interviews but who were not included in another responding FU for 1971. All such individuals were nonresponse.'
   81 - 89 = 'Individuals who were living in 1970 but died by the time of the 1971 interview'
         0 = 'Inap.:  born or moved in after the 1971 interview; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1971 or mover-out nonresponse by 1970 (ER30067=0'
             ')'
   ;
   VALUE ER30069F
         1 = 'Head in 1971; 1970 Head who was mover-out nonresponse by the time of the 1971 interview'
         2 = 'Wife in 1971; 1970 Wife who was mover-out nonresponse by the time of the 1971 interview'
         3 = 'Child, stepchild'
         4 = 'Sibling'
         5 = 'Parent'
         6 = 'Grandchild, great-grandchild'
         7 = 'In-law or other relative'
         8 = 'Nonrelative'
         9 = 'Husband of Head (i.e., Wife was Head of family)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1971 interview (ER30067>0 and ER30068=0); main family nonresponse by 1971 or mover-out nonr'
             'esponse by 1970 (ER30067=0)'
   ;
   VALUE ER30071F
         1 = 'Spouse in couple numbered 1'
         2 = 'Spouse in couple numbered 2'
         3 = 'Spouse in couple numbered 3'
         0 = 'Inap.:  not married; spouse was not in FU in 1971; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1971 interview (ER30067>0 and ER30068=0); main f'
             'amily nonresponse by 1971 or mover-out nonresponse by 1970 (ER30067=0)'
   ;
   VALUE ER30072F
         1 = 'Moved in or born between the 1970 and 1971 interviews; splitoff in 1971'
         2 = 'Appeared; moved in by the time the 1970 interview was taken but not included in FU on previous interviews (usually a listing error)'
         5 = 'Moved out of FU or institution between 1970 and 1971 interviews and was not included in a 1971 panel FU'
         6 = 'Moved out of FU and into an institution between the 1970 and 1971 interviews'
         7 = 'Living in 1970 but died by the time of the 1971 interview'
         8 = 'Disappeared; moved out prior to the 1970 interview but included in FU for 1970 (usually a listing error)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); in main family in both 1970 and 1971 (ER30044=1-20 and ER30068=1-20); in an institution in both 1970 and 1971 (ER30044'
             '=51-59 and ER30068=51-59); born or moved in after the 1971 interview (ER30067>0 and ER30068=0); main family nonresponse by 1971 or mover-out nonresponse by 1970 (ER30067=0)'
   ;
   VALUE ER30075F
         1 = 'Yes, stopped going to school'
         5 = 'No, did not stop; was age 25 or older (ER30069=025-999)'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1971 interview (ER30067>0 and ER30068=0); main family nonresponse by 1971 or mover-out nonr'
             'esponse by 1970 (ER30067=0)'
   ;
   VALUE ER30076F
    1 - 17 = 'Highest grade or year of school completed'
        99 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1971 interview (ER30067>0 and ER30068=0); main family nonresponse by 1971 or mover-out nonr'
             'esponse by 1970 (ER30067=0); Head or Wife in 1971 (ER30068=1-20 and ER30069=1 or 02); did not stop school or individual was age 25 or older (ER30075=5 or 9)'
   ;
   VALUE ER30077F
    1 - 97 = 'Actual hours spent'
        98 = 'Ninety-eight hours or more'
        99 = 'NA; DK'
         0 = 'Inap.:  none; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1971 interview (ER30067>0 and ER30068=0); main family nonresponse by 1971 or mover-ou'
             't nonresponse by 1970 (ER30067=0); in an institution at time of 1971 interview or mover-out nonresponse from 1971 (ER30068=51-89)'
   ;
   VALUE ER30078F
         1 = 'Yes, is disabled'
         2 = 'Yes, requires extra care'
         5 = 'No; in an institution at time of 1971 interview or mover-out nonresponse from 1971 (ER30068=51-89)'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1971 interview (ER30067>0 and ER30068=0); main family nonresponse by 1971 or mover-out nonr'
             'esponse by 1970 (ER30067=0)'
   ;
   VALUE ER30079F
         1 = 'This individual was respondent'
         5 = 'This individual was not respondent; includes institutionalized individuals and mover-out nonresponse from 1971 (ER30068=51-89)'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1971 interview (ER30067>0 and ER30068=0); main family nonresponse by 1971 or mover-out nonr'
             'esponse by 1970 (ER30067=0)'
   ;
   VALUE ER30080F
         1 = 'Labor income only'
         2 = 'Transfer income only'
         3 = 'Asset income only'
         4 = 'Combination including labor income'
         5 = 'Combination excluding labor income'
         9 = 'NA; DK'
         0 = 'Inap.:  no income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1971 interview (ER30067>0 and ER30068=0); main family nonresponse by 1971 or mov'
             'er-out nonresponse by 1970 (ER30067=0); in an institution in both 1970 and 1971 (ER30068=51-59 and ER30072=0)'
   ;
   VALUE ER30083F
         1 = 'Yes, unqualified'
         3 = 'Yes, qualified (a little; less than $10 per week; sometimes)'
         5 = 'No'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); Head or Wife in 1971 (ER30068=1-20 and ER30069=1 or 02); born or moved in after the 1971 interview (ER30067>0 and ER30'
             '068=0); main family nonresponse by 1971 or mover-out nonresponse by 1970 (ER30067=0); in an institution in both 1970 and 1971 (ER30068=51-59 and ER30072=0); no income (ER30080=0)'
   ;
   VALUE ER30088F
         1 = 'This sample member was 18 years old or older at the time of main family nonresponse and had been in the FU in 1970.'
         2 = 'This sample member was less than 18 at the time of main family nonresponse and had been in the FU in 1970.'
         3 = 'This nonsample individual had been in the 1970 FU, and this FU became nonresponse in 1971.'
         4 = 'This sample member had been in an institution in 1970 but his or her main family became nonresponse in 1971.'
         5 = 'This sample member, although connected with a 1971 response family, was in an institution at the time of the 1971 interview.'
         6 = 'This sample individual was 18 years old or older and moved out or died between the 1970 and 1971 interviews.'
         7 = 'This sample member was less than 18 and moved out or died between the 1970 and 1971 interviews.'
         8 = 'This nonsample individual moved out or died between the 1970 and 1971 interviews.'
         9 = 'This individual had not been born or moved in by the time of the 1971 interview; individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        10 = 'This individual had become nonresponse by the time of the 1970 interview.'
        99 = 'NA; DK'
         0 = 'Inap.:  in a panel family in 1971 (ER30068=1-20).'
   ;
   VALUE ER30089F
         1 = 'Wave refusal by all eligible/available FU members.'
         2 = 'No-one at home for contact during the interviewing period.'
         3 = 'Respondent absent; some FU member contacted, but not the appropriate respondent.'
         4 = 'Lost; unable to locate any member of the FU at all.'
         5 = 'FU is located too far away for interviewer contact.'
        11 = 'This individual was in the armed forces.'
        12 = 'This individual was in an educational institution.'
        13 = 'This individual was in a health care facility'
        14 = 'This individual was in jail or prison'
        19 = 'This individual was in some other type of institution, for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        21 = 'This individual was not eligible for the interview and the Head or the Wife, whichever is the sample member, became main family nonresponse because he/she was institutionalized by joining the armed fo'
             'rces.'
        22 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by entering an educational institution.'
        23 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized by entering a health care facil'
             'ity.'
        24 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized through imprisonment.'
        29 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by some means other than the above; for ex'
             'ample, he/she may have entered a religious order. Cases in which the type of institution is unknown are included here, also.'
        31 = 'This individual was unable to cooperate through disability.'
        32 = 'This individual was not eligible for the interview and the Head or Wife, whichever is sample, was unable to cooperate through disability.'
        41 = 'This individual died between the 1970 and 1971 interviews.'
        42 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, died.'
        51 = 'This individual, although followed for interview, was discovered to be nonsample: office error.'
        52 = 'This individual should have been followed but was not: office error.'
        53 = 'This individual was mistakenly included in two or more response families at once; this record is the duplicate, or erroneous, one.'
        54 = 'Listing error: this individual never existed or was not really living in the FU.'
        59 = 'Other office error'
        91 = 'This sample individual moved out of the 1971 main family and was eligible for interviewing but the reason for nonresponse is NA.'
        92 = 'Individual moved out of the 1971 main family and was not eligible for interviewing because he/she was either nonsample or too young.'
        93 = 'The Head or Wife of this FU, whichever is sample, united with another FU; this individual was not eligible for the interview and therefore became nonresponse.'
        97 = 'This individual had not been born or moved in by the time of the 1971 interview (ER30067>0 and ER30068=0); individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        98 = 'This individual became main family or mover-out nonresponse by 1970 (ER30043=0 and ER30067=0 or ER30043>0 and ER30044=71-89 and ER30066=0)'
        99 = 'NA; DK'
         0 = 'Inap.:  in a panel family in 1971 (ER30068=1-20).'
   ;
   VALUE ER30092F
    1 - 20 = 'Individuals in the family at the time of the 1972 interview'
   51 - 59 = 'Individuals in institutions at the time of the 1972 interview'
   71 - 80 = 'Individuals who moved out of the FU or out of institutions between the 1971 and 1972 interviews but who were not included in another responding FU for 1972. All such individuals were nonresponse.'
   81 - 89 = 'Individuals who were living in 1971 but who died by the time of the 1972 interview'
         0 = 'Inap.:  born or moved in after the 1972 interview; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1972 or mover-out nonresponse by 1971 (ER30091=0'
             ')'
   ;
   VALUE ER30093F
         1 = 'Head in 1972; 1971 Head who was mover-out nonresponse by the time of the 1972 interview'
         2 = 'Wife in 1972; 1971 Wife who was mover-out nonresponse by the time of the 1972 interview'
         3 = 'Child, stepchild'
         4 = 'Sibling'
         5 = 'Parent'
         6 = 'Grandchild or great-grandchild'
         7 = 'Other relative; includes in-laws'
         8 = 'Nonrelative'
         9 = 'Husband of Head (i.e., Wife was Head of the family)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1972 interview (ER30091>0 and ER30092=0); main family nonresponse by 1972 or mover-out nonr'
             'esponse by 1971 (ER30091=0)'
   ;
   VALUE ER30095F
         1 = 'Spouse in couple numbered 1'
         0 = 'Inap.:  not married; spouse was not in FU in 1972; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1972 interview (ER30091>0 and ER30092=0); main f'
             'amily nonresponse by 1972 or mover-out nonresponse by 1971 (ER30091=0)'
   ;
   VALUE ER30096F
         1 = 'Moved in or born between the 1971 and 1972 interviews; splitoff in 1972'
         2 = 'Appeared; moved in by the time the 1971 interview was taken but not included in FU on previous interviews'
         5 = 'Moved out of FU or institution between 1971 and 1972 interviews and was not included in a 1972 panel FU'
         6 = 'Moved out of FU and into an institution between the 1971 and 1972 interviews'
         7 = 'Living in 1971 but died by the time of the 1972 interview'
         8 = 'Disappeared; moved out prior to the 1971 interview, but included in FU for 1971 (usually a listing error)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); in main family in both 1971 and 1972 (ER30068=1-20 and ER30092=1-20); in an institution in both 1971 and 1972 (ER30068'
             '=51-59 and ER30092=51-59); born or moved in after the 1972 interview (ER30091>0 and ER30092=0); main family nonresponse by 1972 or mover-out nonresponse by 1971 (ER30091=0)'
   ;
   VALUE ER30099F
         1 = 'Yes, stopped going to school'
         5 = 'No, did not stop; was age 25 or older (ER30094=025-999); Head or Wife in 1972 (ER30092=1-20 and ER30093=1 or 02)'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1972 interview (ER30091>0 and ER30092=0); main family nonresponse by 1972 or mover-out nonr'
             'esponse by 1971 (ER30091=0)'
   ;
   VALUE ER30100F
    1 - 17 = 'Highest grade or year of school completed'
        99 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1972 interview (ER30091>0 and ER30092=0); main family nonresponse by 1972 or mover-out nonr'
             'esponse by 1971 (ER30091=0); Head or Wife in 1972 (ER30092=1-20 and ER30093=1 or 02); did not stop school or individual was age 25 or older (ER30099=5 or 9)'
   ;
   VALUE ER30101F
         1 = 'Yes, this person did some of the work'
         5 = 'No, this person did not do any of the work; in an institution in 1971 and 1972 (ER30092=51-59 and ER30096=0)'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1972 interview (ER30091>0 and ER30092=0); main family nonresponse by 1972 or mover-out nonr'
             'esponse by 1971 (ER30091=0)'
   ;
   VALUE ER30102F
    1 - 97 = 'Actual hours spent'
        98 = 'Ninety-eight hours per week or more'
        99 = 'NA; DK'
         0 = 'Inap.:  none; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1972 or mover-out nonresponse by 1971 (ER30091=0); individual who was born or moved i'
             'n after the 1972 interview (ER30091>0 and ER30092=0); in an institution at time of 1972 interview or mover-out nonresponse from 1972 (ER30092=51-89)'
   ;
   VALUE ER30103F
         1 = 'Yes, is disabled'
         2 = 'Yes, requires extra care'
         5 = 'No, is neither disabled nor requires extra care; in an institution at time of 1972 interview or mover-out nonresponse from 1972 (ER30092=51-89)'
         9 = 'NA; DK'
         0 = 'Inap; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1972 interview (ER30091>0 and ER30092=0); main family nonresponse by 1972 or mover-out nonres'
             'ponse by 1971 (ER30091=0)'
   ;
   VALUE ER30104F
         1 = 'This individual was respondent'
         5 = 'This individual was not respondent; includes institutionalized individuals and mover-out nonresponse from 1972 (ER30092=51-89)'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1972 interview (ER30091>0 and ER30092=0); main family nonresponse by 1972 or mover-out nonr'
             'esponse by 1971 (ER30091=0)'
   ;
   VALUE ER30105F
         1 = 'Labor income only'
         2 = 'Transfer income only'
         3 = 'Asset income only'
         4 = 'Combination including labor'
         5 = 'Combination excluding labor income'
         9 = 'NA; DK'
         0 = 'Inap.:  no income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1972 interview (ER30091>0 and ER30092=0); main family nonresponse by 1972 or mov'
             'er-out nonresponse by 1971 (ER30091=0); in an institution in both 1971 and 1972 (ER30092=51-59 and ER30096=0)'
   ;
   VALUE ER30108F
         1 = 'Yes, unqualified'
         3 = 'Yes, qualified (a little, less than $10 a week, sometimes)'
         5 = 'No'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); Head or Wife in 1972 (ER30092=1-20 and ER30093=1 or 02); born or moved in after the 1972 interview (ER30091>0 and ER30'
             '092=0); main family nonresponse by 1972 or mover-out nonresponse by 1971 (ER30091=0); in an institution in both 1971 and 1972 (ER30092=51-59 and ER30096=0); no income (ER30105=0)'
   ;
   VALUE ER30110F
    1 - 17 = 'Actual grade completed'
        98 = 'Still in school'
        99 = 'NA; DK; either not in a 1968 family and has never stopped school or preschool age in 1968 and has never stopped school'
         0 = 'No education; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1972 interview (ER30091>0 and ER30092=0); main family nonresponse by 1972 or mover-ou'
             't nonresponse by 1971 (ER30091=0)'
   ;
   VALUE ER30114F
         1 = 'This sample member was 18 years old or older at the time of main family nonresponse and had been in the FU in 1971.'
         2 = 'This sample member was less than 18 at the time of main family nonresponse and had been in the FU in 1971.'
         3 = 'This nonsample individual had been in the 1971 FU, and this FU became nonresponse in 1972.'
         4 = 'This sample member had been in an institution in 1971 but his or her main family became nonresponse in 1972.'
         5 = 'This sample member, although connected with a 1972 response family, was in an institution at the time of the 1972 interview.'
         6 = 'This sample individual was 18 years old or older and moved out or died between the 1971 and 1972 interviews.'
         7 = 'This sample member was less than 18 and moved out or died between the 1971 and 1972 interviews.'
         8 = 'This nonsample individual moved out or died between the 1971 and 1972 interviews.'
         9 = 'This individual had not been born or moved in by the time of the 1972 interview; individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        10 = 'This individual had become nonresponse by the time of the 1971 interview.'
        99 = 'NA; DK'
         0 = 'Inap.:  in a panel family in 1972 (ER30092=1-20).'
   ;
   VALUE ER30115F
         1 = 'Wave refusal by all eligible/available FU members.'
         2 = 'No-one at home for contact during the interviewing period.'
         3 = 'Respondent absent; some FU member contacted, but not the appropriate respondent.'
         4 = 'Lost; unable to locate any member of the FU at all.'
         5 = 'FU is located too far away for interviewer contact.'
        11 = 'This individual was in the armed forces.'
        12 = 'This individual was in an educational institution.'
        13 = 'This individual was in a health care facility'
        14 = 'This individual was in jail or prison'
        19 = 'This individual was in some other type of institution, for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        21 = 'This individual was not eligible for the interview and the Head or the Wife, whichever is the sample member, became main family nonresponse because he/she was institutionalized by joining the armed fo'
             'rces.'
        22 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by entering an educational institution.'
        23 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized by entering a health care facil'
             'ity.'
        24 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized through imprisonment.'
        29 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by some means other than the above; for ex'
             'ample, he/she may have entered a religious order. Cases in which the type of institution is unknown are included here, also.'
        31 = 'This individual was unable to cooperate through disability.'
        32 = 'This individual was not eligible for the interview and the Head or Wife, whichever is sample, was unable to cooperate through disability.'
        41 = 'This individual died between the 1971 and 1972 interviews.'
        42 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, died.'
        51 = 'This individual, although followed for interview, was discovered to be nonsample: office error.'
        52 = 'This individual should have been followed but was not: office error.'
        53 = 'This individual was mistakenly included in two or more response families at once; this record is the duplicate, or erroneous, one.'
        54 = 'Listing error: this individual never existed or was not really living in the FU.'
        59 = 'Other office error'
        91 = 'This sample individual moved out of the 1972 main family and was eligible for interviewing but the reason for nonresponse is NA.'
        92 = 'Individual moved out of the 1972 main family and was not eligible for interviewing because he/she was either nonsample or too young.'
        93 = 'The Head or Wife of this FU, whichever is sample, united with another FU; this individual was not eligible for the interview and therefore became nonresponse.'
        97 = 'This individual had not been born or moved in by the time of the 1972 interview (ER30091>0 and ER30092=0); individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        98 = 'This individual became main family or mover-out nonresponse by 1971 (ER30067=0 and ER30091=0 or ER30067>0 and ER30068=71-89 and ER30091=0)'
        99 = 'NA; DK'
         0 = 'Inap.:  in a panel family in 1972 (ER30092=1-20)'
   ;
   VALUE ER30118F
    1 - 20 = 'Individuals in FU at the time of the 1973 interview'
   51 - 59 = 'Individuals in institutions at the time of the 1973 interview'
   71 - 80 = 'Individuals who moved out of the FU or out of institutions between the 1972 and 1973 interviews but who were not included in another responding FU for 1973. All such individuals were nonresponse.'
   81 - 89 = 'Individuals who were living in 1972 but who died by the time of the 1973 interview'
         0 = 'Inap.:  born or moved in after the 1973 interview; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1973 or mover-out nonresponse by 1972 (ER30117=0'
             ')'
   ;
   VALUE ER30119F
         1 = 'Head in 1973; 1972 Head who was mover-out nonresponse by the time of the 1973 interview'
         2 = 'Wife in 1973; 1972 Wife who was mover-out nonresponse by the time of the 1973 interview'
         3 = 'Son or daughter; includes stepchildren or adopted children'
         4 = 'Brother or sister of Head'
         5 = 'Father or mother of Head'
         6 = 'Grandchild or great-grandchild'
         7 = 'Other relative; includes in-laws'
         8 = 'Nonrelative'
         9 = 'Husband of Head (i.e., Wife was Head of FU)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1973 interview (ER30117>0 and ER30118=0); main family nonresponse by 1973 or mover-out nonr'
             'esponse by 1972 (ER30117=0)'
   ;
   VALUE ER30121F
         1 = 'Spouse in couple numbered 1'
         2 = 'Spouse in couple numbered 2'
         3 = 'Spouse in couple numbered 3'
         0 = 'Inap.:  not married; spouse was not in FU in 1973; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1973 interview (ER30117>0 and ER30118=0); main f'
             'amily nonresponse by 1973 or mover-out nonresponse by 1972 (ER30117=0)'
   ;
   VALUE ER30122F
         1 = 'Moved in or born between the 1972 and 1973 interviews; splitoff in 1973'
         2 = 'Appeared; moved in by the time the 1972 interview was taken but not included in FU in 1972 (i.e., listing mistake)'
         5 = 'Moved out of FU or out of an institution between the 1972 and 1973 interviews and was not included in a 1973 panel FU'
         6 = 'Moved out of FU and into an institution between the 1972 and 1973 interviews'
         7 = 'Living in 1972 but died by the time of the 1973 interview'
         8 = 'Disappeared; moved out prior to the 1972 interview, but included in FU for 1972 (usually a listing error)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); in main family in both 1972 and 1973 (ER30092=1-20 and ER30118=1-20); in an institution in both 1972 and 1973 (ER30092'
             '=51-59 and ER30118=51-59); born or moved in after the 1973 interview (ER30117>0 and ER30118=0); main family nonresponse by 1973 or mover-out nonresponse by 1972 (ER30117=0)'
   ;
   VALUE ER30125F
         1 = 'Yes, this person under 25 stopped going to school'
         5 = 'No, did not stop; age 25 or over (ER30120=025-999); Head or Wife in 1973 (ER30118=1-20 and ER30119=1 or 02)'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1973 interview (ER30117>0 and ER30118=0); main family nonresponse by 1973 or mover-out nonr'
             'esponse by 1972 (ER30117=0)'
   ;
   VALUE ER30126F
    1 - 17 = 'Highest grade or year of school completed'
        99 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1973 or mover-out nonresponse by 1972 (ER30117=0); Head or Wife in 1973 (ER30118=1-20 and E'
             'R30119=1 or 02); born or moved in after the 1973 interview (ER30117>0 and ER30118=0); did not stop school or individual was age 25 or older (ER30125=5 or 9)'
   ;
   VALUE ER30127F
    1 - 97 = 'Actual hours spent'
        98 = 'Ninety-eight hours per week or more'
        99 = 'NA; DK'
         0 = 'Inap.:  none; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1973 interview (ER30117>0 and ER30118=0); main family nonresponse by 1973 or mover-ou'
             't nonresponse by 1972 (ER30117=0); in an institution at time of 1973 interview or mover-out nonresponse from 1973 (ER30118=51-89)'
   ;
   VALUE ER30128F
         1 = 'This individual was respondent'
         5 = 'This individual was not respondent; includes institutionalized individuals and mover-out nonresponse from 1973 (ER30118=51-89)'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1973 interview (ER30117>0 and ER30118=0); main family nonresponse by 1973 or mover-out nonr'
             'esponse by 1972 (ER30117=0)'
   ;
   VALUE ER30129F
         1 = 'Labor income only'
         2 = 'Transfer income only'
         3 = 'Asset income only'
         4 = 'Combination including labor income'
         5 = 'Combination excluding labor income'
         9 = 'NA; DK'
         0 = 'Inap.:  no income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1973 interview (ER30117>0 and ER30118=0); main family nonresponse by 1973 or mov'
             'er-out nonresponse by 1972 (ER30117=0); in an institution in both 1972 and 1973 (ER30118=51-59 and ER30122=0)'
   ;
   VALUE ER30135F
         1 = 'This sample member was 18 years old or older at the time of main family nonresponse and had been in the FU in 1972.'
         2 = 'This sample member was less than 18 at the time of main family nonresponse and had been in the FU in 1972.'
         3 = 'This nonsample individual had been in the 1972 FU, and this FU became nonresponse in 1973.'
         4 = 'This sample member had been in an institution in 1972 but his or her main family became nonresponse in 1973.'
         5 = 'This sample member, although connected with a 1973 response family, was in an institution at the time of the 1973 interview.'
         6 = 'This sample individual was 18 years old or older and moved out or died between the 1972 and 1973 interviews.'
         7 = 'This sample member was less than 18 and moved out or died between the 1972 and 1973 interviews.'
         8 = 'This nonsample individual moved out or died between the 1972 and 1973 interviews.'
         9 = 'This individual had not been born or moved in by the time of the 1973 interview; individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        10 = 'This individual had become nonresponse by the time of the 1972 interview.'
        99 = 'NA; DK'
         0 = 'Inap.:  in a panel family in 1973 (ER30118=1-20).'
   ;
   VALUE ER30136F
         1 = 'Wave refusal by all eligible/available FU members.'
         2 = 'No-one at home for contact during the interviewing period.'
         3 = 'Respondent absent; some FU member contacted, but not the appropriate respondent.'
         4 = 'Lost; unable to locate any member of the FU at all.'
         5 = 'FU is located too far away for interviewer contact.'
        11 = 'This individual was in the armed forces.'
        12 = 'This individual was in an educational institution.'
        13 = 'This individual was in a health care facility'
        14 = 'This individual was in jail or prison'
        19 = 'This individual was in some other type of institution, for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        21 = 'This individual was not eligible for the interview and the Head or the Wife, whichever is the sample member, became main family nonresponse because he/she was institutionalized by joining the armed fo'
             'rces.'
        22 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by entering an educational institution.'
        23 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized by entering a health care facil'
             'ity.'
        24 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized through imprisonment.'
        29 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by some means other than the above; for ex'
             'ample, he/she may have entered a religious order. Cases in which the type of institution is unknown are included here, also.'
        31 = 'This individual was unable to cooperate through disability.'
        32 = 'This individual was not eligible for the interview and the Head or Wife, whichever is sample, was unable to cooperate through disability.'
        41 = 'This individual died between the 1972 and 1973 interviews.'
        42 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, died.'
        51 = 'This individual, although followed for interview, was discovered to be nonsample: office error.'
        52 = 'This individual should have been followed but was not: office error.'
        53 = 'This individual was mistakenly included in two or more response families at once; this record is the duplicate, or erroneous, one.'
        54 = 'Listing error: this individual never existed or was not really living in the FU.'
        59 = 'Other office error'
        91 = 'This sample individual moved out of the 1973 main family and was eligible for interviewing but the reason for nonresponse is NA.'
        92 = 'Individual moved out of the 1973 main family and was not eligible for interviewing because he/she was either nonsample or too young.'
        93 = 'The Head or Wife of this FU, whichever is sample, united with another FU; this individual was not eligible for the interview and therefore became nonresponse.'
        97 = 'This individual had not been born or moved in by the time of the 1973 interview (ER30117>0 and ER30118=0); individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        98 = 'This individual became main family or mover-out nonresponse by 1972 (ER30091=0 and ER30117=0 or ER30091>0 and ER30092=71-89 and ER30117=0)'
        99 = 'NA; DK'
         0 = 'Inap.:  in a panel family in 1973 (ER30118=1-20)'
   ;
   VALUE ER30139F
    1 - 20 = 'Individuals in FU at the time of 1974 interview'
   51 - 59 = 'Individuals in institutions at the time of the 1974 interview'
   71 - 80 = 'Individuals who moved out of the FU or out of institutions between the 1973 and 1974 interviews but who were not included in another responding FU for 1974. All such individuals were nonresponse.'
   81 - 89 = 'Individuals who were living in 1973 but who died by the time of the 1974 interview'
         0 = 'Inap.:  born or moved in after the 1974 interview; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1974 or mover-out nonresponse by 1973 (ER30138=0'
             ')'
   ;
   VALUE ER30140F
         1 = 'Head in 1974; 1973 Head who was mover-out nonresponse by the time of the 1974 interview'
         2 = 'Wife in 1974; 1973 Wife who was mover-out nonresponse by the time of the 1974 interview'
         3 = 'Son or daughter; includes stepchildren and adopted children'
         4 = 'Brother or sister of Head'
         5 = 'Father or mother of Head'
         6 = 'Grandchild or great-grandchild'
         7 = 'Other relative; includes in-laws'
         8 = 'Nonrelative'
         9 = 'Husband of Head (i.e., Wife was Head of FU)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1974 interview (ER30138>0 and ER30139=0); main family nonresponse by 1974 or mover-out nonr'
             'esponse by 1973 (ER30138=0)'
   ;
   VALUE ER30142F
         1 = 'Spouse in couple numbered 1'
         0 = 'Inap.:  not married; spouse was not in FU in 1974; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1974 interview (ER30138>0 and ER30139=0); main f'
             'amily nonresponse by 1974 or mover-out nonresponse by 1973 (ER30138=0)'
   ;
   VALUE ER30143F
         1 = 'Moved in or born between the 1973 and 1974 interviews; splitoff in 1974'
         2 = 'Appeared; moved in by the time the 1973 interview was taken but not included in FU in 1973 (i.e., listing error)'
         5 = 'Moved out of FU or out of an institution between 1973 and 1974 interviews and was not included in a 1974 panel FU'
         6 = 'Moved out of FU and into an institution between the 1973 and 1974 interviews'
         7 = 'Living in 1973 but died by the time of the 1974 interview'
         8 = 'Disappeared; moved out prior to the 1973 interview, but included in FU for 1973 (usually a listing error)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); in main family in both 1973 and 1974 (ER30118=1-20 and ER30139=1-20); in an institution in both 1973 and 1974 (ER30118'
             '=51-59 and ER30139=51-59); born or moved in after the 1974 interview (ER30138>0 and ER30139=0); main family nonresponse by 1974 or mover-out nonresponse by 1973 (ER30138=0)'
   ;
   VALUE ER30146F
         1 = 'Yes, this person under 25 stopped going to school'
         5 = 'No, did not stop; Head or Wife in 1974 (ER30139=1-20 and ER30140=1 or 02); age 25 or older (ER30141=025-999)'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1974 interview (ER30138>0 and ER30139=0); main family nonresponse by 1974 or mover-out nonr'
             'esponse by 1973 (ER30138=0)'
   ;
   VALUE ER30147F
    1 - 17 = 'Highest grade or year of school completed'
        99 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1974 interview (ER30138>0 and ER30139=0); main family nonresponse by 1974 or mover-out nonr'
             'esponse by 1973 (ER30138=0); Head or Wife in 1974 (ER30139=1-20 and ER30140=1 or 02); did not stop school or individual was age 25 or older (ER30146=5 or 9)'
   ;
   VALUE ER30148F
    1 - 97 = 'Actual hours spent'
        98 = 'Ninety-eight hours per week or more'
        99 = 'NA; DK'
         0 = 'Inap.:  none; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1974 interview (ER30138>0 and ER30139=0); main family nonresponse by 1974 or mover-ou'
             't nonresponse by 1973 (ER30138=0); in an institution at time of 1974 interview or moved out or died between the 1973 and 1974 interviews (ER30139=51-89)'
   ;
   VALUE ER30149F
         1 = 'This individual was respondent'
         5 = 'This individual was not respondent; includes institutionalized individuals and mover-out nonresponse from 1974 (ER30139=51-89)'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born moved in after the 1974 interview (ER30138>0 and ER30139=0); main family nonresponse by 1974 or mover-out nonresp'
             'onse by 1973 (ER30138=0)'
   ;
   VALUE ER30150F
         1 = 'Labor income only'
         2 = 'Transfer income only'
         3 = 'Asset income only'
         4 = 'Combination including labor income'
         5 = 'Combination excluding labor income'
         9 = 'NA; DK'
         0 = 'Inap.:  no income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1974 interview (ER30138>0 and ER30139=0); main family nonresponse by 1974 or mov'
             'er-out nonresponse by 1973 (ER30138=0); in an institution in both 1973 and 1974 (ER30139=51-59 and ER30143=0)'
   ;
   VALUE ER30151F
         1 = 'All welfare income'
         3 = 'Some welfare income'
         5 = 'No welfare income'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1974 interview (ER30138>0 and ER30139=0); main family nonresponse by 1974 or mover-out nonr'
             'esponse by 1973 (ER30138=0); in an institution in both 1973 and 1974 (ER30139=51-59 and ER30143=0); no income (ER30150=0)'
   ;
   VALUE ER30157F
         1 = 'This sample member was 18 years old or older at the time of main family nonresponse and had been in the FU in 1973.'
         2 = 'This sample member was less than 18 at the time of main family nonresponse and had been in the FU in 1973.'
         3 = 'This nonsample individual had been in the 1973 FU, and this FU became nonresponse in 1974.'
         4 = 'This sample member had been in an institution in 1973 but his or her main family became nonresponse in 1974.'
         5 = 'This sample member, although connected with a 1974 response family, was in an institution at the time of the 1974 interview.'
         6 = 'This sample individual was 18 years old or older and moved out or died between the 1973 and 1974 interviews.'
         7 = 'This sample member was less than 18 and moved out or died between the 1973 and 1974 interviews.'
         8 = 'This nonsample individual moved out or died between the 1973 and 1974 interviews.'
         9 = 'This individual had not been born or moved in by the time of the 1974 interview; individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        10 = 'This individual had become nonresponse by the time of the 1973 interview.'
        99 = 'NA; DK'
         0 = 'Inap.:  in a panel family in 1974 (ER30139=1-20).'
   ;
   VALUE ER30158F
         1 = 'Wave refusal by all eligible/available FU members.'
         2 = 'No-one at home for contact during the interviewing period.'
         3 = 'Respondent absent; some FU member contacted, but not the appropriate respondent.'
         4 = 'Lost; unable to locate any member of the FU at all.'
         5 = 'FU is located too far away for interviewer contact.'
        11 = 'This individual was in the armed forces.'
        12 = 'This individual was in an educational institution.'
        13 = 'This individual was in a health care facility'
        14 = 'This individual was in jail or prison'
        19 = 'This individual was in some other type of institution, for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        21 = 'This individual was not eligible for the interview and the Head or the Wife, whichever is the sample member, became main family nonresponse because he/she was institutionalized by joining the armed fo'
             'rces.'
        22 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by entering an educational institution.'
        23 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized by entering a health care facil'
             'ity.'
        24 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized through imprisonment.'
        29 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by some means other than the above; for ex'
             'ample, he/she may have entered a religious order. Cases in which the type of institution is unknown are included here, also.'
        31 = 'This individual was unable to cooperate through disability.'
        32 = 'This individual was not eligible for the interview and the Head or Wife, whichever is sample, was unable to cooperate through disability.'
        41 = 'This individual died between the 1973 and 1974 interviews.'
        42 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, died.'
        51 = 'This individual, although followed for interview, was discovered to be nonsample: office error.'
        52 = 'This individual should have been followed but was not: office error.'
        53 = 'This individual was mistakenly included in two or more response families at once; this record is the duplicate, or erroneous, one.'
        54 = 'Listing error: this individual never existed or was not really living in the FU.'
        59 = 'Other office error'
        91 = 'This sample individual moved out of the 1974 main family and was eligible for interviewing but the reason for nonresponse is NA.'
        92 = 'Individual moved out of the 1974 main family and was not eligible for interviewing because he/she was either nonsample or too young.'
        93 = 'The Head or Wife of this FU, whichever is sample, united with another FU; this individual was not eligible for the interview and therefore became nonresponse.'
        97 = 'This individual had not been born or moved in by the time of the 1974 interview (ER30138>0 and ER30139=0); individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        98 = 'This individual became main family or mover-out nonresponse by 1973 (ER30117=0 and ER30138=0 or ER30117>0 and ER30118=71-89 and ER30138=0)'
        99 = 'NA; DK'
         0 = 'Inap.:  in a panel family in 1974 (ER30139=1-20)'
   ;
   VALUE ER30161F
    1 - 20 = 'Individuals in FU at the time of the 1975 interview'
   51 - 59 = 'Individuals in institutions at the time of the 1975 interview'
   71 - 80 = 'Individuals who moved out of the FU or out of institutions between the 1974 and 1975 interviews but who were not included in another responding FU for 1975. All such individuals were nonresponse.'
   81 - 89 = 'Individuals who were living in 1974 but who died by the time of the 1975 interview'
         0 = 'Inap.:  born or moved in after the 1975 interview; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1975 or mover-out nonresponse by 1974 (ER30160=0'
             ')'
   ;
   VALUE ER30162F
         1 = 'Head in 1975; 1974 Head who was mover-out nonresponse by the time of the 1975 interview'
         2 = 'Wife in 1975; 1974 Wife who was mover-out nonresponse by the time of the 1975 interview'
         3 = 'Son or daughter; includes stepchildren and adopted children'
         4 = 'Brother or sister of Head'
         5 = 'Father or mother of Head'
         6 = 'Grandchild or great-grandchild'
         7 = 'Other relative; includes in-laws'
         8 = 'Nonrelative'
         9 = 'Husband of Head (i.e., Wife was Head of FU)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1975 interview (ER30160>0 and ER30161=0); main family nonresponse by 1975 or mover-out nonr'
             'esponse by 1974 (ER30160=0)'
   ;
   VALUE ER30164F
         1 = 'Spouse in couple numbered 1'
         2 = 'Spouse in couple numbered 2'
         3 = 'Spouse in couple numbered 3'
         0 = 'Inap.:  not married; spouse was not in FU in 1975; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1975 interview (ER30160>0 and ER30161=0); main f'
             'amily nonresponse by 1975 or mover-out nonresponse by 1974 (ER30160=0)'
   ;
   VALUE ER30165F
         1 = 'Moved in or born between the 1974 and 1975 interviews; splitoff in 1975'
         2 = 'Appeared; moved in by the time the 1974 interview was taken but not included in FU for 1974 (i.e., listing error)'
         5 = 'Moved out of FU or out of an institution between the 1974 and 1975 interviews and was not included in a 1975 panel FU'
         6 = 'Moved out of FU and into an institution between the 1974 and 1975 interviews'
         7 = 'Living in 1974 but died by the time of the 1975 interview'
         8 = 'Disappeared; moved out prior to the 1974 interview, but included in FU for 1974 (usually a listing error)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); in main family in both 1974 and 1975 (ER30139=1-20 and ER30161=1-20); in an institution in both 1974 and 1975 (ER30139'
             '=51-59 and ER30161=51-59); born or moved in after the 1975 interview (ER30160>0 and ER30161=0); main family nonresponse by 1975 or mover-out nonresponse by 1974 (ER30160=0)'
   ;
   VALUE ER30168F
         1 = 'Yes, this person under 25 stopped going to school'
         5 = 'No, did not stop; Head or Wife in 1975 (ER30161=1-20 and ER30162=1 or 02); age 25 or older (ER30163=025-999)'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1975 interview (ER30160>0 and ER30161=0); main family nonresponse by 1975 or mover-out nonr'
             'esponse by 1974 (ER30160=0)'
   ;
   VALUE ER30169F
    1 - 17 = 'Highest grade or year of school completed'
        99 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1975 or mover-out nonresponse by 1974 (ER30160=0); born or moved in after the 1975 intervie'
             'w (ER30160>0 and ER30161=0); Head or Wife in 1975 (ER30161=1-20 and ER30162=1 or 02); did not stop school or not a person under 25 (ER30168=5 or 9)'
   ;
   VALUE ER30170F
         1 = 'This individual was respondent'
         5 = 'This individual was not respondent; includes institutionalized individuals and mover-out nonresponse from 1975 (ER30161=51-89)'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1975 interview (ER30160>0 and ER30161=0); main family nonresponse by 1975 or mover-out nonr'
             'esponse by 1974 (ER30160=0)'
   ;
   VALUE ER30171F
         1 = 'Labor income only'
         2 = 'Asset income only'
         3 = 'Both labor and asset income'
         0 = 'Inap.:  no taxable income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1975 interview (ER30160>0 and ER30161=0); main family nonresponse by 197'
             '5 or mover-out nonresponse by 1974 (ER30160=0); in an institution in both 1974 and 1975 (ER30161=51-59 and ER30165=0)'
   ;
   VALUE ER30172F
         1 = 'ADC, AFDC only'
         2 = 'Other welfare only'
         3 = 'Social Security only'
         4 = 'Other retirement pay, pensions, annuities only'
         5 = 'Unemployment, worker compensation only'
         6 = 'Alimony, child support only'
         7 = 'Help from relatives only'
         8 = 'Supplemental Security Income only'
         9 = 'Any combination; other'
         0 = 'Inap.:  no transfer income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1975 interview (ER30160>0 and ER30161=0); main family nonresponse by 19'
             '75 or mover-out nonresponse by 1974 (ER30160=0); in an institution in both 1974 and 1975 (ER30161=51-59 and ER30165=0)'
   ;
   VALUE ER30181F
    1 - 17 = 'Highest grade or year of school completed'
        96 = 'Twenty-four years old or younger in 1975 and in school from 1968 through 1975'
        97 = 'Less than 12 years of age in 1975 and either not in a 1968 family and has never stopped school or preschool age in 1968 and has never stopped school'
        98 = 'Age is at least 12 but no more than 24 and neither in school nor preschool age in 1968 and has never stopped school'
        99 = 'Attended school in 1968 and turned 25 between 1969 and 1975 and had not stopped school by 25; mover-in who was 25 or older in 1975; age in 1975 was NA; other NA'
         0 = 'No education; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1975 interview (ER30160>0 and ER30161=0); main family nonresponse by 1975 or mover-ou'
             't nonresponse by 1974 (ER30160=0)'
   ;
   VALUE ER30185F
         1 = 'This sample member was 18 years old or older at the time of main family nonresponse and had been in the FU in 1974.'
         2 = 'This sample member was less than 18 at the time of main family nonresponse and had been in the FU in 1974.'
         3 = 'This nonsample individual had been in the 1974 FU, and this FU became nonresponse in 1975.'
         4 = 'This sample member had been in an institution in 1974 but his or her main family became nonresponse in 1975.'
         5 = 'This sample member, although connected with a 1975 response family, was in an institution at the time of the 1975 interview.'
         6 = 'This sample individual was 18 years old or older and moved out or died between the 1974 and 1975 interviews.'
         7 = 'This sample member was less than 18 and moved out or died between the 1974 and 1975 interviews.'
         8 = 'This nonsample individual moved out or died between the 1974 and 1975 interviews.'
         9 = 'This individual had not been born or moved in by the time of the 1975 interview; individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        10 = 'This individual had become nonresponse by the time of the 1974 interview.'
        99 = 'NA; DK'
         0 = 'Inap.:  in a panel family in 1975 (ER30161=1-20).'
   ;
   VALUE ER30186F
         1 = 'Wave refusal by all eligible/available FU members.'
         2 = 'No-one at home for contact during the interviewing period.'
         3 = 'Respondent absent; some FU member contacted, but not the appropriate respondent.'
         4 = 'Lost; unable to locate any member of the FU at all.'
         5 = 'FU is located too far away for interviewer contact.'
        11 = 'This individual was in the armed forces.'
        12 = 'This individual was in an educational institution.'
        13 = 'This individual was in a health care facility'
        14 = 'This individual was in jail or prison'
        19 = 'This individual was in some other type of institution, for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        21 = 'This individual was not eligible for the interview and the Head or the Wife, whichever is the sample member, became main family nonresponse because he/she was institutionalized by joining the armed fo'
             'rces.'
        22 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by entering an educational institution.'
        23 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized by entering a health care facil'
             'ity.'
        24 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized through imprisonment.'
        29 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by some means other than the above; for ex'
             'ample, he/she may have entered a religious order. Cases in which the type of institution is unknown are included here, also.'
        31 = 'This individual was unable to cooperate through disability.'
        32 = 'This individual was not eligible for the interview and the Head or Wife, whichever is sample, was unable to cooperate through disability.'
        41 = 'This individual died between the 1974 and 1975 interviews.'
        42 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, died.'
        51 = 'This individual, although followed for interview, was discovered to be nonsample: office error.'
        52 = 'This individual should have been followed but was not: office error.'
        53 = 'This individual was mistakenly included in two or more response families at once; this record is the duplicate, or erroneous, one.'
        54 = 'Listing error: this individual never existed or was not really living in the FU.'
        59 = 'Other office error'
        91 = 'This sample individual moved out of the 1975 main family and was eligible for interviewing but the reason for nonresponse is NA.'
        92 = 'Individual moved out of the 1975 main family and was not eligible for interviewing because he/she was either nonsample or too young.'
        93 = 'The Head or Wife of this FU, whichever is sample, united with another FU; this individual was not eligible for the interview and therefore became nonresponse.'
        97 = 'This individual had not been born or moved in by the time of the 1975 interview (ER30160>0 and ER30161=0); individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        98 = 'This individual became main family or mover-out nonresponse by 1974 (ER30138=0 and ER30160=0 or ER30138>0 and ER30139=71-89 and ER30160=0)'
        99 = 'NA; DK'
         0 = 'Inap.:  in a panel family in 1975 (ER30161=1-20)'
   ;
   VALUE ER30189F
    1 - 20 = 'Individuals in FU at the time of the 1976 interview'
   51 - 59 = 'Individuals in institutions at the time of the 1976 interview'
   71 - 80 = 'Individuals who moved out of the FU or out of institutions between the 1975 and 1976 interviews but were not included in another responding FU for 1976. All such individuals were nonresponse.'
   81 - 89 = 'Individuals who were living in 1975 but who died by the time of the 1976 interview'
         0 = 'Inap.:  born or moved in after the 1976 interview; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1976 or mover-out nonresponse by 1975 (ER30188=0'
             ')'
   ;
   VALUE ER30190F
         1 = 'Head in 1976; 1975 Head who was mover-out nonresponse by the time of the 1976 interview'
         2 = 'Wife in 1976; 1975 Wife who was mover-out nonresponse by the time of the 1976 interview'
         3 = 'Son or daughter; includes stepchildren and adopted children'
         4 = 'Brother or sister of Head'
         5 = 'Father or mother of Head'
         6 = 'Grandchild or great-grandchild'
         7 = 'Other relative; includes in-laws'
         8 = 'Nonrelative'
         9 = 'Husband of Head (i.e., Wife was Head of FU)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1976 interview (ER30188>0 and ER30189=0); main family nonresponse by 1976 or mover-out nonr'
             'esponse by 1975 (ER30188=0)'
   ;
   VALUE ER30192F
         1 = 'Spouse in couple numbered 1'
         2 = 'Spouse in couple numbered 2'
         3 = 'Spouse in couple numbered 3'
         0 = 'Inap.:  not married; spouse was not in FU in 1976; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1976 interview (ER30188>0 and ER30189=0); main f'
             'amily nonresponse by 1976 or mover-out nonresponse by 1975 (ER30188=0)'
   ;
   VALUE ER30193F
         1 = 'Moved in or born between the 1975 and 1976 interviews; splitoff in 1976'
         2 = 'Appeared; moved in by the time the 1975 interview was taken but not included in FU for 1975 (i.e., listing error)'
         5 = 'Moved out of FU or institution between the 1975 and 1976 interviews and was not included in a 1976 panel FU'
         6 = 'Moved out of FU and into an institution between the 1975 and 1976 interviews'
         7 = 'Living in 1975 but died by the time of the 1976 interview'
         8 = 'Disappeared; moved out prior to the 1975 interview, but included in FU for 1975 (usually a listing error)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); in main family in both 1975 and 1976 (ER30161=1-20 and ER30189=1-20); in an institution in both 1975 and 1976 (ER30161'
             '=51-59 and ER30189=51-59); born or moved in after the 1976 interview (ER30188>0 and ER30189=0); main family nonresponse by 1976 or mover-out nonresponse by 1975 (ER30188=0)'
   ;
   VALUE ER30196F
         1 = 'Yes, this person under 25 stopped going to school'
         5 = 'No, did not stop; Head or Wife in 1976 (ER30189=1-20 and ER30190=1 or 02); was age 25 or older (ER30191=025-999)'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1976 interview (ER30188>0 and ER30189=0); main family nonresponse by 1976 or mover-out nonr'
             'esponse by 1975 (ER30188=0)'
   ;
   VALUE ER30197F
    1 - 17 = 'Highest grade or year of school completed'
        99 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1976 or mover-out nonresponse by 1975 (ER30188=0); born or moved in after the 1976 intervie'
             'w (ER30188>0 and ER30189=0); did not stop school or other individual age 25 or older (ER30189=1-20, ER30190=1 or 02 and ER30196=5 or 9)'
   ;
   VALUE ER30198F
    1 - 97 = 'Actual hours spent'
        98 = 'Ninety-eight hours per week or more'
        99 = 'NA; DK'
         0 = 'Inap.:  none; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1976 or mover-out nonresponse by 1975 (ER30188=0); born or moved in after the 1976 in'
             'terview (ER30188>0 and ER30189=0); in an institution at time of 1976 interview or mover-out nonresponse from 1976 (ER30189=51-89)'
   ;
   VALUE ER30199F
         1 = 'This person requires extra care or is disabled'
         5 = 'This person does not require extra care or is not disabled'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1976 interview (ER30188>0 and ER30189=0); main family nonresponse by 1976 or mover-out nonr'
             'esponse by 1975 (ER30188=0); in an institution at time of 1976 interview or mover-out nonresponse from 1976 (ER30189=51-89)'
   ;
   VALUE ER30200F
         1 = 'This individual was respondent'
         5 = 'This individual was not respondent; includes institutionalized individuals and mover-out nonresponse from 1976 (ER30189=51-89)'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1976 interview (ER30188>0 and ER30189=0); main family nonresponse by 1976 or mover-out nonr'
             'esponse by 1975 (ER30188=0)'
   ;
   VALUE ER30201F
         1 = 'Labor income only'
         2 = 'Asset income only'
         3 = 'Both labor and asset income'
         0 = 'Inap.:  no taxable income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1976 interview (ER30188>0 and ER30189=0); main family nonresponse by 197'
             '6 or mover-out nonresponse by 1975 (ER30188=0); in an institution in both 1975 and 1976 (ER30189=51-59 and ER30193=0)'
   ;
   VALUE ER30208F
         1 = 'ADC, AFDC only'
         2 = 'Other welfare only'
         3 = 'Social Security only'
         4 = 'Other retirement pay, pensions, annuities only'
         5 = 'Unemployment, worker compensation only'
         6 = 'Alimony, child support only'
         7 = 'Help from relatives only'
         8 = 'Supplemental Security Income only'
         9 = 'Any combination; other'
         0 = 'Inap.:  no transfer income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1976 interview (ER30188>0 and ER30189=0); main family nonresponse by 19'
             '76 or mover-out nonresponse by 1975 (ER30188=0); in an institution in both 1975 and 1976 (ER30189=51-59 and ER30193=0)'
   ;
   VALUE ER30214F
         1 = 'This sample member was 18 years old or older at the time of main family nonresponse and had been in the FU in 1975.'
         2 = 'This sample member was less than 18 at the time of main family nonresponse and had been in the FU in 1975.'
         3 = 'This nonsample individual had been in the 1975 FU, and this FU became nonresponse in 1976.'
         4 = 'This sample member had been in an institution in 1975 but his or her main family became nonresponse in 1976.'
         5 = 'This sample member, although connected with a 1976 response family, was in an institution at the time of the 1976 interview.'
         6 = 'This sample individual was 18 years old or older and moved out or died between the 1975 and 1976 interviews.'
         7 = 'This sample member was less than 18 and moved out or died between the 1975 and 1976 interviews.'
         8 = 'This nonsample individual moved out or died between the 1975 and 1976 interviews.'
         9 = 'This individual had not been born or moved in by the time of the 1976 interview; individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        10 = 'This individual had become nonresponse by the time of the 1975 interview.'
        99 = 'NA; DK'
         0 = 'Inap.:  in a panel family in 1976 (ER30189=1-20).'
   ;
   VALUE ER30215F
         1 = 'Wave refusal by all eligible/available FU members.'
         2 = 'No-one at home for contact during the interviewing period.'
         3 = 'Respondent absent; some FU member contacted, but not the appropriate respondent.'
         4 = 'Lost; unable to locate any member of the FU at all.'
         5 = 'FU is located too far away for interviewer contact.'
        11 = 'This individual was in the armed forces.'
        12 = 'This individual was in an educational institution.'
        13 = 'This individual was in a health care facility'
        14 = 'This individual was in jail or prison'
        19 = 'This individual was in some other type of institution, for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        21 = 'This individual was not eligible for the interview and the Head or the Wife, whichever is the sample member, became main family nonresponse because he/she was institutionalized by joining the armed fo'
             'rces.'
        22 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by entering an educational institution.'
        23 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized by entering a health care facil'
             'ity.'
        24 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized through imprisonment.'
        29 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by some means other than the above; for ex'
             'ample, he/she may have entered a religious order. Cases in which the type of institution is unknown are included here, also.'
        31 = 'This individual was unable to cooperate through disability.'
        32 = 'This individual was not eligible for the interview and the Head or Wife, whichever is sample, was unable to cooperate through disability.'
        41 = 'This individual died between the 1975 and 1976 interviews.'
        42 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, died.'
        51 = 'This individual, although followed for interview, was discovered to be nonsample: office error.'
        52 = 'This individual should have been followed but was not: office error.'
        53 = 'This individual was mistakenly included in two or more response families at once; this record is the duplicate, or erroneous, one.'
        54 = 'Listing error: this individual never existed or was not really living in the FU.'
        59 = 'Other office error'
        91 = 'This sample individual moved out of the 1976 main family and was eligible for interviewing but the reason for nonresponse is NA.'
        92 = 'Individual moved out of the 1976 main family and was not eligible for interviewing because he/she was either nonsample or too young.'
        93 = 'The Head or Wife of this FU, whichever is sample, united with another FU; this individual was not eligible for the interview and therefore became nonresponse.'
        97 = 'This individual had not been born or moved in by the time of the 1976 interview (ER30188>0 and ER30189=0); individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        98 = 'This individual became main family or mover-out nonresponse by 1975 (ER30160=0 and ER30188=0 or ER30160>0 and ER30161=71-89 and ER30188=0)'
        99 = 'NA; DK'
         0 = 'Inap.:  in a panel family in 1976 (ER30189=1-20)'
   ;
   VALUE ER30218F
    1 - 20 = 'Individuals in FU at the time of the 1977 interview'
   51 - 59 = 'Individuals in institutions at the time of the 1977 interview'
   71 - 80 = 'Individuals who moved out of the FU or out of institutions between the 1976 and 1977 interviews but who were not included in another responding FU for 1977. All such individuals were nonresponse.'
   81 - 89 = 'Individuals who were living in 1976 but who died by the time of the 1977 interview'
         0 = 'Inap.:  born or moved in after the 1977 interview; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1977 or mover-out nonresponse by 1976 (ER30217=0'
             ')'
   ;
   VALUE ER30219F
         1 = 'Head in 1977; 1976 Head who was mover-out nonresponse by the time of the 1977 interview'
         2 = 'Wife in 1977; 1976 Wife who was mover-out nonresponse by the time of the 1977 interview'
         3 = 'Son or daughter; includes stepchildren and adopted children'
         4 = 'Brother or sister of Head'
         5 = 'Father or mother of Head'
         6 = 'Grandchild or great-grandchild'
         7 = 'Other relative; includes in-laws'
         8 = 'Nonrelative'
         9 = 'Husband of Head (i.e., Wife was Head of FU)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1977 interview (ER30217>0 and ER30218=0); main family nonresponse by 1977 or mover-out nonr'
             'esponse by 1976 (ER30217=0)'
   ;
   VALUE ER30221F
         1 = 'Spouse in couple numbered 1'
         2 = 'Spouse in couple numbered 2'
         3 = 'Spouse in couple numbered 3'
         4 = 'Spouse in couple numbered 4'
         5 = 'Spouse in couple numbered 5'
         0 = 'Inap.:  not married; spouse not in FU in 1977; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1977 interview (ER30217>0 and ER30218=0); main famil'
             'y nonresponse by 1977 or mover-out nonresponse by 1976 (ER30217=0)'
   ;
   VALUE ER30222F
         1 = 'Moved in or born between the 1976 and 1977 interviews; splitoff in 1977'
         2 = 'Appeared; moved in by the time the 1976 interview was taken but not included in FU for 1976 (i.e., listing error)'
         5 = 'Moved out of FU or out of an institution between the 1976 and 1977 interviews and was not included in a 1977 panel FU'
         6 = 'Moved out of FU and into an institution between the 1976 and 1977 interviews'
         7 = 'Living in 1976 but died by the time of the 1977 interview'
         8 = 'Disappeared; moved out prior to the 1976 interview, but included in FU for 1976 (usually a listing error)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); in main family in both 1976 and 1977 (ER30189=1-20 and ER30218=1-20); in an institution in both 1976 and 1977 (ER30189'
             '=51-59 and ER30218=51-59); born or moved in after the 1977 interview (ER30217>0 and ER30218=0); main family nonresponse by 1977 or mover-out nonresponse by 1976 (ER30217=0)'
   ;
   VALUE ER30225F
         1 = 'Yes, this person under 25 stopped going to school'
         5 = 'No, did not stop; Head or Wife in 1977 (ER30218=1-20 and ER30219=1 or 02); was age 25 or older (ER30220=025-999)'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1977 interview (ER30217>0 and ER30218=0); main family nonresponse by 1977 or mover-out nonr'
             'esponse by 1976 (ER30217=0)'
   ;
   VALUE ER30226F
    1 - 17 = 'Highest grade or year of school completed'
        99 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1977 interview (ER30217>0 and ER30218=0); main family nonresponse by 1977 or mover-out nonr'
             'esponse by 1976 (ER30217=0); did not stop school or other individual age 25 or older (ER30218=1-20, ER30219=1 or 20 and ER30225=5 or 9)'
   ;
   VALUE ER30227F
    1 - 97 = 'Actual hours spent'
        98 = 'Ninety-eight hours per week or more'
        99 = 'NA; DK'
         0 = 'Inap.:  none; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1977 interview (ER30217>0 and ER30218=0); main family nonresponse by 1977 or mover-ou'
             't nonresponse by 1976 (ER30217=0); in an institution at time of 1977 interview or mover-out nonresponse from 1977 (ER30218=51-89)'
   ;
   VALUE ER30228F
         1 = 'This person requires extra care or is disabled'
         5 = 'This person does not require extra care or is not disabled'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1977 interview (ER30217>0 and ER30218=0); main family nonresponse by 1977 or mover-out nonr'
             'esponse by 1976 (ER30217=0); in an institution at time of 1977 interview or mover-out nonresponse from 1977 (ER30218=51-89)'
   ;
   VALUE ER30229F
         1 = 'This individual was respondent'
         5 = 'This individual was not respondent; includes institutionalized individuals and mover-out nonresponse from 1977 (ER30218=51-89)'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1977 interview (ER30217>0 and ER30218=0); main family nonresponse by 1977 or mover-out nonr'
             'esponse by 1976 (ER30217=0)'
   ;
   VALUE ER30230F
         1 = 'Labor income only'
         2 = 'Asset income only'
         3 = 'Both labor and asset income'
         0 = 'Inap.:  no taxable income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1977 interview (ER30217>0 and ER30218=0); main family nonresponse by 197'
             '7 or mover-out nonresponse by 1976 (ER30217=0); in an institution in both 1976 and 1977 (ER30218=51-59 and ER30222=0)'
   ;
   VALUE ER30237F
         1 = 'ADC, AFDC only'
         2 = 'Other welfare only'
         3 = 'Social Security only'
         4 = 'Other retirement pay, pensions, annuities only'
         5 = 'Unemployment only'
         6 = 'Worker compensation only'
         7 = 'Child support only'
         8 = 'Help from relatives only'
         9 = 'Supplemental Security Income only'
        10 = 'Other transfers only'
        15 = 'Any combination'
         0 = 'Inap.:  no transfer income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1977 interview (ER30217>0 and ER30218=0); main family nonresponse by 19'
             '77 or mover-out nonresponse by 1976 (ER30217=0); in an institution in both 1976 and 1977 (ER30218=51-59 and ER30222=0)'
   ;
   VALUE ER30243F
         1 = 'This sample member was 18 years old or older at the time of main family nonresponse and had been in the FU in 1976.'
         2 = 'This sample member was less than 18 at the time of main family nonresponse and had been in the FU in 1976.'
         3 = 'This nonsample individual had been in the 1976 FU, and this FU became nonresponse in 1977.'
         4 = 'This sample member had been in an institution in 1976 but his or her main family became nonresponse in 1977.'
         5 = 'This sample member, although connected with a 1977 response family, was in an institution at the time of the 1977 interview.'
         6 = 'This sample individual was 18 years old or older and moved out or died between the 1976 and 1977 interviews.'
         7 = 'This sample member was less than 18 and moved out or died between the 1976 and 1977 interviews.'
         8 = 'This nonsample individual moved out or died between the 1976 and 1977 interviews.'
         9 = 'This individual had not been born or moved in by the time of the 1977 interview; individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        10 = 'This individual had become nonresponse by the time of the 1976 interview.'
        99 = 'NA; DK'
         0 = 'Inap.:  in a panel family in 1977 (ER30218=1-20).'
   ;
   VALUE ER30244F
         1 = 'Wave refusal by all eligible/available FU members.'
         2 = 'No-one at home for contact during the interviewing period.'
         3 = 'Respondent absent; some FU member contacted, but not the appropriate respondent.'
         4 = 'Lost; unable to locate any member of the FU at all.'
         5 = 'FU is located too far away for interviewer contact.'
        11 = 'This individual was in the armed forces.'
        12 = 'This individual was in an educational institution.'
        13 = 'This individual was in a health care facility'
        14 = 'This individual was in jail or prison'
        19 = 'This individual was in some other type of institution, for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        21 = 'This individual was not eligible for the interview and the Head or the Wife, whichever is the sample member, became main family nonresponse because he/she was institutionalized by joining the armed fo'
             'rces.'
        22 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by entering an educational institution.'
        23 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized by entering a health care facil'
             'ity.'
        24 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized through imprisonment.'
        29 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by some means other than the above; for ex'
             'ample, he/she may have entered a religious order. Cases in which the type of institution is unknown are included here, also.'
        31 = 'This individual was unable to cooperate through disability.'
        32 = 'This individual was not eligible for the interview and the Head or Wife, whichever is sample, was unable to cooperate through disability.'
        41 = 'This individual died between the 1976 and 1977 interviews.'
        42 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, died.'
        51 = 'This individual, although followed for interview, was discovered to be nonsample: office error.'
        52 = 'This individual should have been followed but was not: office error.'
        53 = 'This individual was mistakenly included in two or more response families at once; this record is the duplicate, or erroneous, one.'
        54 = 'Listing error: this individual never existed or was not really living in the FU.'
        59 = 'Other office error'
        91 = 'This sample individual moved out of the 1977 main family and was eligible for interviewing but the reason for nonresponse is NA.'
        92 = 'Individual moved out of the 1977 main family and was not eligible for interviewing because he/she was either nonsample or too young.'
        93 = 'The Head or Wife of this FU, whichever is sample, united with another FU; this individual was not eligible for the interview and therefore became nonresponse.'
        97 = 'This individual had not been born or moved in by the time of the 1977 interview (ER30218>0 and ER30219=0); individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        98 = 'This individual became main family or mover-out nonresponse by 1976 (ER30188=0 and ER30217=0 or ER30188>0 and ER30189=71-89 and ER30217=0)'
        99 = 'NA; DK'
         0 = 'Inap.:  in a panel family in 1977 (ER30218=1-20)'
   ;
   VALUE ER30247F
    1 - 20 = 'Individuals in FU at the time of the 1978 interview'
   51 - 59 = 'Individuals in institutions at the time of the 1978 interview'
   71 - 80 = 'Individuals who moved out of the FU or out of institutions between the 1977 and 1978 interviews but who were not included in another responding FU for 1978. All such individuals were nonresponse.'
   81 - 89 = 'Individuals who were living in 1977 but who died by the time of the 1978 interview'
         0 = 'Inap.:  born or moved in after the 1978 interview; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1978 or mover-out nonresponse by 1977 (ER30246=0'
             ')'
   ;
   VALUE ER30248F
         1 = 'Head in 1978; 1977 Head who was mover-out nonresponse by the time of the 1978 interview'
         2 = 'Wife in 1978; 1977 Wife who was mover-out nonresponse by the time of the 1978 interview'
         3 = 'Son or daughter; includes stepchildren and adopted children'
         4 = 'Brother or sister of Head'
         5 = 'Father or mother of Head'
         6 = 'Grandchild or great-grandchild'
         7 = 'Other relative; includes in-laws'
         8 = 'Nonrelative'
         9 = 'Husband of Head (i.e., Wife was Head of FU)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1978 interview (ER30246>0 and ER30247=0); main family nonresponse by 1978 or mover-out nonr'
             'esponse by 1977 (ER30246=0)'
   ;
   VALUE ER30250F
         1 = 'Spouse in couple numbered 1'
         2 = 'Spouse in couple numbered 2'
         3 = 'Spouse in couple numbered 3'
         4 = 'Spouse in couple numbered 4'
         5 = 'Spouse in couple numbered 5'
         0 = 'Inap.:  not married; spouse was not in FU at the time of the 1978 interview; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1978 interview (ER3024'
             '6>0 and ER30247=0); main family nonresponse by 1978 or mover-out nonresponse by 1977 (ER30246=0)'
   ;
   VALUE ER30251F
         1 = 'Moved in or born between the 1977 and 1978 interviews; splitoff in 1978'
         2 = 'Appeared; moved in by the time the 1977 interview was taken but not included in FU for 1977 (i.e., listing error)'
         5 = 'Moved out of FU or institution between the 1977 and 1978 interviews and was not included in a 1978 panel FU'
         6 = 'Moved out of FU and into an institution between the 1977 and 1978 interviews'
         7 = 'Living in 1977 but died by the time of the 1978 interview'
         8 = 'Disappeared; moved out prior to the 1977 interview, but included in FU for 1977 (usually a listing error)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); in main family in both 1977 and 1978 (ER30218=1-20 and ER30247=1-20); in an institution in both 1977 and 1978 (ER30218'
             '=51-59 and ER30247=51-59); born or moved in after the 1978 interview (ER30246>0 and ER30247=0); main family nonresponse by 1978 or mover-out nonresponse by 1977 (ER30246=0)'
   ;
   VALUE ER30254F
         1 = 'Yes, this person under 25 stopped going to school'
         5 = 'No, did not stop; Head or Wife in 1978 (ER30247=1-20 and ER30248=1 or 02); was age 25 or older (ER30249=025-999)'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1978 interview (ER30246>0 and ER30247=0); main family nonresponse by 1978 or mover-out nonr'
             'esponse by 1977 (ER30247=0)'
   ;
   VALUE ER30255F
    1 - 17 = 'Highest grade or year of school completed'
        99 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1978 interview (ER30246>0 and ER30247=0); main family nonresponse by 1978 or mover-out nonr'
             'esponse by 1977 (ER30246=0); did not stop school or other individual was age 25 or older (ER30247=1-20, ER30248=1 or 02 and ER30254=5 or 9)'
   ;
   VALUE ER30256F
    1 - 97 = 'Actual hours spent'
        98 = 'Ninety-eight hours per week or more'
        99 = 'NA; DK'
         0 = 'Inap.:  none; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1978 interview (ER30246>0 and ER30247=0); main family nonresponse by 1978 or mover-ou'
             't nonresponse by 1977 (ER30246=0); in an institution at time of 1978 interview or mover-out nonresponse from 1978 (ER30247=51-89)'
   ;
   VALUE ER30257F
         1 = 'Yes, this individual was looking for work; Head is included here if unemployed at D1 or if retired, permanently disabled, houseWife, student, or other at D1 and answered Yes to F22'
         5 = 'No, this individual was not looking for work; Head is included here if employed at D1 or retired, permanently disabled, houseWife, student, or other at D1 and answered No to F22; institutionalized or'
             'mover-out nonresponse from 1978 (ER30247=51-89)'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1978 interview (ER30246>0 and ER30247=0); main family nonresponse by 1978 or mover-out nonr'
             'esponse by 1977 (ER30246=0)'
   ;
   VALUE ER30259F
         1 = 'This person has a physical or nervous condition'
         5 = 'This person does not have a physical or nervous condition'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1978 interview (ER30246>0 and ER30247=0); main family nonresponse by 1978 or mover-out nonr'
             'esponse by 1977 (ER30246=0); in an institution at time of 1978 interview or mover-out nonresponse from 1978 (ER30247=51-89)'
   ;
   VALUE ER30260F
         1 = 'A lot'
         3 = 'Somewhat'
         5 = 'Just a little'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1978 interview (ER30246>0 and ER30247=0); main family nonresponse by 1978 or mover-out nonr'
             'esponse by 1977 (ER30246=0); in an institution at time of 1978 interview or mover-out nonresponse from 1978 (ER30247=51-89); no physical or nervous condition (ER30259=5 or 9)'
   ;
   VALUE ER30261F
         1 = 'One year or less'
    2 - 97 = 'Actual number of years'
        98 = 'Ninety-eight years or more'
        99 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1978 interview (ER30246>0 and ER30247=0); main family nonresponse by 1978 or mover-out nonr'
             'esponse by 1977 (ER30246=0); in an institution at time of 1978 interview or mover-out nonresponse from 1978 (ER30247=51-89); no physical or nervous condition (ER30259=5 or 9)'
   ;
   VALUE ER30262F
         1 = 'Better'
         3 = 'Same'
         5 = 'Worse'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1978 interview (ER30246>0 and ER30247=0); main family nonresponse by 1978 or mover-out nonr'
             'esponse by 1977 (ER30246=0); in an institution at time of 1978 interview or mover-out nonresponse from 1978 (ER30247=51-89); no physical or nervous condition (ER30259=5 or 9)'
   ;
   VALUE ER30263F
         1 = 'Yes'
         5 = 'No'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1978 interview (ER30246>0 and ER30247=0); main family nonresponse by 1978 or mover-out nonr'
             'esponse by 1977 (ER30246=0); in an institution at time of 1978 interview or mover-out nonresponse from 1978 (ER30247=51-89); no physical or nervous condition (ER30259=5 or 9)'
   ;
   VALUE ER30264F
         1 = 'Yes'
         5 = 'No'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1978 interview (ER30246>0 and ER30247=0); main family nonresponse by 1978 or mover-out nonr'
             'esponse by 1977 (ER30246=0); in an institution at time of 1978 interview or mover-out nonresponse from 1978 (ER30247=51-89); no physical or nervous condition (ER30259=5 or 9); does not require a lot o'
             'f extra care (ER30263=5 or 9)'
   ;
   VALUE ER30265F
         1 = 'Small'
         3 = 'Moderate'
         5 = 'Large'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1978 interview (ER30246>0 and ER30247=0); main family nonresponse by 1978 or mover-out nonr'
             'esponse by 1977 (ER30246=0); in an institution at time of 1978 interview or mover-out nonresponse from 1978 (ER30247=51-89); no physical or nervous condition (ER30259=5 or 9); does not require a lot o'
             'f extra care (ER30263=5 or 9); no extra costs for the family (ER30264=5 or 9)'
   ;
   VALUE ER30266F
         1 = 'This individual was respondent'
         5 = 'This individual was not respondent; includes institutionalized individuals and mover-out nonresponse from 1978 (ER30247=51-89)'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1978 interview (ER30246>0 and ER30247=0); main family nonresponse by 1978 or mover-out nonr'
             'esponse by 1977 (ER30246=0)'
   ;
   VALUE ER30267F
         1 = 'Labor income only'
         2 = 'Asset income only'
         3 = 'Both labor and asset income'
         0 = 'Inap.:  no taxable income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1978 interview (ER30246>0 and ER30247=0); main family nonresponse by 197'
             '8 or mover-out nonresponse by 1977 (ER30246=0); in an institution in both 1977 and 1978 (ER30247=51-59 and ER30251=0)'
   ;
   VALUE ER30274F
         1 = 'ADC, AFDC only'
         2 = 'Supplemental Security Income (SSI) only'
         3 = 'Other welfare only'
         4 = 'Social Security only'
         5 = 'Other retirement pay, pensions, or annuities only'
         6 = 'Unemployment compensation only'
         7 = 'Worker compensation only'
         8 = 'Child support only'
         9 = 'Help from relatives only'
        10 = 'Other transfers only'
        15 = 'More than one of the above; any combination'
         0 = 'Inap.:  no transfer income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1978 interview (ER30246>0 and ER30247=0); main family nonresponse by 19'
             '78 or mover-out nonresponse by 1977 (ER30246=0); in an institution in both 1977 and 1978 (ER30247=51-59 and ER30251=0)'
   ;
   VALUE ER30280F
         1 = 'This sample member was 18 years old or older at the time of main family nonresponse and had been in the FU in 1977.'
         2 = 'This sample member was less than 18 at the time of main family nonresponse and had been in the FU in 1977.'
         3 = 'This nonsample individual had been in the 1977 FU, and this FU became nonresponse in 1978.'
         4 = 'This sample member had been in an institution in 1977 but his or her main family became nonresponse in 1978.'
         5 = 'This sample member, although connected with a 1978 response family, was in an institution at the time of the 1978 interview.'
         6 = 'This sample individual was 18 years old or older and moved out or died between the 1977 and 1978 interviews.'
         7 = 'This sample member was less than 18 and moved out or died between the 1977 and 1978 interviews.'
         8 = 'This nonsample individual moved out or died between the 1977 and 1978 interviews.'
         9 = 'This individual had not been born or moved in by the time of the 1978 interview; individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        10 = 'This individual had become nonresponse by the time of the 1977 interview.'
        99 = 'NA; DK'
         0 = 'Inap.:  in a panel family in 1978 (ER30247=1-20).'
   ;
   VALUE ER30281F
         1 = 'Wave refusal by all eligible/available FU members.'
         2 = 'No-one at home for contact during the interviewing period.'
         3 = 'Respondent absent; some FU member contacted, but not the appropriate respondent.'
         4 = 'Lost; unable to locate any member of the FU at all.'
         5 = 'FU is located too far away for interviewer contact.'
        11 = 'This individual was in the armed forces.'
        12 = 'This individual was in an educational institution.'
        13 = 'This individual was in a health care facility'
        14 = 'This individual was in jail or prison'
        19 = 'This individual was in some other type of institution, for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        21 = 'This individual was not eligible for the interview and the Head or the Wife, whichever is the sample member, became main family nonresponse because he/she was institutionalized by joining the armed fo'
             'rces.'
        22 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by entering an educational institution.'
        23 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized by entering a health care facil'
             'ity.'
        24 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized through imprisonment.'
        29 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by some means other than the above; for ex'
             'ample, he/she may have entered a religious order. Cases in which the type of institution is unknown are included here, also.'
        31 = 'This individual was unable to cooperate through disability.'
        32 = 'This individual was not eligible for the interview and the Head or Wife, whichever is sample, was unable to cooperate through disability.'
        41 = 'This individual died between the 1977 and 1978 interviews.'
        42 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, died.'
        51 = 'This individual, although followed for interview, was discovered to be nonsample: office error.'
        52 = 'This individual should have been followed but was not: office error.'
        53 = 'This individual was mistakenly included in two or more response families at once; this record is the duplicate, or erroneous, one.'
        54 = 'Listing error: this individual never existed or was not really living in the FU.'
        59 = 'Other office error'
        91 = 'This sample individual moved out of the 1978 main family and was eligible for interviewing but the reason for nonresponse is NA.'
        92 = 'Individual moved out of the 1978 main family and was not eligible for interviewing because he/she was either nonsample or too young.'
        93 = 'The Head or Wife of this FU, whichever is sample, united with another FU; this individual was not eligible for the interview and therefore became nonresponse.'
        97 = 'This individual had not been born or moved in by the time of the 1978 interview (ER30246>0 and ER30247=0); individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        98 = 'This individual became main family or mover-out nonresponse by 1977 (ER30217=0 and ER30246=0 or ER30217>0 and ER30218=71-89 and ER30246=0)'
        99 = 'NA; DK'
         0 = 'Inap.:  in a panel family in 1978 (ER30247=1-20)'
   ;
   VALUE ER30284F
    1 - 20 = 'Individuals in the family at the time of the 1979 interview'
   51 - 59 = 'Individuals in institutions at the time of the 1979 interview'
   71 - 80 = 'Individuals who moved out of the FU or out of institutions between the 1978 and 1979 interviews but who were not included in another responding FU for 1979. All such individuals were nonresponse.'
   81 - 89 = 'Individuals who were living in 1978 but who died by the time of the 1978 interview'
         0 = 'Inap.:  born or moved in after the 1979 interview; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1979 or mover-out nonresponse by 1978 (ER30283=0'
             ')'
   ;
   VALUE ER30285F
         1 = 'Head in 1979; 1978 Head who was mover-out nonresponse by the time of the 1979 interview'
         2 = 'Wife in 1979; 1978 Wife who was mover-out nonresponse by the time of the 1979 interview'
         3 = 'Son or daughter; includes stepchildren and adopted children'
         4 = 'Brother or sister of Head'
         5 = 'Father or mother of Head'
         6 = 'Grandchild or great-grandchild'
         7 = 'Other relative, includes in-laws'
         8 = 'Nonrelative'
         9 = 'Husband of Head (i.e., Wife was Head of FU)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1979 interview (ER30283>0 and ER30284=0); main family nonresponse by 1979 or mover-out nonr'
             'esponse by 1978 (ER30283=0)'
   ;
   VALUE ER30287F
         1 = 'Spouse in couple numbered 1'
         2 = 'Spouse in couple numbered 2'
         3 = 'Spouse in couple numbered 3'
         0 = 'Inap.:  not married; spouse was not in FU at the time of the 1979 interview; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1979 interview (ER3028'
             '3>0 and ER30284=0); main family nonresponse by 1979 or mover-out nonresponse by 1978 (ER30283=0)'
   ;
   VALUE ER30288F
         1 = 'Moved in or born between the 1978 and 1979 interviews; splitoff in 1979'
         2 = 'Appeared; moved in by the time the 1978 interview was taken but not included in FU for 1978 (i.e., listing error)'
         5 = 'Moved out of FU or out of an institution between the 1978 and 1979 interviews and was not included in a 1979 panel FU'
         6 = 'Moved out of FU and into an institution between the 1978 and 1979 interviews'
         7 = 'Living in 1978 but died by the time of the 1979 interview'
         8 = 'Disappeared; moved out prior to the 1978 interview, but included in FU for 1978 (usually a listing error)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); in main family in both 1978 and 1979 (ER30247=1-20 and ER30284=1-20); in an institution in both 1978 and 1979 (ER30247'
             '=51-59 and ER30284=51-59); born or moved in after the 1979 interview (ER30283>0 and ER30284=0); main family nonresponse by 1979 or mover-out nonresponse by 1978 (ER30283=0)'
   ;
   VALUE ER30291F
    1 - 97 = 'Actual hours spent'
        98 = 'Ninety-eight hours per week or more'
        99 = 'NA; DK'
         0 = 'Inap.:  none; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1979 interview (ER30283>0 and ER30284=0); main family nonresponse by 1979 or mover-ou'
             't nonresponse by 1978 (ER30283=0); in an institution at time of 1979 interview or mover-out nonresponse from 1979 (ER30284=51-89)'
   ;
   VALUE ER30292F
         1 = 'This individual was respondent'
         5 = 'This individual was not respondent; includes institutionalized individuals and mover-out nonresponse from 1979 (ER30284=51-89)'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1979 interview (ER30283>0 and ER30284=0); main family nonresponse by 1979 or mover-out nonr'
             'esponse by 1978 (ER30283=0)'
   ;
   VALUE ER30293F
         1 = 'Working now'
         2 = 'Only temporarily laid off'
         3 = 'Looking for work, unemployed'
         4 = 'Retired'
         5 = 'Permanently disabled'
         6 = 'HouseWife; keeping house'
         7 = 'Student'
         8 = 'Other; mover-out nonresponse from 1979 only if deceased; NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); in institution in both 1978 and 1979 (ER30284=51-59 and ER30288=0); born or moved in after the 1979 interview (ER30283'
             '>0 and ER30284=0); main family nonresponse by 1979 or mover-out nonresponse by 1978 (ER30283=0); not a person aged 16 or older (ER30286=001-015)'
   ;
   VALUE ER30294F
         1 = 'Full-time student'
         3 = 'Part-time student'
         5 = 'Not enrolled in school'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); in institution in both 1978 and 1979 (ER30284=51-59 and ER30288=0); born or moved in after the 1979 interview (ER30283'
             '>0 and ER30284=0); main family nonresponse by 1979 or mover-out nonresponse by 1978 (ER30283=0); Head or Wife in 1979 (ER30284=1-20 and ER30285=1 or 02); not a person aged 16 or older (ER30286=001-015'
             ')'
   ;
   VALUE ER30295F
    1 - 52 = 'Actual number of weeks'
        98 = 'Don''t know'
        99 = 'NA'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); in institution in both 1978 and 1979 (ER30284=51-59 and ER30288=0); born or moved in after the 1979 interview (ER30283'
             '>0 and ER30284=0); main family nonresponse by 1979 or mover-out nonresponse by 1978 (ER30283=0); Head or Wife in 1979 (ER30284=1-20 and ER30285=1 or 02); not a person aged 16 or older (ER30286=001-015'
             '); not enrolled in school during 1978 (ER30294=5 or 9)'
   ;
   VALUE ER30296F
    1 - 17 = 'Highest grade or year of school completed'
        99 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1979 interview (ER30283>0 and ER30284=0); main family nonresponse by 1979 or mover-out nonr'
             'esponse by 1978 (ER30283=0); in institution in both 1978 and 1979 (ER30284=51-59 and ER30288=0); not a person aged 16 or older (ER30286=001-015)'
   ;
   VALUE ER30297F
         1 = 'Labor income only'
         2 = 'Asset income only'
         3 = 'Both labor and asset income'
         0 = 'Inap.:  no taxable income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1979 interview (ER30283>0 and ER30284=0); main family nonresponse by 197'
             '9 or mover-out nonresponse by 1978 (ER30283=0); in an institution in both 1978 and 1979 (ER30284=51-59 and ER30288=0)'
   ;
   VALUE ER30304F
         1 = 'ADC, AFDC only'
         2 = 'Supplemental Security Income (SSI) only'
         3 = 'Other welfare only'
         4 = 'Social Security only'
         5 = 'Other retirement pay, pensions, or annuities only'
         6 = 'Unemployment compensation only'
         7 = 'Worker compensation only'
         8 = 'Child support only'
         9 = 'Help from relatives only'
        10 = 'Other transfers only'
        15 = 'More than one of the above; any combination'
         0 = 'Inap.:  no transfer income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1979 interview (ER30283>0 and ER30284=0); main family nonresponse by 19'
             '79 or mover-out nonresponse by 1978 (ER30283=0); in an institution in both 1978 and 1979 (ER30284=51-59 and ER30288=0)'
   ;
   VALUE ER30310F
         1 = 'This sample member was 18 years old or older at the time of main family nonresponse and had been in the FU in 1978.'
         2 = 'This sample member was less than 18 at the time of main family nonresponse and had been in the FU in 1978.'
         3 = 'This nonsample individual had been in the 1978 FU, and this FU became nonresponse in 1979.'
         4 = 'This sample member had been in an institution in 1978 but his or her main family became nonresponse in 1979.'
         5 = 'This sample member, although connected with a 1979 response family, was in an institution at the time of the 1979 interview.'
         6 = 'This sample individual was 18 years old or older and moved out or died between the 1978 and 1979 interviews.'
         7 = 'This sample member was less than 18 and moved out or died between the 1978 and 1979 interviews.'
         8 = 'This nonsample individual moved out or died between the 1978 and 1979 interviews.'
         9 = 'This individual had not been born or moved in by the time of the 1979 interview; individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        10 = 'This individual had become nonresponse by the time of the 1978 interview.'
        99 = 'NA; DK'
         0 = 'Inap.:  in a panel family in 1979 (ER30284=1-20).'
   ;
   VALUE ER30311F
         1 = 'Wave refusal by all eligible/available FU members.'
         2 = 'No-one at home for contact during the interviewing period.'
         3 = 'Respondent absent; some FU member contacted, but not the appropriate respondent.'
         4 = 'Lost; unable to locate any member of the FU at all.'
         5 = 'FU is located too far away for interviewer contact.'
        11 = 'This individual was in the armed forces.'
        12 = 'This individual was in an educational institution.'
        13 = 'This individual was in a health care facility'
        14 = 'This individual was in jail or prison'
        19 = 'This individual was in some other type of institution, for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        21 = 'This individual was not eligible for the interview and the Head or the Wife, whichever is the sample member, became main family nonresponse because he/she was institutionalized by joining the armed fo'
             'rces.'
        22 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by entering an educational institution.'
        23 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized by entering a health care facil'
             'ity.'
        24 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized through imprisonment.'
        29 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by some means other than the above; for ex'
             'ample, he/she may have entered a religious order. Cases in which the type of institution is unknown are included here, also.'
        31 = 'This individual was unable to cooperate through disability.'
        32 = 'This individual was not eligible for the interview and the Head or Wife, whichever is sample, was unable to cooperate through disability.'
        41 = 'This individual died between the 1978 and 1979 interviews.'
        42 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, died.'
        51 = 'This individual, although followed for interview, was discovered to be nonsample: office error.'
        52 = 'This individual should have been followed but was not: office error.'
        53 = 'This individual was mistakenly included in two or more response families at once; this record is the duplicate, or erroneous, one.'
        54 = 'Listing error: this individual never existed or was not really living in the FU.'
        59 = 'Other office error'
        91 = 'This sample individual moved out of the 1979 main family and was eligible for interviewing but the reason for nonresponse is NA.'
        92 = 'Individual moved out of the 1979 main family and was not eligible for interviewing because he/she was either nonsample or too young.'
        93 = 'The Head or Wife of this FU, whichever is sample, united with another FU; this individual was not eligible for the interview and therefore became nonresponse.'
        97 = 'This individual had not been born or moved in by the time of the 1979 interview (ER30283>0 and ER30284=0); individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        98 = 'This individual became main family or mover-out nonresponse by 1978 (ER30246=0 and ER30283=0 or ER30246>0 and ER30247=71-89 and ER30283=0)'
        99 = 'NA; DK'
         0 = 'Inap.:  in a panel family in 1979 (ER30284=1-20)'
   ;
   VALUE ER30314F
    1 - 20 = 'Individuals in the family at the time of the 1980 interview'
   51 - 59 = 'Individuals in institutions at the time of the 1980 interview'
   71 - 80 = 'Individuals who moved out of the FU or out of institutions between the 1979 and 1980 interviews but who were not included in another responding FU for 1980. All such individuals were nonresponse.'
   81 - 89 = 'Individuals who were living in 1979 but who died by the time of the 1980 interview'
         0 = 'Inap.:  born or moved in after the 1980 interview; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1980 or mover-out nonresponse by 1979 (ER30313=0'
             ')'
   ;
   VALUE ER30315F
         1 = 'Head in 1980; 1979 Head who was mover-out nonresponse by the time of the 1980 interview'
         2 = 'Wife in 1980; 1979 Wife who was mover-out nonresponse by the time of the 1980 interview'
         3 = 'Son or daughter; includes stepchildren and adopted children'
         4 = 'Brother or sister of Head'
         5 = 'Mother or father of Head'
         6 = 'Grandchild or great-grandchild'
         7 = 'Other relative; includes in-laws'
         8 = 'Nonrelative'
         9 = 'Husband of Head (i.e., Wife was Head of FU)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1980 interview (ER30313>0 and ER30314=0); main family nonresponse by 1980 or mover-out nonr'
             'esponse by 1979 (ER30313=0)'
   ;
   VALUE ER30317F
         1 = 'Spouse in couple numbered 1'
         2 = 'Spouse in couple numbered 2'
         3 = 'Spouse in couple numbered 3'
         0 = 'Inap.:  not married; spouse was not in FU at the time of the 1980 interview; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1980 interview (ER3031'
             '3>0 and ER30314=0); main family nonresponse by 1980 or mover-out nonresponse by 1979 (ER30313=0)'
   ;
   VALUE ER30318F
         1 = 'Moved in or born between the 1979 and 1980 interviews; splitoff in 1980'
         2 = 'Appeared; moved in by the time the 1979 interview was taken but not included in FU for 1979 (i.e., listing error)'
         5 = 'Moved out of FU or out of an institution between the 1979 and 1980 interviews and was not included in a 1980 panel FU.'
         6 = 'Moved out of FU and into an institution between the 1979 and 1980 interviews'
         7 = 'Living in 1979 but died by the time of the 1980 interview'
         8 = 'Disappeared; moved out prior to the 1979 interview, but included in FU for 1979 (usually a listing error)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); in main family in both 1979 and 1980 (ER30284=1-20 and ER30314=1-20); in an institution in both 1979 and 1980 (ER30284'
             '=51-59 and ER30314=51-59); born or moved in after the 1980 interview (ER30313>0 and ER30314=0); main family nonresponse by 1980 or mover-out nonresponse by 1979 (ER30313=0)'
   ;
   VALUE ER30321F
    1 - 97 = 'Actual hours spent'
        98 = 'Ninety-eight hours per week or more'
        99 = 'NA; DK'
         0 = 'Inap.:  none; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1980 interview (ER30313>0 and ER30314=0); main family nonresponse by 1980 or mover-ou'
             't nonresponse by 1979 (ER30313=0); in an institution at time of 1980 interview or mover-out nonresponse from 1980 (ER30314=51-89)'
   ;
   VALUE ER30322F
         1 = 'This individual was respondent'
         5 = 'This individual was not respondent; includes institutionalized individuals and mover-out nonresponse from 1980 (ER30314=51-89)'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1980 interview (ER30313>0 and ER30314=0); main family nonresponse by 1980 or mover-out nonr'
             'esponse by 1979 (ER30313=0)'
   ;
   VALUE ER30323F
         1 = 'Working now'
         2 = 'Only temporarily laid off'
         3 = 'Looking for work, unemployed'
         4 = 'Retired'
         5 = 'Permanently disabled'
         6 = 'HouseWife; keeping house'
         7 = 'Student'
         8 = 'Other'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1980 interview (ER30313>0 and ER30314=0); main family nonresponse by 1980 or mover-out nonr'
             'esponse by 1979 (ER30313=0); mover-out nonresponse for 1980 only if deceased (ER30314=81-89); in an institution in both 1979 and 1980 (ER30314=51-59 and ER30318=0); not a person aged 16 or older (ER30'
             '316=001-015)'
   ;
   VALUE ER30324F
         1 = 'Full-time student'
         3 = 'Part-time student'
         5 = 'Not enrolled in school'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1980 interview (ER30313>0 and ER30314=0); main family nonresponse by 1980 or mover-out nonr'
             'esponse by 1979 (ER30313=0); Head or Wife in 1980 (ER30314=1-20 and ER30315=1 or 02); in an institution in both 1979 and 1980 (ER30314=51-59 and ER30318=0); not a person aged 16 or older (ER30316=001-'
             '015)'
   ;
   VALUE ER30325F
    1 - 52 = 'Actual number of weeks'
        98 = 'DK'
        99 = 'NA'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1980 interview (ER30313>0 and ER30314=0); main family nonresponse by 1980 or mover-out nonr'
             'esponse by 1979 (ER30313=0); Head or Wife in 1980 (ER30314=1-20 and ER30315=1 or 02); in an institution in both 1979 and 1980 (ER30314=51-59 and ER30318=0); not a person aged 16 or older (ER30316=001-'
             '015); not enrolled in school during 1979 (ER30324=5 or 9)'
   ;
   VALUE ER30326F
    1 - 17 = 'Highest grade or year of school completed'
        99 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1980 interview (ER30313>0 and ER30314=0); main family nonresponse by 1980 or mover-out nonr'
             'esponse by 1979 (ER30313=0); in an institution in both 1979 and 1980 (ER30314=51-59 and ER30318=0); not a person aged 16 or older (ER30316=001-015)'
   ;
   VALUE ER30327F
         1 = 'Labor income only'
         2 = 'Asset income only'
         3 = 'Both labor and asset income'
         0 = 'Inap.:  no taxable income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1980 interview (ER30313>0 and ER30314=0); main family nonresponse by 198'
             '0 or mover-out nonresponse by 1979 (ER30313=0); in an institution in both 1979 and 1980 (ER30314=51-59 and ER30318=0)'
   ;
   VALUE ER30334F
         1 = 'ADC, AFDC only'
         2 = 'Supplemental Security Income (SSI) only'
         3 = 'Other welfare only'
         4 = 'Social Security only'
         5 = 'Other retirement pay, pensions, or annuities only'
         6 = 'Unemployment compensation only'
         7 = 'Worker compensation only'
         8 = 'Child support only'
         9 = 'Help from relatives only'
        10 = 'Other transfers only'
        15 = 'More than one of the above; any combination'
         0 = 'Inap.:  no transfer income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1980 interview (ER30313>0 and ER30314=0); main family nonresponse by 19'
             '80 or mover-out nonresponse by 1979 (ER30313=0); in an institution in both 1979 and 1980 (ER30314=51-59 and ER30318=0)'
   ;
   VALUE ER30340F
         1 = 'This sample member was 18 years old or older at the time of main family nonresponse and had been in the FU in 1979.'
         2 = 'This sample member was less than 18 at the time of main family nonresponse and had been in the FU in 1979.'
         3 = 'This nonsample individual had been in the 1979 FU, and this FU became nonresponse in 1980.'
         4 = 'This sample member had been in an institution in 1979 but his or her main family became nonresponse in 1980.'
         5 = 'This sample member, although connected with a 1980 response family, was in an institution at the time of the 1980 interview.'
         6 = 'This sample individual was 18 years old or older and moved out or died between the 1979 and 1980 interviews.'
         7 = 'This sample member was less than 18 and moved out or died between the 1979 and 1980 interviews.'
         8 = 'This nonsample individual moved out or died between the 1979 and 1980 interviews.'
         9 = 'This individual had not been born or moved in by the time of the 1980 interview; individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        10 = 'This individual had become nonresponse by the time of the 1979 interview.'
        99 = 'NA; DK'
         0 = 'Inap.:  in a panel family in 1980 (ER30314=1-20).'
   ;
   VALUE ER30341F
         1 = 'Wave refusal by all eligible/available FU members.'
         2 = 'No-one at home for contact during the interviewing period.'
         3 = 'Respondent absent; some FU member contacted, but not the appropriate respondent.'
         4 = 'Lost; unable to locate any member of the FU at all.'
         5 = 'FU is located too far away for interviewer contact.'
        11 = 'This individual was in the armed forces.'
        12 = 'This individual was in an educational institution.'
        13 = 'This individual was in a health care facility'
        14 = 'This individual was in jail or prison'
        19 = 'This individual was in some other type of institution, for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        21 = 'This individual was not eligible for the interview and the Head or the Wife, whichever is the sample member, became main family nonresponse because he/she was institutionalized by joining the armed fo'
             'rces.'
        22 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by entering an educational institution.'
        23 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized by entering a health care facil'
             'ity.'
        24 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized through imprisonment.'
        29 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by some means other than the above; for ex'
             'ample, he/she may have entered a religious order. Cases in which the type of institution is unknown are included here, also.'
        31 = 'This individual was unable to cooperate through disability.'
        32 = 'This individual was not eligible for the interview and the Head or Wife, whichever is sample, was unable to cooperate through disability.'
        41 = 'This individual died between the 1979 and 1980 interviews.'
        42 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, died.'
        51 = 'This individual, although followed for interview, was discovered to be nonsample: office error.'
        52 = 'This individual should have been followed but was not: office error.'
        53 = 'This individual was mistakenly included in two or more response families at once; this record is the duplicate, or erroneous, one.'
        54 = 'Listing error: this individual never existed or was not really living in the FU.'
        59 = 'Other office error'
        91 = 'This sample individual moved out of the 1980 main family and was eligible for interviewing but the reason for nonresponse is NA.'
        92 = 'Individual moved out of the 1980 main family and was not eligible for interviewing because he/she was either nonsample or too young.'
        93 = 'The Head or Wife of this FU, whichever is sample, united with another FU; this individual was not eligible for the interview and therefore became nonresponse.'
        97 = 'This individual had not been born or moved in by the time of the 1980 interview (ER30313>0 and ER30314=0); individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        98 = 'This individual became main family or mover-out nonresponse by 1979 (ER30283=0 and ER30313=0 or ER30283>0 and ER30284=71-89 and ER30313=0)'
        99 = 'NA; DK'
         0 = 'Inap.:  in a panel family in 1980 (ER30314=1-20)'
   ;
   VALUE ER30344F
    1 - 20 = 'Individuals in the family at the time of the 1981 interview'
   51 - 59 = 'Individuals in institutions at the time of the 1981 interview'
   71 - 80 = 'Individuals who moved out of the FU or out of institutions between the 1980 and 1981 interviews but who were not included in another responding FU for 1981. All such individuals were nonresponse.'
   81 - 89 = 'Individuals who were living in 1980 but who died by the time of the 1981 interview'
         0 = 'Inap.:  born or moved in after the 1981 interview; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1981 or splitoff nonresponse by 1980 (ER30343=0)'
             ' '
   ;
   VALUE ER30345F
         1 = 'Head in 1981; 1980 Head who was mover-out nonresponse by the time of the 1981 interview'
         2 = 'Wife in 1981; 1980 Wife who was mover-out nonresponse by the time of the 1981 interview'
         3 = 'Son or daughter; includes stepchildren and adopted children'
         4 = 'Brother or sister of Head'
         5 = 'Father or mother of Head'
         6 = 'Grandchild or great-grandchild'
         7 = 'Other relative; includes in-laws'
         8 = 'Nonrelative'
         9 = 'Husband of Head (i.e., Wife was Head of FU)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1981 interview (ER30343>0 and ER30344=0); main family nonresponse by 1981 or mover-out nonr'
             'esponse by 1980 (ER30343=0)'
   ;
   VALUE ER30347F
         1 = 'Spouse in couple numbered 1'
         2 = 'Spouse in couple numbered 2'
         3 = 'Spouse in couple numbered 3'
         0 = 'Inap.:  not married; spouse was not in FU at the time of the 1981 interview; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1981 interview (ER3034'
             '3>0 and ER30344=0); main family nonresponse by 1981 or mover-out nonresponse by 1980 (ER30343=0)'
   ;
   VALUE ER30348F
         1 = 'Moved in or born between the 1980 and 1981 interviews; splitoff in 1981'
         2 = 'Appeared; moved in by the time the 1980 interview was taken but not included in FU for 1980 (i.e., listing error)'
         5 = 'Moved out of FU or out of an institution between the 1980 and 1981 interviews and was not included in a 1981 panel FU'
         6 = 'Moved out of FU and into an institution between the 1980 and 1981 interviews'
         7 = 'Living in 1980 but died by the time of the 1981 interview'
         8 = 'Disappeared; moved out prior to the 1980 interview, but included in FU for 1980 (usually a listing error)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); in main family in both 1980 and 1981 (ER30314=1-20 and ER30344=1-20); in an institution in both 1980 and 1981 (ER30314'
             '=51-59 and ER30344=51-59); born or moved in after the 1981 interview (ER30343>0 and ER30344=0); main family nonresponse by 1981 or mover-out nonresponse by 1980 (ER30343=0)'
   ;
   VALUE ER30351F
    1 - 97 = 'Actual hours spent'
        98 = 'Ninety-eight hours per week or more'
        99 = 'NA; DK'
         0 = 'Inap.:  none; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1981 interview (ER30343>0 and ER30344=0); main family nonresponse by 1981 or mover-ou'
             't nonresponse by 1980 (ER30343=0); in an institution at time of 1981 interview or mover-out nonresponse from 1981 (ER30344=51-89)'
   ;
   VALUE ER30352F
         1 = 'This individual was respondent'
         5 = 'This individual was not respondent; includes institutionalized individuals and mover-out nonresponse from 1981 (ER30344=51-89)'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1981 interview (ER30343>0 and ER30344=0); main family nonresponse by 1981 or mover-out nonr'
             'esponse by 1980 (ER30343=0)'
   ;
   VALUE ER30353F
         1 = 'Working now'
         2 = 'Only temporarily laid off'
         3 = 'Looking for work, unemployed'
         4 = 'Retired'
         5 = 'Permanently disabled'
         6 = 'HouseWife; keeping house'
         7 = 'Student'
         8 = 'Other'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1981 interview (ER30343>0 and ER30344=0); main family nonresponse by 1981 or mover-out nonr'
             'esponse by 1980 (ER30343=0); mover-out nonresponse for 1981 only if deceased (ER30344=81-89); in an institution in both 1980 and 1981 (ER30344=51-59 and ER30348=0); not a person aged 16 or older (ER30'
             '346=001-015)'
   ;
   VALUE ER30354F
         1 = 'Full-time student'
         3 = 'Part-time student'
         5 = 'Not enrolled in school'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1981 interview (ER30343>0 and ER30344=0); main family nonresponse by 1981 or mover-out nonr'
             'esponse by 1980 (ER30343=0); in an institution in both 1980 and 1981 (ER30344=51-59 and ER30348=0); Head or Wife in 1981 (ER30344=1-20 and ER30345=1 or 02); not a person aged 16 or older (ER30346=001-'
             '015)'
   ;
   VALUE ER30355F
    1 - 52 = 'Actual number of weeks'
        98 = 'Don''t know'
        99 = 'NA'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1981 interview (ER30343>0 and ER30344=0); main family nonresponse by 1981 or mover-out nonr'
             'esponse by 1980 (ER30343=0); Head or Wife in 1981 (ER30344=1-20 and ER30345=1 or 02); in an institution in both 1980 and 1981 (ER30344=51-59 and ER30348=0); not a person aged 16 or older (ER30346=001-'
             '015); not enrolled in school during 1980 (ER30354=5 or 9)'
   ;
   VALUE ER30356F
    1 - 17 = 'Highest grade or year of school completed'
        99 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1981 interview (ER30343>0 and ER30344=0); main family nonresponse by 1981 or mover-out nonr'
             'esponse by 1980 (ER30343=0); in an institution in both 1980 and 1981 (ER30344=51-59 and ER30348=0); not a person aged 16 or older (ER30346=001-015)'
   ;
   VALUE ER30357F
         1 = 'Labor income only'
         2 = 'Asset income only'
         3 = 'Both labor and asset income'
         0 = 'Inap.:  no taxable income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1981 interview (ER30343>0 and ER30344=0); main family nonresponse by 198'
             '1 or mover-out nonresponse by 1980 (ER30343=0); in an institution in both 1980 and 1981 (ER30344=51-59 and ER30348=0)'
   ;
   VALUE ER30364F
         1 = 'ADC, AFDC only'
         2 = 'Supplemental Security Income (SSI) only'
         3 = 'Other welfare only'
         4 = 'Social Security only'
         5 = 'Other retirement pay, pensions, or annuities only'
         6 = 'Unemployment compensation only'
         7 = 'Worker compensation only'
         8 = 'Child support only'
         9 = 'Help from relatives only'
        10 = 'Other transfers only'
        15 = 'More than one of the above; any combination'
         0 = 'Inap.:  no transfer income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1981 interview (ER30343>0 and ER30344=0); main family nonresponse by 19'
             '81 or mover-out nonresponse by 1980 (ER30343=0); in an institution in both 1980 and 1981 (ER30344=51-59 and ER30348=0)'
   ;
   VALUE ER30370F
         1 = 'This sample member was 18 years old or older at the time of main family nonresponse and had been in the FU in 1980.'
         2 = 'This sample member was less than 18 at the time of main family nonresponse and had been in the FU in 1980.'
         3 = 'This nonsample individual had been in the 1980 FU, and this FU became nonresponse in 1981.'
         4 = 'This sample member had been in an institution in 1980 but his or her main family became nonresponse in 1981.'
         5 = 'This sample member, although connected with a 1981 response family, was in an institution at the time of the 1981 interview.'
         6 = 'This sample individual was 18 years old or older and moved out or died between the 1980 and 1981 interviews.'
         7 = 'This sample member was less than 18 and moved out or died between the 1980 and 1981 interviews.'
         8 = 'This nonsample individual moved out or died between the 1980 and 1981 interviews.'
         9 = 'This individual had not been born or moved in by the time of the 1981 interview; individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        10 = 'This individual had become nonresponse by the time of the 1980 interview.'
        99 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); in a panel family in 1981 (ER30344=1-20).'
   ;
   VALUE ER30371F
         1 = 'Wave refusal by all eligible/available FU members.'
         2 = 'No-one at home for contact during the interviewing period.'
         3 = 'Respondent absent; some FU member contacted, but not the appropriate respondent.'
         4 = 'Lost; unable to locate any member of the FU at all.'
         5 = 'FU is located too far away for interviewer contact.'
        11 = 'This individual was in the armed forces.'
        12 = 'This individual was in an educational institution.'
        13 = 'This individual was in a health care facility'
        14 = 'This individual was in jail or prison'
        19 = 'This individual was in some other type of institution, for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        21 = 'This individual was not eligible for the interview and the Head or the Wife, whichever is the sample member, became main family nonresponse because he/she was institutionalized by joining the armed fo'
             'rces.'
        22 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by entering an educational institution.'
        23 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized by entering a health care facil'
             'ity.'
        24 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized through imprisonment.'
        29 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by some means other than the above; for ex'
             'ample, he/she may have entered a religious order. Cases in which the type of institution is unknown are included here, also.'
        31 = 'This individual was unable to cooperate through disability.'
        32 = 'This individual was not eligible for the interview and the Head or Wife, whichever is sample, was unable to cooperate through disability.'
        41 = 'This individual died between the 1980 and 1981 interviews.'
        42 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, died.'
        51 = 'This individual, although followed for interview, was discovered to be nonsample: office error.'
        52 = 'This individual should have been followed but was not: office error.'
        53 = 'This individual was mistakenly included in two or more response families at once; this record is the duplicate, or erroneous, one.'
        54 = 'Listing error: this individual never existed or was not really living in the FU.'
        59 = 'Other office error'
        91 = 'This sample individual moved out of the 1981 main family and was eligible for interviewing but the reason for nonresponse is NA.'
        92 = 'Individual moved out of the 1981 main family and was not eligible for interviewing because he/she was either nonsample or too young.'
        93 = 'The Head or Wife of this FU, whichever is sample, united with another FU; this individual was not eligible for the interview and therefore became nonresponse.'
        97 = 'This individual had not been born or moved in by the time of the 1981 interview (ER30343>0 and ER30344=0)'
        98 = 'This individual became main family or mover-out nonresponse by 1980 (ER30313=0 and ER30343=0 or ER30313>0 and ER30314=71-89 and ER30343=0)'
        99 = 'NA; DK'
         0 = 'Inap.:  in a panel family in 1981 (ER30344=1-20)'
   ;
   VALUE ER30374F
    1 - 20 = 'Individuals in the family at the time of the 1982 interview'
   51 - 59 = 'Individuals in institutions at the time of the 1982 interview'
   71 - 80 = 'Individuals who moved out of the FU or out of institutions between the 1981 and 1982 interviews but who were not included in another responding FU for 1982. All such individuals were nonresponse.'
   81 - 89 = 'Individuals who were living in 1981 but died by the time of the 1982 interview'
         0 = 'Inap.:  born or moved in after the 1982 interview; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1982 or mover-out nonresponse by 1981 (ER30373=0'
             ')'
   ;
   VALUE ER30375F
         1 = 'Head in 1982; 1981 Head who was mover-out nonresponse by the time of the 1982 interview'
         2 = 'Wife in 1982; 1981 Wife who was mover-out nonresponse by the time of the 1982 interview'
         3 = 'Son or daughter; includes stepchildren and adopted children'
         4 = 'Brother or sister of Head'
         5 = 'Father or mother of Head'
         6 = 'Grandchild or great-grandchild'
         7 = 'Other relative; includes in-laws'
         8 = 'Nonrelative'
         9 = 'Husband of Head (i.e., Wife was Head of FU)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1982 interview (ER30373>0 and ER30374=0); main family nonresponse by 1982 or mover-out nonr'
             'esponse by 1981 (ER30373=0)'
   ;
   VALUE ER30377F
         1 = 'Spouse in couple numbered 1'
         2 = 'Spouse in couple numbered 2'
         3 = 'Spouse in couple numbered 3'
         0 = 'Inap.:  not married; spouse was not in FU at the time of the 1982 interview; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1982 interview (ER3037'
             '3>0 and ER30374=0); main family nonresponse by 1982 or mover-out nonresponse by 1981 (ER30373=0)'
   ;
   VALUE ER30378F
         1 = 'Moved in or born between the 1981 and 1982 interviews; splitoff in 1982'
         2 = 'Appeared; moved in by the time the 1981 interview was taken but not included in FU for 1981 (i.e., listing error)'
         5 = 'Moved out of FU or out of an institution between the 1981 and 1982 interviews and was not included in a 1982 panel FU'
         6 = 'Moved out of FU and into an institution between the 1981 and 1982 interviews'
         7 = 'Living in 1981 but died by the time of the 1982 interview'
         8 = 'Disappeared; moved out prior to the 1981 interview, but included in FU for 1981 (usually a listing error)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); in main family in both 1981 and 1982 (ER30344=1-20 and ER30374=1-20); in an institution in both 1981 and 1982 (ER30344'
             '=51-59 and ER30374=51-59); born or moved in after the 1982 interview (ER30373>0 and ER30374=0); main family nonresponse by 1982 or mover-out nonresponse by 1981 (ER30373=0)'
   ;
   VALUE ER30381F
         1 = 'This individual was respondent'
         5 = 'This individual was not respondent; includes institutionalized individuals and mover-out nonresponse from 1982 (ER30374=51-89)'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1982 interview (ER30373>0 and ER30374=0); main family nonresponse by 1982 or mover-out nonr'
             'esponse by 1981 (ER30373=0)'
   ;
   VALUE ER30382F
         1 = 'Working now'
         2 = 'Only temporarily laid off'
         3 = 'Looking for work, unemployed'
         4 = 'Retired'
         5 = 'Permanently disabled'
         6 = 'HouseWife; keeping house'
         7 = 'Student'
         8 = 'Other'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1982 interview (ER30373>0 and ER30374=0); main family nonresponse by 1982 or mover-out nonr'
             'esponse by 1981 (ER30373=0); mover-out nonresponse for 1982 only if deceased (ER30374=81-89); in an institution in both 1981 and 1982 (ER30374=51-59 and ER30378=0); not a person aged 16 or older (ER30'
             '376=001-015)'
   ;
   VALUE ER30383F
         1 = 'Full-time student'
         3 = 'Part-time student'
         5 = 'Not enrolled in school'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1982 interview (ER30373>0 and ER30374=0); main family nonresponse by 1982 or mover-out nonr'
             'esponse by 1981 (ER30373=0); Head or Wife in 1982 (ER30374=1-20 and ER30375=1 or 02); in an institution in both 1981 and 1982 (ER30374=51-59 and ER30378=0); not a person aged 16 or older (ER30376=001-'
             '015)'
   ;
   VALUE ER30384F
    1 - 17 = 'Highest grade or year of school completed'
        99 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1982 interview (ER30373>0 and ER30374=0); main family nonresponse by 1982 or mover-out nonr'
             'esponse by 1981 (ER30373=0); in an institution in both 1981 and 1982 (ER30374=51-59 and ER30378=0); not a person aged 16 or older (ER30376=001-015)'
   ;
   VALUE ER30385F
         1 = 'Labor income'
         2 = 'Asset income'
         3 = 'Both labor and asset income'
         0 = 'Inap.:  no taxable income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1982 interview (ER30373>0 and ER30374=0); main family nonresponse by 198'
             '2 or mover-out nonresponse by 1981 (ER30373=0); in institution in both 1981 and 1982 (ER30374=51-59 and ER30378=0)'
   ;
   VALUE ER30390F
         1 = 'ADC, AFDC only'
         2 = 'Supplemental Security Income, SSI only'
         3 = 'Other Welfare only'
         4 = 'Social Security only'
         5 = 'Other retirement pay, pensions, or annuities only'
         6 = 'Unemployment compensation only'
         7 = 'Worker compensation only'
         8 = 'Child support only'
         9 = 'Help from relatives only'
        10 = 'Other transfers only'
        11 = 'This code value is erroneous'
        15 = 'More than one of the above; any combination'
         0 = 'Inap.:  no transfer income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1982 interview (ER30373>0 and ER30374=0); main family nonresponse by 19'
             '82 or mover-out nonresponse by 1981 (ER30373=0); in an institution in both 1981 and 1982 (ER30374=51-59 and ER30378=0)'
   ;
   VALUE ER30396F
         1 = 'This sample member was 18 years old or older at the time of main family nonresponse and had been in the FU in 1981.'
         2 = 'This sample member was less than 18 at the time of main family nonresponse and had been in the FU in 1981.'
         3 = 'This nonsample individual had been in the 1981 FU, and this FU became nonresponse in 1982.'
         4 = 'This sample member had been in an institution in 1981 but his or her main family became nonresponse in 1982.'
         5 = 'This sample member, although connected with a 1982 response family, was in an institution at the time of the 1982 interview.'
         6 = 'This sample individual was 18 years old or older and moved out or died between the 1981 and 1982 interviews.'
         7 = 'This sample member was less than 18 and moved out or died between the 1981 and 1982 interviews.'
         8 = 'This nonsample individual moved out or died between the 1981 and 1982 interviews.'
         9 = 'This individual had not been born or moved in by the time of the 1982 interview; individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        10 = 'This individual had become nonresponse by the time of the 1981 interview.'
        99 = 'NA; DK'
         0 = 'Inap.:  in a panel family in 1982 (ER30374=1-20).'
   ;
   VALUE ER30397F
         1 = 'Wave refusal by all eligible/available FU members.'
         2 = 'No-one at home for contact during the interviewing period.'
         3 = 'Respondent absent; some FU member contacted, but not the appropriate respondent.'
         4 = 'Lost; unable to locate any member of the FU at all.'
         5 = 'FU is located too far away for interviewer contact.'
        11 = 'This individual was in the armed forces.'
        12 = 'This individual was in an educational institution.'
        13 = 'This individual was in a health care facility'
        14 = 'This individual was in jail or prison'
        19 = 'This individual was in some other type of institution, for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        21 = 'This individual was not eligible for the interview and the Head or the Wife, whichever is the sample member, became main family nonresponse because he/she was institutionalized by joining the armed fo'
             'rces.'
        22 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by entering an educational institution.'
        23 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized by entering a health care facil'
             'ity.'
        24 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized through imprisonment.'
        29 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by some means other than the above; for ex'
             'ample, he/she may have entered a religious order. Cases in which the type of institution is unknown are included here, also.'
        31 = 'This individual was unable to cooperate through disability.'
        32 = 'This individual was not eligible for the interview and the Head or Wife, whichever is sample, was unable to cooperate through disability.'
        41 = 'This individual died between the 1981 and 1982 interviews.'
        42 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, died.'
        51 = 'This individual, although followed for interview, was discovered to be nonsample: office error.'
        52 = 'This individual should have been followed but was not: office error.'
        53 = 'This individual was mistakenly included in two or more response families at once; this record is the duplicate, or erroneous, one.'
        54 = 'Listing error: this individual never existed or was not really living in the FU.'
        59 = 'Other office error'
        91 = 'This sample individual moved out of the 1982 main family and was eligible for interviewing but the reason for nonresponse is NA.'
        92 = 'Individual moved out of the 1982 main family and was not eligible for interviewing because he/she was either nonsample or too young.'
        93 = 'The Head or Wife of this FU, whichever is sample, united with another FU; this individual was not eligible for the interview and therefore became nonresponse.'
        97 = 'This individual had not been born or moved in by the time of the 1982 interview (ER30373>0 and ER30374=0); individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        98 = 'This individual became main family or mover-out nonresponse by 1981 (ER30343=0 and ER30373=0 or ER30343>0 and ER30344=71-89 and ER30373=0)'
        99 = 'NA; DK'
         0 = 'Inap.:  in a panel family in 1982 (ER30374=1-20)'
   ;
   VALUE ER30400F
    1 - 20 = 'Individuals in the family at the time of the 1983 interview'
   51 - 59 = 'Individuals in institutions at the time of the 1983 interview'
   71 - 80 = 'Individuals who moved out of the FU or out of institutions between the 1982 and 1983 interviews but who were not included in another responding FU for 1983. All such individuals were nonresponse.'
   81 - 89 = 'Individuals who were living in 1982 but died by the time of the 1983 interview'
         0 = 'Inap.:  born or moved in after the 1983 interview; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1983 or mover-out nonresponse by 1982 (ER30399=0'
             ')'
   ;
   VALUE ER30401F
        10 = 'Head in 1983; 1982 Head who was mover-out nonresponse by the time of the 1983 interview'
        20 = 'Legal Wife in 1983; 1982 Wife who was mover-out nonresponse by the time of the 1983 interview'
        22 = '"Wife"--female cohabitor who has lived with Head for 12 months or more or who was present in the 1981 family, since consecutive interviews may be taken less or more than twelve months apart; 1982 "Wif'
             'e" who was mover-out nonresponse by the time of the 1983 interview'
        30 = 'Son or daughter of Head (includes adopted children but not stepchildren)'
        33 = 'Stepson or stepdaughter of Head (children of legal Wife (code 20) who are not children of Head)'
        35 = 'Son or daughter of "Wife" but not Head (includes only those children of mothers whose relationship to Head is 22 but who are not children of Head)'
        37 = 'Son-in-law or daughter-in-law of Head (includes stepchildren-in-law)'
        38 = 'Foster son or foster daughter, not legally adopted'
        40 = 'Brother or sister of Head (includes step and half sisters and brothers)'
        47 = 'Brother-in-law or sister-in-law of Head; i.e., brother or sister of legal Wife, or spouse of Head''s brother or sister.'
        48 = 'Brother or sister of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        50 = 'Father or mother of Head (includes stepparents)'
        57 = 'Father-in-law or mother-in-law of Head (includes parents of legal wives (code 20) only)'
        58 = 'Father or mother of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        60 = 'Grandson or granddaughter of Head (includes grandchildren of legal Wife (code 20),  but those of a cohabitor are coded 97)'
        65 = 'Great-grandson or great-granddaughter of Head (includes great-grandchildren of legal Wife (code 20), but those of a cohabitor are coded 97)'
        66 = 'Grandfather or grandmother of Head (includes stepgrandparents)'
        67 = 'Grandfather or grandmother of legal Wife (code 20)'
        68 = 'Great-grandfather or great-grandmother of Head'
        69 = 'Great-grandfather or great-grandmother of legal Wife (code 20)'
        70 = 'Nephew or niece of Head'
        71 = 'Nephew or niece of legal Wife (code 20)'
        72 = 'Uncle or Aunt of Head'
        73 = 'Uncle or Aunt of legal Wife (code 20)'
        74 = 'Cousin of Head'
        75 = 'Cousin of legal Wife (code 20)'
        83 = 'Children of first-year cohabitor but not of Head (the parent of this child is coded 88)'
        88 = 'First-year cohabitor of Head'
        90 = 'Legal husband of Head'
        95 = 'Other relative of Head'
        96 = 'Other relative of legal Wife (code 20)'
        97 = 'Other relative of cohabitor (the cohabitor is code 22 or 88)'
        98 = 'Other nonrelatives (includes homosexual partners, friends of children of the FU, etc.)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1983 interview (ER30399>0 and ER30400=0); main family nonresponse by 1983 or mover-out nonr'
             'esponse by 1982 (ER30399=0)'
   ;
   VALUE ER30405F
         1 = 'Spouse in couple numbered 1'
         2 = 'Spouse in couple numbered 2'
         3 = 'Spouse in couple numbered 3'
         0 = 'Inap.:  not married or permanently cohabiting; spouse was not in FU at the time of the 1983 interview; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after'
             'the 1983 interview (ER30399>0 and ER30400=0); main family nonresponse by 1983 or mover-out nonresponse by 1982 (ER30399=0)'
   ;
   VALUE ER30406F
         1 = 'Moved in or born between the 1982 and 1983 interviews; splitoff in 1983'
         2 = 'Appeared; moved in by the time the 1982 interview was taken but not included in FU for 1982 (i.e., listing error)'
         5 = 'Moved out of FU or out of an institution between the 1982 and 1983 interviews and was not included in a 1983 panel FU'
         6 = 'Moved out of FU and into an institution between the 1982 and 1983 interviews'
         7 = 'Living in 1982 but died by the time of the 1983 interview'
         8 = 'Disappeared; moved out prior to the 1982 interview, but included in FU for 1982 (usually a listing error)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); in main family in both 1982 and 1983 (ER30374=1-20 and ER30400=1-20); in an institution in both 1982 and 1983 (ER30374'
             '=51-59 and ER30400=51-59); born or moved in after the 1983 interview (ER30399>0 and ER30400=0); main family nonresponse by 1983 or mover-out nonresponse by 1982 (ER30399=0)'
   ;
   VALUE ER30409F
    1 - 97 = 'Actual hours spent'
        98 = 'Ninety-eight hours per week or more'
        99 = 'NA; DK'
         0 = 'Inap.:  none; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1983 interview (ER30399>0 and ER30400=0); main family nonresponse by 1983 or mover-ou'
             't nonresponse by 1982 (ER30399=0); in an institution or mover-out nonresponse for 1983 (ER30400=51-89)'
   ;
   VALUE ER30410F
         1 = 'This individual was respondent'
         5 = 'This individual was not respondent; includes institutionalized individuals and mover-out nonresponse from 1983 (ER30400=51-89)'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1983 interview (ER30399>0 and ER30400=0); main family nonresponse by 1983 or mover-out nonr'
             'esponse by 1982 (ER30399=0)'
   ;
   VALUE ER30411F
         1 = 'Working now'
         2 = 'Only temporarily laid off'
         3 = 'Looking for work, unemployed'
         4 = 'Retired'
         5 = 'Permanently disabled'
         6 = 'HouseWife; keeping house'
         7 = 'Student'
         8 = 'Other'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1983 interview (ER30399>0 and ER30400=0); main family nonresponse by 1983 or mover-out nonr'
             'esponse by 1982 (ER30399=0); mover-out nonresponse for 1983 only if deceased (ER30400=81-89); in an institution in both 1982 and 1983 (ER30400=51-59 and ER30406=0); not a person aged 16 or older (ER30'
             '402=001-015)'
   ;
   VALUE ER30412F
         1 = 'Full-time student'
         3 = 'Part-time student'
         5 = 'Not enrolled in school'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1983 interview (ER30399>0 and ER30400=0); main family nonresponse by 1983 or mover-out nonr'
             'esponse by 1982 (ER30399=0); Head or Wife/"Wife" in 1983 (ER30400=1-20 and ER30401=10, 20 or 22); in an institution in both 1982 and 1983 (ER30400=51-59 and ER30406=0); not a person aged 16 or older ('
             'ER30402=001-015)'
   ;
   VALUE ER30413F
    1 - 17 = 'Highest grade or year of school completed'
        99 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1983 interview (ER30399>0 and ER30400=0); main family nonresponse by 1983 or mover-out nonr'
             'esponse by 1982 (ER30399=0); in an institution in both 1982 and 1983 (ER30400=51-59 and ER30406=0); not a person aged 16 or older (ER30402=001-015)'
   ;
   VALUE ER30414F
         1 = 'Labor income'
         2 = 'Asset income'
         3 = 'Both labor and asset income'
         0 = 'Inap.:  no taxable income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1983 interview (ER30399>0 and ER30400=0); main family nonresponse by 198'
             '3 or mover-out nonresponse by 1982 (ER30399=0); in an institution in both 1982 and 1983 (ER30400=51-59 and ER30406=0)'
   ;
   VALUE ER30419F
         1 = 'ADC, AFDC only'
         2 = 'Supplemental Security Income, SSI only'
         3 = 'Other Welfare only'
         4 = 'Social Security only'
         5 = 'Other retirement pay, pensions, or annuities only'
         6 = 'Unemployment compensation only'
         7 = 'Worker compensation only'
         8 = 'Child support only'
         9 = 'Help from relatives only'
        10 = 'Other transfers only'
        15 = 'More than one of the above; any combination'
         0 = 'Inap.:  no transfer income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1983 interview (ER30399>0 and ER30400=0); main family nonresponse by 19'
             '83 or mover-out nonresponse by 1982 (ER30399=0); in an institution in both 1982 and 1983 (ER30400=51-59 and ER30406=0)'
   ;
   VALUE ER30426F
         1 = 'This sample member was 18 years old or older at the time of main family nonresponse and had been in the FU in 1982.'
         2 = 'This sample member was less than 18 at the time of main family nonresponse and had been in the FU in 1982.'
         3 = 'This nonsample individual had been in the 1982 FU, and this FU became nonresponse in 1983.'
         4 = 'This sample member had been in an institution in 1982 but his or her main family became nonresponse in 1983.'
         5 = 'This sample member, although connected with a 1983 response family, was in an institution at the time of the 1983 interview.'
         6 = 'This sample individual was 18 years old or older and moved out or died between the 1982 and 1983 interviews.'
         7 = 'This sample member was less than 18 and moved out or died between the 1982 and 1983 interviews.'
         8 = 'This nonsample individual moved out or died between the 1982 and 1983 interviews.'
         9 = 'This individual had not been born or moved in by the time of the 1983 interview; individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        10 = 'This individual had become nonresponse by the time of the 1982 interview.'
        99 = 'NA; DK'
         0 = 'Inap.:  in a panel family in 1983 (ER30400=1-20).'
   ;
   VALUE ER30427F
         1 = 'Wave refusal by all eligible/available FU members.'
         2 = 'No-one at home for contact during the interviewing period.'
         3 = 'Respondent absent; some FU member contacted, but not the appropriate respondent.'
         4 = 'Lost; unable to locate any member of the FU at all.'
         5 = 'FU is located too far away for interviewer contact.'
        11 = 'This individual was in the armed forces.'
        12 = 'This individual was in an educational institution.'
        13 = 'This individual was in a health care facility'
        14 = 'This individual was in jail or prison'
        19 = 'This individual was in some other type of institution, for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        21 = 'This individual was not eligible for the interview and the Head or the Wife, whichever is the sample member, became main family nonresponse because he/she was institutionalized by joining the armed fo'
             'rces.'
        22 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by entering an educational institution.'
        23 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized by entering a health care facil'
             'ity.'
        24 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized through imprisonment.'
        29 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by some means other than the above; for ex'
             'ample, he/she may have entered a religious order. Cases in which the type of institution is unknown are included here, also.'
        31 = 'This individual was unable to cooperate through disability.'
        32 = 'This individual was not eligible for the interview and the Head or Wife, whichever is sample, was unable to cooperate through disability.'
        41 = 'This individual died between the 1982 and 1983 interviews.'
        42 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, died.'
        51 = 'This individual, although followed for interview, was discovered to be nonsample: office error.'
        52 = 'This individual should have been followed but was not: office error.'
        53 = 'This individual was mistakenly included in two or more response families at once; this record is the duplicate, or erroneous, one.'
        54 = 'Listing error: this individual never existed or was not really living in the FU.'
        59 = 'Other office error'
        91 = 'This sample individual moved out of the 1983 main family and was eligible for interviewing but the reason for nonresponse is NA.'
        92 = 'Individual moved out of the 1983 main family and was not eligible for interviewing because he/she was either nonsample or too young.'
        93 = 'The Head or Wife of this FU, whichever is sample, united with another FU; this individual was not eligible for the interview and therefore became nonresponse.'
        97 = 'This individual had not been born or moved in by the time of the 1983 interview (ER30399>0 and ER30400=0); individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        98 = 'This individual became main family or mover-out nonresponse by 1982 (ER30373=0 and ER30399=0 or ER30373>0 and ER30374=71-89 and ER30399=0)'
        99 = 'NA; DK'
         0 = 'Inap.:  in a panel family in 1983 (ER30400=1-20)'
   ;
   VALUE ER30430F
    1 - 20 = 'Individuals in the family at the time of the 1984 interview'
   51 - 59 = 'Individuals in institutions at the time of the 1984 interview'
   71 - 80 = 'Individuals who moved out of the FU or out of institutions and established their own households between the 1983 and 1984 interviews'
   81 - 89 = 'Individuals who were living in 1983 but died by the time of the 1984 interview'
         0 = 'Inap.:  born or moved in after the 1984 interview; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1984 or mover-out nonresponse by 1983 (ER30429=0'
             ')'
   ;
   VALUE ER30431F
        10 = 'Head in 1984; 1983 Head who was mover-out nonresponse by the time of the 1984 interview'
        20 = 'Legal Wife in 1984; 1983 Wife who was mover-out nonresponse by the time of the 1984 interview'
        22 = '"Wife"--female cohabitor who has lived with Head for 12 months or more or who was present in the 1982 family, since consecutive interviews may be taken less or more than twelve months apart; 1983 "Wif'
             'e" who was mover-out nonresponse by the time of the 1984 interview'
        30 = 'Son or daughter of Head (includes adopted children but not stepchildren)'
        33 = 'Stepson or stepdaughter of Head (children of legal Wife (code 20) who are not children of Head)'
        35 = 'Son or daughter of "Wife" but not Head (includes only those children of mothers whose relationship to Head is 22 but who are not children of Head)'
        37 = 'Son-in-law or daughter-in-law of Head (includes stepchildren-in-law)'
        38 = 'Foster son or foster daughter, not legally adopted'
        40 = 'Brother or sister of Head (includes step and half sisters and brothers)'
        47 = 'Brother-in-law or sister-in-law of Head; i.e., brother or sister of legal Wife, or spouse of Head''s brother or sister.'
        48 = 'Brother or sister of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        50 = 'Father or mother of Head (includes stepparents)'
        57 = 'Father-in-law or mother-in-law of Head (includes parents of legal wives (code 20) only)'
        58 = 'Father or mother of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        60 = 'Grandson or granddaughter of Head (includes grandchildren of legal Wife (code 20), but those of a cohabitor are coded 97)'
        65 = 'Great-grandson or great-granddaughter of Head (includes great-grandchildren of legal Wife (code 20), but those of a cohabitor are coded 97)'
        66 = 'Grandfather or grandmother of Head (includes stepgrandparents)'
        67 = 'Grandfather or grandmother of legal Wife (code 20)'
        68 = 'Great-grandfather or great-grandmother of Head'
        69 = 'Great-grandfather or great-grandmother of legal Wife (code 20)'
        70 = 'Nephew or niece of Head'
        71 = 'Nephew or niece of legal Wife (code 20)'
        72 = 'Uncle or Aunt of Head'
        73 = 'Uncle or Aunt of legal Wife (code 20)'
        74 = 'Cousin of Head'
        75 = 'Cousin of legal Wife (code 20)'
        83 = 'Children of first-year cohabitor but not of Head (the parent of this child is coded 88)'
        88 = 'First-year cohabitor of Head'
        90 = 'Legal husband of Head'
        95 = 'Other relative of Head'
        96 = 'Other relative of legal Wife (code 20)'
        97 = 'Other relative of cohabitor (the cohabitor is code 22 or 88)'
        98 = 'Other nonrelatives (includes homosexual partners, friends of children of the FU, etc.)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1984 interview (ER30429>0 and ER30430=0); main family nonresponse by 1984 or mover-out nonr'
             'esponse by 1983 (ER30429=0)'
   ;
   VALUE ER30435F
         1 = 'Spouse in couple numbered 1'
         2 = 'Spouse in couple numbered 2'
         3 = 'Spouse in couple numbered 3'
         0 = 'Inap.:  not married or permanently cohabiting; spouse was not in FU at the time of the 1984 interview; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after'
             'the 1984 interview (ER30429>0 and ER30430=0); main family nonresponse by 1984 or mover-out nonresponse by 1983 (ER30429=0)'
   ;
   VALUE ER30436F
         1 = 'Moved in or born between the 1983 and 1984 interviews; splitoff in 1984'
         2 = 'Appeared; moved in by the time the 1983 interview was taken but not included in FU for 1983 (i.e., listing error)'
         5 = 'Moved out of FU or out of an institution between the 1983 and 1984 interviews and was not included in a 1984 panel FU'
         6 = 'Moved out of FU and into an institution between the 1983 and 1984 interviews'
         7 = 'Living in 1983 but died by the time of the 1984 interview'
         8 = 'Disappeared; moved out prior to the 1983 interview, but included in FU for 1983 (usually a listing error)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); in main family in both 1983 and 1984 (ER30400=1-20 and ER30430=1-20); in an institution in both 1983 and 1984 (ER30400'
             '=51-59 and ER30430=51-59); born or moved in after the 1984 interview (ER30429>0 and ER30430=0); main family nonresponse by 1984 or mover-out nonresponse by 1983 (ER30429=0)'
   ;
   VALUE ER30439F
    1 - 97 = 'Actual hours spent'
        98 = 'Ninety-eight hours per week or more'
        99 = 'NA; DK'
         0 = 'Inap.:  none; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1984 interview (ER30429>0 and ER30430=0); main family nonresponse by 1984 or mover-ou'
             't nonresponse by 1983 (ER30429=0); in an institution or mover-out nonresponse for 1984 (ER30430=51-89)'
   ;
   VALUE ER30440F
         1 = 'This individual was respondent'
         5 = 'This individual was not respondent; includes institutionalized individuals and mover-out nonresponse from 1984 (ER30430=51-89)'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1984 interview (ER30429>0 and ER30430=0); main family nonresponse by 1984 or mover-out nonr'
             'esponse by 1983 (ER30429=0)'
   ;
   VALUE ER30441F
         1 = 'Working now'
         2 = 'Only temporarily laid off'
         3 = 'Looking for work, unemployed'
         4 = 'Retired'
         5 = 'Permanently disabled'
         6 = 'HouseWife; keeping house'
         7 = 'Student'
         8 = 'Other'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1984 interview (ER30429>0 and ER30430=0); main family nonresponse by 1984 or mover-out nonr'
             'esponse by 1983 (ER30429=0); mover-out nonresponse for 1984 only if deceased (ER30430=81-89); in an institution in both 1983 and 1984 (ER30430=51-59 and ER30436=0); not a person aged 16 or older (ER30'
             '432=001-015)'
   ;
   VALUE ER30442F
         1 = 'Full-time student'
         3 = 'Part-time student'
         5 = 'Not enrolled in school'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1984 interview (ER30429>0 and ER30430=0); main family nonresponse by 1984 or mover-out nonr'
             'esponse by 1983 (ER30429=0); Head or Wife/"Wife" in 1984 (ER30430=1-20 and ER30431=10, 20 or 22); in an institution in both 1983 and 1984 (ER30430=51-59 and ER30436=0); not a person aged 16 or older ('
             'ER30432=001-015)'
   ;
   VALUE ER30443F
    1 - 17 = 'Highest grade or year of school completed'
        99 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1984 interview (ER30429>0 and ER30430=0); main family nonresponse by 1984 or mover-out nonr'
             'esponse by 1983 (ER30429=0); in an institution in both 1983 and 1984 (ER30430=51-59 and ER30436=0); not a person aged 16 or older (ER30432=001-015)'
   ;
   VALUE ER30444F
         1 = 'Labor income'
         2 = 'Asset income'
         3 = 'Both labor and asset income'
         0 = 'Inap.:  no taxable income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1984 interview (ER30429>0 and ER30430=0); main family nonresponse by 198'
             '4 or mover-out nonresponse by 1983 (ER30429=0); in an institution in both 1983 and 1984 (ER30430=51-59 and ER30436=0)'
   ;
   VALUE ER30449F
         1 = 'ADC, AFDC only'
         2 = 'Supplemental Security Income, SSI only'
         3 = 'Other Welfare only'
         4 = 'Social Security only'
         5 = 'Veterans pension'
         6 = 'Other retirement pay, pensions, or annuities only'
         7 = 'Unemployment compensation only'
         8 = 'Worker compensation only'
         9 = 'Child support only'
        10 = 'Help from relatives only'
        11 = 'Other transfers only'
        15 = 'More than one of the above; any combination'
         0 = 'Inap.:  no transfer income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1984 interview (ER30429>0 and ER30430=0); main family nonresponse by 19'
             '84 or mover-out nonresponse by 1983 (ER30429=0); in an institution in both 1983 and 1984 (ER30430=51-59 and ER30436=0)'
   ;
   VALUE ER30450F
         1 = 'Disability'
         2 = 'Retirement'
         3 = 'Survivor benefits'
         4 = 'Any combination of the above'
         7 = 'Other'
         9 = 'NA; DK'
         0 = 'Inap.:  no Social Security income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1984 interview (ER30429>0 and ER30430=0); main family nonrespons'
             'e by 1984 or mover-out nonresponse by 1983 (ER30429=0); in an institution in both 1983 and 1984 (ER30430=51-59 and ER30436=0); no transfers (ER30449=0)'
   ;
   VALUE ER30460F
         1 = 'This sample member was 18 years old or older at the time of main family nonresponse and had been in the FU in 1983.'
         2 = 'This sample member was less than 18 at the time of main family nonresponse and had been in the FU in 1983.'
         3 = 'This nonsample individual had been in the 1983 FU, and this FU became nonresponse in 1984.'
         4 = 'This sample member had been in an institution in 1983 but his or her main family became nonresponse in 1984.'
         5 = 'This sample member, although connected with a 1984 response family, was in an institution at the time of the 1984 interview.'
         6 = 'This sample individual was 18 years old or older and moved out or died between the 1983 and 1984 interviews.'
         7 = 'This sample member was less than 18 and moved out or died between the 1983 and 1984 interviews.'
         8 = 'This nonsample individual moved out or died between the 1983 and 1984 interviews.'
         9 = 'This individual had not been born or moved in by the time of the 1984 interview; individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        10 = 'This individual had become nonresponse by the time of the 1983 interview.'
        99 = 'NA; DK'
         0 = 'Inap.:  in a panel family in 1984 (ER30430=1-20).'
   ;
   VALUE ER30461F
         1 = 'Wave refusal by all eligible/available FU members.'
         2 = 'No-one at home for contact during the interviewing period.'
         3 = 'Respondent absent; some FU member contacted, but not the appropriate respondent.'
         4 = 'Lost; unable to locate any member of the FU at all.'
         5 = 'FU is located too far away for interviewer contact.'
        11 = 'This individual was in the armed forces.'
        12 = 'This individual was in an educational institution.'
        13 = 'This individual was in a health care facility'
        14 = 'This individual was in jail or prison'
        19 = 'This individual was in some other type of institution, for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        21 = 'This individual was not eligible for the interview and the Head or the Wife, whichever is the sample member, became main family nonresponse because he/she was institutionalized by joining the armed fo'
             'rces.'
        22 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by entering an educational institution.'
        23 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized by entering a health care facil'
             'ity.'
        24 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized through imprisonment.'
        29 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by some means other than the above; for ex'
             'ample, he/she may have entered a religious order. Cases in which the type of institution is unknown are included here, also.'
        31 = 'This individual was unable to cooperate through disability.'
        32 = 'This individual was not eligible for the interview and the Head or Wife, whichever is sample, was unable to cooperate through disability.'
        41 = 'This individual died between the 1983 and 1984 interviews.'
        42 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, died.'
        51 = 'This individual, although followed for interview, was discovered to be nonsample: office error.'
        52 = 'This individual should have been followed but was not: office error.'
        53 = 'This individual was mistakenly included in two or more response families at once; this record is the duplicate, or erroneous, one.'
        54 = 'Listing error: this individual never existed or was not really living in the FU.'
        59 = 'Other office error'
        91 = 'This sample individual moved out of the 1984 main family and was eligible for interviewing but the reason for nonresponse is NA.'
        92 = 'Individual moved out of the 1984 main family and was not eligible for interviewing because he/she was either nonsample or too young.'
        93 = 'The Head or Wife of this FU, whichever is sample, united with another FU; this individual was not eligible for the interview and therefore became nonresponse.'
        97 = 'This individual had not been born or moved in by the time of the 1984 interview (ER30429>0 and ER30430=0); individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        98 = 'This individual became main family or mover-out nonresponse by 1983 (ER30399=0 and ER30429=0 or ER30399>0 and ER30400=71-89 and ER30429=0)'
        99 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); in a panel family in 1984 (ER30430=1-20)'
   ;
   VALUE ER30464F
    1 - 20 = 'Individuals in the family at the time of the 1985 interview'
   51 - 59 = 'Individuals in institutions at the time of the 1985 interview'
   71 - 80 = 'Individuals who moved out of the FU or out of institutions and established their own households between the 1984 and 1985 interviews'
   81 - 89 = 'Individuals who were living in 1984 but died by the time of the 1985 interview'
         0 = 'Inap.:  born or moved in after the 1985 interview; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1985 or mover-out nonresponse by 1984 (ER30463=0'
             ')'
   ;
   VALUE ER30465F
        10 = 'Head in 1985; 1984 Head who was mover-out nonresponse by the time of the 1985 interview'
        20 = 'Legal Wife in 1985; 1984 Wife who was mover-out nonresponse by the time of the 1985 interview'
        22 = '"Wife"--female cohabitor who has lived with Head for 12 months or more or who was present in the 1983 family, since consecutive interviews may be taken less or more than twelve months apart; 1984 "Wif'
             'e" who was mover-out nonresponse by the time of the 1985 interview'
        30 = 'Son or daughter of Head (includes adopted children but not stepchildren)'
        33 = 'Stepson or stepdaughter of Head (children of legal Wife (code 20) who are not children of Head)'
        35 = 'Son or daughter of "Wife" but not Head (includes only those children of mothers whose relationship to Head is 22 but who are not children of Head)'
        37 = 'Son-in-law or daughter-in-law of Head (includes stepchildren-in-law)'
        38 = 'Foster son or foster daughter, not legally adopted'
        40 = 'Brother or sister of Head (includes step and half sisters and brothers)'
        47 = 'Brother-in-law or sister-in-law of Head; i.e., brother or sister of legal Wife, or spouse of Head''s brother or sister.'
        48 = 'Brother or sister of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        50 = 'Father or mother of Head (includes stepparents)'
        57 = 'Father-in-law or mother-in-law of Head (includes parents of legal wives (code 20) only)'
        58 = 'Father or mother of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        60 = 'Grandson or granddaughter of Head (includes grandchildren of legal Wife (code 20), but those of a cohabitor are coded 97)'
        65 = 'Great-grandson or great-granddaughter of Head (includes great-grandchildren of legal Wife (code 20), but those of a cohabitor are coded 97)'
        66 = 'Grandfather or grandmother of Head (includes stepgrandparents)'
        67 = 'Grandfather or grandmother of legal Wife (code 20)'
        68 = 'Great-grandfather or great-grandmother of Head'
        69 = 'Great-grandfather or great-grandmother of legal Wife (code 20)'
        70 = 'Nephew or niece of Head'
        71 = 'Nephew or niece of legal Wife (code 20)'
        72 = 'Uncle or Aunt of Head'
        73 = 'Uncle or Aunt of legal Wife (code 20)'
        74 = 'Cousin of Head'
        75 = 'Cousin of legal Wife (code 20)'
        83 = 'Children of first-year cohabitor but not of Head (the parent of this child is coded 88)'
        88 = 'First-year cohabitor of Head'
        90 = 'Legal husband of Head'
        95 = 'Other relative of Head'
        96 = 'Other relative of legal Wife (code 20)'
        97 = 'Other relative of cohabitor (the cohabitor is code 22 or 88)'
        98 = 'Other nonrelatives (includes homosexual partners, friends of children of the FU, etc.)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1985 interview (ER30463>0 and ER30464=0); main family nonresponse by 1985 or mover-out nonr'
             'esponse by 1984 (ER30463=0)'
   ;
   VALUE ER30469F
         1 = 'Spouse in couple numbered 1'
         2 = 'Spouse in couple numbered 2'
         3 = 'Spouse in couple numbered 3'
         0 = 'Inap.:  not married or permanently cohabiting; spouse was not in FU at the time of the 1985 interview; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after'
             'the 1985 interview (ER30463>0 and ER30464=0); main family nonresponse by 1985 or mover-out nonresponse by 1984 (ER30463=0)'
   ;
   VALUE ER30470F
         1 = 'Moved in or born between the 1984 and 1985 interviews; splitoff in 1985'
         2 = 'Appeared; moved in by the time the 1984 interview was taken interviews, but not included in FU for 1984 (i.e., listing error)'
         5 = 'Moved out of FU or out of an institution between the 1984 and 1985 interviews and was not included in a 1985 panel FU'
         6 = 'Moved out of FU and into an institution between the 1984 and 1985 interviews'
         7 = 'Living in 1984 but died by the time of the 1985 interview'
         8 = 'Disappeared; moved out prior to the 1984 interview, but included in FU for 1984 (usually a listing error)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); in main family in both 1984 and 1985 (ER30430=1-20 and ER30464=1-20); in an institution in both 1984 and 1985 (ER30430'
             '=51-59 and ER30464=51-59); born or moved in after the 1985 interview (ER30463>0 and ER30464=0); main family nonresponse by 1985 or mover-out nonresponse by 1984 (ER30463=0)'
   ;
   VALUE ER30473F
    1 - 97 = 'Actual hours spent'
        98 = 'Ninety-eight hours per week or more'
        99 = 'NA; DK'
         0 = 'Inap.:  none; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1985 interview (ER30463>0 and ER30464=0); main family nonresponse by 1985 or mover-ou'
             't nonresponse by 1984 (ER30463=0); in an institution or mover-out nonresponse for 1985 (ER30464=51-89)'
   ;
   VALUE ER30474F
         1 = 'Working now'
         2 = 'Only temporarily laid off'
         3 = 'Looking for work, unemployed'
         4 = 'Retired'
         5 = 'Permanently disabled'
         6 = 'HouseWife; keeping house'
         7 = 'Student'
         8 = 'Other'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1985 interview (ER30463>0 and ER30464=0); main family nonresponse by 1985 or mover-out nonr'
             'esponse by 1984 (ER30463=0); mover-out nonresponse for 1985 only if deceased (ER30464=81-89); in an institution in both 1984 and 1985 (ER30464=51-59 and ER30470=0); not a person aged 16 or older (ER30'
             '466=001-015)'
   ;
   VALUE ER30477F
         1 = 'Full-time student'
         3 = 'Part-time student'
         5 = 'Not enrolled in school'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1985 interview (ER30463>0 and ER30464=0); main family nonresponse by 1985 or mover-out nonr'
             'esponse by 1984 (ER30463=0); in an institution in both 1984 and 1985 (ER30464=51-59 and ER30470=0); not a person aged 16 or older (ER30466=001-015); last attended school before 1984 (ER30476=1901-1983'
             ', 9998 or 9999); Head or Wife/"Wife" in 1985 (ER30464=1-20 and ER30465=10, 20, or 22)'
   ;
   VALUE ER30478F
    1 - 17 = 'Highest grade or year of school completed'
        99 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1985 interview (ER30463>0 and ER30464=0); main family nonresponse by 1985 or mover-out nonr'
             'esponse by 1984 (ER30463=0); in an institution in both 1984 and 1985 (ER30464=51-59 and ER30470=0); not a person aged 16 or older (ER30466=001-015)'
   ;
   VALUE ER30479F
         1 = 'Labor income'
         2 = 'Asset income'
         3 = 'Both labor and asset income'
         0 = 'Inap.:  no taxable income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1985 interview (ER30463>0 and ER30464=0); main family nonresponse by 198'
             '5 or mover-out nonresponse by 1984 (ER30463=0); in an institution in both 1984 and 1985 (ER30464=51-59 and ER30470=0)'
   ;
   VALUE ER30484F
         1 = 'ADC, AFDC only'
         2 = 'Supplemental Security Income, SSI only'
         3 = 'Other Welfare only'
         4 = 'Social Security only'
         5 = 'Veterans pension'
         6 = 'Other retirement pay, pensions, or annuities only'
         7 = 'Unemployment compensation only'
         8 = 'Worker compensation only'
         9 = 'Child support only'
        10 = 'Help from relatives only'
        11 = 'Other transfers only'
        15 = 'More than one of the above; any combination'
         0 = 'Inap.:  no transfer income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1985 interview (ER30463>0 and ER30464=0); main family nonresponse by 19'
             '85 or mover-out nonresponse by 1984 (ER30463=0); in an institution in both 1984 and 1985 (ER30464=51-59 and ER30480=0)'
   ;
   VALUE ER30485F
         1 = 'Disability'
         2 = 'Retirement'
         3 = 'Survivor benefits'
         4 = 'Any combination of the above'
         7 = 'Other'
         9 = 'NA; DK'
         0 = 'Inap.:  no Social Security income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1985 interview (ER30463>0 and ER30464=0); main family nonrespons'
             'e by 1985 or mover-out nonresponse by 1984 (ER30463=0); in an institution in both 1984 and 1985 (ER30464=51-59 and ER30470=0); no transfers (ER30484=0)'
   ;
   VALUE ER30495F
         1 = 'This sample member was 18 years old or older at the time of main family nonresponse and had been in the FU in 1984.'
         2 = 'This sample member was less than 18 at the time of main family nonresponse and had been in the FU in 1984.'
         3 = 'This nonsample individual had been in the 1984 FU, and this FU became nonresponse in 1985.'
         4 = 'This sample member had been in an institution in 1984 but his or her main family became nonresponse in 1985.'
         5 = 'This sample member, although connected with a 1985 response family, was in an institution at the time of the 1985 interview.'
         6 = 'This sample individual was 18 years old or older and moved out or died between the 1984 and 1985 interviews.'
         7 = 'This sample member was less than 18 and moved out or died between the 1984 and 1985 interviews.'
         8 = 'This nonsample individual moved out or died between the 1984 and 1985 interviews.'
         9 = 'This individual had not been born or moved in by the time of the 1985 interview; individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        10 = 'This individual had become nonresponse by the time of the 1984 interview.'
        99 = 'NA; DK'
         0 = 'Inap.:  in a panel family in 1985 (ER30464=1-20).'
   ;
   VALUE ER30496F
         1 = 'Wave refusal by all eligible/available FU members.'
         2 = 'No-one at home for contact during the interviewing period.'
         3 = 'Respondent absent; some FU member contacted, but not the appropriate respondent.'
         4 = 'Lost; unable to locate any member of the FU at all.'
         5 = 'FU is located too far away for interviewer contact.'
        11 = 'This individual was in the armed forces.'
        12 = 'This individual was in an educational institution.'
        13 = 'This individual was in a health care facility'
        14 = 'This individual was in jail or prison'
        19 = 'This individual was in some other type of institution, for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        21 = 'This individual was not eligible for the interview and the Head or the Wife, whichever is the sample member, became main family nonresponse because he/she was institutionalized by joining the armed fo'
             'rces.'
        22 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by entering an educational institution.'
        23 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized by entering a health care facil'
             'ity.'
        24 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized through imprisonment.'
        29 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by some means other than the above; for ex'
             'ample, he/she may have entered a religious order. Cases in which the type of institution is unknown are included here, also.'
        31 = 'This individual was unable to cooperate through disability.'
        32 = 'This individual was not eligible for the interview and the Head or Wife, whichever is sample, was unable to cooperate through disability.'
        41 = 'This individual died between the 1984 and 1985 interviews.'
        42 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, died.'
        51 = 'This individual, although followed for interview, was discovered to be nonsample: office error.'
        52 = 'This individual should have been followed but was not: office error.'
        53 = 'This individual was mistakenly included in two or more response families at once; this record is the duplicate, or erroneous, one.'
        54 = 'Listing error: this individual never existed or was not really living in the FU.'
        59 = 'Other office error'
        91 = 'This sample individual moved out of the 1985 main family and was eligible for interviewing but the reason for nonresponse is NA.'
        92 = 'Individual moved out of the 1985 main family and was not eligible for interviewing because he/she was either nonsample or too young.'
        93 = 'The Head or Wife of this FU, whichever is sample, united with another FU; this individual was not eligible for the interview and therefore became nonresponse.'
        97 = 'This individual had not been born or moved in by the time of the 1985 interview (ER30463>0 and ER30464=0); individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        98 = 'This individual became main family or mover-out nonresponse by 1984 (ER30429=0 and ER30463=0 or ER30429>0 and ER30430=71-89 and ER30463=0)'
        99 = 'NA; DK'
         0 = 'Inap.:  in a panel family in 1985 (ER30464=1-20)'
   ;
   VALUE ER30499F
    1 - 20 = 'Individuals in the family at the time of the 1986 interview'
   51 - 59 = 'Individuals in institutions at the time of the 1986 interview'
   71 - 80 = 'Individuals who moved out of the FU or out of institutions and established their own households between the 1985 and 1986 interviews'
   81 - 89 = 'Individuals who were living in 1985 but died by the time of the 1986 interview'
         0 = 'Inap.:  born or moved in after the 1986 interview; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1986 or mover-out nonresponse by 1985 (ER30498=0'
             ')'
   ;
   VALUE ER30500F
        10 = 'Head in 1986; 1985 Head who was mover-out nonresponse by the time of the 1986 interview'
        20 = 'Legal Wife in 1986; 1985 Wife who was mover-out nonresponse by the time of the 1986 interview'
        22 = '"Wife"--female cohabitor who has lived with Head for 12 months or more or who was present in the 1985 family, since consecutive interviews may be taken less or more than twelve months apart; 1985 "Wif'
             'e" who was mover-out nonresponse by the time of the 1986 interview'
        30 = 'Son or daughter of Head (includes adopted children but not stepchildren)'
        33 = 'Stepson or stepdaughter of Head (children of legal Wife (code 20) who are not children of Head)'
        35 = 'Son or daughter of "Wife" but not Head (includes only those children of mothers whose relationship to Head is 22 but who are not children of Head)'
        37 = 'Son-in-law or daughter-in-law of Head (includes stepchildren-in-law)'
        38 = 'Foster son or foster daughter, not legally adopted'
        40 = 'Brother or sister of Head (includes step and half sisters and brothers)'
        47 = 'Brother-in-law or sister-in-law of Head; i.e., brother or sister of legal Wife, or spouse of Head''s brother or sister.'
        48 = 'Brother or sister of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        50 = 'Father or mother of Head (includes stepparents)'
        57 = 'Father-in-law or mother-in-law of Head (includes parents of legal wives (code 20) only)'
        58 = 'Father or mother of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        60 = 'Grandson or granddaughter of Head (includes grandchildren of legal Wife (code 20), but those of a cohabitor are coded 97)'
        65 = 'Great-grandson or great-granddaughter of Head (includes great-grandchildren of legal Wife (code 20), but those of a cohabitor are coded 97)'
        66 = 'Grandfather or grandmother of Head (includes stepgrandparents)'
        67 = 'Grandfather or grandmother of legal Wife (code 20)'
        68 = 'Great-grandfather or great-grandmother of Head'
        69 = 'Great-grandfather or great-grandmother of legal Wife (code 20)'
        70 = 'Nephew or niece of Head'
        71 = 'Nephew or niece of legal Wife (code 20)'
        72 = 'Uncle or Aunt of Head'
        73 = 'Uncle or Aunt of legal Wife (code 20)'
        74 = 'Cousin of Head'
        75 = 'Cousin of legal Wife (code 20)'
        83 = 'Children of first-year cohabitor but not of Head (the parent of this child is coded 88)'
        88 = 'First-year cohabitor of Head'
        90 = 'Legal husband of Head'
        95 = 'Other relative of Head'
        96 = 'Other relative of legal Wife (code 20)'
        97 = 'Other relative of cohabitor (the cohabitor is code 22 or 88)'
        98 = 'Other nonrelatives (includes homosexual partners, friends of children of the FU, etc.)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1986 interview (ER30498>0 and ER30499=0); main family nonresponse by 1986 or mover-out nonr'
             'esponse by 1985 (ER30498=0)'
   ;
   VALUE ER30504F
         1 = 'Spouse in couple numbered 1'
         2 = 'Spouse in couple numbered 2'
         3 = 'Spouse in couple numbered 3'
         0 = 'Inap.:  not married or permanently cohabiting; spouse was not in FU at the time of the 1986 interview; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after'
             'the 1986 interview (ER30498>0 and ER30499=0); main family nonresponse by 1986 or mover-out nonresponse by 1985 (ER30498=0)'
   ;
   VALUE ER30505F
         1 = 'Moved in or born between the 1985 and 1986 interviews; splitoff in 1986'
         2 = 'Appeared; moved in by the time the 1985 interview was taken but not included in FU for 1985 (i.e., listing error)'
         5 = 'Moved out of FU or out of an institution between the 1985 and 1986 interviews and was not included in a 1986 panel FU'
         6 = 'Moved out of FU and into an institution between the 1985 and 1986 interviews'
         7 = 'Living in 1985 but died by the time of the 1986 interview'
         8 = 'Disappeared; moved out prior to the 1985 interview, but included in FU for 1985 (usually a listing error)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); in main family in both 1985 and 1986 (ER30464=1-20 and ER30499=1-20); in an institution in both 1985 and 1986 (ER30464'
             '=51-59 and ER30499=51-59); born or moved in after the 1986 interview (ER30498>0 and ER30499=0); main family nonresponse by 1986 or mover-out nonresponse by 1985 (ER30498=0)'
   ;
   VALUE ER30508F
    1 - 97 = 'Actual hours spent'
        98 = 'Ninety-eight hours per week or more'
        99 = 'NA; DK'
         0 = 'Inap.:  none; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1986 interview (ER30498>0 and ER30499=0); main family nonresponse by 1986 or mover-ou'
             't nonresponse by 1985 (ER30498=0); in an institution or mover-out nonresponse for 1986 (ER30499=51-89)'
   ;
   VALUE ER30509F
         1 = 'Working now'
         2 = 'Only temporarily laid off'
         3 = 'Looking for work, unemployed'
         4 = 'Retired'
         5 = 'Permanently disabled'
         6 = 'HouseWife; keeping house'
         7 = 'Student'
         8 = 'Other'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1986 interview (ER30498>0 and ER30499=0); main family nonresponse by 1986 or mover-out nonr'
             'esponse by 1985 (ER30498=0); mover-out nonresponse for 1986 only if deceased (ER30499=81-89); in an institution in both 1985 and 1986 (ER30499=51-59 and ER30505=0); not a person aged 16 or older (ER30'
             '501=001-015)'
   ;
   VALUE ER30512F
         1 = 'Full-time student'
         3 = 'Part-time student'
         5 = 'Not enrolled in school'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1986 interview (ER30498>0 and ER30499=0); main family nonresponse by 1986 or mover-out nonr'
             'esponse by 1985 (ER30498=0); Head or Wife/"Wife" in 1983 (ER30499=1-20 and ER30500=10, 20 or 22); in an institution in both 1985 and 1986 (ER30499=51-59 and ER30505=0); not a person aged 16 or older ('
             'ER30501=001-015); last attended school before 1985 (ER30511=1901-1984, 9998 or 9999)'
   ;
   VALUE ER30513F
    1 - 17 = 'Highest grade or year of school completed'
        99 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1986 interview (ER30498>0 and ER30499=0); main family nonresponse by 1986 or mover-out nonr'
             'esponse by 1985 (ER30498=0); in an institution in both 1985 and 1986 (ER30499=51-59 and ER30505=0); not a person aged 16 or older (ER30501=001-015)'
   ;
   VALUE ER30514F
         1 = 'Labor income'
         2 = 'Asset income'
         3 = 'Both labor and asset income'
         0 = 'Inap.:  no taxable income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1986 interview (ER30498>0 and ER30499=0); main family nonresponse by 198'
             '6 or mover-out nonresponse by 1985 (ER30498=0); in an institution in both 1985 and 1986 (ER30499=51-59 and ER30505=0)'
   ;
   VALUE ER30519F
         1 = 'ADC, AFDC only'
         2 = 'Supplemental Security Income, SSI only'
         3 = 'Other Welfare only'
         4 = 'Social Security only'
         5 = 'Veterans pension'
         6 = 'Other retirement pay, pensions, or annuities only'
         7 = 'Unemployment compensation only'
         8 = 'Worker compensation only'
         9 = 'Child support only'
        10 = 'Help from relatives only'
        11 = 'Other transfers only'
        15 = 'More than one of the above; any combination'
         0 = 'Inap.:  no transfer income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1986 interview (ER30498>0 and ER30499=0); main family nonresponse by 19'
             '86 or mover-out nonresponse by 1985 (ER30498=0); in an institution in both 1985 and 1986 (ER30499=51-59 and ER30505=0)'
   ;
   VALUE ER30520F
         1 = 'Disability'
         2 = 'Retirement'
         3 = 'Survivor benefits'
         4 = 'Any combination of the above'
         7 = 'Other'
         9 = 'NA; DK'
         0 = 'Inap.:  no Social Security income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1986 interview (ER30498>0 and ER30499=0); main family nonrespons'
             'e by 1986 or mover-out nonresponse by 1985 (ER30498=0); in an institution in both 1985 and 1986 (ER30499=51-59 and ER30505=0); no transfers (ER30519=0)'
   ;
   VALUE ER30526F
         1 = 'Yes, is covered'
         5 = 'No, is not covered'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1986 interview (ER30498>0 and ER30499=0); main family nonresponse by 1986 or mover-out nonr'
             'esponse by 1985 (ER30498=0); in an institution or mover-out nonresponse in 1986 (ER30499=51-89)'
   ;
   VALUE ER30527F
         1 = 'Excellent'
         2 = 'Very good'
         3 = 'Good'
         4 = 'Fair'
         5 = 'Poor'
         8 = 'Don''t know'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1986 interview (ER30498>0 and ER30499=0); main family nonresponse by 1986 or mover-out nonr'
             'esponse by 1985 (ER30498=0); in an institution or mover-out nonresponse in 1986 (ER30499=51-89)'
   ;
   VALUE ER30532F
         1 = 'This sample member was 18 years old or older at the time of main family nonresponse and had been in the FU in 1985.'
         2 = 'This sample member was less than 18 at the time of main family nonresponse and had been in the FU in 1985.'
         3 = 'This nonsample individual had been in the 1985 FU, and this FU became nonresponse in 1986.'
         4 = 'This sample member had been in an institution in 1985 but his or her main family became nonresponse in 1986.'
         5 = 'This sample member, although connected with a 1986 response family, was in an institution at the time of the 1986 interview.'
         6 = 'This sample individual was 18 years old or older and moved out or died between the 1985 and 1986 interviews.'
         7 = 'This sample member was less than 18 and moved out or died between the 1985 and 1986 interviews.'
         8 = 'This nonsample individual moved out or died between the 1985 and 1986 interviews.'
         9 = 'This individual had not been born or moved in by the time of the 1986 interview; individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        10 = 'This individual had become nonresponse by the time of the 1985 interview.'
        99 = 'NA; DK'
         0 = 'Inap.:  in a panel family in 1986 (ER30499=1-20).'
   ;
   VALUE ER30533F
         1 = 'Wave refusal by all eligible/available FU members.'
         2 = 'No-one at home for contact during the interviewing period.'
         3 = 'Respondent absent; some FU member contacted, but not the appropriate respondent.'
         4 = 'Lost; unable to locate any member of the FU at all.'
         5 = 'FU is located too far away for interviewer contact.'
        11 = 'This individual was in the armed forces.'
        12 = 'This individual was in an educational institution.'
        13 = 'This individual was in a health care facility'
        14 = 'This individual was in jail or prison'
        19 = 'This individual was in some other type of institution, for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        21 = 'This individual was not eligible for the interview and the Head or the Wife, whichever is the sample member, became main family nonresponse because he/she was institutionalized by joining the armed fo'
             'rces.'
        22 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by entering an educational institution.'
        23 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized by entering a health care facil'
             'ity.'
        24 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized through imprisonment.'
        29 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by some means other than the above; for ex'
             'ample, he/she may have entered a religious order. Cases in which the type of institution is unknown are included here, also.'
        31 = 'This individual was unable to cooperate through disability.'
        32 = 'This individual was not eligible for the interview and the Head or Wife, whichever is sample, was unable to cooperate through disability.'
        41 = 'This individual died between the 1985 and 1986 interviews.'
        42 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, died.'
        51 = 'This individual, although followed for interview, was discovered to be nonsample: office error.'
        52 = 'This individual should have been followed but was not: office error.'
        53 = 'This individual was mistakenly included in two or more response families at once; this record is the duplicate, or erroneous, one.'
        54 = 'Listing error: this individual never existed or was not really living in the FU.'
        59 = 'Other office error'
        91 = 'This sample individual moved out of the 1986 main family and was eligible for interviewing but the reason for nonresponse is NA.'
        92 = 'Individual moved out of the 1986 main family and was not eligible for interviewing because he/she was either nonsample or too young.'
        93 = 'The Head or Wife of this FU, whichever is sample, united with another FU; this individual was not eligible for the interview and therefore became nonresponse.'
        97 = 'This individual had not been born or moved in by the time of the 1986 interview (ER30498>0 and ER30499=0); individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        98 = 'This individual became main family or mover-out nonresponse by 1985 (ER30463=0 and ER30498=0 or ER30463>0 and ER30464=71-89 and ER30498=0)'
        99 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); Inap.:  in a panel family in 1986 (ER30499=1-20)'
   ;
   VALUE ER30536F
    1 - 20 = 'Individuals in the family at the time of the 1987 interview'
   51 - 59 = 'Individuals in institutions at the time of the 1987 interview'
   71 - 80 = 'Individuals who moved out of the FU or out of institutions and established their own households between the 1986 and 1987 interviews'
   81 - 89 = 'Individuals who were living in 1986 but died by the time of the 1987 interview'
         0 = 'Inap.:  born or moved in after the 1987 interview; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1987 or mover-out nonresponse by 1986 (ER30535=0'
             ')'
   ;
   VALUE ER30537F
        10 = 'Head in 1987; 1986 Head who was mover-out nonresponse by the time of the 1987 interview'
        20 = 'Legal Wife in 1987; 1986 Wife who was mover-out nonresponse by the time of the 1987 interview'
        22 = '"Wife"--female cohabitor who has lived with Head for 12 months or more or who was present in the 1986 family, since consecutive interviews may be taken less or more than twelve months apart; 1986 "Wif'
             'e" who was mover-out nonresponse by the time of the 1987 interview'
        30 = 'Son or daughter of Head (includes adopted children but not stepchildren)'
        33 = 'Stepson or stepdaughter of Head (children of legal Wife (code 20) who are not children of Head)'
        35 = 'Son or daughter of "Wife" but not Head (includes only those children of mothers whose relationship to Head is 22 but who are not children of Head)'
        37 = 'Son-in-law or daughter-in-law of Head (includes stepchildren-in-law)'
        38 = 'Foster son or foster daughter, not legally adopted'
        40 = 'Brother or sister of Head (includes step and half sisters and brothers)'
        47 = 'Brother-in-law or sister-in-law of Head; i.e., brother or sister of legal Wife, or spouse of Head''s brother or sister.'
        48 = 'Brother or sister of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        50 = 'Father or mother of Head (includes stepparents)'
        57 = 'Father-in-law or mother-in-law of Head (includes parents of legal wives (code 20) only)'
        58 = 'Father or mother of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        60 = 'Grandson or granddaughter of Head (includes grandchildren of legal Wife (code 20), but those of a cohabitor are coded 97)'
        65 = 'Great-grandson or great-granddaughter of Head (includes great-grandchildren of of legal Wife (code 20), but those of a cohabitor are coded 97)'
        66 = 'Grandfather or grandmother of Head (includes stepgrandparents)'
        67 = 'Grandfather or grandmother of legal Wife (code 20)'
        68 = 'Great-grandfather or great-grandmother of Head'
        69 = 'Great-grandfather or great-grandmother of legal Wife (code 20)'
        70 = 'Nephew or niece of Head'
        71 = 'Nephew or niece of legal Wife (code 20)'
        72 = 'Uncle or Aunt of Head'
        73 = 'Uncle or Aunt of legal Wife (code 20)'
        74 = 'Cousin of Head'
        75 = 'Cousin of legal Wife (code 20)'
        83 = 'Children of first-year cohabitor but not of Head (the parent of this child is coded 88)'
        88 = 'First-year cohabitor of Head'
        90 = 'Legal husband of Head'
        95 = 'Other relative of Head'
        96 = 'Other relative of legal Wife (code 20)'
        97 = 'Other relative of cohabitor (the cohabitor is code 22 or 88)'
        98 = 'Other nonrelatives (includes homosexual partners, friends of children of the FU, etc.)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1987 interview (ER30535>0 and ER30536=0); main family nonresponse by 1987 or mover-out nonr'
             'esponse by 1986 (ER30535=0)'
   ;
   VALUE ER30541F
         1 = 'Spouse in couple numbered 1'
         2 = 'Spouse in couple numbered 2'
         3 = 'Spouse in couple numbered 3'
         0 = 'Inap.:  not married or permanently cohabiting; spouse was not in FU at the time of the 1987 interview; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after'
             'the 1987 interview (ER30535>0 and ER30536=0); main family nonresponse by 1987 or mover-out nonresponse by 1986 (ER30535=0)'
   ;
   VALUE ER30542F
         1 = 'Moved in or born between the 1986 and 1987 interviews; splitoff in 1987'
         2 = 'Appeared; moved in by the time the 1986 interview was taken but not included in FU for 1986 (i.e., listing error)'
         5 = 'Moved out of FU or out of an institution between the 1986 and 1987 interviews and was not included in a 1987 panel FU'
         6 = 'Moved out of FU and into an institution between the 1986 and 1987 interviews'
         7 = 'Living in 1986 but died by the time of the 1987 interview'
         8 = 'Disappeared; moved out prior to the 1986 interview, but included in FU for 1986 (usually a listing error)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); in main family in both 1986 and 1987 (ER30499=1-20 and ER30536=1-20); in an institution in both 1986 and 1987 (ER30499'
             '=51-59 and ER30536=51-59); born or moved in after the 1987 interview (ER30535>0 and ER30536=0); main family nonresponse by 1987 or mover-out nonresponse by 1986 (ER30535=0)'
   ;
   VALUE ER30545F
         1 = 'Working now'
         2 = 'Only temporarily laid off'
         3 = 'Looking for work, unemployed'
         4 = 'Retired'
         5 = 'Permanently disabled'
         6 = 'HouseWife; keeping house'
         7 = 'Student'
         8 = 'Other'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1987 interview (ER30535>0 and ER30536=0); main family nonresponse by 1987 or mover-out nonr'
             'esponse by 1986 (ER30535=0); mover-out nonresponse for 1987 only if deceased (ER30536=81-89); in an institution in both 1986 and 1987 (ER30536=51-59 and ER30542=0); not a person aged 16 or older (ER30'
             '538=001-015)'
   ;
   VALUE ER30548F
         1 = 'Full-time student'
         3 = 'Part-time student'
         5 = 'Not enrolled in school'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1987 interview (ER30535>0 and ER30536=0); main family nonresponse by 1987 or mover-out nonr'
             'esponse by 1986 (ER30535=0); Head or Wife/"Wife" in 1987 (ER30536=1-20 and ER30537=10, 20 or 22); in an institution in both 1986 and 1987 (ER30536=51-59 and ER30542=0); not a person aged 16 or older ('
             'ER30538=001-015); last attended school before 1986 (ER30547=1901-1985, 9998 or 9999)'
   ;
   VALUE ER30549F
    1 - 17 = 'Highest grade or year of school completed'
        99 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1987 interview (ER30535>0 and ER30536=0); main family nonresponse by 1987 or mover-out nonr'
             'esponse by 1986 (ER30535=0); in an institution in both 1986 and 1987 (ER30536=51-59 and ER30542=0); not a person aged 16 or older (ER30538=001-015)'
   ;
   VALUE ER30550F
         1 = 'Labor income'
         2 = 'Asset income'
         3 = 'Both labor and asset income'
         0 = 'Inap.:  no taxable income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1987 interview (ER30535>0 and ER30536=0); main family nonresponse by 198'
             '7 or mover-out nonresponse by 1986 (ER30535=0); in an institution in both 1986 and 1987 (ER30536=51-59 and ER30542=0)'
   ;
   VALUE ER30555F
         1 = 'ADC, AFDC only'
         2 = 'Supplemental Security Income, SSI only'
         3 = 'Other Welfare only'
         4 = 'Social Security only'
         5 = 'Veterans pension'
         6 = 'Other retirement pay, pensions, or annuities only'
         7 = 'Unemployment compensation only'
         8 = 'Worker Compensation only'
         9 = 'Child support only'
        10 = 'Help from relatives only'
        11 = 'Other transfers only'
        15 = 'More than one of the above; any combination'
         0 = 'Inap.:  no transfer income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1987 interview (ER30535>0 and ER30536=0); main family nonresponse by 19'
             '87 or mover-out nonresponse by 1986 (ER30535=0); in an institution in both 1986 and 1987 (ER30536=51-59 and ER30542=0)'
   ;
   VALUE ER30556F
         1 = 'Disability'
         2 = 'Retirement'
         3 = 'Survivor benefits'
         4 = 'Any combination of the above'
         7 = 'Other'
         9 = 'NA; DK'
         0 = 'Inap.:  no Social Security income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1987 interview (ER30535>0 and ER30536=0); main family nonrespons'
             'e by 1987 or mover-out nonresponse by 1986 (ER30535=0); in an institution in both 1986 and 1987 (ER30536=51-59 and ER30542=0); no transfers (ER30555=0)'
   ;
   VALUE ER30562F
         1 = 'Yes, is covered'
         5 = 'No, is not covered'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1987 interview (ER30535>0 and ER30536=0); main family nonresponse by 1987 or mover-out nonr'
             'esponse by 1986 (ER30535=0); in an institution or mover-out nonresponse in 1987 (ER30536=51-89)'
   ;
   VALUE ER30567F
         1 = 'This sample member was 18 years old or older at the time of main family nonresponse and had been in the FU in 1986.'
         2 = 'This sample member was less than 18 at the time of main family nonresponse and had been in the FU in 1986.'
         3 = 'This nonsample individual had been in the 1986 FU, and this FU became nonresponse in 1987.'
         4 = 'This sample member had been in an institution in 1986 but his or her main family became nonresponse in 1987.'
         5 = 'This sample member, although connected with a 1987 response family, was in an institution at the time of the 1987 interview.'
         6 = 'This sample individual was 18 years old or older and moved out or died between the 1986 and 1987 interviews.'
         7 = 'This sample member was less than 18 and moved out or died between the 1986 and 1987 interviews.'
         8 = 'This nonsample individual moved out or died between the 1986 and 1987 interviews.'
         9 = 'This individual had not been born or moved in by the time of the 1987 interview; individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        10 = 'This individual had become nonresponse by the time of the 1986 interview.'
        99 = 'NA; DK'
         0 = 'Inap.:  in a panel family in 1987 (ER30536=1-20).'
   ;
   VALUE ER30568F
         1 = 'Wave refusal by all eligible/available FU members.'
         2 = 'No-one at home for contact during the interviewing period.'
         3 = 'Respondent absent; some FU member contacted, but not the appropriate respondent.'
         4 = 'Lost; unable to locate any member of the FU at all.'
         5 = 'FU is located too far away for interviewer contact.'
        11 = 'This individual was in the armed forces.'
        12 = 'This individual was in an educational institution.'
        13 = 'This individual was in a health care facility'
        14 = 'This individual was in jail or prison'
        19 = 'This individual was in some other type of institution, for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        21 = 'This individual was not eligible for the interview and the Head or the Wife, whichever is the sample member, became main family nonresponse because he/she was institutionalized by joining the armed fo'
             'rces.'
        22 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by entering an educational institution.'
        23 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized by entering a health care facil'
             'ity.'
        24 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized through imprisonment.'
        29 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by some means other than the above; for ex'
             'ample, he/she may have entered a religious order. Cases in which the type of institution is unknown are included here, also.'
        31 = 'This individual was unable to cooperate through disability.'
        32 = 'This individual was not eligible for the interview and the Head or Wife, whichever is sample, was unable to cooperate through disability.'
        41 = 'This individual died between the 1986 and 1987 interviews.'
        42 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, died.'
        51 = 'This individual, although followed for interview, was discovered to be nonsample: office error.'
        52 = 'This individual should have been followed but was not: office error.'
        53 = 'This individual was mistakenly included in two or more response families at once; this record is the duplicate, or erroneous, one.'
        54 = 'Listing error: this individual never existed or was not really living in the FU.'
        59 = 'Other office error'
        91 = 'This sample individual moved out of the 1987 main family and was eligible for interviewing but the reason for nonresponse is NA.'
        92 = 'Individual moved out of the 1987 main family and was not eligible for interviewing because he/she was either nonsample or too young.'
        93 = 'The Head or Wife of this FU, whichever is sample, united with another FU; this individual was not eligible for the interview and therefore became nonresponse.'
        97 = 'This individual had not been born or moved in by the time of the 1987 interview (ER30535>0 and ER30536=0); individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        98 = 'This individual became main family or mover-out nonresponse by 1986 (ER30498=0 and ER30535=0 or ER30498>0 and ER30499=71-89 and ER30535=0)'
        99 = 'NA; DK'
         0 = 'Inap.:  in a panel family in 1987 (ER30536=1-20)'
   ;
   VALUE ER30571F
    1 - 20 = 'Individuals in the family at the time of the 1988 interview'
   51 - 59 = 'Individuals in institutions at the time of the 1988 interview'
   71 - 80 = 'Individuals who moved out of the FU or out of institutions and established their own households between the 1987 and 1988 interviews'
   81 - 89 = 'Individuals who were living in 1987 but died by the time of the 1988 interview'
         0 = 'Inap.:  born or moved in after the 1988 interview; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1988 or mover-out nonresponse by 1987 (ER30570=0'
             ')'
   ;
   VALUE ER30572F
        10 = 'Head in 1988; 1987 Head who was mover-out nonresponse by the time of the 1988 interview'
        20 = 'Legal Wife in 1988; 1987 Wife who was mover-out nonresponse by the time of the 1988 interview'
        22 = '"Wife"--female cohabitor who has lived with Head for 12 months or more or who was present in the 1987 family, since consecutive interviews may be taken less or more than twelve months apart; 1987 "Wif'
             'e" who was mover-out nonresponse by the time of the 1988 interview'
        30 = 'Son or daughter of Head (includes adopted children but not stepchildren)'
        33 = 'Stepson or stepdaughter of Head (children of legal Wife (code 20) who are not children of Head)'
        35 = 'Son or daughter of "Wife" but not Head (includes only those children of mothers whose relationship to Head is 22 but who are not children of Head)'
        37 = 'Son-in-law or daughter-in-law of Head (includes stepchildren-in-law)'
        38 = 'Foster son or foster daughter, not legally adopted'
        40 = 'Brother or sister of Head (includes step and half sisters and brothers)'
        47 = 'Brother-in-law or sister-in-law of Head; i.e., brother or sister of legal Wife, or spouse of Head''s brother or sister.'
        48 = 'Brother or sister of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        50 = 'Father or mother of Head (includes stepparents)'
        57 = 'Father-in-law or mother-in-law of Head (includes parents of legal wives (code 20) only)'
        58 = 'Father or mother of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        60 = 'Grandson or granddaughter of Head (includes grandchildren of legal Wife (code 20), but those of a cohabitor are coded 97)'
        65 = 'Great-grandson or great-granddaughter of Head (includes great-grandchildren of legal Wife (code 20), but those of a cohabitor are coded 97)'
        66 = 'Grandfather or grandmother of Head (includes stepgrandparents)'
        67 = 'Grandfather or grandmother of legal Wife (code 20)'
        68 = 'Great-grandfather or great-grandmother of Head'
        69 = 'Great-grandfather or great-grandmother of legal Wife (code 20)'
        70 = 'Nephew or niece of Head'
        71 = 'Nephew or niece of legal Wife (code 20)'
        72 = 'Uncle or Aunt of Head'
        73 = 'Uncle or Aunt of legal Wife (code 20)'
        74 = 'Cousin of Head'
        75 = 'Cousin of legal Wife (code 20)'
        83 = 'Children of first-year cohabitor but not of Head (the parent of this child is coded 88)'
        88 = 'First-year cohabitor of Head'
        90 = 'Legal husband of Head'
        95 = 'Other relative of Head'
        96 = 'Other relative of legal Wife (code 20)'
        97 = 'Other relative of cohabitor (the cohabitor is code 22 or 88)'
        98 = 'Other nonrelatives (includes homosexual partners, friends of children of the FU, etc.)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1988 interview (ER30570>0 and ER30571=0); main family nonresponse by 1988 or mover-out nonr'
             'esponse by 1987 (ER30570=0)'
   ;
   VALUE ER30576F
         1 = 'Spouse in couple numbered 1'
         2 = 'Spouse in couple numbered 2'
         0 = 'Inap.:  not married or permanently cohabiting; spouse was not in FU at the time of the 1988 interview; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after'
             'the 1988 interview (ER30570>0 and ER30571=0); main family nonresponse by 1988 or mover-out nonresponse by 1987 (ER30570=0)'
   ;
   VALUE ER30577F
         1 = 'Moved in or born between the 1987 and 1988 interviews; splitoff in 1988'
         2 = 'Appeared; moved in by the time the 1987 interview was taken but not included in FU for 1987 (i.e., listing error)'
         5 = 'Moved out of FU or out of an institution between the 1987 and 1988 interviews and was not included in a 1988 panel FU'
         6 = 'Moved out of FU and into an institution between the 1987 and 1988 interviews'
         7 = 'Living in 1987 but died by the time of the 1988 interview'
         8 = 'Disappeared; moved out prior to the 1987 interview, but included in FU for 1987 (usually a listing error)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); in main family in both 1987 and 1988 (ER30536=1-20 and ER30571=1-20); in an institution in both 1987 and 1988 (ER30536'
             '=51-59 and ER30571=51-59); born or moved in after the 1988 interview (ER30570>0 and ER30571=0); main family nonresponse by 1988 or mover-out nonresponse by 1987 (ER30570=0)'
   ;
   VALUE ER30580F
         1 = 'Working now'
         2 = 'Only temporarily laid off'
         3 = 'Looking for work, unemployed'
         4 = 'Retired'
         5 = 'Permanently disabled'
         6 = 'HouseWife; keeping house'
         7 = 'Student'
         8 = 'Other'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1988 or mover-out nonresponse by 1987 (ER30570=0); born or moved in after the 1988 intervie'
             'w (ER30570>0 and ER30571=0); mover-out nonresponse for 1988 only if deceased (ER30571=81-89); in an institution in both 1987 and 1988 (ER30571=51-59 and ER30577=0); not a person aged 16 or older (ER30'
             '573=001-015)'
   ;
   VALUE ER30583F
         1 = 'Full-time student'
         3 = 'Part-time student'
         5 = 'Not enrolled in school'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1988 or mover-out nonresponse by 1987 (ER30570=0); born or moved in after the 1988 intervie'
             'w (ER30570>0 and ER30571=0); Head or Wife/"Wife" in 1988 (ER30571=1-20 and ER30572=10, 20 or 22); in an institution in both 1987 and 1988 (ER30571=51-59 and ER30577=0); not a person aged 16 or older ('
             'ER30573=001-015); last attended school before 1987 (ER30582=1901-1986, 9998 or 9999)'
   ;
   VALUE ER30584F
    1 - 17 = 'Highest grade or year of school completed'
        99 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1988 or mover-out nonresponse by 1987 (ER30570=0); born or moved in after the 1988 intervie'
             'w (ER30570>0 and ER30571=0); in an institution in both 1987 and 1988 (ER30571=51-59 and ER30577=0); not a person aged 16 or older (ER30573=001-015)'
   ;
   VALUE ER30585F
         1 = 'Labor income'
         2 = 'Asset income'
         3 = 'Both labor and asset income'
         0 = 'Inap.:  no taxable income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1988 or mover-out nonresponse by 1987 (ER30570=0); born or moved in afte'
             'r the 1988 interview (ER30570>0 and ER30571=0); in an institution in both 1987 and 1988 (ER30571=51-59 and ER30577=0)'
   ;
   VALUE ER30590F
         1 = 'ADC, AFDC only'
         2 = 'Supplemental Security Income, SSI only'
         3 = 'Other Welfare only'
         4 = 'Social Security only'
         5 = 'Veterans pension'
         6 = 'Other retirement pay, pensions, or annuities only'
         7 = 'Unemployment compensation only'
         8 = 'Worker Compensation only'
         9 = 'Child support only'
        10 = 'Help from relatives only'
        11 = 'Other transfers only'
        15 = 'More than one of the above; any combination'
         0 = 'Inap.:  no transfer income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1988 or mover-out nonresponse by 1987 (ER30570=0); born or moved in aft'
             'er the 1988 interview (ER30570>0 and ER30571=0); in an institution in both 1987 and 1988 (ER30571=51-59 and ER30577=0)'
   ;
   VALUE ER30591F
         1 = 'Disability'
         2 = 'Retirement'
         3 = 'Survivor benefits; dependent of deceased recipient'
         4 = 'Any combination of codes 1-3 and 5-7'
         5 = 'Dependent of disabled recipient'
         6 = 'Dependent of retired recipient'
         7 = 'Other'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  no Social Security income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1988 or mover-out nonresponse by 1987 (ER30570=0); born or moved'
             ' in after the 1988 interview (ER30570>0 and ER30571=0); in an institution in both 1987 and 1988 (ER30571=51-59 and ER30577=0); no transfers (ER30590=0)'
   ;
   VALUE ER30597F
         1 = 'Yes, is covered'
         5 = 'No, is not covered'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1988 or mover-out nonresponse by 1987 (ER30570=0); born or moved in after the 1988 intervie'
             'w (ER30570>0 and ER30571=0); in an institution or mover-out nonresponse in 1988 (ER30571=51-89)'
   ;
   VALUE ER30598F
         1 = 'Yes, is not in good health'
         5 = 'No, is in good health'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1988 or mover-out nonresponse by 1987 (ER30570=0); born or moved in after the 1988 intervie'
             'w (ER30570>0 and ER30571=0); in an institution or mover-out nonresponse in 1988 (ER30571=51-89); current Head or Wife (ER30571=1-2 and ER30572=10, 20, 22)'
   ;
   VALUE ER30603F
         1 = 'This sample member was 18 years old or older at the time of main family nonresponse and had been in the FU in 1987.'
         2 = 'This sample member was less than 18 at the time of main family nonresponse and had been in the FU in 1987.'
         3 = 'This nonsample individual had been in the 1987 FU, and this FU became nonresponse in 1988.'
         4 = 'This sample member had been in an institution in 1987 but his or her main family became nonresponse in 1988.'
         5 = 'This sample member, although connected with a 1988 response family, was in an institution at the time of the 1988 interview.'
         6 = 'This sample individual was 18 years old or older and moved out or died between the 1987 and 1988 interviews.'
         7 = 'This sample member was less than 18 and moved out or died between the 1987 and 1988 interviews.'
         8 = 'This nonsample individual moved out or died between the 1987 and 1988 interviews.'
         9 = 'This individual had not been born or moved in by the time of the 1988 interview; individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        10 = 'This individual had become nonresponse by the time of the 1987 interview.'
        99 = 'NA; DK'
         0 = 'Inap.:  in a panel family in 1988 (ER30571=1-20).'
   ;
   VALUE ER30604F
         1 = 'Wave refusal by all eligible/available FU members.'
         2 = 'No-one at home for contact during the interviewing period.'
         3 = 'Respondent absent; some FU member contacted, but not the appropriate respondent.'
         4 = 'Lost; unable to locate any member of the FU at all.'
         5 = 'FU is located too far away for interviewer contact.'
        11 = 'This individual was in the armed forces.'
        12 = 'This individual was in an educational institution.'
        13 = 'This individual was in a health care facility'
        14 = 'This individual was in jail or prison'
        19 = 'This individual was in some other type of institution, for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        21 = 'This individual was not eligible for the interview and the Head or the Wife, whichever is the sample member, became main family nonresponse because he/she was institutionalized by joining the armed fo'
             'rces.'
        22 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by entering an educational institution.'
        23 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized by entering a health care facil'
             'ity.'
        24 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized through imprisonment.'
        29 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by some means other than the above; for ex'
             'ample, he/she may have entered a religious order. Cases in which the type of institution is unknown are included here, also.'
        31 = 'This individual was unable to cooperate through disability.'
        32 = 'This individual was not eligible for the interview and the Head or Wife, whichever is sample, was unable to cooperate through disability.'
        41 = 'This individual died between the 1987 and 1988 interviews.'
        42 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, died.'
        51 = 'This individual, although followed for interview, was discovered to be nonsample: office error.'
        52 = 'This individual should have been followed but was not: office error.'
        53 = 'This individual was mistakenly included in two or more response families at once; this record is the duplicate, or erroneous, one.'
        54 = 'Listing error: this individual never existed or was not really living in the FU.'
        59 = 'Other office error'
        91 = 'This sample individual moved out of the 1988 main family and was eligible for interviewing but the reason for nonresponse is NA.'
        92 = 'Individual moved out of the 1988 main family and was not eligible for interviewing because he/she was either nonsample or too young.'
        93 = 'The Head or Wife of this FU, whichever is sample, united with another FU; this individual was not eligible for the interview and therefore became nonresponse.'
        97 = 'This individual had not been born or moved in by the time of the 1988 interview (ER30570>0 and ER30571=0); individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        98 = 'This individual became main family or mover-out nonresponse by 1987 (ER30535=0 and ER30570=0 or ER30535>0 and ER30536=71-89 and ER30570=0)'
        99 = 'NA; DK'
         0 = 'Inap.:  in a panel family in 1988 (ER30571=1-20)'
   ;
   VALUE ER30607F
    1 - 20 = 'Individuals in the family at the time of the 1989 interview'
   51 - 59 = 'Individuals in institutions at the time of the 1989 interview'
   71 - 80 = 'Individuals who moved out of the FU or out of institutions and established their own households between the 1988 and 1989 interviews'
   81 - 89 = 'Individuals who were living in 1988 but died by the time of the 1989 interview'
         0 = 'Inap.:  born or moved in after the 1989 interview; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1989 or mover-out nonresponse by 1988 (ER30606=0'
             ')'
   ;
   VALUE ER30608F
        10 = 'Head in 1989; 1988 Head who was mover-out nonresponse by the time of the 1989 interview'
        20 = 'Legal Wife in 1989; 1988 Wife who was mover-out nonresponse by the time of the 1989 interview'
        22 = '"Wife"--female cohabitor who has lived with Head for 12 months or more or who was present in the 1988 family, since consecutive interviews may be taken less or more than twelve months apart; 1988 "Wif'
             'e" who was mover-out nonresponse by the time of the 1989 interview'
        30 = 'Son or daughter of Head (includes adopted children but not stepchildren)'
        33 = 'Stepson or stepdaughter of Head (children of legal Wife (code 20) who are not children of Head)'
        35 = 'Son or daughter of "Wife" but not Head (includes only those children of mothers whose relationship to Head is 22 but who are not children of Head)'
        37 = 'Son-in-law or daughter-in-law of Head (includes stepchildren-in-law)'
        38 = 'Foster son or foster daughter, not legally adopted'
        40 = 'Brother or sister of Head (includes step and half sisters and brothers)'
        47 = 'Brother-in-law or sister-in-law of Head; i.e., brother or sister of legal Wife, or spouse of Head''s brother or sister.'
        48 = 'Brother or sister of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        50 = 'Father or mother of Head (includes stepparents)'
        57 = 'Father-in-law or mother-in-law of Head (includes parents of legal wives (code 20) only)'
        58 = 'Father or mother of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        60 = 'Grandson or granddaughter of Head (includes grandchildren of legal Wife (code 20), but those of a cohabitor are coded 97)'
        65 = 'Great-grandson or great-granddaughter of Head (includes great-grandchildren of legal Wife (code 20), but those of a cohabitor are coded 97)'
        66 = 'Grandfather or grandmother of Head (includes stepgrandparents)'
        67 = 'Grandfather or grandmother of legal Wife (code 20)'
        68 = 'Great-grandfather or great-grandmother of Head'
        69 = 'Great-grandfather or great-grandmother of legal Wife (code 20)'
        70 = 'Nephew or niece of Head'
        71 = 'Nephew or niece of legal Wife (code 20)'
        72 = 'Uncle or Aunt of Head'
        73 = 'Uncle or Aunt of legal Wife (code 20)'
        74 = 'Cousin of Head'
        75 = 'Cousin of legal Wife (code 20)'
        83 = 'Children of first-year cohabitor but not of Head (the parent of this child is coded 88)'
        88 = 'First-year cohabitor of Head'
        90 = 'Legal husband of Head'
        95 = 'Other relative of Head'
        96 = 'Other relative of legal Wife (code 20)'
        97 = 'Other relative of cohabitor (the cohabitor is code 22 or 88)'
        98 = 'Other nonrelatives (includes homosexual partners, friends of children of the FU, etc.)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1989 interview (ER30606>0 and ER30607=0); main family nonresponse by 1989 or mover-out nonr'
             'esponse by 1988 (ER30606=0)'
   ;
   VALUE ER30612F
         1 = 'Spouse in couple numbered 1'
         2 = 'Spouse in couple numbered 2'
         3 = 'Spouse in couple numbered 3'
         0 = 'Inap.:  not married or permanently cohabiting; spouse was not in FU at the time of the 1989 interview; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after'
             'the 1989 interview (ER30606>0 and ER30607=0); main family nonresponse by 1989 or mover-out nonresponse by 1988 (ER30606=0)'
   ;
   VALUE ER30613F
         1 = 'Moved in or born between the 1988 and 1989 interviews; splitoff in 1989'
         2 = 'Appeared; moved in by the time the 1988 interview was taken but not included in FU for 1988 (i.e., listing error)'
         5 = 'Moved out of FU or out of an institution between the 1988 and 1989 interviews and was not included in a 1989 panel FU'
         6 = 'Moved out of FU and into an institution between the 1988 and 1989 interviews'
         7 = 'Living in 1988 but died by the time of the 1989 interview'
         8 = 'Disappeared; moved out prior to the 1988 interview, but included in FU for 1988 (usually a listing error)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); in main family in both 1988 and 1989 (ER30571=1-20 and ER30607=1-20); in an institution in both 1988 and 1989 (ER30571'
             '=51-59 and ER30607=51-59); born or moved in after the 1989 interview (ER30606>0 and ER30607=0); main family nonresponse by 1989 or mover-out nonresponse by 1988 (ER30606=0)'
   ;
   VALUE ER30616F
         1 = 'Working now'
         2 = 'Only temporarily laid off'
         3 = 'Looking for work, unemployed'
         4 = 'Retired'
         5 = 'Permanently disabled'
         6 = 'HouseWife; keeping house'
         7 = 'Student'
         8 = 'Other'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1989 interview (ER30606>0 and ER30607=0); main family nonresponse by 1989 or mover-out nonr'
             'esponse by 1988 (ER30606=0); mover-out nonresponse for 1989 only if deceased (ER30607=81-89); in an institution in both 1988 and 1989 (ER30607=51-59 and ER30613=0); not a person aged 16 or older (ER30'
             '609=001-015)'
   ;
   VALUE ER30619F
         1 = 'Full-time student'
         3 = 'Part-time student'
         5 = 'Not enrolled in school'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1989 interview (ER30606>0 and ER30607=0); main family nonresponse by 1989 or mover-out nonr'
             'esponse by 1988 (ER30606=0); Head or Wife/"Wife" in 1989 (ER30607=1-20 and ER30608=10, 20 or 22); in an institution in both 1988 and 1989 (ER30607=51-59 and ER30613=0); not a person aged 16 or older ('
             'ER30609=001-015); last attended school before 1988 (ER30618=1901-1987, 9998 or 9999)'
   ;
   VALUE ER30620F
    1 - 17 = 'Highest grade or year of school completed'
        99 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1989 interview (ER30606>0 and ER30607=0); main family nonresponse by 1989 or mover-out nonr'
             'esponse by 1988 (ER30606=0); in an institution in both 1988 and 1989 (ER30607=51-59 and ER30613=0); not a person aged 16 or older (ER30609=001-015)'
   ;
   VALUE ER30621F
         1 = 'Labor income'
         2 = 'Asset income'
         3 = 'Both labor and asset income'
         0 = 'Inap.:  no taxable income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1989 interview (ER30606>0 and ER30607=0); main family nonresponse by 198'
             '9 or mover-out nonresponse by 1988 (ER30606=0); in an institution in both 1988 and 1989 (ER30607=51-59 and ER30613=0)'
   ;
   VALUE ER30626F
         1 = 'ADC, AFDC only'
         2 = 'Supplemental Security Income, SSI only'
         3 = 'Other Welfare only'
         4 = 'Social Security only'
         5 = 'Veterans pension'
         6 = 'Other retirement pay, pensions, or annuities only'
         7 = 'Unemployment compensation only'
         8 = 'Worker Compensation only'
         9 = 'Child support only'
        10 = 'Help from relatives only'
        11 = 'Other transfers only'
        15 = 'More than one of the above; any combination'
         0 = 'Inap.:  no transfer income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1989 interview (ER30606>0 and ER30607=0); main family nonresponse by 19'
             '89 or mover-out nonresponse by 1988 (ER30606=0); in an institution in both 1988 and 1989 (ER30607=51-59 and ER30613=0)'
   ;
   VALUE ER30627F
         1 = 'Disability'
         2 = 'Retirement'
         3 = 'Survivor benefits; dependent of deceased recipient'
         4 = 'Any combination of codes 1-3 and 5-7'
         5 = 'Dependent of disabled recipient'
         6 = 'Dependent of retired recipient'
         7 = 'Other'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  no Social Security income; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1989 interview (ER30606>0 and ER30607=0); main family nonrespons'
             'e by 1989 or mover-out nonresponse by 1988 (ER30606=0); in an institution in both 1988 and 1989 (ER30607=51-59 and ER30613=0); no transfers (ER30626=0)'
   ;
   VALUE ER30633F
         1 = 'Yes, is covered'
         5 = 'No, is not covered'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1989 interview (ER30606>0 and ER30607=0); main family nonresponse by 1989 or mover-out nonr'
             'esponse by 1988 (ER30606=0); in an institution or mover-out nonresponse in 1989 (ER30607=51-89)'
   ;
   VALUE ER30634F
         1 = 'Yes, is not in good health'
         5 = 'No, is in good health'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1989 interview (ER30606>0 and ER30607=0); main family nonresponse by 1989 or mover-out nonr'
             'esponse by 1988 (ER30606=0); in an institution or mover-out nonresponse in 1989 (ER30607=51-89); current Head or Wife (ER30607=1-2 and ER30608=10, 20, 22)'
   ;
   VALUE ER30639F
         1 = 'This sample member was 18 years old or older at the time of main family nonresponse and had been in the FU in 1988.'
         2 = 'This sample member was less than 18 at the time of main family nonresponse and had been in the FU in 1988.'
         3 = 'This nonsample individual had been in the 1988 FU, and this FU became nonresponse in 1989.'
         4 = 'This sample member had been in an institution in 1988 but his or her main family became nonresponse in 1989.'
         5 = 'This sample member, although connected with a 1989 response family, was in an institution at the time of the 1989 interview.'
         6 = 'This sample individual was 18 years old or older and moved out or died between the 1988 and 1989 interviews.'
         7 = 'This sample member was less than 18 and moved out or died between the 1988 and 1989 interviews.'
         8 = 'This nonsample individual moved out or died between the 1988 and 1989 interviews.'
         9 = 'This individual had not been born or moved in by the time of the 1989 interview; individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        10 = 'This individual had become nonresponse by the time of the 1988 interview.'
        99 = 'NA; DK'
         0 = 'Inap.:  in a panel family in 1989 (ER30607=1-20).'
   ;
   VALUE ER30640F
         1 = 'Wave refusal by all eligible/available FU members.'
         2 = 'No-one at home for contact during the interviewing period.'
         3 = 'Respondent absent; some FU member contacted, but not the appropriate respondent.'
         4 = 'Lost; unable to locate any member of the FU at all.'
         5 = 'FU is located too far away for interviewer contact.'
        11 = 'This individual was in the armed forces.'
        12 = 'This individual was in an educational institution.'
        13 = 'This individual was in a health care facility'
        14 = 'This individual was in jail or prison'
        19 = 'This individual was in some other type of institution, for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        21 = 'This individual was not eligible for the interview and the Head or the Wife, whichever is the sample member, became main family nonresponse because he/she was institutionalized by joining the armed fo'
             'rces.'
        22 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by entering an educational institution.'
        23 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized by entering a health care facil'
             'ity.'
        24 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized through imprisonment.'
        29 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by some means other than the above; for ex'
             'ample, he/she may have entered a religious order. Cases in which the type of institution is unknown are included here, also.'
        31 = 'This individual was unable to cooperate through disability.'
        32 = 'This individual was not eligible for the interview and the Head or Wife, whichever is sample, was unable to cooperate through disability.'
        41 = 'This individual died between the 1988 and 1989 interviews.'
        42 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, died.'
        51 = 'This individual, although followed for interview, was discovered to be nonsample: office error.'
        52 = 'This individual should have been followed but was not: office error.'
        53 = 'This individual was mistakenly included in two or more response families at once; this record is the duplicate, or erroneous, one.'
        54 = 'Listing error: this individual never existed or was not really living in the FU.'
        59 = 'Other office error'
        91 = 'This sample individual moved out of the 1989 main family and was eligible for interviewing but the reason for nonresponse is NA.'
        92 = 'Individual moved out of the 1989 main family and was not eligible for interviewing because he/she was either nonsample or too young.'
        93 = 'The Head or Wife of this FU, whichever is sample, united with another FU; this individual was not eligible for the interview and therefore became nonresponse.'
        97 = 'This individual had not been born or moved in by the time of the 1989 interview (ER30606>0 and ER30607=0); individual from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308)'
        98 = 'This individual became main family or mover-out nonresponse by 1988 (ER30570=0 and ER30606=0 or ER30570>0 and ER30571=71-89 and ER30606=0)'
        99 = 'NA; DK'
         0 = 'Inap.:  in a panel family in 1989 (ER30607=1-20)'
   ;
   VALUE ER30643F
    1 - 20 = 'Individuals in the family at the time of the 1990 interview'
   51 - 59 = 'Individuals in institutions at the time of the 1990 interview'
   71 - 80 = 'Individuals who moved out of the FU or out of institutions and established their own households between the 1989 and 1990 interviews'
   81 - 89 = 'Individuals who were living in 1989 but died by the time of the 1990 interview'
         0 = 'Inap.:  born or moved in after the 1990 interview; from Immigrant or Latino recontact sample (ER30001=3001-3511,4001-4462, 9044-9308); main family nonresponse by 1990 or mover-out nonresponse by 1989'
             '(ER30642=0)'
   ;
   VALUE ER30644F
        10 = 'Head in 1990; 1989 Head who was mover-out nonresponse by the time of the 1990 interview'
        20 = 'Legal Wife in 1990; 1989 Wife who was mover-out nonresponse by the time of the 1990 interview'
        22 = '"Wife"--female cohabitor who has lived with Head for 12 months or more or who was present in the 1989 family, since consecutive interviews may be taken less or more than twelve months apart; 1989 "Wif'
             'e" who was mover-out nonresponse by the time of the 1990 interview'
        30 = 'Son or daughter of Head (includes adopted children but not stepchildren)'
        33 = 'Stepson or stepdaughter of Head (children of legal Wife (code 20) who are not children of Head)'
        35 = 'Son or daughter of "Wife" but not Head (includes only those children of mothers whose relationship to Head is 22 but who are not children of Head)'
        37 = 'Son-in-law or daughter-in-law of Head (includes stepchildren-in-law)'
        38 = 'Foster son or foster daughter, not legally adopted'
        40 = 'Brother or sister of Head (includes step and half sisters and brothers)'
        47 = 'Brother-in-law or sister-in-law of Head; i.e., brother or sister of legal Wife, or spouse of Head''s brother or sister.'
        48 = 'Brother or sister of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        50 = 'Father or mother of Head (includes stepparents)'
        57 = 'Father-in-law or mother-in-law of Head (includes parents of legal wives (code 20) only)'
        58 = 'Father or mother of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        60 = 'Grandson or granddaughter of Head (includes grandchildren of legal Wife (code 20), but those of a cohabitor are coded 97)'
        65 = 'Great-grandson or great-granddaughter of Head (includes great-grandchildren of of legal Wife (code 20), but those of a cohabitor are coded 97)'
        66 = 'Grandfather or grandmother of Head (includes stepgrandparents)'
        67 = 'Grandfather or grandmother of legal Wife (code 20)'
        68 = 'Great-grandfather or great-grandmother of Head'
        69 = 'Great-grandfather or great-grandmother of legal Wife (code 20)'
        70 = 'Nephew or niece of Head'
        71 = 'Nephew or niece of legal Wife (code 20)'
        72 = 'Uncle or Aunt of Head'
        73 = 'Uncle or Aunt of legal Wife (code 20)'
        74 = 'Cousin of Head'
        75 = 'Cousin of legal Wife (code 20)'
        83 = 'Children of first-year cohabitor but not of Head (the parent of this child is coded 88)'
        88 = 'First-year cohabitor of Head'
        90 = 'Legal husband of Head'
        95 = 'Other relative of Head'
        96 = 'Other relative of legal Wife (code 20)'
        97 = 'Other relative of cohabitor (the cohabitor is code 22 or 88)'
        98 = 'Other nonrelatives (includes homosexual partners, friends of children of the FU, etc.)'
         0 = 'Inap.:  from Immigrant or Latino recontact sample (ER30001=3001-3511,4001-4462, 9044-9308); main family nonresponse by 1990 or mover-out nonresponse by 1989 (ER30642=0); born or moved in after the 199'
             '0 interview (ER30642>0 and ER30643=0)'
   ;
   VALUE ER30648F
         1 = 'Spouse in couple numbered 1'
         2 = 'Spouse in couple numbered 2'
         3 = 'Spouse in couple numbered 3'
         0 = 'Inap.:  not married or permanently cohabiting; spouse was not in FU at the time of the 1990 interview; from Immigrant or Latino recontact sample (ER30001=3001-3511,4001-4462, 9044-9308); main family n'
             'onresponse by 1990 or mover-out nonresponse by 1989 (ER30642=0); born or moved in after the 1990 interview (ER30642>0 and ER30643=0)'
   ;
   VALUE ER30649F
         1 = 'Moved in or born between the 1989 and 1990 interviews; splitoff in 1990'
         2 = 'Appeared; moved in by the time the 1989 interview was taken but not included in FU for 1989 (i.e., listing error)'
         5 = 'Moved out of FU or out of an institution between the 1989 and 1990 interviews and was not included in a 1990 panel FU'
         6 = 'Moved out of FU and into an institution between the 1989 and 1990 interviews'
         7 = 'Living in 1989 but died by the time of the 1990 interview'
         8 = 'Disappeared; moved out prior to the 1989 interview, but included in FU for 1989 (usually a listing error)'
         0 = 'Inap.:  main Latino sample non-mover, either in the FU or in an institution; from Immigrant or Latino recontact sample (ER30001=3001-3511,4001-4462, 9044-9308); core sample individual in main family i'
             'n both 1989 and 1990 (ER30607=1-20 and ER30643=1-20); core sample individual in an institution in both 1989 and 1990 (ER30607=51-59 and ER30643=51-59); main family nonresponse by 1990 or mover-out non'
             'response by 1989 (ER30642=0); born or moved in after the 1990 interview (ER30642>0 and ER30643=0)'
   ;
   VALUE ER30653F
         1 = 'Working now'
         2 = 'Only temporarily laid off'
         3 = 'Looking for work, unemployed'
         4 = 'Retired'
         5 = 'Permanently disabled'
         6 = 'HouseWife; keeping house'
         7 = 'Student'
         8 = 'Other'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino recontact sample (ER30001=3001-3511,4001-4462, 9044-9308); main family nonresponse by 1990 or mover-out nonresponse by 1989 (ER30642=0); born or moved in after the 199'
             '0 interview (ER30642>0 and ER30643=0); mover-out nonresponse for 1990 only if deceased (ER30643=81-89); in an institution in both 1989 and 1990 (ER30643=51-59 and ER30649=0); not a person aged 16 or o'
             'lder (ER30645=001-015)'
   ;
   VALUE ER30656F
         1 = 'Full-time student'
         3 = 'Part-time student'
         5 = 'Not enrolled in school'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino recontact sample (ER30001=3001-3511,4001-4462, 9044-9308); main family nonresponse by 1990 or mover-out nonresponse by 1989 (ER30642=0); born or moved in after the 199'
             '0 interview (ER30642>0 and ER30643=0); Head or Wife/"Wife" in 1990 (ER30643=1-20 and ER30644=10, 20 or 22); in an institution in both 1989 and 1990 (ER30643=51-59 and ER30649=0); not a person aged 16'
             'or older (ER30645=001-015); last attended school before 1989 (ER30655=1901-1988, 9998 or 9999)'
   ;
   VALUE ER30657F
    1 - 17 = 'Highest grade or year of school completed'
        99 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino recontact sample (ER30001=3001-3511,4001-4462, 9044-9308); main family nonresponse by 1990 or mover-out nonresponse by 1989 (ER30642=0); born or moved in after the 199'
             '0 interview (ER30642>0 and ER30643=0); in an institution in both 1989 and 1990 (ER30643=51-59 and ER30649=0); not a person aged 16 or older (ER30645=001-015)'
   ;
   VALUE ER30658F
         1 = 'Labor income'
         2 = 'Asset income'
         3 = 'Both labor and asset income'
         0 = 'Inap.:  no taxable income; from Immigrant or Latino recontact sample (ER30001=3001-3511,4001-4462, 9044-9308); main family nonresponse by 1990 or mover-out nonresponse by 1989 (ER30642=0); born or mov'
             'ed in after the 1990 interview (ER30642>0 and ER30643=0); in an institution in both 1989 and 1990 (ER30643=51-59 and ER30649=0)'
   ;
   VALUE ER30663F
         1 = 'ADC, AFDC only'
         2 = 'Supplemental Security Income, SSI only'
         3 = 'Other Welfare only'
         4 = 'Social Security only'
         5 = 'Veterans pension'
         6 = 'Other retirement pay, pensions, or annuities only'
         7 = 'Unemployment compensation only'
         8 = 'Worker Compensation only'
         9 = 'Child support only'
        10 = 'Help from relatives only'
        11 = 'Other transfers only'
        15 = 'More than one of the above; any combination'
         0 = 'Inap.:  no transfer income; from Immigrant or Latino recontact sample (ER30001=3001-3511,4001-4462, 9044-9308); main family nonresponse by 1990 or mover-out nonresponse by 1989 (ER30642=0); born or mo'
             'ved in after the 1990 interview (ER30642>0 and ER30643=0); in an institution in both 1989 and 1990 (ER30643=51-59 and ER30649=0)'
   ;
   VALUE ER30664F
         1 = 'Disability'
         2 = 'Retirement'
         3 = 'Survivor benefits; dependent of deceased recipient'
         4 = 'Any combination of codes 1-3 and 5-7'
         5 = 'Dependent of disabled recipient'
         6 = 'Dependent of retired recipient'
         7 = 'Other'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  no Social Security income; from Immigrant or Latino recontact sample (ER30001=3001-3511,4001-4462, 9044-9308); main family nonresponse by 1990 or mover-out nonresponse by 1989 (ER30642=0); bor'
             'n or moved in after the 1990 interview (ER30642>0 and ER30643=0); in an institution in both 1989 and 1990 (ER30643=51-59 and ER30649=0); no transfers (ER30663=0)'
   ;
   VALUE ER30670F
         1 = 'Yes, is covered'
         5 = 'No, is not covered'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino recontact sample (ER30001=3001-3511,4001-4462, 9044-9308); main family nonresponse by 1990 or mover-out nonresponse by 1989 (ER30642=0); born or moved in after the 199'
             '0 interview (ER30642>0 and ER30643=0); in an institution or mover-out nonresponse in 1990 (ER30643=51-89)'
   ;
   VALUE ER30671F
         1 = 'Yes, is not in good health'
         5 = 'No, is in good health'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino recontact sample (ER30001=3001-3511,4001-4462, 9044-9308); main family nonresponse by 1990 or mover-out nonresponse by 1989 (ER30642=0); born or moved in after the 199'
             '0 interview (ER30642>0 and ER30643=0); in an institution or mover-out nonresponse in 1990 (ER30643=51-89); current Head or Wife (ER30643=1-2 and ER30644=10, 20, 22)'
   ;
   VALUE ER30681F
         1 = 'This individual became nonresponse between 1985 and 1989, was aged 65 or older in 1990, and was an original PSID sample member: selected for the 1990 elderly recontact sample'
         2 = 'This individual became nonresponse between 1985 and 1989, was aged 65 or older in 1990, and had moved into the study after it began (i.e., was not an original PSID sample member): selected for the 199'
             '0 elderly recontact sample'
         3 = 'This individual was a member of a Latino sample family'
         4 = 'This individual was in a 1989 family or an institution (ER30643=1-20, 51-59), was aged 17 or older in 1989, and was a sample member (ER30002=001-169): this person was followable for the 1990 interview'
             ' '
         5 = 'This individual was in a 1989 family or an institution (ER30643=1-20, 51-59), was aged 64 or older in 1989, and was not sample (ER30002=170-227): this person was followable for the 1990 interview'
         0 = 'Inap: this individual was nonsample and under age 64 in 1989; this individual was sample and under age 17 in 1989; this individual was nonresponse by 1989 but was not eligible for the 1990 elderly rec'
             'ontact effort; from Immigrant or Latino recontact sample (ER30001=3001-3511,4001-4462, 9044-9308); born or moved in after the 1990 interview (ER30642>0 and ER30643=0)'
   ;
   VALUE ER30682F
         1 = 'This individual is 1990 Head, Wife or "Wife", aged 50 or older, eligible for the SAQ and returned a useable questionnaire'
         2 = 'This individual is 1990 core sample Head, Wife or "Wife", under age 50, and so ineligible for the SAQ'
         3 = 'This individual is 1990 core sample Head, Wife or "Wife", aged 50 or older, eligible for the SAQ but actively refused to complete it'
         4 = 'This individual is 1990 core sample Head, Wife or "Wife", aged 50 or older, eligible for the SAQ but died after the completion of the 1990 interview but before returning a SAQ'
         5 = 'This individual is 1990 core sample Head, Wife or "Wife", aged 50 or older, and ineligible for the SAQ because Spanish was the preferred language for the interview'
         6 = 'This individual is 1990 core sample Head, Wife or "Wife", aged 50 or older, eligible for the SAQ but returned a blank one'
         7 = 'This individual is 1990 core sample Head, Wife or "Wife", aged 50 or older, eligible for the SAQ but did not return it (passive refusal)'
         0 = 'Inap.: This individual is not core sample (ER30001=3011-3511, 7001-9308); born or moved in after the 1990 interview (ER30642>0 and ER30643=0); this individual is not 1990 Head, Wife or "Wife" (ER30643'
             '=1-02 and ER30644=10, 20 or 22)'
   ;
   VALUE ER30683F
         1 = 'This individual is 1990 core sample Head, Wife or "Wife", aged 50 or older, covered by Medicare, gave permission and returned a useable Medicare number and signed permission form.'
         2 = 'This individual is 1990 core sample Head, Wife or "Wife" aged 65 or older who reported he or she was not covered by Medicare; this individual is 1990 core sample Head, Wife or "Wife" aged 50 to 64 who'
             ' reported he or she was eligible for but not covered by Medicare.'
         3 = 'This individual is 1990 core sample Head, Wife or "Wife" aged 65 or older who actively refused to give permission; this individual is 1990 core sample Head, Wife or "Wife" aged 50 to 64 who reported h'
             'e or she was eligible for Medicare but actively refused to give permission.'
         4 = 'This individual is 1990 core sample Head, Wife or "Wife" aged 50 or older, eligible to receive Medicare and gave permission but did not give his or her Medicare participant number.'
         5 = 'This individual is 1990 core sample Head, Wife or "Wife", aged 65 or older who left the permission form blank; this individual is 1990 core sample Head, Wife or "Wife" who reported he or she was eligi'
             'ble for Medicare but left the permission form blank.'
         6 = 'This individual is 1990 core sample Head, Wife or "Wife" aged 50 or older who supplied a Medicare participant number but omitted the authorizing signature. He or she may or may not have answered the p'
             'ermission question.'
         7 = 'This individual is 1990 core sample Head, Wife or "Wife" aged 50 to 64 but it was not ascertained whether he or she was eligible for Medicare, and the permission form was left blank.'
         8 = 'This individual is 1990 core sample Head, Wife or "Wife" aged 50 to 64 who says he or she is not eligible for Medicare.'
         9 = 'This individual is 1990 core sample Head, Wife or "Wife" aged 65 or older who gave a Medicare participant number and gave an authorizing signature but who left the permission question blank.'
         0 = 'Inap.:  this individual is not core sample (ER30001=3001-3511,4001-4462,7001-9308); born or moved in after the 1990 interview (ER30642>0 and ER30643=0); this individual is not 1990 Head, Wife or "Wife'
             '" (ER30643>01 and ER30644 NE 20 or 22); this individual is 1990 core sample Head, Wife or "Wife", but is under age 50, and so ineligible for Medicare permission (ER30643=1-02 and ER30644=10, 20 or 22'
             'and ER30645<050); this individual is core sample Head, Wife or "Wife" aged 50 or older but did not respond to the SAQ or the permission mailing (ER30682=3-6)'
   ;
   VALUE ER30684F
         1 = 'This sample member was 18 years old or older at the time of main family nonresponse and had been in the FU in 1989; this 1990 elderly recontact individual was not successfully interviewed'
         2 = 'This sample member was less than 18 at the time of main family nonresponse and had been in the FU in 1989.'
         3 = 'This nonsample individual had been in the 1989 FU, and this FU became nonresponse in 1990.'
         4 = 'This sample member had been in an institution in 1989 but his or her main family became nonresponse in 1990.'
         5 = 'This sample member, although connected with a 1990 response family, was in an institution at the time of the 1990 interview.'
         6 = 'This sample individual was 18 years old or older and moved out or died between the 1989 and 1990 interviews.'
         7 = 'This sample member was less than 18 and moved out or died between the 1989 and 1990 interviews.'
         8 = 'This nonsample individual moved out or died between the 1989 and 1990 interviews.'
         9 = 'This individual had not been born or moved in by the time of the 1990 interview; individual from Immigrant or Latino recontact sample (ER30001=3001-3511,4001-4462, 9044-9308)'
        10 = 'This individual had become nonresponse by the time of the 1989 interview.'
        99 = 'NA; DK'
         0 = 'Inap.:  this individual was in a panel family in 1990 (ER30643=1-20).'
   ;
   VALUE ER30685F
         1 = 'Wave refusal by all eligible/available FU members.'
         2 = 'No-one at home for contact during the interviewing period.'
         3 = 'Respondent absent; some FU member contacted, but not the appropriate respondent.'
         4 = 'Lost; unable to locate any member of the FU at all.'
         5 = 'FU is located too far away for interviewer contact.'
        11 = 'This individual was in the armed forces.'
        12 = 'This individual was in an educational institution.'
        13 = 'This individual was in a health care facility'
        14 = 'This individual was in jail or prison'
        19 = 'This individual was in some other type of institution, for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        21 = 'This individual was not eligible for the interview and the Head or the Wife, whichever is the sample member, became main family nonresponse because he/she was institutionalized by joining the armed fo'
             'rces.'
        22 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by entering an educational institution.'
        23 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized by entering a health care facil'
             'ity.'
        24 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized through imprisonment.'
        29 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by some means other than the above; for ex'
             'ample, he/she may have entered a religious order. Cases in which the type of institution is unknown are included here, also.'
        31 = 'This individual was unable to cooperate through disability.'
        32 = 'This individual was not eligible for the interview and the Head or Wife, whichever is sample, was unable to cooperate through disability.'
        41 = 'This individual died between the 1989 and 1990 interviews; this 1990 elderly recontact individual died after becoming nonresponse for some other reason but before the 1990 recontact attempt.'
        42 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, died.'
        51 = 'This individual, although followed for interview, was discovered to be nonsample: office error.'
        52 = 'This individual should have been followed but was not: office error.'
        53 = 'This individual was mistakenly included in two or more response families at once; this record is the duplicate, or erroneous, one.'
        54 = 'Listing error: this individual never existed or was not really living in the FU.'
        59 = 'Other office error'
        91 = 'This sample individual moved out of the 1990 main family and was eligible for interviewing but the reason for nonresponse is NA.'
        92 = 'Individual moved out of the 1990 main family and was not eligible for interviewing because he/she was either nonsample or too young.'
        93 = 'The Head or Wife of this FU, whichever is sample, united with another FU; this individual was not eligible for the interview and therefore became nonresponse.'
        97 = 'This individual had not been born or moved in by the time of the 1990 interview (ER30642>0 and ER30643=0); individual from Immigrant or Latino recontact sample (ER30001=3001-3511,4001-4462, 9044-9308)'
             ' '
        98 = 'This individual became main family or mover-out nonresponse by 1989 (ER30570=0 and ER30642=0 or ER30570>0 and ER30571=71-89 and ER30642=0)'
        99 = 'NA; DK'
         0 = 'Inap.:  this individual was in a panel family in 1990 (ER30643=1-20)'
   ;
   VALUE ER30690F
    1 - 20 = 'Individuals in the family at the time of the 1991 interview'
   51 - 59 = 'Individuals in institutions at the time of the 1991 interview'
   71 - 80 = 'Individuals who moved out of the FU or out of institutions and established their own households between the 1990 and 1991 interviews'
   81 - 89 = 'Individuals who were living in 1990 but died by the time of the 1991 interview'
         0 = 'Inap.:  born or moved in after the 1991 interview; from Immigrant or Latino recontact sample (ER30001=3001-3511,4001-4462, 9044-9308); main family nonresponse by 1991 or mover-out nonresponse by 1990'
             '(ER30689=0)'
   ;
   VALUE ER30691F
        10 = 'Head in 1991; 1990 Head who was mover-out nonresponse by the time of the 1991 interview'
        20 = 'Legal Wife in 1991; 1990 Wife who was mover-out nonresponse by the time of the 1991 interview'
        22 = '"Wife"--female cohabitor who has lived with Head for 12 months or more or who was present in the 1990 family, since consecutive interviews may be taken less or more than twelve months apart; 1990 "Wif'
             'e" who was mover-out nonresponse by the time of the 1991 interview'
        30 = 'Son or daughter of Head (includes adopted children but not stepchildren)'
        33 = 'Stepson or stepdaughter of Head (children of legal Wife (code 20) who are not children of Head)'
        35 = 'Son or daughter of "Wife" but not Head (includes only those children of mothers whose relationship to Head is 22 but who are not children of Head)'
        37 = 'Son-in-law or daughter-in-law of Head (includes stepchildren-in-law)'
        38 = 'Foster son or foster daughter, not legally adopted'
        40 = 'Brother or sister of Head (includes step and half sisters and brothers)'
        47 = 'Brother-in-law or sister-in-law of Head; i.e., brother or sister of legal Wife, or spouse of Head''s brother or sister.'
        48 = 'Brother or sister of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        50 = 'Father or mother of Head (includes stepparents)'
        57 = 'Father-in-law or mother-in-law of Head (includes parents of legal wives (code 20) only)'
        58 = 'Father or mother of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        60 = 'Grandson or granddaughter of Head (includes grandchildren of legal Wife (code 20), but those of a cohabitor are coded 97)'
        65 = 'Great-grandson or great-granddaughter of Head (includes great-grandchildren of legal Wife (code 20), but those of a cohabitor are coded 97)'
        66 = 'Grandfather or grandmother of Head (includes stepgrandparents)'
        67 = 'Grandfather or grandmother of legal Wife (code 20)'
        68 = 'Great-grandfather or great-grandmother of Head'
        69 = 'Great-grandfather or great-grandmother of legal Wife (code 20)'
        70 = 'Nephew or niece of Head'
        71 = 'Nephew or niece of legal Wife (code 20)'
        72 = 'Uncle or Aunt of Head'
        73 = 'Uncle or Aunt of legal Wife (code 20)'
        74 = 'Cousin of Head'
        75 = 'Cousin of legal Wife (code 20)'
        83 = 'Children of first-year cohabitor but not of Head (the parent of this child is coded 88)'
        88 = 'First-year cohabitor of Head'
        90 = 'Legal husband of Head'
        95 = 'Other relative of Head'
        96 = 'Other relative of legal Wife (code 20)'
        97 = 'Other relative of cohabitor (the cohabitor is code 22 or 88)'
        98 = 'Other nonrelatives (includes homosexual partners, friends of children of the FU, etc.)'
         0 = 'Inap.:  from Immigrant or Latino recontact sample (ER30001=3001-3511,4001-4462, 9044-9308); main family nonresponse by 1991 or mover-out nonresponse by 1990 (ER30689=0); born or moved in after the 199'
             '1 interview (ER30689>0 and ER30690=0)'
   ;
   VALUE ER30695F
         1 = 'Spouse in couple numbered 1'
         2 = 'Spouse in couple numbered 2'
         3 = 'Spouse in couple numbered 3'
         0 = 'Inap.:  not married or permanently cohabiting; spouse was not in FU at the time of the 1991 interview; from Immigrant or Latino recontact sample (ER30001=3001-3511,4001-4462, 9044-9308); main family n'
             'onresponse by 1991 or mover-out nonresponse by 1990 (ER30689=0); born or moved in after the 1991 interview (ER30689>0 and ER30690=0)'
   ;
   VALUE ER30696F
         1 = 'Moved in or born between the 1990 and 1991 interviews; splitoff in 1991'
         2 = 'Appeared; moved in by the time the 1990 interview was taken but not included in FU for 1990 (i.e., listing error)'
         5 = 'Moved out of FU or out of an institution between the 1990 and 1991 interviews and was not included in a 1991 panel FU'
         6 = 'Moved out of FU and into an institution between the 1990 and 1991 interviews'
         7 = 'Living in 1990 but died by the time of the 1991 interview'
         8 = 'Disappeared; moved out prior to the 1990 interview, but included in FU for 1990 (usually a listing error)'
         0 = 'Inap.:  from Immigrant or Latino recontact sample (ER30001=3001-3511,4001-4462, 9044-9308); in main family in both 1990 and 1991 (ER30643=1-20 and ER30690=1-20); in an institution in both 1990 and 199'
             '1 (ER30643=51-59 and ER30690=51-59); born or moved in after the 1991 interview (ER30689>0 and ER30690=0); main family nonresponse by 1991 or mover-out nonresponse by 1990 (ER30689=0)'
   ;
   VALUE ER30699F
         1 = 'Working now'
         2 = 'Only temporarily laid off'
         3 = 'Looking for work, unemployed'
         4 = 'Retired'
         5 = 'Permanently disabled'
         6 = 'HouseWife; keeping house'
         7 = 'Student'
         8 = 'Other'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino recontact sample (ER30001=3001-3511,4001-4462, 9044-9308); main family nonresponse by 1991 or mover-out nonresponse by 1990 (ER30689=0); born or moved in after the 199'
             '1 interview (ER30689>0 and ER30690=0); mover-out nonresponse for 1991 only if deceased (ER30690=81-89); in an institution in both 1990 and 1991 (ER30690=51-59 and ER30696=0); not a person aged 16 or o'
             'lder (ER30692=001-015)'
   ;
   VALUE ER30702F
         1 = 'Full-time student'
         3 = 'Part-time student'
         5 = 'Not enrolled in school'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino recontact sample (ER30001=3001-3511,4001-4462, 9044-9308); main family nonresponse by 1991 or mover-out nonresponse by 1990 (ER30689=0); born or moved in after the 199'
             '1 interview (ER30689>0 and ER30690=0); Head or Wife/"Wife" in 1991 (ER30690=1-20 and ER30691=10, 20 or 22); in an institution in both 1990 and 1991 (ER30690=51-59 and ER30696=0); not a person aged 16'
             'or older (ER30692=001-015); last attended school before 1990 (ER30701=1901-1989, 9998 or 9999)'
   ;
   VALUE ER30703F
    1 - 17 = 'Highest grade or year of school completed'
        99 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino recontact sample (ER30001=3001-3511,4001-4462, 9044-9308); main family nonresponse by 1991 or mover-out nonresponse by 1990 (ER30689=0); born or moved in after the 199'
             '1 interview (ER30689>0 and ER30690=0); in an institution in both 1990 and 1991 (ER30690=51-59 and ER30696=0); not a person aged 16 or older (ER30692=001-015)'
   ;
   VALUE ER30704F
         1 = 'Labor income'
         2 = 'Asset income'
         3 = 'Both labor and asset income'
         0 = 'Inap.:  no taxable income; from Immigrant or Latino recontact sample (ER30001=3001-3511,4001-4462, 9044-9308); main family nonresponse by 1991 or mover-out nonresponse by 1990 (ER30689=0); born or mov'
             'ed in after the 1991 interview (ER30689>0 and ER30690=0); in an institution in both 1990 and 1991 (ER30690=51-59 and ER30696=0)'
   ;
   VALUE ER30708F
         1 = 'Minor assignment'
         2 = 'Major assignment'
         0 = 'Inap.:  no assignment; from Immigrant or Latino recontact sample (ER30001=3001-3511,4001-4462, 9044-9308); main family nonresponse by 1991 or mover-out nonresponse by 1990 (ER30689=0); born or moved i'
             'n after the 1991 interview (ER30689>0 and ER30690=0); in an institution in both 1989 and 1990 (ER30690=51-59 and ER30696=0); no asset income (ER30704=0 or 1)'
   ;
   VALUE ER30711F
         1 = 'ADC, AFDC only'
         2 = 'Supplemental Security Income, SSI only'
         3 = 'Other Welfare only'
         4 = 'Social Security only'
         5 = 'Veterans pension'
         6 = 'Other retirement pay, pensions, or annuities only'
         7 = 'Unemployment compensation only'
         8 = 'Worker Compensation only'
         9 = 'Child support only'
        10 = 'Help from relatives only'
        11 = 'Other transfers only'
        15 = 'More than one of the above; any combination'
         0 = 'Inap.:  no transfer income; from Immigrant or Latino recontact sample (ER30001=3001-3511,4001-4462, 9044-9308); main family nonresponse by 1991 or mover-out nonresponse by 1990 (ER30689=0); born or mo'
             'ved in after the 1991 interview (ER30689>0 and ER30690=0); in an institution in both 1990 and 1991 (ER30690=51-59 and ER30696=0)'
   ;
   VALUE ER30712F
         1 = 'Disability'
         2 = 'Retirement'
         3 = 'Survivor benefits; dependent of deceased recipient'
         4 = 'Any combination of codes 1-3 and 5-7'
         5 = 'Dependent of disabled recipient'
         6 = 'Dependent of retired recipient'
         7 = 'Other'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  no Social Security income; from Immigrant or Latino recontact sample (ER30001=3001-3511,4001-4462, 9044-9308); main family nonresponse by 1991 or mover-out nonresponse by 1990 (ER30689=0); bor'
             'n or moved in after the 1991 interview (ER30689>0 and ER30690=0); in an institution in both 1990 and 1991 (ER30690=51-59 and ER30696=0); no transfers (ER30711=0)'
   ;
   VALUE ER30718F
         1 = 'Yes, is covered'
         5 = 'No, is not covered'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino recontact sample (ER30001=3001-3511,4001-4462, 9044-9308); main family nonresponse by 1991 or mover-out nonresponse by 1990 (ER30689=0); born or moved in after the 199'
             '1 interview (ER30689>0 and ER30690=0); in an institution or mover-out nonresponse in 1991 (ER30690=51-89)'
   ;
   VALUE ER30719F
         1 = 'Yes, is not in good health'
         5 = 'No, is in good health'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino recontact sample (ER30001=3001-3511,4001-4462, 9044-9308); main family nonresponse by 1991 or mover-out nonresponse by 1990 (ER30689=0); born or moved in after the 199'
             '1 interview (ER30689>0 and ER30690=0); in an institution or mover-out nonresponse in 1991 (ER30690=51-89); current Head or Wife (ER30690=1-2 and ER30691=10, 20, 22)'
   ;
   VALUE ER30724F
         1 = 'In 1990, this individual was a response sample member aged 17 or older: this person was followable in 1991'
         2 = 'In 1990, this individual was a response nonsample person aged 64 or older: this person was followable in 1991'
         0 = 'Inap: from Immigrant or Latino recontact sample (ER30001=3001-3511,4001-4462, 9044-9308); this individual was sample and under age 17 in 1990 (ER30002=001-169 and ER30643=1-59 and ER30645=001-017); th'
             'is individual was nonsample and under age 64 in 1990 (ER30002=170-227 and ER30643=1-59 and ER30645=001-064); this individual was not a member of a 1990 FU or in an institution in 1990 (ER30643=00, 71-'
             '89)'
   ;
   VALUE ER30725F
         1 = 'This individual is 1991 core sample Head, Wife or "Wife" who renewed permission for 1991.'
         5 = 'This individual is 1991 core sample Head, Wife or "Wife" but no permission renewal was received for 1991.'
         0 = 'Inap.:  this individual is not core sample (ER30001=3001-3511,4001-4462,7001-9308); this individual is not 1991 Head, Wife or "Wife" (ER30690>01 and ER30691 NE 20 or 22); this individual is 1991 core'
             'sample Head, Wife or "Wife", but was not eligible for Medicare permission renewal (ER30683=0, 2-3 or 7-9)'
   ;
   VALUE ER30727F
         1 = 'The PHS contains a data record for the parents of this individual'
         5 = 'At least one of the parents of this individual was eligible for the PHS but no data record exists because of interviewer error, the respondent refused or was not able to answer the supplement, the int'
             'erview was administered in Spanish, etc.'
         0 = 'Inap.:  neither parent was eligible for the PHS; Immigrant or Latino samples individual (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1991 or mover-out nonresponse by 1990 (ER306'
             '89=0); born or moved in after the 1991 interview (ER30689>0 and ER30690=0); not current Head or Wife/"Wife" (ER30690 NE 01 or 02 and ER30691 NE 0, 20, or 22)'
   ;
   VALUE ER30728F
         1 = 'This sample member was 18 years old or older at the time of main family nonresponse and had been in the FU in 1990.'
         2 = 'This sample member was less than 18 at the time of main family nonresponse and had been in the FU in 1990.'
         3 = 'This nonsample individual had been in the 1990 FU, and this FU became nonresponse in 1991.'
         4 = 'This sample member had been in an institution in 1990 but his or her main family became nonresponse in 1991.'
         5 = 'This sample member, although connected with a 1991 response family, was in an institution at the time of the 1991 interview.'
         6 = 'This sample individual was 18 years old or older and moved out or died between the 1990 and 1991 interviews.'
         7 = 'This sample member was less than 18 and moved out or died between the 1990 and 1991 interviews.'
         8 = 'This nonsample individual moved out or died between the 1990 and 1991 interviews.'
         9 = 'This individual had not been born or moved in by the time of the 1991 interview; individual from Immigrant or Latino recontact sample (ER30001=3001-3511,4001-4462, 9044-9308)'
        10 = 'This individual had become nonresponse by the time of the 1990 interview.'
        99 = 'NA; DK'
         0 = 'Inap.:  this individual was in a panel family in 1991 (ER30690=1-20).'
   ;
   VALUE ER30729F
         1 = 'Wave refusal by all eligible/available FU members.'
         2 = 'No-one at home for contact during the interviewing period.'
         3 = 'Respondent absent; some FU member contacted, but not the appropriate respondent.'
         4 = 'Lost; unable to locate any member of the FU at all.'
         5 = 'FU is located too far away for interviewer contact.'
        11 = 'This individual was in the armed forces.'
        12 = 'This individual was in an educational institution.'
        13 = 'This individual was in a health care facility'
        14 = 'This individual was in jail or prison'
        19 = 'This individual was in some other type of institution, for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        21 = 'This individual was not eligible for the interview and the Head or the Wife, whichever is the sample member, became main family nonresponse because he/she was institutionalized by joining the armed fo'
             'rces.'
        22 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by entering an educational institution.'
        23 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized by entering a health care facil'
             'ity.'
        24 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized through imprisonment.'
        29 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by some means other than the above; for ex'
             'ample, he/she may have entered a religious order. Cases in which the type of institution is unknown are included here, also.'
        31 = 'This individual was unable to cooperate through disability.'
        32 = 'This individual was not eligible for the interview and the Head or Wife, whichever is sample, was unable to cooperate through disability.'
        41 = 'This individual died between the 1990 and 1991 interviews.'
        42 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, died.'
        51 = 'This individual, although followed for interview, was discovered to be nonsample: office error.'
        52 = 'This individual should have been followed but was not: office error.'
        53 = 'This individual was mistakenly included in two or more response families at once; this record is the duplicate, or erroneous, one.'
        54 = 'Listing error: this individual never existed or was not really living in the FU.'
        59 = 'Other office error'
        91 = 'This sample individual moved out of the 1991 main family and was eligible for interviewing but the reason for nonresponse is NA.'
        92 = 'Individual moved out of the 1991 main family and was not eligible for interviewing because he/she was either nonsample or too young.'
        93 = 'The Head or Wife of this FU, whichever is sample, united with another FU; this individual was not eligible for the interview and therefore became nonresponse.'
        97 = 'This individual had not been born or moved in by the time of the 1991 interview (ER30689>0 and ER30690=0); individual from Immigrant or Latino recontact sample (ER30001=3001-3511,4001-4462, 9044-9308)'
             ' '
        98 = 'This individual became main family or mover-out nonresponse by 1990 (ER30642=0 and ER30689=0 or ER30642>0 and ER30643=71-89 and ER30689=0)'
        99 = 'NA; DK'
         0 = 'Inap.:  this individual was in a panel family in 1991 (ER30690=1-20)'
   ;
   VALUE ER30734F
    1 - 20 = 'Individuals in the family at the time of the 1992 interview'
   51 - 59 = 'Individuals in institutions at the time of the 1992 interview'
   71 - 80 = 'Individuals who moved out of the FU or out of institutions and established their own households between the 1991 and 1992 interviews'
   81 - 89 = 'Individuals who were living in 1991 but died by the time of the 1992 interview'
         0 = 'Inap.:  born or moved in after the 1992 interview; from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1992 or mover-out nonresponse by 1991 (ER30733=0)'
   ;
   VALUE ER30735F
        10 = 'Head in 1992; 1991 Head who was mover-out nonresponse by the time of the 1992 interview'
        20 = 'Legal Wife in 1992; 1991 Wife who was mover-out nonresponse by the time of the 1992 interview'
        22 = '"Wife"--female cohabitor who has lived with Head for 12 months or more or who was present in the 1991 family, since consecutive interviews may be taken less or more than twelve months apart; 1991 "Wif'
             'e" who was mover-out nonresponse by the time of the 1992 interview'
        30 = 'Son or daughter of Head (includes adopted children but not stepchildren)'
        33 = 'Stepson or stepdaughter of Head (children of legal Wife (code 20) who are not children of Head)'
        35 = 'Son or daughter of "Wife" but not Head (includes only those children of mothers whose relationship to Head is 22 but who are not children of Head)'
        37 = 'Son-in-law or daughter-in-law of Head (includes stepchildren-in-law)'
        38 = 'Foster son or foster daughter, not legally adopted'
        40 = 'Brother or sister of Head (includes step and half sisters and brothers)'
        47 = 'Brother-in-law or sister-in-law of Head; i.e., brother or sister of legal Wife, or spouse of Head''s brother or sister.'
        48 = 'Brother or sister of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        50 = 'Father or mother of Head (includes stepparents)'
        57 = 'Father-in-law or mother-in-law of Head (includes parents of legal wives (code 20) only)'
        58 = 'Father or mother of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        60 = 'Grandson or granddaughter of Head (includes grandchildren of legal Wife (code 20), but those of a cohabitor are coded 97)'
        65 = 'Great-grandson or great-granddaughter of Head (includes great-grandchildren of legal Wife (code 20), but those of a cohabitor are coded 97)'
        66 = 'Grandfather or grandmother of Head (includes stepgrandparents)'
        67 = 'Grandfather or grandmother of legal Wife (code 20)'
        68 = 'Great-grandfather or great-grandmother of Head'
        69 = 'Great-grandfather or great-grandmother of legal Wife (code 20)'
        70 = 'Nephew or niece of Head'
        71 = 'Nephew or niece of legal Wife (code 20)'
        72 = 'Uncle or Aunt of Head'
        73 = 'Uncle or Aunt of legal Wife (code 20)'
        74 = 'Cousin of Head'
        75 = 'Cousin of legal Wife (code 20)'
        83 = 'Children of first-year cohabitor but not of Head (the parent of this child is coded 88)'
        88 = 'First-year cohabitor of Head'
        90 = 'Legal husband of Head'
        95 = 'Other relative of Head'
        96 = 'Other relative of legal Wife (code 20)'
        97 = 'Other relative of cohabitor (the cohabitor is code 22 or 88)'
        98 = 'Other nonrelatives (includes homosexual partners, friends of children of the FU, etc.)'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1992 or mover-out nonresponse by 1991 (ER30733=0); born or moved in after the 1992 interview (ER30733>0 and ER30'
             '734=0)'
   ;
   VALUE ER30739F
         1 = 'Spouse in couple numbered 1'
         2 = 'Spouse in couple numbered 2'
         3 = 'Spouse in couple numbered 3'
         0 = 'Inap.:  not married or permanently cohabiting; spouse was not in FU at the time of the 1992 interview; from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1992 or mover-out'
             ' nonresponse by 1991 (ER30733=0); born or moved in after the 1992 interview (ER30733>0 and ER30734=0)'
   ;
   VALUE ER30740F
         1 = 'Moved in or born between the 1991 and 1992 interviews; splitoff in 1992'
         2 = 'Appeared; moved in by the time the 1991 interview was taken but not included in FU for 1991 (i.e., listing error)'
         5 = 'Moved out of FU or out of an institution between the 1991 and 1992 interviews and was not included in a 1992 panel FU'
         6 = 'Moved out of FU and into an institution between the 1991 and 1992 interviews'
         7 = 'Living in 1991 but died by the time of the 1992 interview'
         8 = 'Disappeared; moved out prior to the 1991 interview, but included in FU for 1991 (usually a listing error)'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); in main family in both 1991 and 1992 (ER30690=1-20 and ER30734=1-20); in an institution in 1991 and 1992 (ER30690=51-59 and ER30734=51-59);'
             ' main family nonresponse by 1992 or mover-out nonresponse by 1991 (ER30733=0); born or moved in after the 1992 interview (ER30733>0 and ER30734=0)'
   ;
   VALUE ER30744F
         1 = 'Working now'
         2 = 'Only temporarily laid off'
         3 = 'Looking for work, unemployed'
         4 = 'Retired'
         5 = 'Permanently disabled'
         6 = 'HouseWife; keeping house'
         7 = 'Student'
         8 = 'Other'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1992 or mover-out nonresponse by 1991 (ER30733=0); mover-out nonresponse for 1992 only if deceased (ER30734=81-8'
             '9); in an institution in both 1991 and 1992 (ER30734=51-59 and ER30740=0); not a person aged 16 or older (ER30736=001-015); born or moved in after the 1992 interview (ER30733>0 and ER30734=0)'
   ;
   VALUE ER30747F
         1 = 'Full-time student'
         3 = 'Part-time student'
         5 = 'Not enrolled in school'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1992 or mover-out nonresponse by 1991 (ER30733=0); Head or Wife/"Wife" in 1992 (ER30734=1-20 and ER30735=10, 20'
             'or 22); in an institution in both 1991 and 1992 (ER30734=51-59 and ER30740=0); not a person aged 16 or older (ER30736=001-015); last attended school before 1991 (ER30746=1901-1990, 9998 or 9999); born'
             ' or moved in after the 1992 interview (ER30733>0 and ER30734=0)'
   ;
   VALUE ER30748F
    1 - 17 = 'Highest grade or year of school completed'
        99 = 'NA; DK'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1992 or mover-out nonresponse by 1991 (ER30733=0); in an institution in both 1991 and 1992 (ER30734=51-59 and ER'
             '30740=0); not a person aged 16 or older (ER30736=001-015); born or moved in after the 1992 interview (ER30733>0 and ER30734=0)'
   ;
   VALUE ER30749F
         1 = 'Labor income'
         2 = 'Asset income'
         3 = 'Both labor and asset income'
         0 = 'Inap.:  no taxable income; from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1992 or mover-out nonresponse by 1991 (ER30733=0); in an institution in both 1991 and 1992 (E'
             'R30734=51-59 and ER30740=0); born or moved in after the 1992 interview (ER30733>0 and ER30734=0)'
   ;
   VALUE ER30753F
         1 = 'Minor assignment'
         2 = 'Major assignment'
         0 = 'Inap.:  no assignment; from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1992 or mover-out nonresponse by 1991 (ER30733=0); in an institution in both 1991 and 1992 (ER307'
             '34=51-59 and ER30740=0); no asset income (ER30749=0 or 1)'
   ;
   VALUE ER30756F
         1 = 'ADC, AFDC only'
         2 = 'Supplemental Security Income, SSI only'
         3 = 'Other Welfare only'
         4 = 'Social Security only'
         5 = 'Veterans pension'
         6 = 'Other retirement pay, pensions, or annuities only'
         7 = 'Unemployment compensation only'
         8 = 'Worker Compensation only'
         9 = 'Child support only'
        10 = 'Help from relatives only'
        11 = 'Other transfers only'
        15 = 'More than one of the above; any combination'
         0 = 'Inap.:  no transfer income; from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1992 or mover-out nonresponse by 1991 (ER30733=0); in an institution in both 1991 and 1992 ('
             'ER30734=51-59 and ER30740=0); born or moved in after the 1992 interview (ER30733>0 and ER30734=0)'
   ;
   VALUE ER30757F
         1 = 'Disability'
         2 = 'Retirement'
         3 = 'Survivor benefits; dependent of deceased recipient'
         4 = 'Any combination of codes 1-3 and 5-7'
         5 = 'Dependent of disabled recipient'
         6 = 'Dependent of retired recipient'
         7 = 'Other'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  no Social Security income; from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1992 or mover-out nonresponse by 1991 (ER30733=0); in an institution in both 1991 and'
             ' 1992 (ER30734=51-59 and ER30740=0); no transfers (ER30756=0)'
   ;
   VALUE ER30763F
         1 = 'Yes, is covered'
         5 = 'No, is not covered'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1992 or mover-out nonresponse by 1991 (ER30733=0); in an institution or mover-out nonresponse in 1992 (ER30734=5'
             '1-89); born or moved in after the 1992 interview (ER30733>0 and ER30734=0)'
   ;
   VALUE ER30764F
         1 = 'Yes, is not in good health'
         5 = 'No, is in good health'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1992 or mover-out nonresponse by 1991 (ER30733=0); in an institution or mover-out nonresponse in 1992 (ER30734=5'
             '1-89); born or moved in after the 1992 interview (ER30733>0 and ER30734=0); current Head or Wife (ER30734=1-2 and ER30735=10, 20, 22)'
   ;
   VALUE ER30770F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1992 or mover-out nonresponse by 1991 (ER30733=0); in an institution or mover-out nonresponse in 1992 (ER30734=5'
             '1-89); born or moved in after the 1992 interview (ER30733>0 and ER30734=0); not a person age 55 or older (ER30736=001-054)'
   ;
   VALUE ER30771F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1992 mover-out nonresponse by 1991 (ER30733=0); in an institution or mover-out nonresponse in 1992 (ER30734=51-8'
             '9); born or moved in after the 1992 interview (ER30733>0 and ER30734=0); not a person age 55 or older (ER30736=001-054)'
   ;
   VALUE ER30772F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1992 or mover-out nonresponse by 1991 (ER30733=0); in an institution or mover-out nonresponse in 1992 (ER30734=5'
             '1-89); born or moved in after the 1992 interview (ER30733>0 and ER30734=0); not a person age 55 or older (ER30736=001-054)'
   ;
   VALUE ER30773F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1992 or mover-out nonresponse by 1991 (ER30733=0); in an institution or mover-out nonresponse in 1992 (ER30734=5'
             '1-89); born or moved in after the 1992 interview (ER30733>0 and ER30734=0); not a person age 55 or older (ER30736=001-054)'
   ;
   VALUE ER30774F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1992 or mover-out nonresponse by 1991 (ER30733=0); in an institution or mover-out nonresponse in 1992 (ER30734=5'
             '1-89); born or moved in after the 1992 interview (ER30733>0 and ER30734=0); not a person age 55 or older (ER30736=001-054)'
   ;
   VALUE ER30775F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1992 or mover-out nonresponse by 1991 (ER30733=0); in an institution or mover-out nonresponse in 1992 (ER30734=5'
             '1-89); born or moved in after the 1992 interview (ER30733>0 and ER30734=0); not a person age 55 or older (ER30736=001-054)'
   ;
   VALUE ER30776F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1992 or mover-out nonresponse by 1991 (ER30733=0); in an institution or mover-out nonresponse in 1992 (ER30734=5'
             '1-89); born or moved in after the 1992 interview (ER30733>0 and ER30734=0); not a person age 55 or older (ER30736=001-054)'
   ;
   VALUE ER30777F
         1 = 'Yes to at least one variable among ER30770-ER30776'
         5 = 'No to ER30770-ER30776'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1992 or mover-out nonresponse by 1991 (ER30733=0); in an institution or mover-out nonresponse in 1992 (ER30734=5'
             '1-89); born or moved in after the 1992 interview (ER30733>0 and ER30734=0); not a person age 55 or older (ER30736=001-054)'
   ;
   VALUE ER30778F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1992 or mover-out nonresponse by 1991 (ER30733=0); in an institution or mover-out nonresponse in 1992 (ER30734=5'
             '1-89); born or moved in after the 1992 interview (ER30733>0 and ER30734=0); not a person age 55 or older (ER30736=001-054); no difficulty (ER30777=5)'
   ;
   VALUE ER30779F
         1 = 'Yes'
         5 = 'No'
         7 = 'Doesn''t do'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1992 or mover-out nonresponse by 1991 (ER30733=0); in an institution or mover-out nonresponse in 1992 (ER30734=5'
             '1-89); born or moved in after the 1992 interview (ER30733>0 and ER30734=0); not a person age 55 or older (ER30736=001-054)'
   ;
   VALUE ER30781F
         1 = 'Yes'
         5 = 'No'
         7 = 'Doesn''t do'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1992 or mover-out nonresponse by 1991 (ER30733=0); in an institution or mover-out nonresponse in 1992 (ER30734=5'
             '1-89); born or moved in after the 1992 interview (ER30733>0 and ER30734=0); not a person age 55 or older (ER30736=001-054)'
   ;
   VALUE ER30783F
         1 = 'Yes'
         5 = 'No'
         7 = 'Doesn''t do'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1992 or mover-out nonresponse by 1991 (ER30733=0); in an institution or mover-out nonresponse in 1992 (ER30734=5'
             '1-89); born or moved in after the 1992 interview (ER30733>0 and ER30734=0); not a person age 55 or older (ER30736=001-054)'
   ;
   VALUE ER30785F
         1 = 'Yes'
         5 = 'No'
         7 = 'Doesn''t do'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1992 or mover-out nonresponse by 1991 (ER30733=0); in an institution or mover-out nonresponse in 1992 (ER30734=5'
             '1-89); born or moved in after the 1992 interview (ER30733>0 and ER30734=0); not a person age 55 or older (ER30736=001-054)'
   ;
   VALUE ER30787F
         1 = 'Yes'
         5 = 'No'
         7 = 'Doesn''t do'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1992 or mover-out nonresponse by 1991 (ER30733=0); in an institution or mover-out nonresponse in 1992 (ER30734=5'
             '1-89); born or moved in after the 1992 interview (ER30733>0 and ER30734=0); not a person age 55 or older (ER30736=001-054)'
   ;
   VALUE ER30789F
         1 = 'Yes'
         5 = 'No'
         7 = 'Doesn''t do'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1992 or mover-out nonresponse by 1991 (ER30733=0); in an institution or mover-out nonresponse in 1992 (ER30734=5'
             '1-89); born or moved in after the 1992 interview (ER30733>0 and ER30734=0); not a person age 55 or older (ER30736=001-054)'
   ;
   VALUE ER30791F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1992 or mover-out nonresponse by 1991 (ER30733=0); moved out (ER30690=1-20 and ER30734=51-89); not a person age'
             '55 or older (ER30736=001-054); born or moved in after the 1992 interview (ER30733>0 and ER30734=0)'
   ;
   VALUE ER30793F
         1 = 'One week or less'
    2 - 52 = 'Actual number of weeks'
        97 = 'All of them'
        98 = 'DK'
        99 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1992 or mover-out nonresponse by 1991 (ER30733=0); moved out (ER30690=1-20 and ER30734=51-89); not a person age'
             '55 or older (ER30736=001-054); not a resident of a nursing home since January 1 of last year (ER30792=5, 8 or 9); born or moved in after the 1992 interview (ER30733>0 and ER30734=0)'
   ;
   VALUE ER30794F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1992 or mover-out nonresponse by 1991 (ER30733=0); moved out (ER30690=1-20 and ER30734=51-89); not a person age'
             '55 or older (ER30736=001-054); not a resident of a nursing home since January 1 of last year (ER30792=5, 8 or 9); born or moved in after the 1992 interview (ER30733>0 and ER30734=0)'
   ;
   VALUE ER30799F
         1 = 'This individual was an original sample member who was selected for recontact on the basis that he or she had become nonresponse by 1990 but some member of his or her family was still responding in 199'
             '1: this person was followable for 1992'
         2 = 'This individual was sample and aged 16 or older in 1990 or was nonsample and age 63 or older in 1990 and was associated with a 1990 response main family that became nonresponse in 1991: this person wa'
             's followable for 1992'
         3 = 'This individual was under age 16 in 1990 or was age 16-62 and nonsample in 1990; additionally, he or she was associated with a 1990 response main family that became nonresponse in 1991: not followable'
             ' for 1992'
         4 = 'This individual was a sample mover-out aged 18 or older in 1991 or was a nonsample mover-out age 65 or older in 1991: this person was followable for 1992'
         5 = 'This individual was a member of a successfully-interviewed Latino recontact family'
         6 = 'This individual was sample and age 17 or older in 1991 and was associated with a 1991 response family: this person was followable for 1992'
         7 = 'This individual was nonsample and age 64 or older in 1991 and was associated with a 1991 response family: this person was followable for 1992'
         0 = 'Inap: nonsample and under age 64 in 1991; sample and under age 17 in 1991; nonresponse by 1990 but was not selected for the 1992 recontact effort; born or new mover-in in 1992; deceased by 1991 interv'
             'iew (ER30729=41); born or moved in after the 1992 interview (ER30733>0 and ER30734=0)'
   ;
   VALUE ER30800F
         1 = 'This individual is 1992 core sample Head, Wife or "Wife" who renewed permission for 1992.'
         5 = 'This individual is 1992 core sample Head, Wife or "Wife" and permission was received for 1991 but no renewal was received for 1992.'
         0 = 'This individual is not core sample (ER30001=3001-3511,4001-4462,7001-9308); this individual is not 1992 Head, Wife or "Wife" (ER30734>01 and ER30735 NE 20 or 22); this individual is 1992 core sample H'
             'ead, Wife or "Wife", but was not eligible for Medicare permission renewal (ER30725=0 or 5); this individual was born or moved in after the 1992 interview (ER30733>0 and ER30734=0)'
   ;
   VALUE ER30801F
         1 = 'This sample member was 18 years old or older at the time of main family nonresponse and had been in the FU in 1991.'
         2 = 'This sample member was less than 18 at the time of main family nonresponse and had been in the FU in 1991.'
         3 = 'This nonsample individual had been in the 1991 FU, and this FU became nonresponse in 1992.'
         4 = 'This sample member had been in an institution in 1991 but his or her main family became nonresponse in 1992.'
         5 = 'This sample member, although connected with a 1992 response family, was in an institution at the time of the 1992 interview.'
         6 = 'This sample individual was 18 years old or older and moved out or died between the 1991 and 1992 interviews.'
         7 = 'This sample member was less than 18 and moved out or died between the 1991 and 1992 interviews.'
         8 = 'This nonsample individual moved out or died between the 1991 and 1992 interviews.'
         9 = 'This individual had not been born or moved in by the time of the 1992 interview; individual from Immigrant sample (ER30001=3001-3511,4001-4462)'
        10 = 'This individual had become nonresponse by the time of the 1991 interview.'
        20 = 'Sample recontact: this sample member, nonresponse by 1990, was selected for recontact but was not successfully interviewed in 1992.'
        21 = 'Main family recontact: this sample member was 16 years old or older and had been in the FU in 1990, but the family was not successfully interviewed in 1992.'
        22 = 'Main family recontact: this sample member was less than 16 and had been in the FU in 1990, but the family was not successfully interviewed in 1992.'
        23 = 'Main family recontact: this nonsample individual had been in the 1990 FU, and and had been in the FU in 1990, but the family was not successfully interviewed in 1992.'
        24 = 'Main family recontact: this sample member had been in an institution in 1990; his or her main family became nonresponse in 1992.'
        26 = 'Splitoff recontact: this sample individual was 18 years old or older, moved out in 1991 but was not successfully interviewed in 1992.'
        99 = 'NA; DK'
         0 = 'Inap.:  this individual was in a panel family in 1992 (ER30734=1-20).'
   ;
   VALUE ER30802F
         1 = 'Wave refusal by all eligible/available FU members.'
         2 = 'No one at home for contact during the interviewing period.'
         3 = 'Respondent absent; some FU member contacted, but not the appropriate respondent.'
         4 = 'Lost; unable to locate any member of the FU at all.'
         5 = 'FU is located too far away for interviewer contact.'
        11 = 'This individual was in the armed forces.'
        12 = 'This individual was in an educational institution.'
        13 = 'This individual was in a health care facility'
        14 = 'This individual was in jail or prison'
        19 = 'This individual was in some other type of institution, for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        21 = 'This individual was not eligible for the interview and the Head or the Wife, whichever is the sample member, became main family nonresponse because he/she was institutionalized by joining the armed fo'
             'rces.'
        22 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by entering an educational institution.'
        23 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized by entering a health care facil'
             'ity.'
        24 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized through imprisonment.'
        29 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by some means other than the above; for ex'
             'ample, he/she may have entered a religious order. Cases in which the type of institution is unknown are included here, also.'
        31 = 'This individual was unable to cooperate because of disability.'
        32 = 'This individual was not eligible for the interview and the Head or Wife, whichever is sample, was unable to cooperate because of disability.'
        41 = 'This individual died between the 1991 and 1992 interviews.'
        42 = 'This individual was not eligible for the interview and became main family nonresponse because the Head or Wife, whichever is sample, died.'
        51 = 'This individual, although followed for interview, was discovered to be nonsample: office error.'
        52 = 'This individual should have been followed but was not: office error.'
        53 = 'This individual was mistakenly included in two or more response families at once; this record is the duplicate, or erroneous, one.'
        54 = 'Listing error: this individual never existed or was not really living in the FU.'
        59 = 'Other office error'
        91 = 'This sample individual moved out of the 1992 main family and was eligible for interviewing but the reason for nonresponse is NA.'
        92 = 'Individual moved out of the 1992 main family and was not eligible for interviewing because he/she was either nonsample or too young.'
        93 = 'The Head or Wife of this FU, whichever is sample, united with another FU; this individual was not eligible for the interview and therefore became nonresponse.'
        94 = '1992 Latino recontacts only: this individual was a sample member and mover-out in 1992 but was deliberately not followed for interview. Latino recontact sample membership, i.e., person number, was ass'
             'igned to an individual based on whether he or she was deemed to have been living with a Temple respondent in 1990.'
        97 = 'This individual had not been born or moved in by the time of the 1992 interview (ER30733>0 and ER30734=0); individual from Immigrant sample (ER30001=3001-3511,4001-4462)'
        98 = 'This individual became main family or mover-out nonresponse by 1992 (ER30689=0 and ER30733=0 or ER30689>0 and ER30690=71-89 and ER30733=0)'
        99 = 'NA; DK'
         0 = 'Inap.:  this individual was in a panel family in 1992 (ER30734=1-20)'
   ;
   VALUE ER30807F
    1 - 20 = 'Individuals in the family at the time of the 1993 interview'
   51 - 59 = 'Individuals in institutions at the time of the 1993 interview'
   71 - 80 = 'Individuals who moved out of the FU or out of institutions and established their own households between the 1992 and 1993 interviews'
   81 - 89 = 'Individuals who were living in 1992 but died by the time of the 1993 interview'
         0 = 'Inap.:  born or moved in after the 1993 interview; from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1993 or mover-out nonresponse by 1992 (ER30806=0)'
   ;
   VALUE ER30808F
        10 = 'Head in 1993; 1992 Head who was mover-out nonresponse by the time of the 1993 interview'
        20 = 'Legal Wife in 1993; 1992 Wife who was mover-out nonresponse by the time of the 1993 interview'
        22 = '"Wife"--female cohabitor who has lived with Head for 12 months or more or who was present in the 1992 family, since consecutive interviews may be taken less or more than twelve months apart; 1992 "Wif'
             'e" who was mover-out nonresponse by the time of the 1993 interview'
        30 = 'Son or daughter of Head (includes adopted children but not stepchildren)'
        33 = 'Stepson or stepdaughter of Head (children of legal Wife (code 20) who are not children of Head)'
        35 = 'Son or daughter of "Wife" but not Head (includes only those children of mothers whose relationship to Head is 22 but who are not children of Head)'
        37 = 'Son-in-law or daughter-in-law of Head (includes stepchildren-in-law)'
        38 = 'Foster son or foster daughter, not legally adopted'
        40 = 'Brother or sister of Head (includes step and half sisters and brothers)'
        47 = 'Brother-in-law or sister-in-law of Head; i.e., brother or sister of legal Wife, or spouse of Head''s brother or sister.'
        48 = 'Brother or sister of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        50 = 'Father or mother of Head (includes stepparents)'
        57 = 'Father-in-law or mother-in-law of Head (includes parents of legal wives (code 20) only)'
        58 = 'Father or mother of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        60 = 'Grandson or granddaughter of Head (includes grandchildren of legal Wife (code 20), but those of a cohabitor are coded 97)'
        65 = 'Great-grandson or great-granddaughter of Head (includes great-grandchildren of legal Wife (code 20), but those of a cohabitor are coded 97)'
        66 = 'Grandfather or grandmother of Head (includes stepgrandparents)'
        67 = 'Grandfather or grandmother of legal Wife (code 20)'
        68 = 'Great-grandfather or great-grandmother of Head'
        69 = 'Great-grandfather or great-grandmother of legal Wife (code 20)'
        70 = 'Nephew or niece of Head'
        71 = 'Nephew or niece of legal Wife (code 20)'
        72 = 'Uncle or Aunt of Head'
        73 = 'Uncle or Aunt of legal Wife (code 20)'
        74 = 'Cousin of Head'
        75 = 'Cousin of legal Wife (code 20)'
        83 = 'Children of first-year cohabitor but not of Head (the parent of this child is coded 88)'
        88 = 'First-year cohabitor of Head'
        90 = 'Legal husband of Head'
        95 = 'Other relative of Head'
        96 = 'Other relative of legal Wife (code 20)'
        97 = 'Other relative of cohabitor (the cohabitor is code 22 or 88)'
        98 = 'Other nonrelatives (includes homosexual partners, friends of children of the FU, etc.)'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1993 or mover-out nonresponse by 1992 (ER30806=0); born or moved in after the 1993 interview (ER30806>0 and ER30'
             '807=0)'
   ;
   VALUE ER30812F
         1 = 'Spouse in couple numbered 1'
         2 = 'Spouse in couple numbered 2'
         3 = 'Spouse in couple numbered 3'
         0 = 'Inap.:  not married or permanently cohabiting; spouse was not in FU at the time of the 1993 interview; from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1993 or mover-out'
             ' nonresponse by 1992 (ER30806=0); born or moved in after the 1993 interview (ER30806>0 and ER30807=0)'
   ;
   VALUE ER30813F
         1 = 'Moved in or born between the 1992 and 1993 interviews; splitoff in 1993'
         2 = 'Appeared; moved in by the time the 1992 interview was taken but not included in FU for 1992 (i.e., listing error)'
         5 = 'Moved out of FU or out of an institution between the 1992 and 1993 interviews and was not included in a 1993 panel FU'
         6 = 'Moved out of FU and into an institution between the 1992 and 1993 interviews'
         7 = 'Living in 1992 but died by the time of the 1993 interview'
         8 = 'Disappeared; moved out prior to the 1992 interview, but included in FU for 1992 (usually a listing error)'
         0 = 'Inap.:  from Immmigrant sample (ER30001=3001-3511,4001-4462); in main family in both 1992 and 1993 (ER30734=1-20 and ER30807=1-20); in an institution in both 1992 and 1993 (ER30734=51-59 and ER30807=5'
             '1-59); main family nonresponse by 1993 or mover-out nonresponse by 1992 (ER30806=0); born or moved in after the 1993 interview (ER30806>0 and ER30807=0)'
   ;
   VALUE ER30816F
         1 = 'Working now'
         2 = 'Only temporarily laid off'
         3 = 'Looking for work, unemployed'
         4 = 'Retired'
         5 = 'Permanently disabled'
         6 = 'HouseWife; keeping house'
         7 = 'Student'
         8 = 'Other'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1993 or mover-out nonresponse by 1992 (ER30806=0); born or moved in after the 1993 interview (ER30806>0 and ER30'
             '807=0); mover-out nonresponse for 1993 only if deceased (ER30807=81-89); in an institution in both 1992 and 1993 (ER30807=51-59 and ER30813=0); not a person aged 16 or older (ER30809=001-015)'
   ;
   VALUE ER30819F
         1 = 'Full-time student'
         2 = 'Part-time student'
         5 = 'Not enrolled in school'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1993 or mover-out nonresponse by 1992 (ER30806=0); born or moved in after the 1993 interview (ER30806>0 and ER30'
             '807=0); Head or Wife/"Wife" in 1993 (ER30807=1-20 and ER30808=10, 20 or 22); in an institution in both 1992 and 1993 (ER30807=51-59 and ER30813=0); under age 16, or aged 50 or older (ER30809=001-015,'
             '050-125 or 999); last attended school before 1992 (ER30818=1901-1991, 9997, 9998, or 9999)'
   ;
   VALUE ER30820F
    1 - 17 = 'Highest grade or year of school completed'
        99 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1993 or mover-out nonresponse by 1992 (ER30806=0); born or moved in after the 1993 interview (ER30806>0 and ER30'
             '807=0); in an institution in both 1992 and 1993 (ER30807=51-59 and ER30813=0); not a person aged 16 or older (ER30809=001-015)'
   ;
   VALUE ER30824F
         1 = 'ADC, AFDC only'
         2 = 'Supplemental Security Income, SSI only'
         3 = 'Other Welfare only'
         4 = 'Social Security only'
         5 = 'Veterans pension'
         6 = 'Other retirement pay, pensions, or annuities only'
         7 = 'Unemployment compensation only'
         8 = 'Worker Compensation only'
         9 = 'Child support only'
        10 = 'Help from relatives only'
        11 = 'Other transfers only'
        15 = 'More than one of the above; any combination'
         0 = 'Inap.:  no transfer income; from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1993 or mover-out nonresponse by 1992 (ER30806=0); born or moved in after the 1993 interview'
             ' (ER30806>0 and ER30807=0); in an institution in both 1992 and 1993 (ER30807=51-59 and ER30813=0)'
   ;
   VALUE ER30826F
         1 = 'Yes, is covered'
         5 = 'No, is not covered'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1993 or mover-out nonresponse by 1992 (ER30806=0); born or moved in after the 1993 interview (ER30806>0 and ER30'
             '807=0); in an institution or mover-out nonresponse in 1993 (ER30807=51-89)'
   ;
   VALUE ER30827F
         1 = 'Yes, is not in good health'
         5 = 'No, is in good health'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1993 or mover-out nonresponse by 1992 (ER30806=0); born or moved in after the 1993 interview (ER30806>0 and ER30'
             '807=0); in an institution or mover-out nonresponse in 1993 (ER30807=51-89); current Head or Wife (ER30807=1-2 and ER30808=10, 20, 22)'
   ;
   VALUE ER30828F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1993 or mover-out nonresponse by 1992 (ER30806=0); born or moved in after the 1993 interview (ER30806>0 and ER30'
             '807=0); in an institution or mover-out nonresponse in 1993 (ER30807=51-89); not a person age 55 or older (ER30809=001-054)'
   ;
   VALUE ER30829F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1993 or mover-out nonresponse by 1992 (ER30806=0); born or moved in after the 1993 interview (ER30806>0 and ER30'
             '807=0); in an institution or mover-out nonresponse in 1993 (ER30807=51-89); not a person age 55 or older (ER30809=001-054)'
   ;
   VALUE ER30830F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1993 or mover-out nonresponse by 1992 (ER30806=0); born or moved in after the 1993 interview (ER30806>0 and ER30'
             '807=0); in an institution or mover-out nonresponse in 1993 (ER30807=51-89); not a person age 55 or older (ER30809=001-054)'
   ;
   VALUE ER30831F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1993 or mover-out nonresponse by 1992 (ER30806=0); born or moved in after the 1993 interview (ER30806>0 and ER30'
             '807=0); in an institution or mover-out nonresponse in 1993 (ER30807=51-89); not a person age 55 or older (ER30809=001-054)'
   ;
   VALUE ER30832F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1993 or mover-out nonresponse by 1992 (ER30806=0); born or moved in after the 1993 interview (ER30806>0 and ER30'
             '807=0); in an institution or mover-out nonresponse in 1993 (ER30807=51-89); not a person age 55 or older (ER30809=001-054)'
   ;
   VALUE ER30833F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1993 or mover-out nonresponse by 1992 (ER30806=0); born or moved in after the 1993 interview (ER30806>0 and ER30'
             '807=0); in an institution or mover-out nonresponse in 1993 (ER30807=51-89); not a person age 55 or older (ER30809=001-054)'
   ;
   VALUE ER30834F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1993 or mover-out nonresponse by 1992 (ER30806=0); born or moved in after the 1993 interview (ER30806>0 and ER30'
             '807=0); in an institution or mover-out nonresponse in 1993 (ER30807=51-89); not a person age 55 or older (ER30809=001-054)'
   ;
   VALUE ER30835F
         1 = 'Yes to at least one variable among ER30828-ER30834'
         5 = 'No to ER30826-ER30834'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1993 or mover-out nonresponse by 1992 (ER30806=0); born or moved in after the 1993 interview (ER30806>0 and ER30'
             '807=0); in an institution or mover-out nonresponse in 1993 (ER30807=51-89); not a person age 55 or older (ER30809=001-054)'
   ;
   VALUE ER30836F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1993 or mover-out nonresponse by 1992 (ER30806=0); born or moved in after the 1993 interview (ER30806>0 and ER30'
             '807=0); in an institution or mover-out nonresponse in 1993 (ER30807=51-89); not a person age 55 or older (ER30809=001-054); no difficulty (ER30835=5)'
   ;
   VALUE ER30837F
         1 = 'Yes'
         5 = 'No'
         7 = 'Doesn''t do'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1993 or mover-out nonresponse by 1992 (ER30806=0); born or moved in after the 1993 interview (ER30806>0 and ER30'
             '807=0); in an institution or mover-out nonresponse in 1993 (ER30807=51-89); not a person age 55 or older (ER30809=001-054)'
   ;
   VALUE ER30839F
         1 = 'Yes'
         5 = 'No'
         7 = 'Doesn''t do'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1993 or mover-out nonresponse by 1992 (ER30806=0); born or moved in after the 1993 interview (ER30806>0 and ER30'
             '807=0); in an institution or mover-out nonresponse in 1993 (ER30807=51-89); not a person age 55 or older (ER30809=001-054)'
   ;
   VALUE ER30841F
         1 = 'Yes'
         5 = 'No'
         7 = 'Doesn''t do'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1993 or mover-out nonresponse by 1992 (ER30806=0); born or moved in after the 1993 interview (ER30806>0 and ER30'
             '807=0); in an institution or mover-out nonresponse in 1993 (ER30807=51-89); not a person age 55 or older (ER30809=001-054)'
   ;
   VALUE ER30843F
         1 = 'Yes'
         5 = 'No'
         7 = 'Doesn''t do'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1993 or mover-out nonresponse by 1992 (ER30806=0); born or moved in after the 1993 interview (ER30806>0 and ER30'
             '807=0); in an institution or mover-out nonresponse in 1993 (ER30807=51-89); not a person age 55 or older (ER30809=001-054)'
   ;
   VALUE ER30845F
         1 = 'Yes'
         5 = 'No'
         7 = 'Doesn''t do'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1993 or mover-out nonresponse by 1992 (ER30806=0); born or moved in after the 1993 interview (ER30806>0 and ER30'
             '807=0); in an institution or mover-out nonresponse in 1993 (ER30807=51-89); not a person age 55 or older (ER30809=001-054)'
   ;
   VALUE ER30847F
         1 = 'Yes'
         5 = 'No'
         7 = 'Doesn''t do'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1993 or mover-out nonresponse by 1992 (ER30806=0); born or moved in after the 1993 interview (ER30806>0 and ER30'
             '807=0); in an institution or mover-out nonresponse in 1993 (ER30807=51-89); not a person age 55 or older (ER30809=001-054)'
   ;
   VALUE ER30849F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1993 or mover-out nonresponse by 1992 (ER30806=0); born or moved in after the 1993 interview (ER30806>0 and ER30'
             '807=0); in an institution or mover-out nonresponse in 1993 (ER30807=51-89); not a person age 55 or older (ER30809=001-054)'
   ;
   VALUE ER30851F
         1 = 'One week or less'
    2 - 52 = 'Actual number of weeks'
        97 = 'All of them'
        98 = 'DK'
        99 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1993 or mover-out nonresponse by 1992 (ER30806=0); born or moved in after the 1993 interview (ER30806>0 and ER30'
             '807=0); in an institution or mover-out nonresponse in 1993 (ER30807=51-89); not a person age 55 or older (ER30809=001-054); not a resident of a nursing home any time during 1992 (ER30850=5, 8 or 9)'
   ;
   VALUE ER30852F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1993 or mover-out nonresponse by 1992 (ER30806=0); born or moved in after the 1993 interview (ER30806>0 and ER30'
             '807=0); in an institution or mover-out nonresponse in 1993 (ER30807=51-89); not a person age 55 or older (ER30809=001-054); not a resident of a nursing home any time during 1992 (ER30850=5, 8 or 9)'
   ;
   VALUE ER30859F
         1 = 'This individual was eligible to be followed in 1993'
         5 = 'This individual was not eligible to be followed in 1993'
         0 = 'Inap.:  this individual was nonresponse by 1992 and was not selected for recontact in 1993; born or moved in after the 1993 interview (ER30806>0 and ER30807=0)'
   ;
   VALUE ER30861F
         1 = 'This individual is 1993 core sample Head, Wife or "Wife" who renewed permission for 1993'
         5 = 'This individual is 1993 core sample Head, Wife or "Wife" and permission was received for 1992 but no renewal was received for 1993'
         7 = 'This individual is 1993 core sample Head, Wife or "Wife" who gave permission in 1992 but was unavailable to give permission in 1993'
         9 = 'This individual is 1993 core sample Head, Wife or "Wife" who gave permission in 1992 but had died by the time of the 1993 interview'
         0 = 'This individual is not core sample (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1993 or mover-out nonresponse by 1992 (ER30806=0); born or moved in after the 1993 interview (ER3'
             '0806>0 and ER30807=0); this individual is not 1993 Head, Wife or "Wife" (ER30807>01 and ER30808 NE 20 or 22); this individual is 1993 core sample Head, Wife or "Wife", but was not eligible for Medicar'
             'e permission renewal (ER30800=0 or 5)'
   ;
   VALUE ER30862F
         1 = 'This individual was eligible to be followed at the time of main family nonresponse and had been in the FU in 1992.'
         3 = 'This individual, ineligible to be followed, had been in the 1992 FU, and this FU became nonresponse in 1993.'
         4 = 'This individual, eligible to be followed, had been in an institution in 1992, but his or her family became nonresponse in 1993.'
         5 = 'This individual, eligible to be followed and linked to a 1993 response family, was in an institution at the time of the 1993 interview.'
         6 = 'This individual, eligible to be followed, moved out or died between the 1992 and 1993 interviews.'
         8 = 'This individual, ineligible to be followed, moved out or died between the 1992 and 1993 interviews.'
         9 = 'This individual had not been born or moved in by the time of the 1993 interview; individual from Immigrant sample (ER30001=3001-3511,4001-4462)'
        10 = 'This individual had become nonresponse by the time of the 1992 interview.'
        21 = 'Main family recontact: this person was selected for recontact in 1993, but the family was not successfully interviewed.'
        26 = 'Splitoff recontact: this sample individual moved out of a 1993 recontact main family but was not successfully interviewed.'
        99 = 'NA; DK'
         0 = 'Inap.:  this individual was in a panel family in 1993 (ER30807=1-20).'
   ;
   VALUE ER30863F
         1 = 'Wave refusal by all eligible/available FU members.'
         2 = 'No one at home for contact during the interviewing period.'
         3 = 'Respondent absent; some FU member contacted, but not the appropriate respondent.'
         4 = 'Lost; unable to locate any member of the FU at all.'
         5 = 'FU is located too far away for interviewer contact.'
        11 = 'This individual was in the armed forces.'
        12 = 'This individual was in an educational institution.'
        13 = 'This individual was in a health care facility'
        14 = 'This individual was in jail or prison'
        19 = 'This individual was in some other type of institution, for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        21 = 'This individual was not eligible to be followed, and the Head or the Wife, whichever is the sample member, became main family nonresponse because he/she was institutionalized by joining the armed forc'
             'es.'
        22 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by entering an educational institution.'
        23 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized by entering a health care facility'
             '.'
        24 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized through imprisonment.'
        29 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by some means other than the above; for examp'
             'le, he/she may have entered a religious order. Cases in which the type of institution is unknown are included here, also.'
        31 = 'This individual was unable to cooperate through disability.'
        32 = 'This individual was not eligible to be followed, and the Head or Wife, whichever is sample, was unable to cooperate through disability.'
        41 = 'This individual died between the 1992 and 1993 interviews.'
        42 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is sample, died.'
        51 = 'This individual, although followed for interview, was discovered to be nonsample: office error.'
        52 = 'This individual should have been followed but was not: office error.'
        53 = 'This individual was mistakenly included in two or more response families at once; this record is the duplicate, or erroneous, one.'
        54 = 'Listing error: this individual never existed or was not really living in the FU.'
        59 = 'Limited number of contacts attempted; miscellaneous office error (does not include codes 1-54 above or codes 91-99 below)'
        91 = 'This individual moved out of the 1993 main family and was eligible to be followed, but the reason for nonresponse is NA.'
        92 = 'Individual moved out of the 1993 main family and was not eligible to be followed'
        93 = 'All followable members of this FU united with other panel FUs; this individual was not eligible to be followed and therefore became nonresponse.'
        97 = 'This individual had not been born or moved in by the time of the 1993 interview (ER30806>0 and ER30807=0); individual from Immigrant sample (ER30001=3001-3511,4001-4462)'
        98 = 'This individual became main family or mover-out nonresponse by 1992 and was not selected for recontact in 1993 (ER30733=0 and ER30806=0 and ER30859=0 or ER30733>0 and ER30734=71-89 and ER30806=0 and E'
             'R30859=0)'
        99 = 'NA; DK'
         0 = 'Inap.:  this individual was in a panel family in 1993 (ER30807=1-20)'
   ;
   VALUE ER32000F
         1 = 'Male'
         2 = 'Female'
         9 = 'NA'
   ;
   VALUE ER32001F
         0 = 'Core individual always present in an FU'
         1 = 'Core individual not always present in an FU'
         2 = 'Latino or Immigrant individual always present in an FU'
         3 = 'Latino individual not always present in an FU, including Latino recontacts (ER30001=9044-9308); Immigrant individual not always present in an FU'
   ;
   VALUE ER32002F
         1 = 'This individual has been in an institution while connected to a responding family for at least one year during the study.'
         0 = 'All others'
   ;
   VALUE ER32022F
         0 = 'None'
    1 - 25 = 'Total number of live births'
        98 = 'NA; DK'
        99 = 'No birth history was collected for this individual in 1985-2017 (ER32021=99)'
   ;
   VALUE ER32034F
         0 = 'None'
    1 - 13 = 'Actual number of marriages'
        98 = 'NA; DK'
        99 = 'No marriage history was collected for this individual in 1985-2017 (ER32033=9999)'
   ;
   VALUE ER32037F
         1 = 'First or only marriage still intact'
         3 = 'First or only marriage ended in widowhood'
         4 = 'First or only marriage ended in divorce or annulment'
         5 = 'Separated during first or only marriage'
         7 = 'Other'
         8 = 'NA; DK'
         9 = 'No marriage history was collected for this individual in 1985-2017 (ER32033=99); never married (ER32034=0); number of marriages not ascertained (ER32034=98) and no first marriage identified in 1985-20'
             '17'
   ;
   VALUE ER32044F
         1 = 'Most recent of two or more marriages still intact'
         3 = 'Most recent of two or more marriages ended in widowhood'
         4 = 'Most recent of two or more marriages ended in divorce or annulment'
         5 = 'Separated during most recent of two or more marriages'
         7 = 'Other'
         8 = 'NA; DK'
         9 = 'No marriage history was collected for this individual in 1985-2017 (ER32033=99); never married or married only once (ER32034=00-01); number of marriages not ascertained (ER32034=98) and no last marria'
             'ge identified in 1985-2017'
   ;
   VALUE ER32049F
         1 = 'Married'
         2 = 'Never married'
         3 = 'Widowed'
         4 = 'Divorced, annulment'
         5 = 'Separated'
         8 = 'NA; DK'
         9 = 'No marital histories were collected for this individual in 1985-2017 (ER32033=99)'
   ;
   VALUE ER33102F
    1 - 20 = 'Individuals in the family at the time of the 1994 interview'
   51 - 59 = 'Individuals in institutions at the time of the 1994 interview'
   71 - 80 = 'Individuals who moved out of the FU or out of institutions and established their own households between the 1993 and 1994 interviews'
   81 - 89 = 'Individuals who were living in 1993 but died by the time of the 1994 interview'
         0 = 'Inap.:  born or moved in after the 1994 interview; from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1994 or mover-out nonresponse by 1993 (ER33101=0)'
   ;
   VALUE ER33103F
        10 = 'Head in 1994; 1993 Head who was mover-out nonresponse by the time of the 1994 interview'
        20 = 'Legal Wife in 1994; 1993 Wife who was mover-out nonresponse by the time of the 1994 interview'
        22 = '"Wife"--female cohabitor who has lived with Head for 12 months or more or who was present in the 1993 family, since consecutive interviews may be taken less or more than twelve months apart; 1993 "Wif'
             'e" who was mover-out nonresponse by the time of the 1994 interview'
        30 = 'Son or daughter of Head (includes adopted children but not stepchildren)'
        33 = 'Stepson or stepdaughter of Head (children of legal Wife (code 20) who are not children of Head)'
        35 = 'Son or daughter of "Wife" but not Head (includes only those children of mothers whose relationship to Head is 22 but who are not children of Head)'
        37 = 'Son-in-law or daughter-in-law of Head (includes stepchildren-in-law)'
        38 = 'Foster son or foster daughter, not legally adopted'
        40 = 'Brother or sister of Head (includes step and half sisters and brothers)'
        47 = 'Brother-in-law or sister-in-law of Head; i.e., brother or sister of legal Wife, or spouse of Head''s brother or sister.'
        48 = 'Brother or sister of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        50 = 'Father or mother of Head (includes stepparents)'
        57 = 'Father-in-law or mother-in-law of Head (includes parents of legal wives (code 20) only)'
        58 = 'Father or mother of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        60 = 'Grandson or granddaughter of Head (includes grandchildren of legal Wife (code 20), but those of a cohabitor are coded 97)'
        65 = 'Great-grandson or great-granddaughter of Head (includes great-grandchildren of legal Wife (code 20), but those of a cohabitor are coded 97)'
        66 = 'Grandfather or grandmother of Head (includes stepgrandparents)'
        67 = 'Grandfather or grandmother of legal Wife (code 20)'
        68 = 'Great-grandfather or great-grandmother of Head'
        69 = 'Great-grandfather or great-grandmother of legal Wife (code 20)'
        70 = 'Nephew or niece of Head'
        71 = 'Nephew or niece of legal Wife (code 20)'
        72 = 'Uncle or Aunt of Head'
        73 = 'Uncle or Aunt of legal Wife (code 20)'
        74 = 'Cousin of Head'
        75 = 'Cousin of legal Wife (code 20)'
        83 = 'Children of first-year cohabitor but not of Head (the parent of this child is coded 88)'
        88 = 'First-year cohabitor of Head'
        90 = 'Legal husband of Head'
        95 = 'Other relative of Head'
        96 = 'Other relative of legal Wife (code 20)'
        97 = 'Other relative of cohabitor (the cohabitor is code 22 or 88)'
        98 = 'Other nonrelatives (includes homosexual partners, friends of children of the FU, etc.)'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1994 or mover-out nonresponse by 1993 (ER33101=0)'
   ;
   VALUE ER33107F
         1 = 'Spouse in couple numbered 1'
         2 = 'Spouse in couple numbered 2'
         3 = 'Spouse in couple numbered 3'
         4 = 'Spouse in couple numbered 4'
         0 = 'Inap.:  not married or permanently cohabiting; spouse was not in FU at the time of the 1994 interview; from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1994 or mover-out'
             ' nonresponse by 1993 (ER33101=0)'
   ;
   VALUE ER33108F
         1 = 'Moved in or born between the 1993 and 1994 interviews; splitoff in 1994'
         2 = 'Appeared; moved in by the time the 1993 interview was taken but not included in FU for 1993 (i.e., listing error)'
         5 = 'Moved out of FU or out of an institution between the 1993 and 1994 interviews and was not included in a 1994 panel FU'
         6 = 'Moved out of FU and into an institution between the 1993 and 1994 interviews'
         7 = 'Living in 1993 but died by the time of the 1994 interview'
         8 = 'Disappeared; moved out prior to the 1993 interview, but included in FU for 1993 (usually a listing error)'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); in main family in both 1993 and 1994 (ER30807=1-20 and ER33102=1-20); in an institution in both 1993 and 1994 (ER30807=51-59 and ER33102=51'
             '-59); main family nonresponse by 1994 or mover-out nonresponse by 1993 (ER33101=0)'
   ;
   VALUE ER33111F
         1 = 'Working now'
         2 = 'Only temporarily laid off'
         3 = 'Looking for work, unemployed'
         4 = 'Retired'
         5 = 'Permanently disabled'
         6 = 'HouseWife; keeping house'
         7 = 'Student'
         8 = 'Other'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1994 or mover-out nonresponse by 1993 (ER33101=0); mover-out nonresponse for 1994 only if deceased (ER33102=81-8'
             '9); in an institution in both 1993 and 1994 (ER33102=51-59 and ER33108=0); not a person aged 16 or older (ER33104=001-015)'
   ;
   VALUE ER33114F
         1 = 'Full-time student'
         2 = 'Part-time student'
         5 = 'Not enrolled in school'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1994 or mover-out nonresponse by 1993 (ER33101=0); Head or Wife/"Wife" in 1994 (ER33102=1-20 and ER33103=10, 20'
             'or 22); in an institution in both 1993 and 1994 (ER33102=51-59 and ER33108=0); under age 16, or aged 50 or older (ER33104=001-015, 050-125 or 999); last attended school before 1993 (ER33113=1901-1992,'
             ' 9997 or 9999)'
   ;
   VALUE ER33115F
    1 - 17 = 'Highest grade or year of school completed'
        98 = 'DK'
        99 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1994 or mover-out nonresponse by 1993 (ER33101=0); in an institution in both 1993 and 1994 (ER33102=51-59 and ER'
             '33108=0); born or moved in after the 1994 interview (ER33101>0 and ER33102=0); not a person aged 16 or older (ER33104=001-015)'
   ;
   VALUE ER33116F
         1 = 'Yes, is covered'
         5 = 'No, is not covered'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1994 or mover-out nonresponse by 1993 (ER33101=0); in an institution or mover-out nonresponse in 1994 (ER33102=5'
             '1-89)'
   ;
   VALUE ER33117F
         1 = 'Yes, is in poor health'
         5 = 'No, is not in poor health'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1994 or mover-out nonresponse by 1993 (ER33101=0); in an institution or mover-out nonresponse in 1994 (ER33102=5'
             '1-89); current Head or Wife (ER33102=1-2 and ER33103=10, 20, 22); an other FU member aged 55 or older (ER33104>54)'
   ;
   VALUE ER33118F
         1 = 'This individual is 1994 core sample Head, Wife or "Wife" who renewed permission for 1994'
         5 = 'This individual is 1994 core sample Head, Wife or "Wife" and permission was received for 1993 but no renewal was received for 1994'
         7 = 'This individual is 1994 core sample Head, Wife or "Wife" who gave permission in 1993 but was unavailable to give permission in 1994'
         9 = 'This individual is 1994 core sample Head, Wife or "Wife" who gave permission in 1993 but had died by the time of the 1994 interview'
         0 = 'This individual is not core sample (ER30001=3001-3511,4001-4462,7001-9308); this individual is not 1994 Head, Wife or "Wife" (ER33102>01 and ER33103 NE 20 or 22); this individual is 1994 core sample H'
             'ead, Wife or "Wife", but was not eligible for Medicare permission renewal (ER30800=0 or 5)'
   ;
   VALUE ER33125F
         1 = 'This individual was eligible to be followed in 1994'
         5 = 'This individual was not eligible to be followed in 1994'
         0 = 'Inap.:  this individual was nonresponse by 1993 and was not selected for recontact in 1994; born or moved in after the 1994 interview (ER33101>0 and ER33102=0)'
   ;
   VALUE ER33126F
         1 = 'This individual was eligible to be followed at the time of main family nonresponse and had been in the FU in 1993.'
         3 = 'This individual, ineligible to be followed, had been in the 1993 FU, and this FU became nonresponse in 1994.'
         4 = 'This individual, eligible to be followed, had been in an institution in 1993, but his or her family became nonresponse in 1994.'
         5 = 'This individual, eligible to be followed and linked to a 1994 response family, was in an institution at the time of the 1994 interview.'
         6 = 'This individual, eligible to be followed, moved out or died between the 1993 and 1994 interviews.'
         8 = 'This individual, ineligible to be followed, moved out or died between the 1993 and 1994 interviews.'
         9 = 'This individual had not been born or moved in by the time of the 1994 interview; individual from Immigrant sample (ER30001=3001-3511,4001-4462)'
        10 = 'This individual had become nonresponse by the time of the 1993 interview.'
        21 = 'Main family recontact: this person was selected for recontact in 1994, but the family was not successfully interviewed.'
        26 = 'Splitoff recontact: this sample individual moved out of a 1994 recontact main family but was not successfully interviewed.'
        99 = 'NA; DK'
         0 = 'Inap.:  this individual was in a panel family in 1994 (ER33102=1-20).'
   ;
   VALUE ER33127F
         1 = 'Wave refusal by all eligible/available FU members.'
         2 = 'No one at home for contact during the interviewing period.'
         3 = 'Respondent absent; some FU member contacted, but not the appropriate respondent.'
         4 = 'Lost; unable to locate any member of the FU at all.'
         5 = 'FU is located too far away for interviewer contact.'
        10 = 'Panel refusal by all all eligible/available FU members.  These individuals will never be asked to participate in the study again, regardless of recontact efforts.'
        11 = 'This individual was in the armed forces.'
        12 = 'This individual was in an educational institution.'
        13 = 'This individual was in a health care facility'
        14 = 'This individual was in jail or prison'
        19 = 'This individual was in some other type of institution, for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        21 = 'This individual was not eligible to be followed, and the Head or the Wife, whichever is the sample member, became main family nonresponse because he/she was institutionalized by joining the armed forc'
             'es.'
        22 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by entering an educational institution.'
        23 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized by entering a health care facility'
             '.'
        24 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized through imprisonment.'
        29 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by some means other than the above; for examp'
             'le, he/she may have entered a religious order. Cases in which the type of institution is unknown are included here, also.'
        31 = 'This individual was unable to cooperate through disability.'
        32 = 'This individual was not eligible to be followed, and the Head or Wife, whichever is sample, was unable to cooperate through disability.'
        41 = 'This individual died between the 1993 and 1994 interviews.'
        42 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is sample, died.'
        51 = 'This individual, although followed for interview, was discovered to be nonsample: office error.'
        52 = 'This individual should have been followed but was not: office error.'
        53 = 'This individual was mistakenly included in two or more response families at once; this record is the duplicate, or erroneous, one.'
        54 = 'Listing error: this individual never existed or was not really living in the FU.'
        56 = 'This individual became a followable non-sample parent (had baby) in this wave.  Because the PSID predetermines followability before entering the field each wave, he/she was not followed.'
        57 = 'Insufficient information that would permit recontact; paper coversheet(s) missing; no name or identifying information available'
        58 = 'Due to budgetary and/or time constraints, PSID staff decided not to take all of the usual steps to try to locate and/or persuade this FU.'
        59 = 'Limited number of contacts attempted; miscellaneous office error (does not include codes 1-54 above or codes 91-99 below)'
        91 = 'This individual moved out of the 1994 main family and was eligible to be followed, but the reason for nonresponse is NA.'
        92 = 'Individual moved out of the 1994 main family and was not eligible to be followed'
        93 = 'All followable members of this FU united with other panel FUs; this individual was not eligible to be followed and therefore became nonresponse.'
        97 = 'This individual had not been born or moved in by the time of the 1994 interview (ER33101>0 and ER33102=0); individual from Immigrant sample (ER30001=3001-3511,4001-4462)'
        98 = 'This individual became main family or mover-out nonresponse by 1993 and was not selected for recontact in 1994 (ER30733=0 and ER30806=0 and ER30859=0 or ER30733>0 and ER30734=71-89 and ER30806=0 and E'
             'R30859=0)'
        99 = 'NA; DK'
         0 = 'Inap.:  this individual was in a panel family in 1994 (ER33102=1-20)'
   ;
   VALUE ER33128F
         1 = 'Excellent'
         2 = 'Very good'
         3 = 'Good'
         4 = 'Fair'
         5 = 'Poor'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1994 or mover-out nonresponse by 1993 (ER33101=0); in an institution or mover-out nonresponse in 1994 (ER33102=5'
             '1-89); not an other FU member aged 55 or older (ER33104=001-054)'
   ;
   VALUE ER33129F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1994 or mover-out nonresponse by 1993 (ER33101=0); in an institution or mover-out nonresponse in 1994 (ER33102=5'
             '1-89); not a person age 55 or older (ER33104=001-054)'
   ;
   VALUE ER33130F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1994 or mover-out nonresponse by 1993 (ER33101=0); in an institution or mover-out nonresponse in 1994 (ER33102=5'
             '1-89); not a person age 55 or older (ER33104=001-054)'
   ;
   VALUE ER33131F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1994 or mover-out nonresponse by 1993 (ER33101=0); in an institution or mover-out nonresponse in 1994 (ER33102=5'
             '1-89); not a person age 55 or older (ER33104=001-054)'
   ;
   VALUE ER33132F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1994 or mover-out nonresponse by 1993 (ER33101=0); in an institution or mover-out nonresponse in 1994 (ER33102=5'
             '1-89); not a person age 55 or older (ER33104=001-054)'
   ;
   VALUE ER33133F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1994 or mover-out nonresponse by 1993 (ER33101=0); in an institution or mover-out nonresponse in 1994 (ER33102=5'
             '1-89); not a person age 55 or older (ER33104=001-054)'
   ;
   VALUE ER33134F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1994 or mover-out nonresponse by 1993 (ER33101=0); in an institution or mover-out nonresponse in 1994 (ER33102=5'
             '1-89); not a person age 55 or older (ER33104=001-054)'
   ;
   VALUE ER33135F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1994 or mover-out nonresponse by 1993 (ER33101=0); in an institution or mover-out nonresponse in 1994 (ER33102=5'
             '1-89); not a person age 55 or older (ER33104=001-054)'
   ;
   VALUE ER33136F
         1 = 'Yes to at least one variable among ER33129-ER33135'
         5 = 'No to ER33129-ER33135'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1994 or mover-out nonresponse by 1993 (ER33101=0); in an institution or mover-out nonresponse in 1994 (ER33102=5'
             '1-89); not a person age 55 or older (ER33104=001-054)'
   ;
   VALUE ER33137F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1994 or mover-out nonresponse by 1993 (ER33101=0); in an institution or mover-out nonresponse in 1994 (ER33102=5'
             '1-89); not a person age 55 or older (ER33104=001-054); no difficulty (ER33136=5)'
   ;
   VALUE ER33138F
         1 = 'Yes'
         5 = 'No'
         7 = 'Doesn''t do'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1994 or mover-out nonresponse by 1993 (ER33101=0); in an institution or mover-out nonresponse in 1994 (ER33102=5'
             '1-89); not a person age 55 or older (ER33104=001-054)'
   ;
   VALUE ER33140F
         1 = 'Yes'
         5 = 'No'
         7 = 'Doesn''t do'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1994 or mover-out nonresponse by 1993 (ER33101=0); in an institution or mover-out nonresponse in 1994 (ER33102=5'
             '1-89); not a person age 55 or older (ER33104=001-054)'
   ;
   VALUE ER33142F
         1 = 'Yes'
         5 = 'No'
         7 = 'Doesn''t do'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1994 or mover-out nonresponse by 1993 (ER33101=0); in an institution or mover-out nonresponse in 1994 (ER33102=5'
             '1-89); not a person age 55 or older (ER33104=001-054)'
   ;
   VALUE ER33144F
         1 = 'Yes'
         5 = 'No'
         7 = 'Doesn''t do'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1994 or mover-out nonresponse by 1993 (ER33101=0); in an institution or mover-out nonresponse in 1994 (ER33102=5'
             '1-89); not a person age 55 or older (ER33104=001-054)'
   ;
   VALUE ER33146F
         1 = 'Yes'
         5 = 'No'
         7 = 'Doesn''t do'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1994 or mover-out nonresponse by 1993 (ER33101=0); in an institution or mover-out nonresponse in 1994 (ER33102=5'
             '1-89); not a person age 55 or older (ER33104=001-054)'
   ;
   VALUE ER33148F
         1 = 'Yes'
         5 = 'No'
         7 = 'Doesn''t do'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1994 or mover-out nonresponse by 1993 (ER33101=0); in an institution or mover-out nonresponse in 1994 (ER33102=5'
             '1-89); not a person age 55 or older (ER33104=001-054)'
   ;
   VALUE ER33202F
    1 - 20 = 'Individuals in the family at the time of the 1995 interview'
   51 - 59 = 'Individuals in institutions at the time of the 1995 interview'
   71 - 80 = 'Individuals who moved out of the FU or out of institutions and established their own households between the 1994 and 1995 interviews'
   81 - 89 = 'Individuals who were living in 1994 but died by the time of the 1995 interview'
         0 = 'Inap.:  born or moved in after the 1995 interview; from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0)'
   ;
   VALUE ER33203F
        10 = 'Head in 1995; 1994 Head who was mover-out nonresponse by the time of the 1995 interview'
        20 = 'Legal Wife in 1995; 1994 Wife who was mover-out nonresponse by the time of the 1995 interview'
        22 = '"Wife"--female cohabitor who has lived with Head for 12 months or more or who was present in the 1994 family, since consecutive interviews may be taken less or more than twelve months apart; 1994 "Wif'
             'e" who was mover-out nonresponse by the time of the 1995 interview'
        30 = 'Son or daughter of Head (includes adopted children but not stepchildren)'
        33 = 'Stepson or stepdaughter of Head (children of legal Wife (code 20) who are not children of Head)'
        35 = 'Son or daughter of "Wife" but not Head (includes only those children of mothers whose relationship to Head is 22 but who are not children of Head)'
        37 = 'Son-in-law or daughter-in-law of Head (includes stepchildren-in-law)'
        38 = 'Foster son or foster daughter, not legally adopted'
        40 = 'Brother or sister of Head (includes step and half sisters and brothers)'
        47 = 'Brother-in-law or sister-in-law of Head; i.e., brother or sister of legal Wife, or spouse of Head''s brother or sister.'
        48 = 'Brother or sister of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        50 = 'Father or mother of Head (includes stepparents)'
        57 = 'Father-in-law or mother-in-law of Head (includes parents of legal wives (code 20) only)'
        58 = 'Father or mother of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        60 = 'Grandson or granddaughter of Head (includes grandchildren of legal Wife (code 20), but those of a cohabitor are coded 97)'
        65 = 'Great-grandson or great-granddaughter of Head (includes great-grandchildren of legal Wife (code 20), but those of a cohabitor are coded 97)'
        66 = 'Grandfather or grandmother of Head (includes stepgrandparents)'
        67 = 'Grandfather or grandmother of legal Wife (code 20)'
        68 = 'Great-grandfather or great-grandmother of Head'
        69 = 'Great-grandfather or great-grandmother of legal Wife (code 20)'
        70 = 'Nephew or niece of Head'
        71 = 'Nephew or niece of legal Wife (code 20)'
        72 = 'Uncle or Aunt of Head'
        73 = 'Uncle or Aunt of legal Wife (code 20)'
        74 = 'Cousin of Head'
        75 = 'Cousin of legal Wife (code 20)'
        83 = 'Children of first-year cohabitor but not of Head (the parent of this child is coded 88)'
        88 = 'First-year cohabitor of Head'
        90 = 'Legal husband of Head'
        95 = 'Other relative of Head'
        96 = 'Other relative of legal Wife (code 20)'
        97 = 'Other relative of cohabitor (the cohabitor is code 22 or 88)'
        98 = 'Other nonrelatives (includes homosexual partners, friends of children of the FU, etc.)'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 and ER33'
             '202=0)'
   ;
   VALUE ER33207F
         1 = 'Spouse in couple numbered 1'
         2 = 'Spouse in couple numbered 2'
         3 = 'Spouse in couple numbered 3'
         4 = 'Spouse in couple numbered 4'
         0 = 'Inap.:  not married or permanently cohabiting; spouse was not in FU at the time of the 1995 interview; from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out'
             ' nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 and ER33202=0)'
   ;
   VALUE ER33208F
         1 = 'Moved in or born between the 1994 and 1995 interviews; splitoff in 1995'
         2 = 'Appeared; moved in by the time the 1994 interview was taken but not included in FU for 1994 (i.e., listing error)'
         5 = 'Moved out of FU or out of an institution between the 1994 and 1995 interviews and was not included in a 1995 panel FU'
         6 = 'Moved out of FU and into an institution between the 1994 and 1995 interviews'
         7 = 'Living in 1994 but died by the time of the 1995 interview'
         8 = 'Disappeared; moved out prior to the 1994 interview, but included in FU for 1994 (usually a listing error)'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); in main family in both 1994 and 1995 (ER33102=1-20 and ER33202=1-20); in an institution in both 1994 and 1995 (ER33102=51-59 and ER33202=51'
             '-59);  main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 and ER33202=0)'
   ;
   VALUE ER33211F
         1 = 'Working now'
         2 = 'Only temporarily laid off'
         3 = 'Looking for work, unemployed'
         4 = 'Retired'
         5 = 'Permanently disabled'
         6 = 'HouseWife; keeping house'
         7 = 'Student'
         8 = 'Other'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 and ER33'
             '202=0); mover-out nonresponse for 1995 only if deceased (ER33202=81-89); in an institution in both 1994 and 1995 (ER33202=51-59 and ER33208=0); not a person aged 16 or older (ER33204=001-015)'
   ;
   VALUE ER33214F
         1 = 'Full-time student'
         2 = 'Part-time student'
         5 = 'Not enrolled in school'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 and ER33'
             '202=0); Head or Wife/"Wife" in 1995 (ER33202=1-20 and ER33203=10, 20 or 22); in an institution in both 1994 and 1995 (ER33202=51-59 and ER33208=0); under age 16, or aged 50 or older (ER33204=001-015,'
             '050-125 or 999); last attended school before 1994 (ER33213=1901-1993, 9997, 9998, or 9999)'
   ;
   VALUE ER33215F
    1 - 17 = 'Highest grade or year of school completed'
        98 = 'DK'
        99 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); in an institution in both 1994 and 1995 (ER33202=51-59 and ER'
             '33208=0); born or moved in after the 1995 interview (ER33201>0 and ER33202=0); not a person aged 16 or older (ER33204=001-015)'
   ;
   VALUE ER33216F
         1 = 'Yes, is covered'
         5 = 'No, is not covered'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 and ER33'
             '202=0); in an institution or mover-out nonresponse in 1995 (ER33202=51-89)'
   ;
   VALUE ER33217F
         1 = 'Yes, is in poor health'
         5 = 'No, is not in poor health'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 and ER33'
             '202=0); in an institution or mover-out nonresponse in 1995 (ER33202=51-89); current Head or Wife (ER33102=1-2 and ER33203=10, 20, 22); an other FU member aged 55 or older (ER33204>54)'
   ;
   VALUE ER33218F
         1 = 'This individual is 1995 core sample Head, Wife or "Wife" who renewed permission for 1995'
         5 = 'This individual is 1995 core sample Head, Wife or "Wife" and permission was received for 1994 but no renewal was received for 1995'
         7 = 'This individual is 1995 core sample Head, Wife or "Wife" who gave permission in 1994 but was unavailable to give permission in 1995'
         9 = 'This individual is 1995 core sample Head, Wife or "Wife" who gave permission in 1994 but had died by the time of the 1995 interview'
         0 = 'This individual is not core sample (ER30001=3001-3511,4001-4462,7001-9308); this individual is not 1995 Head, Wife or "Wife" (ER33202>01 and ER33203 NE 20 or 22); this individual is 1995 core sample H'
             'ead, Wife or "Wife", but was not eligible for Medicare permission renewal (ER33118=0 or 5)'
   ;
   VALUE ER33220F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 and ER33'
             '202=0); under age 5 or over age 49 (ER33204=001-004, 050-125 or 999); deceased (ER33202=81-89)'
   ;
   VALUE ER33221F
         1 = 'Full-time'
         2 = 'Part-time'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 and ER33'
             '202=0); under age 16 or over age 49 (ER33204=001-015, 050-125 or 999); deceased (ER33202=81-89); not in school (ER33220=5, 8 or 9)'
   ;
   VALUE ER33226F
         1 = 'Full-time'
         2 = 'Part-time'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 and ER33'
             '202=0); under age 16 or over age 49 (ER33204=001-015, 050-125 or 999); in school (ER33220=1); never in school (ER33225=9996)'
   ;
   VALUE ER33230F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 and ER33'
             '202=0); under age 5 or aged 40 or over (ER33204=001-004, 040-120 or 999); not in school  (ER33220=5, 8 or 9); in school but attending college or ungraded school (ER33222=13-18 or 93)'
   ;
   VALUE ER33245F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 and ER33'
             '202=0); under age 5 or aged 40 or over (ER33204=001-004, 040-120 or 999); never in school (ER33225=9996)'
   ;
   VALUE ER33246F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 and ER33'
             '202=0); under age 5 or aged 40 or over (ER33204=001-004, 040-120 or 999); never in school (ER33225=9996)'
   ;
   VALUE ER33247F
    1 - 12 = 'Actual grade'
        93 = 'Ungraded'
        95 = 'Kindergarten'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 and ER33'
             '202=0); under age 5 or aged 40 or over (ER33204=001-004, 040-120 or 999); never in school (ER33225=9996); never repeated a grade because of school recommendation (ER33246=5, 8 or 9)'
   ;
   VALUE ER33259F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 and ER33'
             '202=0); under age 5 or aged 40 or over (ER33204=001-004, 040-120 or 999); never in school (ER33225=9996)'
   ;
   VALUE ER33260F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 and ER33'
             '202=0); under age 5 or aged 40 or over (ER33204=001-004, 040-120 or 999); never in school (ER33225=9996)'
   ;
   VALUE ER33261F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 and ER33'
             '202=0); under age 5 or aged 40 or over (ER33204=001-004, 040-120 or 999); never in school (ER33225=9996)'
   ;
   VALUE ER33264F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 and ER33'
             '202=0); under age 5 or aged 40 or over (ER33204=001-004, 040-120 or 999); never in school (ER33225=9996)'
   ;
   VALUE ER33265F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 and ER33'
             '202=0); under age 5 or aged 40 or over (ER33204=001-004, 040-120 or 999); never in school (ER33225=9996)'
   ;
   VALUE ER33266F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 and ER33'
             '202=0); under age 13 or aged 50 or over (ER33204=001-012, 050-125 or 999); never in school (ER33225=9996)'
   ;
   VALUE ER33267F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 and ER33'
             '202=0); under age 13 or aged 50 or over (ER33204=001-012, 050-125 or 999); never in school (ER33225=9996); never been booked or charged (ER33266=5, 8 or 9)'
   ;
   VALUE ER33268F
    1 - 20 = 'Actual number of times'
        98 = 'DK'
        99 = 'NA; refused  NA; refused'
         0 = 'Inap.:  none; from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 an'
             'd ER33202=0); under age 13 or aged 50 or over (ER33204=001-012, 050-125 or 999); never in school (ER33225=9996); never been booked or charged (ER33266=5, 8 or 9); never spent time in a corrections ins'
             'titution (ER33267=5, 8 or 9)'
   ;
   VALUE ER33269F
    1 - 20 = 'Actual number of times'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  none; from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 an'
             'd ER33202=0); under age 13 or aged 50 or over (ER33204=001-012, 050-125 or 999); never in school (ER33225=9996); never been booked or charged (ER33266=5, 8 or 9); never spent time in a corrections ins'
             'titution (ER33267=5, 8 or 9)'
   ;
   VALUE ER33272F
         1 = 'Once'
         2 = 'Twice'
         3 = 'Three times'
         4 = 'Four or more times'
         5 = 'None'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 and ER33'
             '202=0); under age 5 or aged 50 or over (ER33204=001-004, 050-125 or 999); in school and not attending kindergarten through twelfth grade (ER33220=1 and ER33222=13-18, 93, 94, 98, 99); never attended s'
             'chool (ER33225=9996); not in school and last attendance date is before September 1994 (ER33225=1950-1994, 9997-9999 or ER33224=1-08, 98, 99 and ER33275=1994); not in school and completed less than kin'
             'dergarten or at least some college (ER33227=13-17, 93, 94, 98, 99)'
   ;
   VALUE ER33273F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 and ER33'
             '202=0); under age 5 or aged 50 or over (ER33204=001-004, 050-125 or 999); in school and not attending kindergarten through twelfth grade (ER33220=1 and ER33222=13-18, 93, 94, 98, 99); never attended s'
             'chool (ER33225=9996); not in school and last attendance date is before September 1994 (ER33225=1950-1994, 9997-9999 or ER33224=1-08, 98, 99 and ER33275=1994); not in school and completed less than kin'
             'dergarten or at least some college (ER33227=13-17, 93, 94, 98, 99)'
   ;
   VALUE ER33274F
         1 = 'Daily'
         2 = 'Once or twice a week'
         3 = 'Several times a month'
         4 = 'Less than once a month'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 and ER33'
             '202=0); under age 5 or aged 50 or over (ER33204=001-004, 050-125 or 999); in school and not attending kindergarten through twelfth grade (ER33220=1 and ER33222=13-18, 93, 94, 98, 99); never attended s'
             'chool (ER33225=9996); not in school and last attendance date is before September 1994 (ER33225=1950-1994, 9997-9999 or ER33224=1-08, 98, 99 and ER33275=1994); not in school and completed less than kin'
             'dergarten or at least some college (ER33227=13-17, 93, 94, 98, 99); no extracurricular activities (ER33273=5, 8 or 9)'
   ;
   VALUE ER33281F
         1 = 'This individual was eligible to be followed in 1995'
         5 = 'This individual was not eligible to be followed in 1995'
         0 = 'Inap.:  this individual was from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview'
             ' (ER33201>0 and ER33202=0); born or moved in after the 1992 interview (ER33201>0 and ER33202=0)'
   ;
   VALUE ER33282F
         1 = 'This individual was eligible to be followed at the time of main family nonresponse and had been in the FU in 1994.'
         3 = 'This individual, ineligible to be followed, had been in the 1994 FU, and this FU became nonresponse in 1995.'
         4 = 'This individual, eligible to be followed, had been in an institution in 1994, but his or her family became nonresponse in 1995.'
         5 = 'This individual, eligible to be followed and linked to a 1995 response family, was in an institution at the time of the 1995 interview.'
         6 = 'This individual, eligible to be followed, moved out or died between the 1994 and 1995 interviews.'
         8 = 'This individual, ineligible to be followed, moved out or died between the 1994 and 1995 interviews.'
         9 = 'This individual had not been born or moved in by the time of the 1995 interview; individual from Immigrant sample (ER30001=3001-3511,4001-4462)'
        10 = 'This individual had become nonresponse by the time of the 1994 interview.'
        99 = 'NA; DK'
         0 = 'Inap.:  this individual was in a panel family in 1995 (ER33202=1-20).'
   ;
   VALUE ER33283F
         1 = 'Wave refusal by all eligible/available FU members.'
         2 = 'No one at home for contact during the interviewing period.'
         3 = 'Respondent absent; some FU member contacted, but not the appropriate respondent.'
         4 = 'Lost; unable to locate any member of the FU at all.'
         5 = 'FU is located too far away for interviewer contact.'
        10 = 'Panel refusal by all all eligible/available FU members.  These individuals will never be asked to participate in the study again, regardless of recontact efforts.'
        11 = 'This individual was in the armed forces.'
        12 = 'This individual was in an educational institution.'
        13 = 'This individual was in a health care facility'
        14 = 'This individual was in jail or prison'
        19 = 'This individual was in some other type of institution, for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        21 = 'This individual was not eligible to be followed, and the Head or the Wife, whichever is the sample member, became main family nonresponse because he/she was institutionalized by joining the armed forc'
             'es.'
        22 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by entering an educational institution.'
        23 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized by entering a health care facility'
             '.'
        24 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized through imprisonment.'
        29 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by some means other than the above; for examp'
             'le, he/she may have entered a religious order. Cases in which the type of institution is unknown are included here, also.'
        31 = 'This individual was unable to cooperate through disability.'
        32 = 'This individual was not eligible to be followed, and the Head or Wife, whichever is sample, was unable to cooperate through disability.'
        41 = 'This individual died between the 1994 and 1995 interviews.'
        42 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is sample, died.'
        51 = 'This individual, although followed for interview, was discovered to be nonsample: office error.'
        52 = 'This individual should have been followed but was not: office error.'
        53 = 'This individual was mistakenly included in two or more response families at once; this record is the duplicate, or erroneous, one.'
        54 = 'Listing error: this individual never existed or was not really living in the FU.'
        56 = 'This individual became a followable non-sample parent (had baby) in this wave.  Because the PSID predetermines followability before entering the field each wave, he/she was not followed.'
        57 = 'Insufficient information that would permit recontact; paper coversheet(s) missing; no name or identifying information available'
        58 = 'Due to budgetary and/or time constraints, PSID staff decided not to take all of the usual steps to try to locate and/or persuade this FU.'
        59 = 'Limited number of contacts attempted; miscellaneous office error (does not include codes 1-54 above or codes 91-99 below)'
        91 = 'This individual moved out of the 1995 main family and was eligible to be followed, but the reason for nonresponse is NA.'
        92 = 'Individual moved out of the 1995 main family and was not eligible to be followed'
        93 = 'All followable members of this FU united with other panel FUs; this individual was not eligible to be followed and therefore became nonresponse.'
        97 = 'This individual had not been born or moved in by the time of the 1995 interview (ER33201>0 and ER33202=0); individual from Immigrant sample (ER30001=3001-3511,4001-4462)'
        98 = 'This individual became main family or mover-out nonresponse by 1994 (ER33101=0 and ER33201=0 or ER33101>0 and ER33102=71-89 and ER33201=0)'
        99 = 'NA; DK'
         0 = 'Inap.:  this individual was in a panel family in 1995 (ER33202=1-20)'
   ;
   VALUE ER33284F
         1 = 'Excellent'
         2 = 'Very good'
         3 = 'Good'
         4 = 'Fair'
         5 = 'Poor'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); in an institution or mover-out nonresponse in 1995 (ER33202=5'
             '1-89); not an other FU member age 55 or older (ER33204=001-054)'
   ;
   VALUE ER33285F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 and ER33'
             '202=0); in an institution or mover-out nonresponse in 1995 (ER33202=51-89); not a person age 55 or older (ER33204=001-054)'
   ;
   VALUE ER33286F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 and ER33'
             '202=0); in an institution or mover-out nonresponse in 1995 (ER33202=51-89); not a person age 55 or older (ER33204=001-054)'
   ;
   VALUE ER33287F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 and ER33'
             '202=0); in an institution or mover-out nonresponse in 1995 (ER33202=51-89); not a person age 55 or older (ER33204=001-054)'
   ;
   VALUE ER33288F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 and ER33'
             '202=0); in an institution or mover-out nonresponse in 1995 (ER33202=51-89); not a person age 55 or older (ER33204=001-054)'
   ;
   VALUE ER33289F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 and ER33'
             '202=0); in an institution or mover-out nonresponse in 1995 (ER33202=51-89); not a person age 55 or older (ER33204=001-054)'
   ;
   VALUE ER33290F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 and ER33'
             '202=0); in an institution or mover-out nonresponse in 1995 (ER33202=51-89); not a person age 55 or older (ER33204=001-054)'
   ;
   VALUE ER33291F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 and ER33'
             '202=0); in an institution or mover-out nonresponse in 1995 (ER33202=51-89); not a person age 55 or older (ER33204=001-054)'
   ;
   VALUE ER33292F
         1 = 'Yes to at least one variable among ER33285-ER33291'
         5 = 'No to ER33285-ER33291'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 and ER33'
             '202=0); in an institution or mover-out nonresponse in 1995 (ER33202=51-89); not a person age 55 or older (ER33204=001-054)'
   ;
   VALUE ER33293F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 and ER33'
             '202=0); in an institution or mover-out nonresponse in 1995 (ER33202=51-89); not a person age 55 or older (ER33204=001-054); no difficulty (ER33292=5)'
   ;
   VALUE ER33294F
         1 = 'Yes'
         5 = 'No'
         7 = 'Doesn''t do'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 and ER33'
             '202=0); in an institution or mover-out nonresponse in 1995 (ER33202=51-89); not a person age 55 or older (ER33204=001-054)'
   ;
   VALUE ER33295F
         1 = 'Yes'
         5 = 'No'
         7 = 'Doesn''t do'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 and ER33'
             '202=0); in an institution or mover-out nonresponse in 1995 (ER33202=51-89); not a person age 55 or older (ER33204=001-054)'
   ;
   VALUE ER33296F
         1 = 'Yes'
         5 = 'No'
         7 = 'Doesn''t do'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 and ER33'
             '202=0); in an institution or mover-out nonresponse in 1995 (ER33202=51-89); not a person age 55 or older (ER33204=001-054)'
   ;
   VALUE ER33297F
         1 = 'Yes'
         5 = 'No'
         7 = 'Doesn''t do'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 and ER33'
             '202=0); in an institution or mover-out nonresponse in 1995 (ER33202=51-89); not a person age 55 or older (ER33204=001-054)'
   ;
   VALUE ER33298F
         1 = 'Yes'
         5 = 'No'
         7 = 'Doesn''t do'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 and ER33'
             '202=0); in an institution or mover-out nonresponse in 1995 (ER33202=51-89); not a person age 55 or older (ER33204=001-054)'
   ;
   VALUE ER33299F
         1 = 'Yes'
         5 = 'No'
         7 = 'Doesn''t do'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1995 or mover-out nonresponse by 1994 (ER33201=0); born or moved in after the 1995 interview (ER33201>0 and ER33'
             '202=0); in an institution or mover-out nonresponse in 1995 (ER33202=51-89); not a person age 55 or older (ER33204=001-054)'
   ;
   VALUE ER33302F
    1 - 20 = 'Individuals in the family at the time of the 1996 interview'
   51 - 59 = 'Individuals in institutions at the time of the 1996 interview'
   71 - 80 = 'Individuals who moved out of the FU or out of institutions and established their own households between the 1995 and 1996 interviews'
   81 - 89 = 'Individuals who were living in 1995 but died by the time of the 1996 interview'
         0 = 'Inap.:  born or moved in after the 1996 interview; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1996 or mover-out nonresponse by 1995 (ER33301=0'
             ')'
   ;
   VALUE ER33303F
        10 = 'Head in 1996; 1995 Head who was mover-out nonresponse by the time of the 1996 interview'
        20 = 'Legal Wife in 1996; 1995 Wife who was mover-out nonresponse by the time of the 1996 interview'
        22 = '"Wife"--female cohabitor who has lived with Head for 12 months or more or who was present in the 1995 family, since consecutive interviews may be taken less or more than twelve months apart; 1995 "Wif'
             'e" who was mover-out nonresponse by the time of the 1996 interview'
        30 = 'Son or daughter of Head (includes adopted children but not stepchildren)'
        33 = 'Stepson or stepdaughter of Head (children of legal Wife (code 20) who are not children of Head)'
        35 = 'Son or daughter of "Wife" but not Head (includes only those children of mothers whose relationship to Head is 22 but who are not children of Head)'
        37 = 'Son-in-law or daughter-in-law of Head (includes stepchildren-in-law)'
        38 = 'Foster son or foster daughter, not legally adopted'
        40 = 'Brother or sister of Head (includes step and half sisters and brothers)'
        47 = 'Brother-in-law or sister-in-law of Head; i.e., brother or sister of legal Wife, or spouse of Head''s brother or sister.'
        48 = 'Brother or sister of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        50 = 'Father or mother of Head (includes stepparents)'
        57 = 'Father-in-law or mother-in-law of Head (includes parents of legal wives (code 20) only)'
        58 = 'Father or mother of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        60 = 'Grandson or granddaughter of Head (includes grandchildren of legal Wife (code 20), but those of a cohabitor are coded 97)'
        65 = 'Great-grandson or great-granddaughter of Head (includes great-grandchildren of legal Wife (code 20), but those of a cohabitor are coded 97)'
        66 = 'Grandfather or grandmother of Head (includes stepgrandparents)'
        67 = 'Grandfather or grandmother of legal Wife (code 20)'
        68 = 'Great-grandfather or great-grandmother of Head'
        69 = 'Great-grandfather or great-grandmother of legal Wife (code 20)'
        70 = 'Nephew or niece of Head'
        71 = 'Nephew or niece of legal Wife (code 20)'
        72 = 'Uncle or Aunt of Head'
        73 = 'Uncle or Aunt of legal Wife (code 20)'
        74 = 'Cousin of Head'
        75 = 'Cousin of legal Wife (code 20)'
        83 = 'Children of first-year cohabitor but not of Head (the parent of this child is coded 88)'
        88 = 'First-year cohabitor of Head'
        90 = 'Legal husband of Head'
        95 = 'Other relative of Head'
        96 = 'Other relative of legal Wife (code 20)'
        97 = 'Other relative of cohabitor (the cohabitor is code 22 or 88)'
        98 = 'Other nonrelatives (includes homosexual partners, friends of children of the FU, etc.)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1996 or mover-out nonresponse by 1995 (ER33301=0); born or moved in after the 1996 intervie'
             'w (ER33301>0 and ER33302=0)'
   ;
   VALUE ER33307F
         1 = 'Spouse in couple numbered 1'
         2 = 'Spouse in couple numbered 2'
         3 = 'Spouse in couple numbered 3'
         0 = 'Inap.:  not married or permanently cohabiting; spouse was not in FU at the time of the 1996 interview; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse'
             ' by 1996 or mover-out nonresponse by 1995 (ER33301=0); born or moved in after the 1996 interview (ER33301>0 and ER33302=0)'
   ;
   VALUE ER33308F
         1 = 'Moved in or born between the 1995 and 1996 interviews; splitoff in 1996'
         2 = 'Appeared; moved in by the time the 1995 interview was taken but not included in FU for 1995 (i.e., listing error)'
         5 = 'Moved out of FU or out of an institution between the 1995 and 1996 interviews and was not included in a 1996 panel FU'
         6 = 'Moved out of FU and into an institution between the 1995 and 1996 interviews'
         7 = 'Living in 1995 but died by the time of the 1996 interview'
         8 = 'Disappeared; moved out prior to the 1995 interview, but included in FU for 1995 (usually a listing error)'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); in main family in both 1995 and 1996 (ER33202=1-20 and ER33302=1-20); in an institution in both 1995 and 1996 (ER33202'
             '=51-59 and ER33302=51-59);  main family nonresponse by 1996 or mover-out nonresponse by 1995 (ER33301=0); born or moved in after the 1996 interview (ER33301>0 and ER33302=0)'
   ;
   VALUE ER33311F
         1 = 'Working now'
         2 = 'Only temporarily laid off'
         3 = 'Looking for work, unemployed'
         4 = 'Retired'
         5 = 'Permanently disabled'
         6 = 'HouseWife; keeping house'
         7 = 'Student'
         8 = 'Other'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1996 or mover-out nonresponse by 1995 (ER33301=0); born or moved in after the 1996 intervie'
             'w (ER33301>0 and ER33302=0); mover-out nonresponse for 1996 only if deceased (ER33302=81-89); in an institution in both 1995 and 1996 (ER33302=51-59 and ER33308=0); not a person aged 16 or older (ER33'
             '304=001-015)'
   ;
   VALUE ER33314F
         1 = 'Full-time student'
         2 = 'Part-time student'
         5 = 'Not enrolled in school'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1996 or mover-out nonresponse by 1995 (ER33301=0); born or moved in after the 1996 intervie'
             'w (ER33301>0 and ER33302=0); Head or Wife/"Wife" in 1996 (ER33302=1-20 and ER33303=10, 20 or 22); in an institution in both 1995 and 1996 (ER33302=51-59 and ER33308=0); under age 16, or aged 50 or old'
             'er (ER33304=001-015, 050-125 or 999); last attended school before 1995 (ER33313=1901-1994, 9997, 9998, or 9999)'
   ;
   VALUE ER33315F
    1 - 17 = 'Highest grade or year of school completed'
        98 = 'DK'
        99 = 'NA'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1996 or mover-out nonresponse by 1995 (ER33301=0); in an institution in both 1995 and 1996'
             '(ER33302=51-59 and ER33308=0); born or moved in after the 1996 interview (ER33301>0 and ER33302=0); not a person aged 16 or older (ER33304=001-015)'
   ;
   VALUE ER33316F
         1 = 'Yes, is covered'
         5 = 'No, is not covered'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1996 or mover-out nonresponse by 1995 (ER33301=0); born or moved in after the 1996 intervie'
             'w (ER33301>0 and ER33302=0); in an institution or mover-out nonresponse in 1996 (ER33302=51-89)'
   ;
   VALUE ER33317F
         1 = 'Yes, is in poor health'
         5 = 'No, is not in poor health'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1996 or mover-out nonresponse by 1995 (ER33301=0); born or moved in after the 1996 intervie'
             'w (ER33301>0 and ER33302=0); in an institution or mover-out nonresponse in 1996 (ER33302=51-89); current Head or Wife (ER33302=1-2 and ER33303=10, 20, 22); an other FU member aged 55 or older (ER33304'
             '>54)'
   ;
   VALUE ER33322F
         1 = 'This individual was eligible to be followed in 1996'
         5 = 'This individual was not eligible to be followed in 1996'
         0 = 'Inap.:  this individual was from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1996 or mover-out nonresponse by 1995 (ER33301=0); born or moved in aft'
             'er the 1996 interview (ER33301>0 and ER33302=0)'
   ;
   VALUE ER33324F
         1 = 'This individual was eligible to be followed at the time of main family nonresponse and had been in the FU in 1995.'
         3 = 'This individual, ineligible to be followed, had been in the 1995 FU, and this FU became nonresponse in 1996.'
         4 = 'This individual, eligible to be followed, had been in an institution in 1995, but his or her family became nonresponse in 1996.'
         5 = 'This individual, eligible to be followed and linked to a 1996 response family, was in an institution at the time of the 1996 interview.'
         6 = 'This individual, eligible to be followed, moved out or died between the 1995 and 1996 interviews.'
         8 = 'This individual, ineligible to be followed, moved out or died between the 1995 and 1996 interviews.'
         9 = 'This individual had not been born or moved in by the time of the 1996 interview; individual from Immigrant sample (ER30001=3001-3511,4001-4462)'
        10 = 'This individual had become nonresponse by the time of the 1995 interview.'
        40 = 'Individual connected with the Latino sample (ER30001=7001-9308).  This sample was dropped beginning in 1996. Individual connected with the Immigrant 17 sample (ER30001=4001-4462).'
        41 = 'Nonsample elderly individual who had been followed during the period 1990 through 1995.  If such a person was not living with a followable individual, then he or she was dropped from the study beginni'
             'ng in 1996.'
        99 = 'NA; DK'
         0 = 'Inap.:  this individual was in a panel family in 1996 (ER33302=1-20).'
   ;
   VALUE ER33325F
         1 = 'Wave refusal by all eligible/available FU members.'
         2 = 'No one at home for contact during the interviewing period.'
         3 = 'Respondent absent; some FU member contacted, but not the appropriate respondent.'
         4 = 'Lost; unable to locate any member of the FU at all.'
         5 = 'FU is located too far away for interviewer contact.'
        10 = 'Panel refusal by all all eligible/available FU members.  These individuals will never be asked to participate in the study again, regardless of recontact efforts.'
        11 = 'This individual was in the armed forces.'
        12 = 'This individual was in an educational institution.'
        13 = 'This individual was in a health care facility'
        14 = 'This individual was in jail or prison'
        19 = 'This individual was in some other type of institution, for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        21 = 'This individual was not eligible to be followed, and the Head or the Wife, whichever is the sample member, became main family nonresponse because he/she was institutionalized by joining the armed forc'
             'es.'
        22 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by entering an educational institution.'
        23 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized by entering a health care facility'
             '.'
        24 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized through imprisonment.'
        29 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by some means other than the above; for examp'
             'le, he/she may have entered a religious order. Cases in which the type of institution is unknown are included here, also.'
        31 = 'This individual was unable to cooperate through disability.'
        32 = 'This individual was not eligible to be followed, and the Head or Wife, whichever is sample, was unable to cooperate through disability.'
        41 = 'This individual died between the 1995 and 1996 interviews.'
        42 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is sample, died.'
        51 = 'This individual, although followed for interview, was discovered to be nonsample: office error.'
        52 = 'This individual should have been followed but was not: office error.'
        53 = 'This individual was mistakenly included in two or more response families at once; this record is the duplicate, or erroneous, one.'
        54 = 'Listing error: this individual never existed or was not really living in the FU.'
        56 = 'This individual became a followable non-sample parent (had baby) in this wave.  Because the PSID predetermines followability before entering the field each wave, he/she was not followed.'
        57 = 'Insufficient information that would permit recontact; paper coversheet(s) missing; no name or identifying information available'
        58 = 'Due to budgetary and/or time constraints, PSID staff decided not to take all of the usual steps to try to locate and/or persuade this FU.'
        59 = 'Limited number of contacts attempted; miscellaneous office error (does not include codes 1-54 above or codes 91-99 below)'
        80 = 'Individual connected with the Latino sample (ER30001=7001-9308).  This sample was dropped beginning in 1996.Individual connected with the Immigrant 17 sample (ER30001=4001-4462).'
        81 = 'This non-sample elderly individual was followed during the period 1990 through 1995.  If he or she was not living with a followable individual in 1996, then he or she was dropped from the study in 199'
             '6.  Other non-followable individuals connected with dropped non-sample elderly families are also included here.'
        91 = 'This individual moved out of the 1996 main family and was eligible to be followed, but the reason for nonresponse is NA.'
        92 = 'Individual moved out of the 1996 main family and was not eligible to be followed, including the nonsample elderly'
        93 = 'All followable members of this FU united with other panel FUs; this individual was not eligible to be followed and therefore became nonresponse.'
        97 = 'This individual had not been born or moved in by the time of the 1996 interview (ER33301>0 and ER33302=0); individual from Immigrant sample (ER30001=3001-3511,4001-4462)'
        98 = 'This individual became main family or mover-out nonresponse by 1995 (ER33201=0 and ER33301=0 or ER33201>0 and ER33202=71-89 and ER33301=0)'
        99 = 'NA; DK'
         0 = 'Inap.:  this individual was in a panel family in 1996 (ER33302=1-20)'
   ;
   VALUE ER33326F
         1 = 'Excellent'
         2 = 'Very good'
         3 = 'Good'
         4 = 'Fair'
         5 = 'Poor'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.:  from Immigrant sample (ER30001=3001-3511,4001-4462); main family nonresponse by 1996 or mover-out nonresponse by 1995 (ER33301=0); in an institution or mover-out nonresponse in 1996 (ER33302=5'
             '1-89); not an other FU member age 55 or older (ER33304=001-054)'
   ;
   VALUE ER33327F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1996 or mover-out nonresponse by 1995 (ER33301=0); born or moved in after the 1996 intervie'
             'w (ER33301>0 and ER33302=0); in an institution or mover-out nonresponse in 1996 (ER33302=51-89); not a person age 55 or older (ER33304=001-054)'
   ;
   VALUE ER33328F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1996 or mover-out nonresponse by 1995 (ER33301=0); born or moved in after the 1996 intervie'
             'w (ER33301>0 and ER33302=0); in an institution or mover-out nonresponse in 1996 (ER33302=51-89); not a person age 55 or older (ER33304=001-054)'
   ;
   VALUE ER33329F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1996 or mover-out nonresponse by 1995 (ER33301=0); born or moved in after the 1996 intervie'
             'w (ER33301>0 and ER33302=0); in an institution or mover-out nonresponse in 1996 (ER33302=51-89); not a person age 55 or older (ER33304=001-054)'
   ;
   VALUE ER33330F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1996 or mover-out nonresponse by 1995 (ER33301=0); born or moved in after the 1996 intervie'
             'w (ER33301>0 and ER33302=0); in an institution or mover-out nonresponse in 1996 (ER33302=51-89); not a person age 55 or older (ER33304=001-054)'
   ;
   VALUE ER33331F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1996 or mover-out nonresponse by 1995 (ER33301=0); born or moved in after the 1996 intervie'
             'w (ER33301>0 and ER33302=0); in an institution or mover-out nonresponse in 1996 (ER33302=51-89); not a person age 55 or older (ER33304=001-054)'
   ;
   VALUE ER33332F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1996 or mover-out nonresponse by 1995 (ER33301=0); born or moved in after the 1996 intervie'
             'w (ER33301>0 and ER33302=0); in an institution or mover-out nonresponse in 1996 (ER33302=51-89); not a person age 55 or older (ER33304=001-054)'
   ;
   VALUE ER33333F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1996 or mover-out nonresponse by 1995 (ER33301=0); born or moved in after the 1996 intervie'
             'w (ER33301>0 and ER33302=0); in an institution or mover-out nonresponse in 1996 (ER33302=51-89); not a person age 55 or older (ER33304=001-054)'
   ;
   VALUE ER33334F
         1 = 'Yes to at least one variable among ER33327-ER33333'
         5 = 'No to ER33327-ER33333'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1996 or mover-out nonresponse by 1995 (ER33301=0); born or moved in after the 1996 intervie'
             'w (ER33301>0 and ER33302=0); in an institution or mover-out nonresponse in 1996 (ER33302=51-89); not a person age 55 or older (ER33304=001-054)'
   ;
   VALUE ER33335F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1996 or mover-out nonresponse by 1995 (ER33301=0); born or moved in after the 1996 intervie'
             'w (ER33301>0 and ER33302=0); in an institution or mover-out nonresponse in 1996 (ER33302=51-89); not a person age 55 or older (ER33304=001-054); no difficulty (ER33334=5)'
   ;
   VALUE ER33336F
         1 = 'Yes'
         5 = 'No'
         7 = 'Doesn''t do'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1996 or mover-out nonresponse by 1995 (ER33301=0); born or moved in after the 1996 intervie'
             'w (ER33301>0 and ER33302=0); in an institution or mover-out nonresponse in 1996 (ER33302=51-89); not a person age 55 or older (ER33304=001-054)'
   ;
   VALUE ER33338F
         1 = 'Yes'
         5 = 'No'
         7 = 'Doesn''t do'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1996 or mover-out nonresponse by 1995 (ER33301=0); born or moved in after the 1996 intervie'
             'w (ER33301>0 and ER33302=0); in an institution or mover-out nonresponse in 1996 (ER33302=51-89); not a person age 55 or older (ER33304=001-054)'
   ;
   VALUE ER33340F
         1 = 'Yes'
         5 = 'No'
         7 = 'Doesn''t do'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1996 or mover-out nonresponse by 1995 (ER33301=0); born or moved in after the 1996 intervie'
             'w (ER33301>0 and ER33302=0); in an institution or mover-out nonresponse in 1996 (ER33302=51-89); not a person age 55 or older (ER33304=001-054)'
   ;
   VALUE ER33342F
         1 = 'Yes'
         5 = 'No'
         7 = 'Doesn''t do'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1996 or mover-out nonresponse by 1995 (ER33301=0); born or moved in after the 1996 intervie'
             'w (ER33301>0 and ER33302=0); in an institution or mover-out nonresponse in 1996 (ER33302=51-89); not a person age 55 or older (ER33304=001-054)'
   ;
   VALUE ER33344F
         1 = 'Yes'
         5 = 'No'
         7 = 'Doesn''t do'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1996 or mover-out nonresponse by 1995 (ER33301=0); born or moved in after the 1996 intervie'
             'w (ER33301>0 and ER33302=0); in an institution or mover-out nonresponse in 1996 (ER33302=51-89); not a person age 55 or older (ER33304=001-054)'
   ;
   VALUE ER33346F
         1 = 'Yes'
         5 = 'No'
         7 = 'Doesn''t do'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1996 or mover-out nonresponse by 1995 (ER33301=0); born or moved in after the 1996 intervie'
             'w (ER33301>0 and ER33302=0); in an institution or mover-out nonresponse in 1996 (ER33302=51-89); not a person age 55 or older (ER33304=001-054)'
   ;
   VALUE ER33402F
    1 - 20 = 'Individuals in the family at the time of the 1997 interview'
   51 - 59 = 'Individuals in institutions at the time of the 1997 interview'
   71 - 80 = 'Individuals who moved out of the FU or out of institutions and established their own households between the 1996 and 1997 interviews'
   81 - 89 = 'Individuals who were living in 1996 but died by the time of the 1997 interview'
         0 = 'Inap.:  born or moved in after the 1997 interview; from Immigrant or Latino samples (ER30001=3001-3511,4001-4462,7001-9308); main family nonresponse by 1997 or mover-out nonresponse by 1996 (ER33401=0'
             ')'
   ;
   VALUE ER33403F
        10 = 'Head in 1997; 1996 Head who was mover-out nonresponse by the time of the 1997 interview'
        20 = 'Legal Wife in 1997; 1996 Wife who was mover-out nonresponse by the time of the 1997 interview'
        22 = '"Wife"--female cohabitor who has lived with Head for 12 months or more or who was present in the 1996 family, since consecutive interviews may be taken less or more than twelve months apart; 1996 "Wif'
             'e" who was mover-out nonresponse by the time of the 1997 interview'
        30 = 'Son or daughter of Head (includes adopted children but not stepchildren)'
        33 = 'Stepson or stepdaughter of Head (children of legal Wife (code 20) who are not children of Head)'
        35 = 'Son or daughter of "Wife" but not Head (includes only those children of mothers whose relationship to Head is 22 but who are not children of Head)'
        37 = 'Son-in-law or daughter-in-law of Head (includes stepchildren-in-law)'
        38 = 'Foster son or foster daughter, not legally adopted'
        40 = 'Brother or sister of Head (includes step and half sisters and brothers)'
        47 = 'Brother-in-law or sister-in-law of Head; i.e., brother or sister of legal Wife, or spouse of Head''s brother or sister.'
        48 = 'Brother or sister of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        50 = 'Father or mother of Head (includes stepparents)'
        57 = 'Father-in-law or mother-in-law of Head (includes parents of legal wives (code 20) only)'
        58 = 'Father or mother of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        60 = 'Grandson or granddaughter of Head (includes grandchildren of legal Wife (code 20), but those of a cohabitor are coded 97)'
        65 = 'Great-grandson or great-granddaughter of Head (includes great-grandchildren of legal Wife (code 20), but those of a cohabitor are coded 97)'
        66 = 'Grandfather or grandmother of Head (includes stepgrandparents)'
        67 = 'Grandfather or grandmother of legal Wife (code 20)'
        68 = 'Great-grandfather or great-grandmother of Head'
        69 = 'Great-grandfather or great-grandmother of legal Wife (code 20)'
        70 = 'Nephew or niece of Head'
        71 = 'Nephew or niece of legal Wife (code 20)'
        72 = 'Uncle or Aunt of Head'
        73 = 'Uncle or Aunt of legal Wife (code 20)'
        74 = 'Cousin of Head'
        75 = 'Cousin of legal Wife (code 20)'
        83 = 'Children of first-year cohabitor but not of Head (the parent of this child is coded 88)'
        88 = 'First-year cohabitor of Head'
        90 = 'Legal husband of Head'
        95 = 'Other relative of Head'
        96 = 'Other relative of legal Wife (code 20)'
        97 = 'Other relative of cohabitor (the cohabitor is code 22 or 88)'
        98 = 'Other nonrelatives (includes homosexual partners, friends of children of the FU, etc.)'
         0 = 'Inap. from Immigrant Sample added in 1999, from Immigrant Sample added in 2017 or Latino samples (ER30001=3442-3511, 4001-4462, 7001-9308); main family nonresponse by 1997 or mover-out nonresponse by'
             '1996 (ER33401=0); born or moved in after the 1997 interview (ER33401>0 and ER33402=0)'
   ;
   VALUE ER33407F
         1 = 'Spouse in couple numbered 1'
         2 = 'Spouse in couple numbered 2'
         3 = 'Spouse in couple numbered 3'
         0 = 'Inap.:  not married or permanently cohabiting; spouse was not in FU at the time of the 1997 interview; from Immigrant 99 recontact, Immigrant 17 or Latino samples (ER30001=3442-3511, 4001-4462, 7001-9'
             '308); main family nonresponse by 1997 or mover-out nonresponse by 1996 (ER33401=0); born or moved in after the 1997 interview (ER33401>0 and ER33402=0)'
   ;
   VALUE ER33408F
         1 = 'Moved in or born between the 1996 and 1997 interviews; splitoff in 1997'
         2 = 'Appeared; moved in by the time the 1996 interview was taken but not included in FU for 1996 (i.e., listing error)'
         5 = 'Moved out of FU or out of an institution between the 1996 and 1997 interviews and was not included in a 1997 panel FU'
         6 = 'Moved out of FU and into an institution between the 1996 and 1997 interviews'
         7 = 'Living in 1996 but died by the time of the 1997 interview'
         8 = 'Disappeared; moved out prior to the 1996 interview, but included in FU for 1996 (usually a listing error)'
         0 = 'Inap.:  main Immigrant sample non-mover, either in the FU or in an institution; from Immigrant 99 recontact, Immigrant 17 or Latino samples (ER30001=3442-3511, 4001-4462, 7001-9308); in main family in'
             ' both 1996 and 1997 (ER33302=1-20 and ER33402=1-20); in an institution in both 1996 and 1997 (ER33302=51-59 and ER33402=51-59); main family nonresponse by 1997 or mover-out nonresponse by 1996 (ER3340'
             '1=0); born or moved in after the 1997 interview (ER33401>0 and ER33402=0)'
   ;
   VALUE ER33411F
         1 = 'Working now'
         2 = 'Only temporarily laid off'
         3 = 'Looking for work, unemployed'
         4 = 'Retired'
         5 = 'Permanently disabled'
         6 = 'HouseWife; keeping house'
         7 = 'Student'
         8 = 'Other'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant 99 recontact, Immigrant 17 or Latino samples (ER30001=3442-3511, 4001-4462, 7001-9308); main family nonresponse by 1997 or mover-out nonresponse by 1996 (ER33401=0); born or mov'
             'ed in after the 1997 interview (ER33401>0 and ER33402=0); mover-out nonresponse for 1997 only if deceased (ER33402=81-89); in an institution in both 1996 and 1997 (ER33402=51-59 and ER33408=0); not a'
             'person aged 16 or older (ER33404=001-015)'
   ;
   VALUE ER33414F
         1 = 'Full-time student'
         2 = 'Part-time student'
         5 = 'Not enrolled in school'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Immigrant 99 recontact, Immigrant 17 or Latino samples (ER30001=3442-3511, 4001-4462, 7001-9308); main family nonresponse by 1997 or mover-out nonresponse by 1996 (ER33401=0); born or mov'
             'ed in after the 1997 interview (ER33401>0 and ER33402=0); Head or Wife/"Wife" in 1997 (ER33402=1-20 and ER33403=10, 20 or 22); in an institution in both 1996 and 1997 (ER33402=51-59 and ER33408=0); un'
             'der age 16, or aged 50 or older (ER33404=001-015, 50-98); last attended school before 1996 (ER33413=1901-1995, 9997, 9998, or 9999)'
   ;
   VALUE ER33415F
    1 - 17 = 'Highest grade or year of school completed'
        98 = 'DK'
        99 = 'NA'
         0 = 'Inap.:  from Immigrant 99 recontact, Immigrant 17 or Latino samples (ER30001=3442-3511,4001-4462,7001-9308); main family nonresponse by 1997 or mover-out nonresponse by 1996 (ER33401=0); in an institu'
             'tion in both 1996 and 1997 (ER33402=51-59 and ER33408=0); born or moved in after the 1997 interview (ER33401>0 and ER33402=0); not a person aged 16 or older (ER33404=001-015)'
   ;
   VALUE ER33416F
         1 = 'Yes, is covered'
         5 = 'No, is not covered'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant 99 recontact, Immigrant 17 or Latino samples (ER30001=3442-3511, 4001-4462, 7001-9308); main family nonresponse by 1997 or mover-out nonresponse by 1996 (ER33401=0); born or mov'
             'ed in after the 1997 interview (ER33401>0 and ER33402=0); in an institution or mover-out nonresponse in 1997 (ER33402=51-89)'
   ;
   VALUE ER33417F
         1 = 'Yes, is in poor health'
         5 = 'No, is not in poor health'
         9 = 'NA; DK'
         0 = 'Inap.:  from Immigrant 99 recontact, Immigrant 17 or Latino samples (ER30001=3442-3511, 4001-4462, 7001-9308); main family nonresponse by 1997 or mover-out nonresponse by 1996 (ER33401=0); born or mov'
             'ed in after the 1997 interview (ER33401>0 and ER33402=0); in an institution or mover-out nonresponse in 1997 (ER33402=51-89); current Head or Wife (ER33402=1-2 and ER33403=10, 20, 22); an other FU mem'
             'ber aged 55 or older (ER33404>54)'
   ;
   VALUE ER33418F
         1 = 'Eligible for CDS'
         5 = 'Ineligible for CDS (child was under age 13 but was nonsample and was mistakenly selected for CDS)'
         0 = 'Inap.:  from Immigrant 99 recontact, Immigrant 17 or Latino samples (ER30001=3442-3511, 4001-4462, 7001-9308); main family nonresponse by 1997 or mover-out nonresponse by 1996 and was not selected for'
             ' recontact in 1997 (ER33401=0); born or moved in after the 1997 interview (ER33401>0 and ER33402=0); moved out by 1997 (ER33402=51-89); aged 13 or older (ER33404=13-999)'
   ;
   VALUE ER33419F
         1 = 'Selected for CDS'
         5 = 'Eligible but not selected for CDS'
         0 = 'Inap.:  this individual was from Immigrant 99 recontact, Immigrant 17 or Latino samples (ER30001=3442-3511, 4001-4462, 7001-9308); main family nonresponse by 1997 or mover-out nonresponse by 1996 and'
             'was not selected for recontact in 1997 (ER33401=0); born or moved in after the 1997 interview (ER33401>0 and ER33402=0); moved out by 1997 (ER33402=51-89); aged 13 or older (ER33404=13-999)'
   ;
   VALUE ER33420F
         1 = 'Interview with sample child'
         2 = 'Interview with nonsample child'
         3 = 'Nonresponse--refused'
         4 = 'Nonresponse--lost'
         5 = 'Nonresponse--incapacitated, permanent condition'
         6 = 'Nonresponse--deceased'
         7 = 'Nonresponse--could not contact primary caregiver for actual interview'
         8 = 'Nonresponse--area too dangerous for interviewer'
         9 = 'Nonresponse--language barrier'
        20 = 'Nonresponse--study ended before interview could be completed'
        96 = 'Office Error--interviewer reports interview taken, but no primary caregiver interview logged'
        97 = 'Office Error--eligible child who should have been selected for interview'
        98 = 'Office Error--outside continental U.S., should have been called'
         0 = 'Inap.:  from Immigrant 99 recontact, Immigrant 17 or Latino samples (ER30001=3442-3511, 4001-4462, 7001-9308); main family nonresponse by 1997 or mover-out nonresponse by 1996 (ER33401=0); born or mov'
             'ed in after the 1997 interview (ER33401>0 and ER33402=0); moved out by 1997 (ER33402=51-89); aged 13 or older (ER33404=13-999); not selected for an interview (ER33419=5)'
   ;
   VALUE ER33434F
         1 = 'This individual was eligible to be followed in 1997'
         5 = 'This individual was not eligible to be followed in 1997'
         0 = 'Inap.:  main family or mover-out nonresponse in 1996 and was not selected for recontact in 1997; this individual was from Immigrant 99 recontact, Immigrant 17 or Latino samples (ER30001=3442-3511, 400'
             '1-4462, 7001-9308); born or moved in after the 1997 interview (ER33401>0 and ER33402=0)'
   ;
   VALUE ER33436F
         1 = 'This individual was eligible to be followed at the time of main family nonresponse and had been in the FU in 1996.'
         3 = 'This individual, ineligible to be followed, had been in the 1996 FU, and this FU became nonresponse in 1997.'
         4 = 'This individual, eligible to be followed, had been in an institution in 1996, but his or her family became nonresponse in 1997.'
         5 = 'This individual, eligible to be followed and linked to a 1997 response family, was in an institution at the time of the 1997 interview.'
         6 = 'This individual, eligible to be followed, moved out or died between the 1996 and 1997 interviews.'
         8 = 'This individual, ineligible to be followed, moved out or died between the 1996 and 1997 interviews.'
         9 = 'This individual had not been born or moved in by the time of the 1997 interview; individual from Immigrant 99 recontact sample (ER30001=3442-3511); individual from Immigrant 17 sample (ER30001=4001-44'
             '62)'
        10 = 'This individual had become nonresponse by the time of the 1996 interview.'
        21 = 'Main family recontact: this person was selected for recontact in 1997, but the family was not successfully interviewed.'
        26 = 'Splitoff recontact: this sample individual moved out of a 1997 recontact main family but was not successfully interviewed.'
        40 = 'Individual connected with the Latino sample (ER30001=7001-9308); this sample was dropped beginning in 1996.  Individual dropped from the Census (SEO) sample due to budgetary constraints; this group wa'
             's dropped beginning in 1997.'
        99 = 'NA; DK'
         0 = 'Inap.:  this individual was in a panel family in 1997 (ER33402=1-20).'
   ;
   VALUE ER33437F
         1 = 'Wave refusal by all eligible/available FU members.'
         2 = 'No one at home for contact during the interviewing period.'
         3 = 'Respondent absent; some FU member contacted, but not the appropriate respondent.'
         4 = 'Lost; unable to locate any member of the FU at all.'
         5 = 'FU is located too far away for interviewer contact.'
        10 = 'Panel refusal by all all eligible/available FU members.  These individuals will never be asked to participate in the study again, regardless of recontact efforts.'
        11 = 'This individual was in the armed forces.'
        12 = 'This individual was in an educational institution.'
        13 = 'This individual was in a health care facility'
        14 = 'This individual was in jail or prison'
        19 = 'This individual was in some other type of institution, for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        21 = 'This individual was not eligible to be followed, and the Head or the Wife, whichever is the sample member, became main family nonresponse because he/she was institutionalized by joining the armed forc'
             'es.'
        22 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by entering an educational institution.'
        23 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized by entering a health care facility'
             '.'
        24 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized through imprisonment.'
        29 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by some means other than the above; for examp'
             'le, he/she may have entered a religious order. Cases in which the type of institution is unknown are included here, also.'
        31 = 'This individual was unable to cooperate through disability.'
        32 = 'This individual was not eligible to be followed, and the Head or Wife, whichever is sample, was unable to cooperate through disability.'
        41 = 'This individual died between the 1996 and 1997 interviews.'
        42 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is sample, died.'
        45 = 'This individual was a sample member but has been adopted by unrelated nonsample persons and therefore has become nonsample.'
        51 = 'This individual, although followed for interview, was discovered to be nonsample: office error.'
        52 = 'This individual should have been followed but was not: office error.'
        53 = 'This individual was mistakenly included in two or more response families at once; this record is the duplicate, or erroneous, one.'
        54 = 'Listing error: this individual never existed or was not really living in the FU.'
        56 = 'This individual became a followable non-sample parent (had baby) in this wave.  Because the PSID predetermines followability before entering the field each wave, he/she was not followed.'
        57 = 'Insufficient information that would permit recontact; paper coversheet(s) missing; no name or identifying information available'
        58 = 'Due to budgetary and/or time constraints, PSID staff decided not to take all of the usual steps to try to locate and/or persuade this FU.'
        59 = 'Limited number of contacts attempted; miscellaneous office error (does not include codes 1-54 above or codes 91-99 below)'
        80 = 'Individual connected with the Latino sample (ER30001=7001-9308); this sample was dropped beginning in 1996.  Individual dropped from the Census (SEO) sample due to budgetary constraints; this group wa'
             's dropped beginning in 1997.'
        81 = 'This non-sample elderly individual was followed during the period 1990 through 1995.  If he or she was not living with a followable individual in 1996, then he or she was dropped from the study in 199'
             '6.  Other non-followable individuals connected with dropped non-sample elderly families are also included here.'
        91 = 'This individual moved out of the 1997 main family and was eligible to be followed, but the reason for nonresponse is NA.'
        92 = 'Individual moved out of the 1997 main family and was not eligible to be followed, including the nonsample elderly'
        93 = 'All followable members of this FU united with other panel FUs; this individual was not eligible to be followed and therefore became nonresponse.'
        97 = 'This individual had not been born or moved in by the time of the 1997 interview (ER33401>0 and ER33402=0); individual from Immigrant 99 recontact sample (ER30001=3442-3511);  individual from Immigrant'
             ' 17 sample (ER30001=4001-4462)'
        98 = 'This individual became main family or mover-out nonresponse by 1996 and was not selected for recontact in 1997 (ER33301=0 and ER33401=0 and ER33434=0 or ER33301>0 and ER33302=71-89 and ER33401=0 and E'
             'R33434=0)'
        99 = 'NA; DK'
         0 = 'Inap.:  this individual was in a panel family in 1997 (ER33402=1-20)'
   ;
   VALUE ER33502F
    1 - 20 = 'Individuals in the family at the time of the 1999 interview'
   51 - 59 = 'Individuals in institutions at the time of the 1999 interview'
   71 - 80 = 'Individuals who moved out of the FU or out of institutions and established their own households between the 1997 and 1999 interviews'
   81 - 89 = 'Individuals who were living in 1997 but died by the time of the 1999 interview'
         0 = 'Inap.:  born or moved in after the 1999 interview; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 1999 or mover-out nonresponse by 1'
             '997 (ER33501=0)'
   ;
   VALUE ER33503F
        10 = 'Head in 1999; 1997 Head who was mover-out nonresponse by the time of the 1999 interview'
        20 = 'Legal Wife in 1999; 1997 Wife who was mover-out nonresponse by the time of the 1999 interview'
        22 = '"Wife"--female cohabitor who has lived with Head for 12 months or more; 1997 "Wife" who was mover-out nonresponse by the time of the 1999 interview'
        30 = 'Son or daughter of Head (includes adopted children but not stepchildren)'
        33 = 'Stepson or stepdaughter of Head (children of legal Wife (code 20) who are not children of Head)'
        35 = 'Son or daughter of "Wife" but not Head (includes only those children of mothers whose relationship to Head is 22 but who are not children of Head)'
        37 = 'Son-in-law or daughter-in-law of Head (includes stepchildren-in-law)'
        38 = 'Foster son or foster daughter, not legally adopted'
        40 = 'Brother or sister of Head (includes step and half sisters and brothers)'
        47 = 'Brother-in-law or sister-in-law of Head; i.e., brother or sister of legal Wife, or spouse of Head''s brother or sister.'
        48 = 'Brother or sister of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        50 = 'Father or mother of Head (includes stepparents)'
        57 = 'Father-in-law or mother-in-law of Head (includes parents of legal wives (code 20) only)'
        58 = 'Father or mother of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        60 = 'Grandson or granddaughter of Head (includes grandchildren of legal Wife (code 20), but those of a cohabitor are coded 97)'
        65 = 'Great-grandson or great-granddaughter of Head (includes great-grandchildren of legal Wife (code 20), but those of a cohabitor are coded 97)'
        66 = 'Grandfather or grandmother of Head (includes stepgrandparents)'
        67 = 'Grandfather or grandmother of legal Wife (code 20)'
        68 = 'Great-grandfather or great-grandmother of Head'
        69 = 'Great-grandfather or great-grandmother of legal Wife (code 20)'
        70 = 'Nephew or niece of Head'
        71 = 'Nephew or niece of legal Wife (code 20)'
        72 = 'Uncle or Aunt of Head'
        73 = 'Uncle or Aunt of legal Wife (code 20)'
        74 = 'Cousin of Head'
        75 = 'Cousin of legal Wife (code 20)'
        83 = 'Children of first-year cohabitor but not of Head (the parent of this child is coded 88)'
        88 = 'First-year cohabitor of Head'
        90 = 'Legal husband of Head'
        95 = 'Other relative of Head'
        96 = 'Other relative of legal Wife (code 20)'
        97 = 'Other relative of cohabitor (the cohabitor is code 22 or 88)'
        98 = 'Other nonrelatives (includes homosexual partners, friends of children of the FU, etc.)'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 1999 or mover-out nonresponse by 1997 (ER33501=0); born or moved in after the'
             ' 1999 interview (ER33501>0 and ER33502=0)'
   ;
   VALUE ER33507F
         1 = 'Spouse in couple numbered 1'
         2 = 'Spouse in couple numbered 2'
         3 = 'Spouse in couple numbered 3'
         4 = 'Spouse in couple numbered 4'
         0 = 'Inap.:  not married or permanently cohabiting; spouse was not in FU at the time of the 1999 interview; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main fami'
             'ly nonresponse by 1999 or mover-out nonresponse by 1997 (ER33501=0); born or moved in after the 1999 interview (ER33501>0 and ER33502=0)'
   ;
   VALUE ER33508F
         1 = 'Moved in or born between the 1997 and 1999 interviews; splitoff in 1999'
         2 = 'Appeared; moved in by the time the 1997 interview was taken but not included in FU for 1997 (i.e., listing error)'
         5 = 'Moved out of FU or out of an institution between the 1997 and 1999 interviews and was not included in a 1999 panel FU'
         6 = 'Moved out of FU and into an institution between the 1997 and 1999 interviews'
         7 = 'Living in 1997 but died by the time of the 1999 interview'
         8 = 'Disappeared; moved out prior to the 1997 interview, but included in FU for 1997 (usually a listing error)'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); in main family in both 1997 and 1999 (ER33402=1-20 and ER33502=1-20); in an institution in both 1997 and'
             ' 1999 (ER33402=51-59 and ER33502=51-59); main family nonresponse by 1999 or mover-out nonresponse by 1997 (ER33501=0); born or moved in after the 1999 interview (ER33501>0 and ER33502=0)'
   ;
   VALUE ER33511F
         1 = 'This individual was respondent'
         5 = 'This individual was not respondent; includes institutionalized individuals and mover-out nonresponse from 1999 (ER33502=51-89)'
         9 = 'NA; DK'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 1999 or mover-out nonresponse by 1997 (ER33501=0); born or moved in after the'
             ' 1999 interview (ER33501>0 and ER33502=0)'
   ;
   VALUE ER33512F
         1 = 'Working now'
         2 = 'Only temporarily laid off'
         3 = 'Looking for work, unemployed'
         4 = 'Retired'
         5 = 'Permanently disabled'
         6 = 'HouseWife; keeping house'
         7 = 'Student'
         8 = 'Other'
         9 = 'NA; DK'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 1999 or mover-out nonresponse by 1997 (ER33501=0); born or moved in after the'
             ' 1999 interview (ER33501>0 and ER33502=0); mover-out nonresponse for 1999 only if deceased (ER33502=81-89); in an institution in both 1997 and 1999 (ER33502=51-59 and ER33508=0); not a person aged 16'
             'or older (ER33504=001-015)'
   ;
   VALUE ER33515F
         1 = 'Full-time student'
         2 = 'Part-time student'
         5 = 'Not enrolled in school'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 1999 or mover-out nonresponse by 1997 (ER33501=0); born or moved in after the'
             ' 1999 interview (ER33501>0 and ER33502=0); Head or Wife/"Wife" in 1999 (ER33502=1-20 and ER33503=10, 20 or 22); in an institution in both 1997 and 1999 (ER33502=51-59 and ER33508=0); under age 16, or'
             'aged 50 or older (ER33504=001-015, 050-125 or 999); last attended school before 1998 (ER33514=1901-1997, 9997, 9998, or 9999)'
   ;
   VALUE ER33516F
    1 - 17 = 'Highest grade or year of school completed'
        98 = 'DK'
        99 = 'NA'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 1999 or mover-out nonresponse by 1997 (ER33501=0);  in an institution in both'
             ' 1997 and 1999 (ER33502=51-59 and ER33508=0); associated with a 1999 FU but actually moved out before 1998 (ER33508=5, 6, or 8 and ER33510<1998) or born or moved in after the 1999 interview (ER33501>0'
             ' and ER33502=0);  not a person aged 16 or older (ER33504=001-015)'
   ;
   VALUE ER33517F
         1 = 'Yes, is in poor health'
         5 = 'No, is not in poor health'
         9 = 'NA; DK'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 1999 or mover-out nonresponse by 1997 (ER33501=0); born or moved in after the'
             ' 1999 interview (ER33501>0 and ER33502=0); in an institution or mover-out nonresponse in 1999 (ER33502=51-89); current Head or Wife (ER33502=1-2 and ER33503=10, 20, 22); an other FU member aged 55 or'
             'older (ER33504>54)'
   ;
   VALUE ER33518F
         1 = 'Employer provided health insurance'
         2 = 'Private health insurance purchased directly'
         3 = 'Medicare'
         4 = 'Medi-Gap'
         5 = 'Medicaid/Medical Assistance/Medi-Cal'
         6 = 'Military health care/VA'
         7 = 'CHAMPUS/TRICARE/CHAMP-VA'
         8 = 'Indian Health Insurance'
         9 = 'State-sponsored health plan'
        10 = 'Other government program'
        97 = 'Other'
        98 = 'DK'
        99 = 'NA'
         0 = 'Inap.:  not covered by health care plan; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 1999 or mover-out nonresponse by 1997 (ER335'
             '01=0); born or moved in after the 1999 interview (ER33501>0 and ER33502=0); moved into FU in 1999 (ER33502=1-20 and ER33510=1999); moved out before 1997 (ER33502=71-89 and ER33510>0 and ER33510<1997)'
   ;
   VALUE ER33519F
         1 = 'Employer provided health insurance'
         2 = 'Private health insurance purchased directly'
         3 = 'Medicare'
         4 = 'Medi-Gap'
         5 = 'Medicaid/Medical Assistance/Medi-Cal'
         6 = 'Military health care/VA'
         7 = 'CHAMPUS/TRICARE/CHAMP-VA'
         8 = 'Indian Health Insurance'
         9 = 'State-sponsored health plan'
        10 = 'Other government program'
        97 = 'Other'
         0 = 'Inap.:  no second mention; not covered by health care plan (ER33518=0); from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 1999 or mover'
             '-out nonresponse by 1997 (ER33501=0); born or moved in after the 1999 interview (ER33501>0 and ER33502=0); moved into FU in 1999 (ER33502=1-20 and ER33510=1999); moved out before 1997 (ER33502=71-89 a'
             'nd ER33510>0 and ER33510<1997); not covered by health care plan or NA, DK to first mention (ER33518=00, 98, 99)'
   ;
   VALUE ER33520F
         1 = 'Employer provided health insurance'
         2 = 'Private health insurance purchased directly'
         3 = 'Medicare'
         4 = 'Medi-Gap'
         5 = 'Medicaid/Medical Assistance/Medi-Cal'
         6 = 'Military health care/VA'
         7 = 'CHAMPUS/TRICARE/CHAMP-VA'
         8 = 'Indian Health Insurance'
         9 = 'State-sponsored health plan'
        10 = 'Other government program'
        97 = 'Other'
         0 = 'Inap.:  no third mention; not covered by health care plan (ER33518=0); from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 1999 or mover-'
             'out nonresponse by 1997 (ER33501=0); born or moved in after the 1999 interview (ER33501>0 and ER33502=0); moved into FU in 1999 (ER33502=1-20 and ER33510=1999); moved out before 1997 (ER33502=71-89 an'
             'd ER33510>0 and ER33510<1997); not covered by health care plan or NA, DK to first mention (ER33518=00, 98, 99)'
   ;
   VALUE ER33521F
         1 = 'Employer provided health insurance'
         2 = 'Private health insurance purchased directly'
         3 = 'Medicare'
         4 = 'Medi-Gap'
         5 = 'Medicaid/Medical Assistance/Medi-Cal'
         6 = 'Military health care/VA'
         7 = 'CHAMPUS/TRICARE/CHAMP-VA'
         8 = 'Indian Health Insurance'
         9 = 'State-sponsored health plan'
        10 = 'Other government program'
        97 = 'Other'
         0 = 'Inap.:  no fourth mention; not covered by health care plan (ER33518=0); from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 1999 or mover'
             '-out nonresponse by 1997 (ER33501=0); born or moved in after the 1999 interview (ER33501>0 and ER33502=0); moved into FU in 1999 (ER33502=1-20 and ER33510=1999); moved out before 1997 (ER33502=71-89 a'
             'nd ER33510>0 and ER33510<1997); not covered by health care plan or NA, DK to first mention (ER33518=00, 98, 99)'
   ;
   VALUE ER33522F
    1 - 12 = 'Actual number of months covered in 1997'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  not covered in 1997; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 1999 or mover-out nonresponse by 1997 (ER33501=0); born'
             'or moved in after the 1999 interview (ER33501>0 and ER33502=0); moved into FU in 1999 (ER33502=1-20 and ER33510=1999); moved out before 1997 (ER33502=71-89 and ER33510>0 and ER33510<1997); not covered'
             ' by health care plan (ER33518=0)'
   ;
   VALUE ER33523F
    1 - 12 = 'Actual number of months covered in 1998'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  not covered in 1998; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 1999 or mover-out nonresponse by 1997 (ER33501=0); born'
             'or moved in after the 1999 interview (ER33501>0 and ER33502=0); moved into FU in 1999 (ER33502=1-20 and ER33510=1999); moved out before 1997 (ER33502=71-89 and ER33510>0 and ER33510<1997); not covered'
             ' by health care plan (ER33518=0)'
   ;
   VALUE ER33532AF
         1 = 'This individual received public assistance'
         0 = 'Inap.: did not receive public assistance; not in FU in 1997'
   ;
   VALUE ER33532BF
         1 = 'Alabama'
         2 = 'Alaska'
         4 = 'Arizona'
         5 = 'Arkansas'
         6 = 'California'
         8 = 'Colorado'
         9 = 'Connecticut'
        10 = 'Delaware'
        11 = 'District of Columbia'
        12 = 'Florida'
        13 = 'Georgia'
        15 = 'Hawaii'
        16 = 'Idaho'
        17 = 'Illinois'
        18 = 'Indiana'
        19 = 'Iowa'
        20 = 'Kansas'
        21 = 'Kentucky'
        22 = 'Louisiana'
        23 = 'Maine'
        24 = 'Maryland'
        25 = 'Massachusetts'
        26 = 'Michigan'
        27 = 'Minnesota'
        28 = 'Mississippi'
        29 = 'Missouri'
        30 = 'Montana'
        31 = 'Nebraska'
        32 = 'Nevada'
        33 = 'New Hampshire'
        34 = 'New Jersey'
        35 = 'New Mexico	'
        36 = 'New York'
        37 = 'North Carolina'
        38 = 'North Dakota'
        39 = 'Ohio'
        40 = 'Oklahoma'
        41 = 'Oregon'
        42 = 'Pennsylvania'
        44 = 'Rhode Island'
        45 = 'South Carolina'
        46 = 'South Dakota'
        47 = 'Tennessee'
        48 = 'Texas'
        49 = 'Utah'
        50 = 'Vermont'
        51 = 'Virginia'
        53 = 'Washington'
        54 = 'West Virginia'
        55 = 'Wisconsin'
        56 = 'Wyoming'
        99 = 'DK; NA; refused'
         0 = 'Inap.:  not receiving public assistance in 1997 (ER33532A=0); not in FU in 1997.'
   ;
   VALUE ER33532CF
         1 = 'Received TANF assistance'
         0 = 'INAP.: received no public assistance in 1997 (ER33532A = 0), or received another type of assistance; was not in FU in 1997.'
   ;
   VALUE ER33532DF
         1 = 'Received ADC assistance'
         0 = 'INAP.: received no public assistance in 1997 (ER33532A = 0), or received another type of assistance; was not in FU in 1997.'
   ;
   VALUE ER33532EF
         1 = 'Received General Assistance'
         0 = 'INAP.: received no public assistance in 1997 (ER33532A = 0), or received another type of assistance; was not in FU in 1997.'
   ;
   VALUE ER33532FF
         1 = 'Received Emergency Assistance'
         0 = 'INAP.: received no public assistance in 1997 (ER33532A = 0), or received another type of assistance; was not in FU in 1997.'
   ;
   VALUE ER33532GF
         1 = 'Received Cuban/Haitian Refugee Assistance'
         0 = 'INAP.: received no public assistance in 1997 (ER33532A = 0), or received another type of assistance; was not in FU in 1997.'
   ;
   VALUE ER33532HF
         1 = 'Received Indian Assistance'
         0 = 'INAP.: received no public assistance in 1997 (ER33532A = 0), or received another type of assistance; was not in FU in 1997.'
   ;
   VALUE ER33532IF
         1 = 'Received Other Assistance'
         0 = 'INAP.: received no public assistance in 1997 (ER33532A = 0), or received another type of assistance; was not in FU in 1997.'
   ;
   VALUE ER33532XF
    1 - 12 = 'Actual number of months in which public assistance was received in 1997'
        99 = 'DK; refused'
         0 = 'Inap.: did not receive public assistance in 1997 (ER33532A=0); was not in FU in 1997; this individual''s portion of public assistance is included in a lump sum attached to the parents or guardians indi'
             'vidual data'
   ;
   VALUE ER33533F
         1 = 'This individual received SSI'
         0 = 'Inap.:  did not receive SSI; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 1999 or mover-out nonresponse by 1997 (ER33501=0); born'
             'or moved in after the 1999 interview (ER33501>0 and ER33502=0); in an institution in both 1997 and 1999 (ER33502=51-59 and ER33508=0); moved in after or moved out before 1997 (ER33502=1-20 and ER33510'
             '=1998-1999 or ER33502=51-89 and ER33508=8)'
   ;
   VALUE ER33534F
         1 = 'This individual received child support'
         0 = 'Inap.:  did not receive child support; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 1999 or mover-out nonresponse by 1997 (ER33501'
             '=0); born or moved in after the 1999 interview (ER33501>0 and ER33502=0); in an institution in both 1997 and 1999 (ER33502=51-59 and ER33508=0); moved in after or moved out before 1997 (ER33502=1-20 a'
             'nd ER33510=1998-1999 or ER33502=51-89 and ER33508=8)'
   ;
   VALUE ER33535F
         1 = 'This individual received help from relatives'
         0 = 'Inap.:  did not receive help from relatives; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 1999 or mover-out nonresponse by 1997 (E'
             'R33501=0); born or moved in after the 1999 interview (ER33501>0 and ER33502=0); in an institution in both 1997 and 1999 (ER33502=51-59 and ER33508=0); moved in after or moved out before 1997 (ER33502='
             '1-20 and ER33510=1998-1999 or ER33502=51-89 and ER33508=8)'
   ;
   VALUE ER33536F
         1 = 'This individual received other help'
         0 = 'Inap.:  did not receive other help; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 1999 or mover-out nonresponse by 1997 (ER33501=0)'
             '; born or moved in after the 1999 interview (ER33501>0 and ER33502=0); in an institution in both 1997 and 1999 (ER33502=51-59 and ER33508=0); moved in after or moved out before 1997 (ER33502=1-20 and'
             'ER33510=1998-1999 or ER33502=51-89 and ER33508=8)'
   ;
   VALUE ER33536BF
         1 = 'Hour'
         2 = 'Day'
         3 = 'Week'
         4 = 'Two weeks'
         5 = 'Month'
         6 = 'Year'
         9 = 'DK; NA; refused'
         0 = 'Inap.:  individual did not work in 1997; was not in FU in 1997; under age 18 in 1999'
   ;
   VALUE ER33536CF
    1 - 52 = 'Actual number of weeks worked in 1997'
        99 = 'DK; NA; refused'
         0 = 'Inap.:  individual did not work in 1997; was not in FU in 1997; under age 18 in 1999'
   ;
   VALUE ER33536PF
    1 - 12 = 'Actual number of months in which earnings were received in 1997'
        99 = 'NA; DK'
         0 = 'Inap.:  individual did not work in 1997; was not in FU in 1997; under age 18 in 1999'
   ;
   VALUE ER33537F
         1 = 'This individual stopped receiving benefits'
         0 = 'Inap.:  did not stop receiving benefits; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 1999 or mover-out nonresponse by 1997 (ER335'
             '01=0); born or moved in after the 1999 interview (ER33501>0 and ER33502=0); in an institution in both 1997 and 1999 (ER33502=51-59 and ER33508=0); moved in after or moved out before 1997 (ER33502=1-20'
             ' and ER33510=1998-1999 or ER33502=51-89 and ER33508=8)'
   ;
   VALUE ER33537MF
    1 - 12 = 'Actual number of months in which this individual was unemployed and looking for work in 1997'
        99 = 'DK; NA; refused'
         0 = 'Inap.:  was not unemployed in 1997; was not in FU in 1997; under age 18 in 1999'
   ;
   VALUE ER33538F
         1 = 'This individual stopped receiving food stamps'
         0 = 'Inap.:  did not stop receiving food stamps; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 1999 or mover-out nonresponse by 1997 (ER'
             '33501=0); born or moved in after the 1999 interview (ER33501>0 and ER33502=0); in an institution in both 1997 and 1999 (ER33502=51-59 and ER33508=0); moved in after or moved out before 1997 (ER33502=1'
             '-20 and ER33510=1998-1999 or ER33502=51-89 and ER33508=8)'
   ;
   VALUE ER33542F
         1 = 'This individual was eligible to be followed in 1999'
         5 = 'This individual was not eligible to be followed in 1999'
         0 = 'Inap.:  main family or mover-out nonresponse in 1997 and was not selected for recontact in 1999; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); born or moved i'
             'n after the 1999 interview (ER33501>0 and ER33502=0)'
   ;
   VALUE ER33544F
         1 = 'This individual was eligible to be followed at the time of main family nonresponse and had been in the FU in 1997.'
         3 = 'This individual, ineligible to be followed, had been in the 1997 FU, and this FU became nonresponse in 1999.'
         4 = 'This individual, eligible to be followed, had been in an institution in 1997, but his or her family became nonresponse in 1999.'
         5 = 'This individual, eligible to be followed and linked to a 1999 response family, was in an institution at the time of the 1999 interview.'
         6 = 'This individual, eligible to be followed, moved out or died between the 1997 and 1999 interviews.'
         8 = 'This individual, ineligible to be followed, moved out or died between the 1997 and 1999 interviews.'
         9 = 'This individual had not been born or moved in by the time of the 1999 interview;  individual from Immigrant 17 sample (ER30001=4001-4462)'
        10 = 'This individual had become nonresponse by the time of the 1997 interview.'
        21 = 'Main family recontact: this person was selected for recontact in 1999, but the family was not successfully interviewed.'
        26 = 'Splitoff recontact: this sample individual moved out of a 1999 recontact main family but was not successfully interviewed.'
        40 = 'Individual connected with the Latino sample (ER30001=7001-9308); this sample was dropped beginning in 1996.  Individual dropped from the Census (SEO) sample due to budgetary constraints; this group wa'
             's dropped beginning in 1997.'
        99 = 'NA; DK'
         0 = 'Inap.:  this individual was in a panel family in 1999 (ER33502=1-20).'
   ;
   VALUE ER33545F
         1 = 'Wave refusal by all eligible/available FU members.'
         2 = 'No one at home for contact during the interviewing period.'
         3 = 'Respondent absent; some FU member contacted, but not the appropriate respondent.'
         4 = 'Lost; unable to locate any member of the FU at all.'
         5 = 'FU is located too far away for interviewer contact.'
        10 = 'Panel refusal by all all eligible/available FU members.  These individuals will never be asked to participate in the study again, regardless of recontact efforts.'
        11 = 'This individual was in the armed forces.'
        12 = 'This individual was in an educational institution.'
        13 = 'This individual was in a health care facility'
        14 = 'This individual was in jail or prison'
        19 = 'This individual was in some other type of institution, for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        21 = 'This individual was not eligible to be followed, and the Head or the Wife, whichever is the sample member, became main family nonresponse because he/she was institutionalized by joining the armed forc'
             'es.'
        22 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by entering an educational institution.'
        23 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized by entering a health care facility'
             '.'
        24 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized through imprisonment.'
        29 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by some means other than the above; for examp'
             'le, he/she may have entered a religious order. Cases in which the type of institution is unknown are included here, also.'
        31 = 'This individual was unable to cooperate through disability.'
        32 = 'This individual was not eligible to be followed, and the Head or Wife, whichever is sample, was unable to cooperate through disability.'
        41 = 'This individual died between the 1997 and 1999 interviews; this individual died after becoming nonresponse for some other reason before the 1997 interview.'
        42 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is sample, died.'
        45 = 'This individual was a sample member but has been adopted by unrelated nonsample persons and therefore has become nonsample.'
        51 = 'This individual, although followed for interview, was discovered to be nonsample: office error.'
        52 = 'This individual should have been followed but was not: office error.'
        53 = 'This individual was mistakenly included in two or more response families at once; this record is the duplicate, or erroneous, one.'
        54 = 'Listing error: this individual never existed or was not really living in the FU.'
        56 = 'This individual became a followable non-sample parent (had baby) in this wave.  Because the PSID predetermines followability before entering the field each wave, he/she was not followed.  However, beg'
             'inning in the 1999 wave, he/she is eligible for recontact efforts in the next wave.'
        57 = 'Insufficient information that would permit recontact; paper coversheet(s) missing; no name or identifying information available'
        58 = 'Due to budgetary and/or time constraints, PSID staff decided not to take all of the usual steps to try to locate and/or persuade this FU.'
        59 = 'Limited number of contacts attempted; miscellaneous office error (does not include codes 1-54 above or codes 91-99 below)'
        60 = 'This nonsample parent of a sample child is no longer followable and became nonresponse because either the child is now aged 25 or is nonresponse and was not selected for recontact in the next wave.'
        61 = 'This individual was not eligible to be followed and was associated with a family containing a person erroneously designated as followable; the erroneous person''s code is 51, 53, 54, or 60.'
        80 = 'Individual connected with the Latino sample (ER30001=7001-9308); this sample was dropped beginning in 1996.  Individual dropped from the Census (SEO) sample due to budgetary constraints; this group wa'
             's dropped beginning in 1997.'
        91 = 'This individual moved out of the 1994 main family and was eligible to be followed, but the reason for nonresponse is NA.'
        92 = 'Individual moved out of the 1994 main family and was not eligible to be followed, including the nonsample elderly'
        93 = 'All followable members of this FU united with other panel FUs; this individual was not eligible to be followed and therefore became nonresponse.'
        97 = 'This individual had not been born or moved in by the time of the 1999 interview (ER33501>0 and ER33502=0);  individual from Immigrant 17 sample (ER30001=4001-4462)'
        98 = 'This individual became main family or mover-out nonresponse by 1997 and was not selected for recontact in 1999 (ER33401=0 and ER33501=0 and ER33542=0 or ER33401>0 and ER33402=71-89 and ER33501=0 and E'
             'R33542=0)'
        99 = 'NA; DK'
         0 = 'Inap.:  this individual was in a panel family in 1994 (ER33502=1-20)'
   ;
   VALUE ER33602F
    1 - 20 = 'Individuals in the family at the time of the 2001 interview'
   51 - 59 = 'Individuals in institutions at the time of the 2001 interview'
   71 - 80 = 'Individuals who moved out of the FU or out of institutions and established their own households between the 1999 and 2001 interviews'
   81 - 89 = 'Individuals who were living in 1999 but died by the time of the 2001 interview'
         0 = 'Inap.:  born or moved in after the 2001 interview; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2001 or mover-out nonresponse by 1'
             '999 (ER33601=0)'
   ;
   VALUE ER33603F
        10 = 'Head in 2001; 1999 Head who was mover-out nonresponse by the time of the 2001 interview'
        20 = 'Legal Wife in 2001; 1999 Wife who was mover-out nonresponse by the time of the 2001 interview'
        22 = '"Wife"--female cohabitor who has lived with Head for 12 months or more; 1999 "Wife" who was mover-out nonresponse by the time of the 2001 interview'
        30 = 'Son or daughter of Head (includes adopted children but not stepchildren)'
        33 = 'Stepson or stepdaughter of Head (children of legal Wife (code 20) who are not children of Head)'
        35 = 'Son or daughter of "Wife" but not Head (includes only those children of mothers whose relationship to Head is 22 but who are not children of Head)'
        37 = 'Son-in-law or daughter-in-law of Head (includes stepchildren-in-law)'
        38 = 'Foster son or foster daughter, not legally adopted'
        40 = 'Brother or sister of Head (includes step and half sisters and brothers)'
        47 = 'Brother-in-law or sister-in-law of Head; i.e., brother or sister of legal Wife, or spouse of Head''s brother or sister.'
        48 = 'Brother or sister of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        50 = 'Father or mother of Head (includes stepparents)'
        57 = 'Father-in-law or mother-in-law of Head (includes parents of legal wives (code 20) only)'
        58 = 'Father or mother of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        60 = 'Grandson or granddaughter of Head (includes grandchildren of legal Wife (code 20), but those of a cohabitor are coded 97)'
        65 = 'Great-grandson or great-granddaughter of Head (includes great-grandchildren of legal Wife (code 20), but those of a cohabitor are coded 97)'
        66 = 'Grandfather or grandmother of Head (includes stepgrandparents)'
        67 = 'Grandfather or grandmother of legal Wife (code 20)'
        68 = 'Great-grandfather or great-grandmother of Head'
        69 = 'Great-grandfather or great-grandmother of legal Wife (code 20)'
        70 = 'Nephew or niece of Head'
        71 = 'Nephew or niece of legal Wife (code 20)'
        72 = 'Uncle or Aunt of Head'
        73 = 'Uncle or Aunt of legal Wife (code 20)'
        74 = 'Cousin of Head'
        75 = 'Cousin of legal Wife (code 20)'
        83 = 'Children of first-year cohabitor but not of Head (the parent of this child is coded 88)'
        88 = 'First-year cohabitor of Head'
        90 = 'Legal husband of Head'
        95 = 'Other relative of Head'
        96 = 'Other relative of legal Wife (code 20)'
        97 = 'Other relative of cohabitor (the cohabitor is code 22 or 88)'
        98 = 'Other nonrelatives (includes homosexual partners, friends of children of the FU, etc.)'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2001 or mover-out nonresponse by 1999 (ER33601=0); born or moved in after the'
             ' 2001 interview (ER33601>0 and ER33602=0)'
   ;
   VALUE ER33607F
         1 = 'Spouse in couple numbered 1'
         2 = 'Spouse in couple numbered 2'
         3 = 'Spouse in couple numbered 3'
         4 = 'Spouse in couple numbered 4'
         0 = 'Inap.:  not married or permanently cohabiting; spouse was not in FU at the time of the 2001 interview; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main fami'
             'ly nonresponse by 2001 or mover-out nonresponse by 1999 (ER33601=0); born or moved in after the 2001 interview (ER33601>0 and ER33602=0)'
   ;
   VALUE ER33608F
         1 = 'Moved in or born between the 1999 and 2001 interviews; splitoff in 2001'
         2 = 'Appeared; moved in by the time the 1999 interview was taken but not included in FU for 1999 (i.e., listing error)'
         5 = 'Moved out of FU or out of an institution between the 1999 and 2001 interviews and was not included in a 2001 panel FU'
         6 = 'Moved out of FU and into an institution between the 1999 and 2001 interviews'
         7 = 'Living in 1999 but died by the time of the 2001 interview'
         8 = 'Disappeared; moved out prior to the 1999 interview, but included in FU for 1999 (usually a listing error)'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); in main family in both 1999 and 2001 (ER33502=1-20 and ER33602=1-20); in an institution in both 1999 and'
             ' 2001 (ER33502=51-59 and ER33602=51-59); main family nonresponse by 2001 or mover-out nonresponse by 1999 (ER33601=0); born or moved in after the 2001 interview (ER33601>0 and ER33602=0)'
   ;
   VALUE ER33611F
         1 = 'This individual was respondent'
         5 = 'This individual was not respondent; includes institutionalized individuals and mover-out nonresponse from 2001 (ER33602=51-89)'
         9 = 'NA; DK'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2001 or mover-out nonresponse by 1999 (ER33601=0); born or moved in after the'
             ' 2001 interview (ER33601>0 and ER33602=0)'
   ;
   VALUE ER33612F
         1 = 'Working now'
         2 = 'Only temporarily laid off'
         3 = 'Looking for work, unemployed'
         4 = 'Retired'
         5 = 'Permanently disabled'
         6 = 'HouseWife; keeping house'
         7 = 'Student'
         8 = 'Other'
         9 = 'NA; DK'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2001 or mover-out nonresponse by 1999 (ER33601=0); mover-out nonresponse for'
             '2001 only if deceased (ER33602=81-89); in an institution in both 1999 and 2001 (ER33602=51-59 and ER33608=0); not a person aged 16 or older (ER33604=001-015); born or moved in after the 2001 interview'
             ' (ER33601>0 and ER33602=0)'
   ;
   VALUE ER33615F
         1 = 'Full-time student'
         2 = 'Part-time student'
         5 = 'Not enrolled in school'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2001 or mover-out nonresponse by 1999 (ER33601=0); Head or Wife/"Wife" in 200'
             '1 (ER33602=1-20 and ER33603=10, 20 or 22); in an institution in both 1999 and 2001 (ER33602=51-59 and ER33608=0); under age 16, or aged 50 or older (ER33604=001-015, 050-125 or 999); last attended sch'
             'ool before 1999 (ER33614=1901-1998, 9997, 9998, or 9999); born or moved in after the 2001 interview (ER33601>0 and ER33602=0)'
   ;
   VALUE ER33616F
    1 - 17 = 'Highest grade or year of school completed'
        98 = 'DK'
        99 = 'NA'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2001 or mover-out nonresponse by 1999 (ER33601=0); in an institution in both'
             '1999 and 2001 (ER33602=51-59 and ER33608=0); associated with a 2001 FU but moved out before 2000 (ER33608=5, 6, or 8 and ER33610<2000) or born or moved in after the 2001 interview (ER33601>0 and ER336'
             '02=0); not a person aged 16 or older (ER33604=001-015, 999)'
   ;
   VALUE ER33617F
         1 = 'Yes, is in poor health'
         5 = 'No, is not in poor health'
         9 = 'NA'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2001 or mover-out nonresponse by 1999 (ER33601=0); in an institution or mover'
             '-out nonresponse in 2001 (ER33602=51-89); born or moved in after the 2001 interview (ER33601>0 and ER33602=0); current Head or Wife (ER33602=1-2 and ER33603=10, 20, 22)'
   ;
   VALUE ER33618F
         1 = 'Employer provided health insurance'
         2 = 'Private health insurance purchased directly'
         3 = 'Medicare'
         4 = 'Medi-Gap'
         5 = 'Medicaid/Medical Assistance/Medi-Cal'
         6 = 'Military health care/VA'
         7 = 'CHAMPUS/TRICARE/CHAMP-VA'
         8 = 'Indian Health Insurance'
         9 = 'State-sponsored health plan'
        10 = 'Other government program'
        97 = 'Other'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  not covered by health care plan; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2001 or mover-out nonresponse by 1999 (ER336'
             '01=0); moved into FU in 2001 (ER33602=1-20 and ER33610=2001); moved out before 1999 (ER33602=71-89 and ER33610>0 and ER33610<1999); born or moved in after the 2001 interview (ER33601>0 and ER33602=0)'
   ;
   VALUE ER33619F
         1 = 'Employer provided health insurance'
         2 = 'Private health insurance purchased directly'
         3 = 'Medicare'
         4 = 'Medi-Gap'
         5 = 'Medicaid/Medical Assistance/Medi-Cal'
         6 = 'Military health care/VA'
         7 = 'CHAMPUS/TRICARE/CHAMP-VA'
         8 = 'Indian Health Insurance'
         9 = 'State-sponsored health plan'
        10 = 'Other government program'
        97 = 'Other'
         0 = 'Inap.:  no second mention; not covered by health care plan (ER33618=0); from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2001 or mover'
             '-out nonresponse by 1999 (ER33601=0); moved into FU in 2001 (ER33602=1-20 and ER33610=2001); moved out before 1999 (ER33602=71-89 and ER33610>0 and ER33610<1999); NA, DK to first mention (ER33618=98 o'
             'r 99); born or moved in after the 2001 interview (ER33601>0 and ER33602=0)'
   ;
   VALUE ER33620F
         1 = 'Employer provided health insurance'
         2 = 'Private health insurance purchased directly'
         3 = 'Medicare'
         4 = 'Medi-Gap'
         5 = 'Medicaid/Medical Assistance/Medi-Cal'
         6 = 'Military health care/VA'
         7 = 'CHAMPUS/TRICARE/CHAMP-VA'
         8 = 'Indian Health Insurance'
         9 = 'State-sponsored health plan'
        10 = 'Other government program'
        97 = 'Other'
         0 = 'Inap.:  no third mention; not covered by health care plan (ER33618=0); from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2001 or mover-'
             'out nonresponse by 1999 (ER33601=0); moved into FU in 2001 (ER33602=1-20 and ER33610=2001); moved out before 1999 (ER33602=71-89 and ER33610>0 and ER33610<1999); NA, DK to first mention (ER33618=98 or'
             ' 99); born or moved in after the 2001 interview (ER33601>0 and ER33602=0)'
   ;
   VALUE ER33621F
         1 = 'Employer provided health insurance'
         2 = 'Private health insurance purchased directly'
         3 = 'Medicare'
         4 = 'Medi-Gap'
         5 = 'Medicaid/Medical Assistance/Medi-Cal'
         6 = 'Military health care/VA'
         7 = 'CHAMPUS/TRICARE/CHAMP-VA'
         8 = 'Indian Health Insurance'
         9 = 'State-sponsored health plan'
        10 = 'Other government program'
        97 = 'Other'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  no fourth mention; not covered by health care plan (ER33618=0); from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2001 or mover'
             '-out nonresponse by 1999 (ER33601=0); moved into FU in 2001 (ER33602=1-20 and ER33610=2001); moved out before 1999 (ER33602=71-89 and ER33610>0 and ER33610<1999); NA, DK to first mention (ER33618=98 o'
             'r 99); born or moved in after the 2001 interview (ER33601>0 and ER33602=0)'
   ;
   VALUE ER33622F
    1 - 12 = 'Actual number of months covered in 1999'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  not covered in 1999; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2001 or mover-out nonresponse by 1999 (ER33601=0); moved'
             ' into FU in 2001 (ER33602=1-20 and ER33610=2001); moved out before 1999 (ER33602=71-89 and ER33610>0 and ER33610<1999); not covered by health care plan (ER33618=0); born or moved in after the 2001 int'
             'erview (ER33601>0 and ER33602=0)'
   ;
   VALUE ER33623F
    1 - 12 = 'Actual number of months covered in 2000'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  not covered in 2000; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2001 or mover-out nonresponse by 1999 (ER33601=0); moved'
             ' into FU in 2001 (ER33602=1-20 and ER33610=2001); moved out before 1999 (ER33602=71-89 and ER33610>0 and ER33610<1999); not covered by health care plan (ER33618=0); born or moved in after the 2001 int'
             'erview (ER33601>0 and ER33602=0)'
   ;
   VALUE ER33623AF
         1 = 'This individual received public assistance'
         0 = 'Inap.: did not receive public assistance; not in FU in 1999'
   ;
   VALUE ER33623BF
         1 = 'Alabama'
         2 = 'Alaska'
         4 = 'Arizona'
         5 = 'Arkansas'
         6 = 'California'
         8 = 'Colorado'
         9 = 'Connecticut'
        10 = 'Delaware'
        11 = 'District of Columbia'
        12 = 'Florida'
        13 = 'Georgia'
        15 = 'Hawaii'
        16 = 'Idaho'
        17 = 'Illinois'
        18 = 'Indiana'
        19 = 'Iowa'
        20 = 'Kansas'
        21 = 'Kentucky'
        22 = 'Louisiana'
        23 = 'Maine'
        24 = 'Maryland'
        25 = 'Massachusetts'
        26 = 'Michigan'
        27 = 'Minnesota'
        28 = 'Mississippi'
        29 = 'Missouri'
        30 = 'Montana'
        31 = 'Nebraska'
        32 = 'Nevada'
        33 = 'New Hampshire'
        34 = 'New Jersey'
        35 = 'New Mexico	'
        36 = 'New York'
        37 = 'North Carolina'
        38 = 'North Dakota'
        39 = 'Ohio'
        40 = 'Oklahoma'
        41 = 'Oregon'
        42 = 'Pennsylvania'
        44 = 'Rhode Island'
        45 = 'South Carolina'
        46 = 'South Dakota'
        47 = 'Tennessee'
        48 = 'Texas'
        49 = 'Utah'
        50 = 'Vermont'
        51 = 'Virginia'
        53 = 'Washington'
        54 = 'West Virginia'
        55 = 'Wisconsin'
        56 = 'Wyoming'
        99 = 'DK; NA; refused'
         0 = 'Inap.:  not receiving public assistance in 1999 (ER33623A=0); not in FU in 1999.'
   ;
   VALUE ER33623CF
         1 = 'Received TANF assistance'
         9 = 'DK; NA; refused'
         0 = 'INAP.: received no public assistance in 1999 (ER33623A = 0), or received another type of assistance; was not in FU in 1999.'
   ;
   VALUE ER33623DF
         1 = 'Received ADC assistance'
         9 = 'DK; NA; refused'
         0 = 'INAP.: received no public assistance in 1999 (ER33623A = 0), or received another type of assistance; was not in FU in 1999.'
   ;
   VALUE ER33623EF
         1 = 'Received General Assistance'
         9 = 'DK; NA; refused'
         0 = 'INAP.: received no public assistance in 1999 (ER33623A = 0), or received another type of assistance; was not in FU in 1999.'
   ;
   VALUE ER33623FF
         1 = 'Received Emergency Assistance'
         9 = 'DK; NA; refused'
         0 = 'INAP.: received no public assistance in 1999 (ER33623A = 0), or received another type of assistance; was not in FU in 1999.'
   ;
   VALUE ER33623GF
         1 = 'Received Cuban/Haitian Refugee Assistance'
         9 = 'DK; NA; refused'
         0 = 'INAP.: received no public assistance in 1999 (ER33623A = 0), or received another type of assistance; was not in FU in 1999.'
   ;
   VALUE ER33623HF
         1 = 'Received Indian Assistance'
         9 = 'DK; NA; refused'
         0 = 'INAP.: received no public assistance in 1999 (ER33623A = 0), or received another type of assistance; was not in FU in 1999.'
   ;
   VALUE ER33623IF
         1 = 'Received Other Assistance'
         9 = 'DK; NA; refused'
         0 = 'INAP.: received no public assistance in 1999 (ER33623A = 0), or received another type of assistance; was not in FU in 1999.'
   ;
   VALUE ER33623XF
    1 - 12 = 'Actual number of months in which public assistance was received in 1999'
        99 = 'DK; NA; refused'
         0 = 'Inap.: did not receive public assistance in 1997 (ER33623A=0); was not in FU in 1999; this individual''s portion of public assistance is included in a lump sum attached to the parents or guardians indi'
             'vidual data'
   ;
   VALUE ER33624F
         1 = 'This individual received SSI in 1999'
         0 = 'Inap.:  did not receive SSI; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2001 or mover-out nonresponse by 1999 (ER33601=0); born'
             'or moved in after the 2001 interview (ER33601>0 and ER33602=0); in an institution in both 1999 and 2001 (ER33602=51-59 and ER33608=0); moved in after or moved out before 1999 (ER33602=1-20 and ER33610'
             '=2000-2001 or ER33602=51-89 and ER33608=8)'
   ;
   VALUE ER33625F
         1 = 'This individual received child support in 1999'
         0 = 'Inap.:  did not receive child support; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2001 or mover-out nonresponse by 1999 (ER33601'
             '=0); born or moved in after the 2001 interview (ER33601>0 and ER33602=0); in an institution in both 1999 and 2001 (ER33602=51-59 and ER33608=0); moved in after or moved out before 1999 (ER33602=1-20 a'
             'nd ER33610=2000-2001 or ER33602=51-89 and ER33608=8)'
   ;
   VALUE ER33626F
         1 = 'This individual received help from relatives in 1999'
         0 = 'Inap.:  did not receive help from relatives; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2001 or mover-out nonresponse by 1999 (E'
             'R33601=0); born or moved in after the 2001 interview (ER33601>0 and ER33602=0); in an institution in both 1999 and 2001 (ER33602=51-59 and ER33608=0); moved in after or moved out before 1999 (ER33602='
             '1-20 and ER33610=2000-2001 or ER33602=51-89 and ER33608=8)'
   ;
   VALUE ER33627F
         1 = 'This individual received other help in 1999'
         0 = 'Inap.:  did not receive other help; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2001 or mover-out nonresponse by 1999 (ER33601=0)'
             '; born or moved in after the 2001 interview (ER33601>0 and ER33602=0); in an institution in both 1999 and 2001 (ER33602=51-59 and ER33608=0); moved in after or moved out before 1999 (ER33602=1-20 and'
             'ER33610=2000-2001 or ER33602=51-89 and ER33608=8)'
   ;
   VALUE ER33627BF
         1 = 'Hour'
         2 = 'Day'
         3 = 'Week'
         4 = 'Two weeks'
         5 = 'Month'
         6 = 'Year'
         9 = 'DK; NA; refused'
         0 = 'Inap.:  individual did not work in 1999; was not in FU in 1999; under age 18 in 2001'
   ;
   VALUE ER33627CF
         0 = 'Inap.:  individual did not work in 1999; was not in FU in 1999; under age 18 in 2001'
    1 - 52 = 'Actual number of weeks worked in 1999'
        99 = 'DK; NA; refused'
   ;
   VALUE ER33627PF
    1 - 12 = 'Actual number of months in which earnings were received in 1999'
        99 = 'NA; DK'
         0 = 'Inap.:  individual did not work in 1999; was not in FU in 1999; under age 18 in 2001'
   ;
   VALUE ER33628F
         1 = 'This individual stopped receiving benefits since January 1999'
         0 = 'Inap.:  did not stop receiving benefits; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2001 or mover-out nonresponse by 1999 (ER336'
             '01=0); born or moved in after the 2001 interview (ER33601>0 and ER33602=0); in an institution in both 1999 and 2001 (ER33602=51-59 and ER33608=0); moved in after or moved out before 1999 (ER33602=1-20'
             ' and ER33610=2000-2001 or ER33602=51-89 and ER33608=8)'
   ;
   VALUE ER33628MF
         0 = 'Inap.:  was not unemployed in 1999; was not in FU in 1999; under age 18 in 2001'
    1 - 12 = 'Actual number of months in which this individual was unemployed and looking for work in 1999'
        99 = 'DK; NA; refused'
   ;
   VALUE ER33629F
         1 = 'This individual stopped receiving food stamps since January 1999'
         0 = 'Inap.:  did not stop receiving food stamps; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2001 or mover-out nonresponse by 1999 (ER'
             '33601=0); born or moved in after the 2001 interview (ER33601>0 and ER33602=0); in an institution in both 1999 and 2001 (ER33602=51-59 and ER33608=0); moved in after or moved out before 1999 (ER33602=1'
             '-20 and ER33610=2000-2001 or ER33602=51-89 and ER33608=8)'
   ;
   VALUE ER33633F
         1 = 'This individual was eligible to be followed in 2001'
         5 = 'This individual was not eligible to be followed in 2001'
         0 = 'Inap.:  main family or mover-out nonresponse in 1999 and was not selected for recontact in 2001; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); born or moved i'
             'n after the 2001 interview (ER33601>0 and ER33602=0)'
   ;
   VALUE ER33635F
         1 = 'This individual was eligible to be followed at the time of main family nonresponse and had been in the FU in 1999.'
         3 = 'This individual, ineligible to be followed, had been in the 1999 FU, and this FU became nonresponse in 2001.'
         4 = 'This individual, eligible to be followed, had been in an institution in 1999, but his or her family became nonresponse in 2001.'
         5 = 'This individual, eligible to be followed and linked to a 2001 response family, was in an institution at the time of the 2001 interview.'
         6 = 'This individual, eligible to be followed, moved out or died between the 1999 and 2001 interviews.'
         8 = 'This individual, ineligible to be followed, moved out or died between the 1999 and 2001 interviews.'
         9 = 'This individual had not been born or moved in by the time of the 2001 interview; individual from Immigrant 17 sample (ER30001=4001-4462)'
        10 = 'This individual had become nonresponse by the time of the 1999 interview.'
        21 = 'Main family recontact: this person was selected for recontact in 2001, but the family was not successfully interviewed.'
        26 = 'Splitoff recontact: this sample individual moved out of a 2001 recontact main family but was not successfully interviewed.'
        40 = 'Individual connected with the Latino sample (ER30001=7001-9308); this sample was dropped beginning in 1996.  Individual dropped from the Census (SEO) sample due to budgetary constraints; this group wa'
             's dropped beginning in 1997.'
        99 = 'NA; DK'
         0 = 'Inap.:  this individual was in a panel family in 2001 (ER33602=1-20).'
   ;
   VALUE ER33636F
         1 = 'Wave refusal by all eligible/available FU members.'
         2 = 'No one at home for contact during the interviewing period.'
         3 = 'Respondent absent; some FU member contacted, but not the appropriate respondent.'
         4 = 'Lost; unable to locate any member of the FU at all.'
         5 = 'FU is located too far away for interviewer contact.'
        10 = 'Panel refusal by all all eligible/available FU members.  These individuals will never be asked to participate in the study again, regardless of recontact efforts.'
        11 = 'This individual was in the armed forces.'
        12 = 'This individual was in an educational institution.'
        13 = 'This individual was in a health care facility'
        14 = 'This individual was in jail or prison'
        19 = 'This individual was in some other type of institution, for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        21 = 'This individual was not eligible to be followed, and the Head or the Wife, whichever is the sample member, became main family nonresponse because he/she was institutionalized by joining the armed forc'
             'es.'
        22 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by entering an educational institution.'
        23 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized by entering a health care facility'
             '.'
        24 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized through imprisonment.'
        29 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by some means other than the above; for examp'
             'le, he/she may have entered a religious order. Cases in which the type of institution is unknown are included here, also.'
        31 = 'This individual was unable to cooperate through disability.'
        32 = 'This individual was not eligible to be followed, and the Head or Wife, whichever is sample, was unable to cooperate through disability.'
        41 = 'This individual died between the 1999 and 2001 interviews;  this individual died after becoming nonresponse for some other reason before the 1999 interview.'
        42 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is sample, died.'
        45 = 'This individual was a sample member but has been adopted by unrelated nonsample persons and therefore has become nonsample.'
        51 = 'This individual, although followed for interview, was discovered to be nonsample: office error.'
        52 = 'This individual should have been followed but was not: office error.'
        53 = 'This individual was mistakenly included in two or more response families at once; this record is the duplicate, or erroneous, one.'
        54 = 'Listing error: this individual never existed or was not really living in the FU.'
        56 = 'This individual became a followable non-sample parent (had baby) in this wave.  Because the PSID predetermines followability before entering the field each wave, he/she was not followed.  However, beg'
             'inning in the 1999 wave, he/she is eligible for recontact efforts in the next wave.'
        57 = 'Insufficient information that would permit recontact; no name or identifying information available'
        58 = 'Due to budgetary and/or time constraints, PSID staff decided not to take all of the usual steps to try to locate and/or persuade this FU.'
        59 = 'Limited number of contacts attempted; miscellaneous office error (does not include codes 1-54 above or codes 91-99 below)'
        60 = 'This nonsample parent of a sample child is no longer followable and became nonresponse because either the child is now aged 25 or is nonresponse and was not selected for recontact in the next wave.'
        61 = 'This individual was not eligible to be followed and was associated with a family containing a person erroneously designated as followable; the erroneous person''s code is 51, 53, 54, or 60.'
        80 = 'Individual connected with the Latino sample (ER30001=7001-9308); this sample was dropped beginning in 1996.  Individual dropped from the Census (SEO) sample due to budgetary constraints; this group wa'
             's dropped beginning in 1997.'
        91 = 'This individual moved out of the 2001 main family and was eligible to be followed, but the reason for nonresponse is NA.'
        92 = 'Individual moved out of the 2001 main family and was not eligible to be followed, including the nonsample elderly'
        93 = 'All followable members of this FU united with other panel FUs; this individual was not eligible to be followed and therefore became nonresponse.'
        97 = 'This individual had not been born or moved in by the time of the 2001 interview (ER33601>0 and ER33602=0); individual from Immigrant 17 sample (ER30001=4001-4462)'
        98 = 'This individual became main family or mover-out nonresponse by 1999 and was not selected for recontact in 2001 (ER33501=0 and ER33601=0 and ER33633=0 or ER33501>0 and ER33502=71-89 and ER33601=0 and E'
             'R33633=0)'
        99 = 'NA; DK'
         0 = 'Inap.:  this individual was in a panel family in 2001 (ER33602=1-20)'
   ;
   VALUE ER33638F
         1 = 'Interview with sample child'
         2 = 'Interview with ineligible sample individual (e.g., sample person who was later found to be nonsample)'
         3 = 'Refused'
         4 = 'Lost'
         5 = 'Incapacitated; permanent condition'
         6 = 'Deceased'
         9 = 'Language barrier with primary caregiver'
        20 = 'Study ended before interview could be completed'
        30 = 'Lives on military base'
        31 = 'Lives outside of the United States'
        32 = 'No longer residing with a primary caregiver (established own household)'
        33 = 'Lives away at college'
        34 = 'Incarcerated or in a detention home/center'
        70 = 'Eligible child randomly dropped because two others in the family unit were also eligible (respondent burden)'
        72 = 'Discovered to be nonsample since 1997 PSID interview'
        95 = 'Office error--eligible child who should have been interviewed'
         0 = 'Inap.:  from  Latino sample (ER30001=7001-9308); no valid interview for 1997 CDS (ER33420 NE 1); born or moved in after the 2001 interview (ER33601>0 and ER33602=0)'
   ;
   VALUE ER33702F
    1 - 20 = 'Individuals in the family at the time of the 2003 interview'
   51 - 59 = 'Individuals in institutions at the time of the 2003 interview'
   71 - 80 = 'Individuals who moved out of the FU or out of institutions and established their own households between the 2001 and 2003 interviews'
   81 - 89 = 'Individuals who were living in 2001 but died by the time of the 2003 interview'
         0 = 'Inap.:  born or moved in after the 2003 interview; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2003 or mover-out nonresponse by 2'
             '001 (ER33701=0)'
   ;
   VALUE ER33703F
        10 = 'Head in 2003; 2001 Head who was mover-out nonresponse by the time of the 2003 interview'
        20 = 'Legal Wife in 2003; 2001 Wife who was mover-out nonresponse by the time of the 2003 interview'
        22 = '"Wife"--female cohabitor who has lived with Head for 12 months or more; 2001 "Wife" who was mover-out nonresponse by the time of the 2003 interview'
        30 = 'Son or daughter of Head (includes adopted children but not stepchildren)'
        33 = 'Stepson or stepdaughter of Head (children of legal Wife (code 20) who are not children of Head)'
        35 = 'Son or daughter of "Wife" but not Head (includes only those children of mothers whose relationship to Head is 22 but who are not children of Head)'
        37 = 'Son-in-law or daughter-in-law of Head (includes stepchildren-in-law)'
        38 = 'Foster son or foster daughter, not legally adopted'
        40 = 'Brother or sister of Head (includes step and half sisters and brothers)'
        47 = 'Brother-in-law or sister-in-law of Head; i.e., brother or sister of legal Wife, or spouse of Head''s brother or sister.'
        48 = 'Brother or sister of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        50 = 'Father or mother of Head (includes stepparents)'
        57 = 'Father-in-law or mother-in-law of Head (includes parents of legal wives (code 20) only)'
        58 = 'Father or mother of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        60 = 'Grandson or granddaughter of Head (includes grandchildren of legal Wife (code 20); those of a cohabitor are coded 97)'
        65 = 'Great-grandson or great-granddaughter of Head (includes great-grandchildren of legal Wife (code 20); those of a cohabitor are coded 97)'
        66 = 'Grandfather or grandmother of Head (includes stepgrandparents)'
        67 = 'Grandfather or grandmother of legal Wife (code 20)'
        68 = 'Great-grandfather or great-grandmother of Head'
        69 = 'Great-grandfather or great-grandmother of legal Wife (code 20)'
        70 = 'Nephew or niece of Head'
        71 = 'Nephew or niece of legal Wife (code 20)'
        72 = 'Uncle or Aunt of Head'
        73 = 'Uncle or Aunt of legal Wife (code 20)'
        74 = 'Cousin of Head'
        75 = 'Cousin of legal Wife (code 20)'
        83 = 'Children of first-year cohabitor but not of Head (the parent of this child is coded 88)'
        88 = 'First-year cohabitor of Head'
        90 = 'Legal husband of Head'
        95 = 'Other relative of Head'
        96 = 'Other relative of legal Wife (code 20)'
        97 = 'Other relative of cohabitor (the cohabitor is code 22 or 88)'
        98 = 'Other nonrelatives (includes homosexual partners, friends of children of the FU, etc.)'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2003 or mover-out nonresponse by 2001 (ER33701=0); born or moved in after the'
             ' 2003 interview (ER33701>0 and ER33702=0)'
   ;
   VALUE ER33707F
         1 = 'Spouse in couple numbered 1'
         2 = 'Spouse in couple numbered 2'
         3 = 'Spouse in couple numbered 3'
         4 = 'Spouse in couple numbered 4'
         0 = 'Inap.:  not married or permanently cohabiting; spouse was not in FU at the time of the 2003 interview; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main fami'
             'ly nonresponse by 2003 or mover-out nonresponse by 2001 (ER33701=0); born or moved in after the 2003 interview (ER33701>0 and ER33702=0)'
   ;
   VALUE ER33708F
         1 = 'Moved in or born between the 2001 and 2003 interviews; splitoff in 2003'
         2 = 'Appeared; moved in by the time the 2001 interivew was taken but not included in FU for 2001 (i.e., listing error)'
         5 = 'Moved out of FU or out of an institution between the 2001 and 2003 interviews and was not included in a 2003 panel FU'
         6 = 'Moved out of FU and into an institution between the 2001 and 2003 interviews'
         7 = 'Living in 2001 but died by the time of the 2003 interview'
         8 = 'Disappeared; moved out prior to the 2001 interview, but included in FU for 2001 (usually a listing error)'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); in main family in both 2001 and 2003 (ER33602=1-20 and ER33702=1-20); in an institution in both 2001 and'
             ' 2003 (ER33602=51-59 and ER33702=51-59); main family nonresponse by 2003 or mover-out nonresponse by 2001 (ER33701=0); born or moved in after the 2003 interview (ER33701>0 and ER33702=0)'
   ;
   VALUE ER33711F
         1 = 'This individual was respondent'
         5 = 'This individual was not respondent; includes institutionalized individuals and mover-out nonresponse from 2003 (ER33702=51-89)'
         9 = 'NA; DK'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2003 or mover-out nonresponse by 2001 (ER33701=0); born or moved in after the'
             ' 2003 interview (ER33701>0 and ER33702=0)'
   ;
   VALUE ER33712F
         1 = 'Working now'
         2 = 'Only temporarily laid off'
         3 = 'Looking for work, unemployed'
         4 = 'Retired'
         5 = 'Permanently disabled'
         6 = 'HouseWife; keeping house'
         7 = 'Student'
         8 = 'Other'
         9 = 'NA; DK'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2003 or mover-out nonresponse by 2001 (ER33701=0); born or moved in after the'
             ' 2003 interview (ER33701>0 and ER33702=0); mover-out nonresponse for 2003, only if deceased (ER33702=81-89); in an institution in both 2001 and 2003 (ER33702=51-59 and ER33708=0); not a person aged 16'
             ' or older (ER33704=001-015); associated with 2003 FU but moved out before 2002 (ER33708=5, 6, or 8 and ER33710<2002) or moved in in 2003 (ER33708=1 and ER33710=2003)'
   ;
   VALUE ER33715F
         1 = 'Full-time student'
         2 = 'Part-time student'
         5 = 'Not enrolled in school'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2003 or mover-out nonresponse by 2001 (ER33701=0); born or moved in after the'
             ' 2003 interview (ER33701>0 and ER33702=0); Head or Wife/"Wife" in 2003 (ER33702=1-20 and ER33703=10, 20 or 22); in an institution in both 2001 and 2003 (ER33702=51-59 and ER33708=0); under age 16, or'
             'age 50 or older (ER33704=001-015, 050-125 or 999); associated with 2003 FU but moved out before 2002 (ER33708=5, 6, or 8 and ER33710<2002) or moved in in 2003 (ER33708=1 and ER33710=2003); last attend'
             'ed school before 2002 (ER33714=1901-2001, 9997, 9998, or 9999)'
   ;
   VALUE ER33716F
    1 - 17 = 'Highest grade or year of school completed'
        98 = 'DK'
        99 = 'NA'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2003 or mover-out nonresponse by 2001 (ER33701=0); born or moved in after the'
             ' 2003 interview (ER33701>0 and ER33702=0); in an institution in both 2001 and 2003 (ER33702=51-59 and ER33708=0); associated with 2003 FU but actually moved out before 2002 (ER33708=5, 6, or 8 and ER3'
             '3710<2002) or moved in in 2003 (ER33708=1 and ER33710=2003); not a person aged 16 or older (ER33704=001-015, 999)'
   ;
   VALUE ER33717F
         1 = 'Yes, is in poor health'
         5 = 'No, is not in poor health'
         9 = 'NA'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2003 or mover-out nonresponse by 2001 (ER33701=0); in an institution or mover'
             '-out nonresponse in 2003 (ER33702=51-89); born or moved in after the 2003 interview (ER33701>0 and ER33702=0); current Head or Wife (ER33702=1-2 and ER33703=10, 20, 22)'
   ;
   VALUE ER33718F
         1 = 'Employer provided health insurance'
         2 = 'Private health insurance purchased directly'
         3 = 'Medicare'
         4 = 'Medi-Gap'
         5 = 'Medicaid/Medical Assistance/Medi-Cal'
         6 = 'Military health care/VA'
         7 = 'CHAMPUS/TRICARE/CHAMP-VA'
         8 = 'Indian Health Insurance'
         9 = 'State-sponsored health plan'
        10 = 'Other government program'
        97 = 'Other'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  not covered by health care plan; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2003 or mover-out nonresponse by 2001 (ER337'
             '01=0); born or moved in after the 2003 interview (ER33701>0 and ER33702=0); moved into FU in 2003 (ER33702=1-20 and ER33710=2003); moved out before 2001 (ER33702=71-89 and ER33710>0 and ER33710<2001)'
   ;
   VALUE ER33719F
         1 = 'Employer provided health insurance'
         2 = 'Private health insurance purchased directly'
         3 = 'Medicare'
         4 = 'Medi-Gap'
         5 = 'Medicaid/Medical Assistance/Medi-Cal'
         6 = 'Military health care/VA'
         7 = 'CHAMPUS/TRICARE/CHAMP-VA'
         8 = 'Indian Health Insurance'
         9 = 'State-sponsored health plan'
        10 = 'Other government program'
        97 = 'Other'
         0 = 'Inap.:  no second mention; not covered by health care plan (ER33718=0); from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2003 or mover'
             '-out nonresponse by 2001 (ER33701=0); born or moved in after the 2003 interview (ER33701>0 and ER33702=0); moved into FU in 2003 (ER33702=1-20 and ER33710=2003); moved out before 2001 (ER33702=71-89 a'
             'nd ER33710>0 and ER33710<2001); NA, DK to first mention (ER33718=98 or 99)'
   ;
   VALUE ER33720F
         1 = 'Employer provided health insurance'
         2 = 'Private health insurance purchased directly'
         3 = 'Medicare'
         4 = 'Medi-Gap'
         5 = 'Medicaid/Medical Assistance/Medi-Cal'
         6 = 'Military health care/VA'
         7 = 'CHAMPUS/TRICARE/CHAMP-VA'
         8 = 'Indian Health Insurance'
         9 = 'State-sponsored health plan'
        10 = 'Other government program'
        97 = 'Other'
         0 = 'Inap.:  no third mention; not covered by health care plan (ER33718=0); from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2003 or mover-'
             'out nonresponse by 2001 (ER33701=0); born or moved in after the 2003 interview (ER33701>0 and ER33702=0); moved into FU in 2003 (ER33702=1-20 and ER33710=2003); moved out before 2001 (ER33702=71-89 an'
             'd ER33710>0 and ER33710<2001); NA, DK to first mention (ER33718=98 or 99)'
   ;
   VALUE ER33721F
         1 = 'Employer provided health insurance'
         2 = 'Private health insurance purchased directly'
         3 = 'Medicare'
         4 = 'Medi-Gap'
         5 = 'Medicaid/Medical Assistance/Medi-Cal'
         6 = 'Military health care/VA'
         7 = 'CHAMPUS/TRICARE/CHAMP-VA'
         8 = 'Indian Health Insurance'
         9 = 'State-sponsored health plan'
        10 = 'Other government program'
        97 = 'Other'
         0 = 'Inap.:  no fourth mention; not covered by health care plan (ER33718=0); from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2003 or mover'
             '-out nonresponse by 2001 (ER33701=0); born or moved in after the 2003 interview (ER33701>0 and ER33702=0); moved into FU in 2003 (ER33702=1-20 and ER33710=2003); moved out before 2001 (ER33702=71-89 a'
             'nd ER33710>0 and ER33710<2001); NA, DK to first mention (ER33718=98 or 99)'
   ;
   VALUE ER33722F
    1 - 12 = 'Actual number of months covered in 2001'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  not covered in 2001; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2003 or mover-out nonresponse by 2001 (ER33701=0); born'
             'or moved in after the 2003 interview (ER33701>0 and ER33702=0); moved into FU in 2003 (ER33702=1-20 and ER33710=2003); moved out before 2001 (ER33702=71-89 and ER33710>0 and ER33710<2001); not covered'
             ' by health care plan (ER33718=0)'
   ;
   VALUE ER33723F
    1 - 12 = 'Actual number of months covered in 2002'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  not covered in 2002; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2003 or mover-out nonresponse by 2001 (ER33701=0); born'
             'or moved in after the 2003 interview (ER33701>0 and ER33702=0); moved into FU in 2003 (ER33702=1-20 and ER33710=2003); moved out before 2001 (ER33702=71-89 and ER33710>0 and ER33710<2001); not covered'
             ' by health care plan (ER33718=0)'
   ;
   VALUE ER33724F
         1 = 'This individual received public assistance or state or local welfare in 2001'
         0 = 'Inap.:  did not receive public assistance or state or local welfare; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2003 or mover-ou'
             't nonresponse by 2001 (ER33701=0); born or moved in after the 2003 interview (ER33701>0 and ER33702=0); in an institution in both 2001 and 2003 (ER33702=51-59 and ER33708=0); moved in after or moved o'
             'ut before 2001 (ER33702=1-20 and ER33710=2002-2003 or ER33702=51-89 and ER33708=8)'
   ;
   VALUE ER33724AF
         1 = 'Alabama'
         2 = 'Alaska'
         4 = 'Arizona'
         5 = 'Arkansas'
         6 = 'California'
         8 = 'Colorado'
         9 = 'Connecticut'
        10 = 'Delaware'
        11 = 'District of Columbia'
        12 = 'Florida'
        13 = 'Georgia'
        15 = 'Hawaii'
        16 = 'Idaho'
        17 = 'Illinois'
        18 = 'Indiana'
        19 = 'Iowa'
        20 = 'Kansas'
        21 = 'Kentucky'
        22 = 'Louisiana'
        23 = 'Maine'
        24 = 'Maryland'
        25 = 'Massachusetts'
        26 = 'Michigan'
        27 = 'Minnesota'
        28 = 'Mississippi'
        29 = 'Missouri'
        30 = 'Montana'
        31 = 'Nebraska'
        32 = 'Nevada'
        33 = 'New Hampshire'
        34 = 'New Jersey'
        35 = 'New Mexico	'
        36 = 'New York'
        37 = 'North Carolina'
        38 = 'North Dakota'
        39 = 'Ohio'
        40 = 'Oklahoma'
        41 = 'Oregon'
        42 = 'Pennsylvania'
        44 = 'Rhode Island'
        45 = 'South Carolina'
        46 = 'South Dakota'
        47 = 'Tennessee'
        48 = 'Texas'
        49 = 'Utah'
        50 = 'Vermont'
        51 = 'Virginia'
        53 = 'Washington'
        54 = 'West Virginia'
        55 = 'Wisconsin'
        56 = 'Wyoming'
        99 = 'DK; NA; refused'
         0 = 'Inap.:  not receiving public assistance in 2001 (ER33724=0); not in FU in 2001.'
   ;
   VALUE ER33724BF
         1 = 'Received TANF assistance'
         0 = 'INAP.: received no public assistance in 2001 (ER33724 = 0), or received another type of assistance; was not in FU in 2001.'
   ;
   VALUE ER33724CF
         1 = 'Received ADC assistance'
         0 = 'INAP.: received no public assistance in 2001 (ER33724 = 0), or received another type of assistance; was not in FU in 2001.'
   ;
   VALUE ER33724DF
         1 = 'Received General Assistance'
         0 = 'INAP.: received no public assistance in 2001 (ER33724 = 0), or received another type of assistance; was not in FU in 2001.'
   ;
   VALUE ER33724EF
         1 = 'Received Emergency Assistance'
         0 = 'INAP.: received no public assistance in 2001 (ER33724 = 0), or received another type of assistance; was not in FU in 2001.'
   ;
   VALUE ER33724FF
         1 = 'Received Cuban/Haitian Refugee assistance'
         0 = 'INAP.: received no public assistance in 2001 (ER33724 = 0), or received another type of assistance; was not in FU in 2001.'
   ;
   VALUE ER33724GF
         1 = 'Received Indian Assistance'
         0 = 'INAP.: received no public assistance in 2001 (ER33724 = 0), or received another type of assistance; was not in FU in 2001.'
   ;
   VALUE ER33724HF
         1 = 'Received Other Assistance'
         0 = 'INAP.: received no public assistance in 2001 (ER33724 = 0), or received another type of assistance; was not in FU in 2001.'
   ;
   VALUE ER33724IF
         1 = 'This individual received Supplemental Security Income in 2001'
         0 = 'Inap.:  did not receive SSI; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2003 or mover-out nonresponse by 2001 (ER33701=0); born'
             'or moved in after the 2003 interview (ER33701>0 and ER33702=0); in an institution in both 2001 and 2003 (ER33702=51-59 and ER33708=0); moved in after or moved out before 2001 (ER33702=1-20 and ER33710'
             '=2002-2003 or ER33702=51-89 and ER33708=8)'
   ;
   VALUE ER33725F
         1 = 'This individual received child support in 2001'
         0 = 'Inap.:  did not receive child support; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2003 or mover-out nonresponse by 2001 (ER33701'
             '=0); born or moved in after the 2003 interview (ER33701>0 and ER33702=0); in an institution in both 2001 and 2003 (ER33702=51-59 and ER33708=0); moved in after or moved out before 2001 (ER33702=1-20 a'
             'nd ER33710=2002-2003 or ER33702=51-89 and ER33708=8)'
   ;
   VALUE ER33726F
         1 = 'This individual received help from relatives in 2001'
         0 = 'Inap.:  did not receive help from relatives; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2003 or mover-out nonresponse by 2001 (E'
             'R33701=0); born or moved in after the 2003 interview (ER33701>0 and ER33702=0); in an institution in both 2001 and 2003 (ER33702=51-59 and ER33708=0); moved in after or moved out before 2001 (ER33702='
             '1-20 and ER33710=2002-2003 or ER33702=51-89 and ER33708=8)'
   ;
   VALUE ER33727F
         1 = 'This individual received other help in 2001'
         0 = 'Inap.:  did not receive other help; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2003 or mover-out nonresponse by 2001 (ER33701=0)'
             '; born or moved in after the 2003 interview (ER33701>0 and ER33702=0); in an institution in both 2001 and 2003 (ER33702=51-59 and ER33708=0); moved in after or moved out before 2001 (ER33702=1-20 and'
             'ER33710=2002-2003 or ER33702=51-89 and ER33708=8)'
   ;
   VALUE ER33727BF
         1 = 'Hour'
         2 = 'Day'
         3 = 'Week'
         4 = 'Two weeks'
         5 = 'Month'
         6 = 'Year'
         9 = 'DK; NA; refused'
         0 = 'Inap.:  individual did not work in 2001; was not in FU in 2001; under age 18 in 2003'
   ;
   VALUE ER33727CF
    1 - 52 = 'Actual number of weeks worked in 2001'
        99 = 'DK; NA; refused'
         0 = 'Inap.:  individual did not work in 2001; was not in FU in 2001; under age 18 in 2003'
   ;
   VALUE ER33727PF
         0 = 'Inap.:  individual did not work in 2001; was not in FU in 2001; under age 18 in 2003'
    1 - 12 = 'Actual number of months in which earnings were received in 2001'
        99 = 'NA; DK'
   ;
   VALUE ER33728F
         1 = 'This individual stopped receiving benefits since January 2001'
         0 = 'Inap.:  did not stop receiving benefits; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2003 or mover-out nonresponse by 2001 (ER337'
             '01=0); born or moved in after the 2003 interview (ER33701>0 and ER33702=0); in an institution in both 2001 and 2003 (ER33702=51-59 and ER33708=0); moved in after or moved out before 2001 (ER33702=1-20'
             ' and ER33710=2002-2003 or ER33702=51-89 and ER33708=8)'
   ;
   VALUE ER33728MF
         0 = 'Inap.:  was not unemployed in 2001; was not in FU in 2001; under age 18 in 2003'
    1 - 12 = 'Actual number of months in which this individual was unemployed and looking for work in 2001'
        99 = 'DK; NA; refused'
   ;
   VALUE ER33729F
         1 = 'This individual stopped receiving food stamps since January 2001'
         0 = 'Inap.:  did not stop receiving food stamps; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2003 or mover-out nonresponse by 2001 (ER'
             '33701=0); born or moved in after the 2003 interview (ER33701>0 and ER33702=0); in an institution in both 2001 and 2003 (ER33702=51-59 and ER33708=0); moved in after or moved out before 2001 (ER33702=1'
             '-20 and ER33710=2002-2003 or ER33702=51-89 and ER33708=8)'
   ;
   VALUE ER33730F
         1 = 'This individual received free or reduced-cost meals for the elderly in 2002'
         5 = 'Wild code'
         0 = 'Inap.:  did not receive free or reduced cost meals for the elderly; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2003 or mover-out'
             ' nonresponse by 2001 (ER33701=0); born or moved in after the 2003 interview (ER33701>0 and ER33702=0); mover-out nonresponse for 2003, only if deceased (ER33702=81-89); in an institution in both 2001'
             'and 2003 (ER33702=51-59 and ER33708=0); not a person aged 61 or older (ER33704=001-060,999)'
   ;
   VALUE ER33731F
         1 = 'This individual received free or reduced-cost lunches at school in 2002'
         0 = 'Inap.:  did not receive free or reduced-cost lunches at school; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2003 or mover-out non'
             'response by 2001 (ER33701=0); born or moved in after the 2003 interview (ER33701>0 and ER33702=0); mover-out nonresponse for 2003, only if deceased (ER33702=81-89); in an institution in both 2001 and'
             '2003 (ER33702=51-59 and ER33708=0); not a person aged 6-19 (ER33704=001-005, 20-999)'
   ;
   VALUE ER33732F
         1 = 'This individual received free or reduced-cost breakfasts at school in 2002'
         0 = 'Inap.:  did not receive free or reduced-cost breakfasts at school; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2003 or mover-out'
             'nonresponse by 2001 (ER33701=0); born or moved in after the 2003 interview (ER33701>0 and ER33702=0); mover-out nonresponse for 2003, only if deceased (ER33702=81-89); in an institution in both 2001 a'
             'nd 2003 (ER33702=51-59 and ER33708=0); not a person aged 6-19 (ER33704=001-005, 20-999)'
   ;
   VALUE ER33736F
         1 = 'This individual was eligible to be followed in 2003'
         5 = 'This individual was not eligible to be followed in 2003'
         0 = 'Inap.:  main family or mover-out nonresponse in 2001 and was not selected for recontact in 2003; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); born or moved i'
             'n after the 2003 interview (ER33701>0 and ER33702=0)'
   ;
   VALUE ER33738F
         1 = 'This individual was eligible to be followed at the time of main family nonresponse and had been in the FU in 2001.'
         3 = 'This individual, ineligible to be followed, had been in the 2001 FU, and this FU became nonresponse in 2003.'
         4 = 'This individual, eligible to be followed, had been in an institution in 2001, but his or her family became nonresponse in 2003.'
         5 = 'This individual, eligible to be followed and linked to a 2003 response family, was in an institution at the time of the 2003 interview.'
         6 = 'This individual, eligible to be followed, moved out or died between the 2001 and 2003 interviews.'
         8 = 'This individual, ineligible to be followed, moved out or died between the 2001 and 2003 interviews.'
         9 = 'This individual had not been born or moved in by the time of the 2003 interview; individual from Immigrant 17 sample (ER30001=4001-4462)'
        10 = 'This individual had become nonresponse by the time of the 2001 interview.'
        21 = 'Main family recontact: this person was selected for recontact in 2003, but the family was not successfully interviewed.'
        26 = 'Splitoff recontact: this sample individual moved out of a 2003 recontact main family but was not successfully interviewed.'
        40 = 'Individual connected with the Latino sample (ER30001=7001-9308); this sample was dropped beginning in 1996.  Individual dropped from the Census (SEO) sample due to budgetary constraints; this group wa'
             's dropped beginning in 1997.'
        99 = 'NA; DK'
         0 = 'Inap.:  this individual was in a panel family in 2003 (ER33702=1-20).'
   ;
   VALUE ER33739F
         1 = 'Wave refusal by all eligible/available FU members.'
         2 = 'No one at home for contact during the interviewing period.'
         3 = 'Respondent absent; some FU member contacted, but not the appropriate respondent.'
         4 = 'Lost; unable to locate any member of the FU at all.'
         5 = 'FU is located too far away for interviewer contact.'
        10 = 'Panel refusal by all all eligible/available FU members.  These individuals will never be asked to participate in the study again, regardless of recontact efforts.'
        11 = 'This individual was in the armed forces.'
        12 = 'This individual was in an educational institution.'
        13 = 'This individual was in a health care facility'
        14 = 'This individual was in jail or prison'
        19 = 'This individual was in some other type of institution, for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        21 = 'This individual was not eligible to be followed, and the Head or the Wife, whichever is the sample member, became main family nonresponse because he/she was institutionalized by joining the armed forc'
             'es.'
        22 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by entering an educational institution.'
        23 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized by entering a health care facility'
             '.'
        24 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized through imprisonment.'
        29 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by some means other than the above; for examp'
             'le, he/she may have entered a religious order. Cases in which the type of institution is unknown are included here, also.'
        31 = 'This individual was unable to cooperate through disability.'
        32 = 'This individual was not eligible to be followed, and the Head or Wife, whichever is sample, was unable to cooperate through disability.'
        41 = 'This individual died between the 2001 and 2003 interviews; this individual died after becoming nonresponse for some other reason before the 2001 interview.'
        42 = 'This individual was not eligible to be followed and became main family nonresponse because the Head or Wife, whichever is sample, died.'
        45 = 'This individual was a sample member but has been adopted by unrelated nonsample persons and therefore has become nonsample.'
        51 = 'This individual, although followed for interview, was discovered to be nonsample: office error.'
        52 = 'This individual should have been followed but was not: office error.'
        53 = 'This individual was mistakenly included in two or more response families at once; this record is the duplicate, or erroneous, one.'
        54 = 'Listing error: this individual never existed or was not really living in the FU.'
        56 = 'This individual became a followable non-sample parent (had baby) in this wave.  Because the PSID predetermines followability before entering the field each wave, he/she was not followed.  However, beg'
             'inning in the 2001 wave, he/she is eligible for recontact efforts in the next wave.'
        57 = 'Insufficient information that would permit recontact; no name or identifying information available'
        58 = 'Due to budgetary and/or time constraints, PSID staff decided not to take all of the usual steps to try to locate and/or persuade this FU.'
        59 = 'Limited number of contacts attempted; miscellaneous office error (does not include codes 1-54 above or codes 91-99 below)'
        60 = 'This nonsample parent of a sample child is no longer followable and became nonresponse because either the child is now aged 25 or is nonresponse and was not selected for recontact in the next wave.'
        61 = 'This individual was not eligible to be followed and was associated with a family containing a person erroneously designated as followable; the erroneous person''s code is 45, 51, 53, 54, or 60.'
        80 = 'Individual connected with the Latino sample (ER30001=7001-9308); this sample was dropped beginning in 1996.  Individual dropped from the Census (SEO) sample due to budgetary constraints; this group wa'
             's dropped beginning in 1997.'
        91 = 'This individual moved out of the 2003 main family and was eligible to be followed, but the reason for nonresponse is NA.'
        92 = 'Individual moved out of the 2003 main family and was not eligible to be followed, including the nonsample elderly'
        93 = 'All followable members of this FU united with other panel FUs; this individual was not eligible to be followed and therefore became nonresponse.'
        97 = 'This individual had not been born or moved in by the time of the 2003 interview (ER33701>0 and ER33702=0);  individual from Immigrant 17 sample (ER30001=4001-4462)'
        98 = 'This individual became main family or mover-out nonresponse by 2001 and was not selected for recontact in 2003 (ER33601=0 and ER33701=0 and ER33736=0 or ER33601>0 and ER33602=71-89 and ER33701=0 and E'
             'R33736=0)'
        99 = 'NA; DK'
         0 = 'Inap.:  this individual was in a panel family in 2003 (ER33702=1-20)'
   ;
   VALUE ER33741F
         1 = 'This individual made most of the decisions'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.:  this person did not make most of the decisions; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2003 or mover-out nonresponse'
             ' by 2001 (ER33701=0); in an institution in both 2001 and 2003 (ER33702=51-59 and ER33697=0); born or moved in after the 2003 interview (ER33701>0 and ER33702=0)'
   ;
   VALUE ER33802F
    1 - 20 = 'Individuals in the family at the time of the 2005 interview'
   51 - 59 = 'Individuals in institutions at the time of the 2005 interview'
   71 - 80 = 'Individuals who moved out of the FU or out of institutions and established their own households between the 2003 and 2005 interviews'
   81 - 89 = 'Individuals who were living in 2003 but died by the time of the 2005 interview'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2005 or mover-out nonresponse by 2003 (ER33801=0)'
   ;
   VALUE ER33803F
        10 = 'Head in 2005; 2003 Head who was mover-out nonresponse by the time of the 2005 interview'
        20 = 'Legal Wife in 2005; 2003 Wife who was mover-out nonresponse by the time of the 2005 interview'
        22 = '"Wife"--female cohabitor who has lived with Head for 12 months or more; 2003 "Wife" who was mover-out nonresponse by the time of the 2005 interview'
        30 = 'Son or daughter of Head (includes adopted children but not stepchildren)'
        33 = 'Stepson or stepdaughter of Head (children of legal Wife [code 20] who are not children of Head)'
        35 = 'Son or daughter of "Wife" but not Head (includes only those children of mothers whose relationship to Head is 22 but who are not children of Head)'
        37 = 'Son-in-law or daughter-in-law of Head (includes stepchildren-in-law)'
        38 = 'Foster son or foster daughter, not legally adopted'
        40 = 'Brother or sister of Head (includes step and half sisters and brothers)'
        47 = 'Brother-in-law or sister-in-law of Head; i.e., brother or sister of legal Wife, or spouse of Head''s brother or sister'
        48 = 'Brother or sister of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        50 = 'Father or mother of Head (includes stepparents)'
        57 = 'Father-in-law or mother-in-law of Head (includes parents of legal wives [code 20] only)'
        58 = 'Father or mother of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        60 = 'Grandson or granddaughter of Head (includes grandchildren of legal Wife [code 20] only; those of a cohabitor are coded 97)'
        65 = 'Great-grandson or great-granddaughter of Head (includes great-grandchildren of legal Wife [code 20]; those of a cohabitor are coded 97)'
        66 = 'Grandfather or grandmother of Head (includes stepgrandparents)'
        67 = 'Grandfather or grandmother of legal Wife (code 20)'
        68 = 'Great-grandfather or great-grandmother of Head'
        69 = 'Great-grandfather or great-grandmother of legal Wife (code 20)'
        70 = 'Nephew or niece of Head'
        71 = 'Nephew or niece of legal Wife (code 20)'
        72 = 'Uncle or Aunt of Head'
        73 = 'Uncle or Aunt of legal Wife (code 20)'
        74 = 'Cousin of Head'
        75 = 'Cousin of legal Wife (code 20)'
        83 = 'Children of first-year cohabitor but not of Head (the parent of this child is coded 88)'
        88 = 'First-year cohabitor of Head'
        90 = 'Legal husband of Head'
        95 = 'Other relative of Head'
        96 = 'Other relative of legal Wife (code 20)'
        97 = 'Other relative of cohabitor (the cohabitor is code 22 or 88)'
        98 = 'Other nonrelatives (includes homosexual partners, friends of children of the FU, etc.)'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2005 or mover-out nonresponse by 2003 (ER33801=0)'
   ;
   VALUE ER33807F
         1 = 'Spouse in couple numbered 1'
         2 = 'Spouse in couple numbered 2'
         3 = 'Spouse in couple numbered 3'
         4 = 'Spouse in couple numbered 4'
         0 = 'Inap.:  not married or permanently cohabiting; spouse was not in FU at the time of the 2005 interview; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main fami'
             'ly nonresponse by 2005 or mover-out nonresponse by 2003 (ER33801=0)'
   ;
   VALUE ER33808F
         1 = 'Moved in or born between the 2003 and 2005 interviews; splitoff in 2005'
         2 = 'Appeared; moved in by the time the 2003 interview was taken but not included in FU for 2003 (i.e., listing error)'
         5 = 'Moved out of FU or out of an institution between the 2003 and 2005 interviews and was not included in a 2005 panel FU'
         6 = 'Moved out of FU and into an institution between the 2003 and 2005 interviews'
         7 = 'Living in 2003 but died by the time of the 2005 interview'
         8 = 'Disappeared; moved out prior to the 2003 interview, but included in FU for 2003 (usually a listing error)'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); in main family in both 2003 and 2005 (ER33702=1-20 and ER33802=1-20); in an institution in both 2003 and'
             ' 2005 (ER33702=51-59 and ER33802=51-59); main family nonresponse by 2005 or mover-out nonresponse by 2003 (ER33801=0); born or moved in after the 2005 interview (ER33801>0 and ER33802=0)'
   ;
   VALUE ER33811F
         1 = 'This individual was respondent'
         5 = 'This individual was not respondent; includes institutionalized individuals and mover-out nonresponse from 2005 (ER33802=51-89)'
         9 = 'NA; DK'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2005 or mover-out nonresponse by 2003 (ER33801=0)'
   ;
   VALUE ER33812F
         1 = 'Head who received TANF'
         2 = 'Wife/"Wife" who received TANF'
         3 = 'Other Family Unit Member who received TANF'
         0 = 'Inap.:  this individual did not receive TANF; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2005 or mover-out nonresponse by 2003 ('
             'ER33801=0); in an institution in both 2003 and 2005 (ER33802=51-59 and ER33808=0)'
   ;
   VALUE ER33813F
         1 = 'Working now'
         2 = 'Only temporarily laid off'
         3 = 'Looking for work, unemployed'
         4 = 'Retired'
         5 = 'Permanently disabled'
         6 = 'HouseWife; keeping house'
         7 = 'Student'
         8 = 'Other'
         9 = 'NA; DK'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2005 or mover-out nonresponse by 2003 (ER33801=0); mover-out nonresponse for'
             '2005, only if deceased (ER33802=81-89); in an institution in both 2003 and 2005 (ER33802=51-59 and ER33808=0); not a person aged 16 or older (ER33804=001-015); associated with 2005 FU but moved out be'
             'fore 2004 (ER33808=5, 6, or 8 and ER33810<2004) or moved in in 2005 (ER33808=1 and ER33810=2005)'
   ;
   VALUE ER33816F
         1 = 'Full-time student'
         2 = 'Part-time student'
         5 = 'Not enrolled in school'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2005 or mover-out nonresponse by 2003 (ER33801=0); Head or Wife/"Wife" in 200'
             '5 (ER33802=1-20 and ER33803=10, 20 or 22); in an institution in both 2003 and 2005 (ER33802=51-59 and ER33808=0); under age 16 or age 50 or older (ER33804=001-015, 050-125 or 999); associated with 200'
             '5 FU but moved out before 2004 (ER33808=5, 6, or 8 and ER33810<2004) or moved in in 2005 (ER33808=1 and ER33810=2005); last attended school before 2004 (ER33815=1901-2003, 9997, 9998, or 9999)'
   ;
   VALUE ER33817F
    1 - 17 = 'Highest grade or year of school completed'
        98 = 'DK'
        99 = 'NA'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2005 or mover-out nonresponse by 2003 (ER33801=0); in an institution in both'
             '2003 and 2005 (ER33802=51-59 and ER33808=0); not a person aged 16 or older (ER33804=001-015, 999); associated with 2005 FU but actually moved out before 2004 (ER33808=5, 6, or 8 and ER33810<2004) or m'
             'oved in in 2005 (ER33808=1 and ER33810=2005)'
   ;
   VALUE ER33818F
         1 = 'Yes, is in poor health'
         5 = 'No, is not in poor health'
         9 = 'NA'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2005 or mover-out nonresponse by 2003 (ER33801=0); in an institution or mover'
             '-out nonresponse in 2005 (ER33802=51-89); current Head or Wife (ER33802=1-2 and ER33803=10, 20, 22)'
   ;
   VALUE ER33819F
         1 = 'Employer provided health insurance'
         2 = 'Private health insurance purchased directly'
         3 = 'Medicare'
         4 = 'Medi-Gap/Supplemental'
         5 = 'Medicaid/Medical Assistance/[STATE PROGRAM]'
         6 = 'Military health care/TRICARE (Active)'
         7 = 'CHAMPUS/TRICARE/CHAMP-VA (Dependents, Veterans)'
         8 = 'Indian Health Insurance'
         9 = 'Other state-sponsored plan (not Medicaid)'
        10 = 'Other government program'
        97 = 'Other'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  not covered by health care plan; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2005 or mover-out nonresponse by 2003 (ER338'
             '01=0); moved into FU in 2005 (ER33802=1-20 and ER33810=2005); moved out before 2003 (ER33802=71-89 and ER33810>0 and ER33810<2003)'
   ;
   VALUE ER33820F
         1 = 'Employer provided health insurance'
         2 = 'Private health insurance purchased directly'
         3 = 'Medicare'
         4 = 'Medi-Gap/Supplemental'
         5 = 'Medicaid/Medical Assistance/[STATE PROGRAM]'
         6 = 'Military health care/TRICARE (Active)'
         7 = 'CHAMPUS/TRICARE/CHAMP-VA (Dependents, Veterans)'
         8 = 'Indian Health Insurance'
         9 = 'Other state-sponsored plan (not Medicaid)'
        10 = 'Other government program'
        97 = 'Other'
         0 = 'Inap.:  no second mention; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2005 or mover-out nonresponse by 2003 (ER33801=0); moved i'
             'nto FU in 2005 (ER33802=1-20 and ER33810=2005); moved out before 2003 (ER33802=71-89 and ER33810>0 and ER33810<2003); not covered by health care plan (ER33819=0); DK, NA, or RF to first mention (ER338'
             '19=98 or 99)'
   ;
   VALUE ER33821F
         1 = 'Employer provided health insurance'
         2 = 'Private health insurance purchased directly'
         3 = 'Medicare'
         4 = 'Medi-Gap/Supplemental'
         5 = 'Medicaid/Medical Assistance/[STATE PROGRAM]'
         6 = 'Military health care/TRICARE (Active)'
         7 = 'CHAMPUS/TRICARE/CHAMP-VA (Dependents, Veterans)'
         8 = 'Indian Health Insurance'
         9 = 'Other state-sponsored plan (not Medicaid)'
        10 = 'Other government program'
        97 = 'Other'
         0 = 'Inap.:  no third mention; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2005 or mover-out nonresponse by 2003 (ER33801=0); moved in'
             'to FU in 2005 (ER33802=1-20 and ER33810=2005); moved out before 2003 (ER33802=71-89 and ER33810>0 and ER33810<2003); not covered by health care plan (ER33819=0); DK, NA, or RF to first mention (ER3381'
             '9=98 or 99)'
   ;
   VALUE ER33822F
         1 = 'Employer provided health insurance'
         2 = 'Private health insurance purchased directly'
         3 = 'Medicare'
         4 = 'Medi-Gap/Supplemental'
         5 = 'Medicaid/Medical Assistance/[STATE PROGRAM]'
         6 = 'Military health care/TRICARE (Active)'
         7 = 'CHAMPUS/TRICARE/CHAMP-VA (Dependents, Veterans)'
         8 = 'Indian Health Insurance'
         9 = 'Other state-sponsored plan (not Medicaid)'
        10 = 'Other government program'
        97 = 'Other'
         0 = 'Inap.:  no fourth mention; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2005 or mover-out nonresponse by 2003 (ER33801=0); moved i'
             'nto FU in 2005 (ER33802=1-20 and ER33810=2005); moved out before 2003 (ER33802=71-89 and ER33810>0 and ER33810<2003); not covered by health care plan (ER33819=0); DK, NA, or RF to first mention (ER338'
             '19=98 or 99)'
   ;
   VALUE ER33823F
         1 = 'Yes, it is the state health insurance plan for uninsured children'
         5 = 'No, it is not the state health insurance plan for uninsured children'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2005 or mover-out nonresponse by 2003 (ER33801=0); moved into FU in 2005 (ER3'
             '3802=1-20 and ER33810=2005); moved out before 2003 (ER33802=71-89 and ER33810>0 and ER33810<2003); not covered by health care plan (ER33819=0); not covered by other health care plan and not less than'
             '18 years old (ER33819=1-8 and ER33820 NE 9-10,97 and ER33821 NE 9-10 or 97 and ER33822 NE 9-10 or 97 and ER33804>17)'
   ;
   VALUE ER33824F
    1 - 12 = 'Actual number of months covered in 2003'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  not covered in 2003; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2005 or mover-out nonresponse by 2003 (ER33801=0); moved'
             ' into FU in 2005 (ER33802=1-20 and ER33810=2005); moved out before 2003 (ER33802=71-89 and ER33810>0 and ER33810<2003); not covered by health care plan (ER33819=0)'
   ;
   VALUE ER33825F
    1 - 12 = 'Actual number of months covered in 2004'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  not covered in 2004; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2005 or mover-out nonresponse by 2003 (ER33801=0); moved'
             ' into FU in 2005 (ER33802=1-20 and ER33810=2005); moved out before 2003 (ER33802=71-89 and ER33810>0 and ER33810<2003); not covered by health care plan (ER33819=0)'
   ;
   VALUE ER33826F
         1 = 'This individual is a 2005 Head, Wife, or "Wife" who was covered by Medicare, was the respondent, and provided a useable Medicare number.'
         2 = 'This individual is a 2005 Head, Wife, or "Wife" who was covered by Medicare, was the respondent, and provided a Medicare number but the it was not useable (e.g., missing digits).'
         5 = 'This individual is a 2005 Head, Wife, or "Wife" who was covered by Medicare, was the respondent, declined to give his/her Medicare number (H62a=5), did not know/refused whether the number was a Medica'
             're Claim or Railroad Retirement Board number, or did not know the number at H62c/H62e-f.'
         9 = 'This individual is a 2005 Head, Wife, or "Wife" who was covered by Medicare, was the respondent but whether a Medicare number could be provided was NA or DK (H62a=8 or 9).'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308)); main family nonresponse by 2005 or mover-out nonresponse by 2003 (ER33801=0); moved out before 2003 (ER33802=71-89 and ER33810>0 and ER33810<2003); not'
             ' Head or Wife/"Wife" in 2005 (ER33803>22 or ER33802>50); not the respondent (ER33811=5); not covered by health care plan (ER33819=0); not covered by Medicare (neither ER33819, ER33820, ER33821, nor ER'
             '33822=3)'
   ;
   VALUE ER33826BF
         1 = 'Hour'
         2 = 'Day'
         3 = 'Week'
         4 = 'Two weeks'
         5 = 'Month'
         6 = 'Year'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.:  individual did not work in 2003; was not in FU in 2003; under age 18 in 2005'
   ;
   VALUE ER33827F
         1 = 'This individual received asset income in 2003'
         0 = 'Inap.:  did not receive asset income in 2003; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2005 or mover-out nonresponse by 2003 ('
             'ER38701=0); in an institution in both 2003 and 2005 (ER33802=51-59 and ER33808=0); moved in after or moved out before 2003 (ER33802=1-20 and ER33810=2004-2005 or ER33802=51-89 and ER33808=8)'
   ;
   VALUE ER33827FF
         5 = 'Month'
         6 = 'Year'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'INAP.: received no asset income in 2003 (ER33827 = 0); was not in FU in 2003; under age 18 in 2005'
   ;
   VALUE ER33827SF
    1 - 52 = 'Actual number of weeks worked in 2003'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  individual did not work in 2003; was not in FU in 2003; under age 18 in 2005; individual was HD or WF in FU in 2005'
   ;
   VALUE ER33828F
         1 = 'This individual received social security in 2003'
         0 = 'Inap.:  did not receive social security in 2003; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2005 or mover-out nonresponse by 200'
             '3 (ER33801=0); in an institution in both 2003 and 2005 (ER33802=51-59 and ER33808=0); moved in after or moved out before 2003 (ER33802=1-20 and ER33810=2004-2005 or ER33802=51-89 and ER33808=8)'
   ;
   VALUE ER33829F
         1 = 'This individual received pension income in 2003'
         0 = 'Inap.:  did not receive pension income in 2003; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2005 or mover-out nonresponse by 2003'
             ' (ER33801=0); in an institution in both 2003 and 2005 (ER33802=51-59 and ER33808=0); moved in after or moved out before 2003 (ER33802=1-20 and ER33810=2004-2005 or ER33802=51-89 and ER33808=8)'
   ;
   VALUE ER33830F
         1 = 'This individual received veteran''s income in 2003'
         0 = 'Inap.:  did not receive veteran''s income in 2003; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2005 or mover-out nonresponse by 20'
             '03 (ER33801=0); in an institution in both 2003 and 2005 (ER33802=51-59 and ER33808=0); moved in after or moved out before 2003 (ER33802=1-20 and ER33810=2004-2005 or ER33802=51-89 and ER33808=8)'
   ;
   VALUE ER33831F
         1 = 'This individual received Unemployment Compensation in 2003'
         0 = 'Inap.:  did not receive Unemployment Compensation in 2003; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2005 or mover-out nonrespo'
             'nse by 2003 (ER33801=0); in an institution in both 2003 and 2005 (ER33802=51-59 and ER33808=0); moved in after or moved out before 2003 (ER33802=1-20 and ER33810=2004-2005 or ER33802=51-89 and ER33808'
             '=8)'
   ;
   VALUE ER33832F
         1 = 'This individual received Workers Compensation in 2003'
         0 = 'Inap.:  did not receive Workers Compensation in 2003; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2005 or mover-out nonresponse b'
             'y 2003 (ER33801=0); in an institution in both 2003 and 2005 (ER33802=51-59 and ER33808=0); moved in after or moved out before 2003 (ER33802=1-20 and ER33810=2004-2005 or ER33802=51-89 and ER33808=8)'
   ;
   VALUE ER33833F
         1 = 'This individual received public assistance or state or local welfare in 2003'
         0 = 'Inap.:  did not receive public assistance or state or local welfare in 2003; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2005 or'
             'mover-out nonresponse by 2003 (ER33801=0); in an institution in both 2003 and 2005 (ER33802=51-59 and ER33808=0); moved in after or moved out before 2003 (ER33802=1-20 and ER33810=2004-2005 or ER33802'
             '=51-89 and ER33808=8)'
   ;
   VALUE ER33833AF
         1 = 'Alabama'
         2 = 'Alaska'
         4 = 'Arizona'
         5 = 'Arkansas'
         6 = 'California'
         8 = 'Colorado'
         9 = 'Connecticut'
        10 = 'Delaware'
        11 = 'District of Columbia'
        12 = 'Florida'
        13 = 'Georgia'
        15 = 'Hawaii'
        16 = 'Idaho'
        17 = 'Illinois'
        18 = 'Indiana'
        19 = 'Iowa'
        20 = 'Kansas'
        21 = 'Kentucky'
        22 = 'Louisiana'
        23 = 'Maine'
        24 = 'Maryland'
        25 = 'Massachusetts'
        26 = 'Michigan'
        27 = 'Minnesota'
        28 = 'Mississippi'
        29 = 'Missouri'
        30 = 'Montana'
        31 = 'Nebraska'
        32 = 'Nevada'
        33 = 'New Hampshire'
        34 = 'New Jersey'
        35 = 'New Mexico	'
        36 = 'New York'
        37 = 'North Carolina'
        38 = 'North Dakota'
        39 = 'Ohio'
        40 = 'Oklahoma'
        41 = 'Oregon'
        42 = 'Pennsylvania'
        44 = 'Rhode Island'
        45 = 'South Carolina'
        46 = 'South Dakota'
        47 = 'Tennessee'
        48 = 'Texas'
        49 = 'Utah'
        50 = 'Vermont'
        51 = 'Virginia'
        53 = 'Washington'
        54 = 'West Virginia'
        55 = 'Wisconsin'
        56 = 'Wyoming'
        99 = 'DK; NA; refused'
         0 = 'Inap.:  not receiving public assistance in 2003 (ER33833=0); not in FU in 2003.'
   ;
   VALUE ER33833BF
         1 = 'Received TANF assistance'
         9 = 'DK; NA; refused'
         0 = 'INAP.: received no public assistance in 2003 (ER33833 = 0), or received another type of assistance; was not in FU in 2005'
   ;
   VALUE ER33833CF
         1 = 'Received ADC assistance'
         9 = 'DK; NA; refused'
         0 = 'INAP.: received no public assistance in 2003 (ER33833 = 0), or received another type of assistance; was not in FU in 2005'
   ;
   VALUE ER33833DF
         1 = 'Received General Assistance'
         9 = 'DK; NA; refused'
         0 = 'INAP.: received no public assistance in 2003 (ER33833 = 0), or received another type of assistance; was not in FU in 2005'
   ;
   VALUE ER33833EF
         1 = 'Received Emergency Assistance'
         9 = 'DK; NA; refused'
         0 = 'INAP.: received no public assistance in 2003 (ER33833 = 0), or received another type of assistance; was not in FU in 2005'
   ;
   VALUE ER33833FF
         1 = 'Received Cuban/Haitian Refugee Assistance'
         9 = 'DK; NA; refused'
         0 = 'INAP.: received no public assistance in 2003 (ER33833 = 0), or received another type of assistance; was not in FU in 2005'
   ;
   VALUE ER33833GF
         1 = 'Received Indian Assistance'
         9 = 'DK; NA; refused'
         0 = 'INAP.: received no public assistance in 2003 (ER33833 = 0), or received another type of assistance; was not in FU in 2005'
   ;
   VALUE ER33833HF
         1 = 'Received Other assistance'
         9 = 'DK; NA; refused'
         0 = 'INAP.: received no public assistance in 2003 (ER33833 = 0), or received another type of assistance; was not in FU in 2005'
   ;
   VALUE ER33834F
         1 = 'This individual received Supplemental Security Income in 2003'
         0 = 'Inap.:  did not receive Supplemental Security Income in 2003; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2005 or mover-out nonre'
             'sponse by 2003 (ER33801=0); in an institution in both 2003 and 2005 (ER33802=51-59 and ER33808=0); moved in after or moved out before 2003 (ER33802=1-20 and ER33810=2004-2005 or ER33802=51-89 and ER33'
             '808=8)'
   ;
   VALUE ER33835F
         1 = 'This individual received other welfare in 2003'
         0 = 'Inap.:  did not receive other welfare in 2003; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2005 or mover-out nonresponse by 2003'
             '(ER33801=0); in an institution in both 2003 and 2005 (ER33802=51-59 and ER33808=0); moved in after or moved out before 2003 (ER33802=1-20 and ER33810=2004-2005 or ER33802=51-89 and ER33808=8)'
   ;
   VALUE ER33836F
         1 = 'This individual received child support, alimony or separate maintenance in 2003'
         0 = 'Inap.:  did not receive child support, alimony, or separate maintenance in 2003; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2005'
             ' or mover-out nonresponse by 2003 (ER33801=0); in an institution in both 2003 and 2005 (ER33802=51-59 and ER33808=0); moved in after or moved out before 2003 (ER33802=1-20 and ER33810=2004-2005 or ER3'
             '3802=51-89 and ER33808=8)'
   ;
   VALUE ER33837F
         1 = 'This individual received help from relatives or friends in 2003'
         0 = 'Inap.:  did not receive help from relatives or friends in 2003; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2005 or mover-out non'
             'response by 2003 (ER33801=0); in an institution in both 2003 and 2005 (ER33802=51-59 and ER33808=0); moved in after or moved out before 2003 (ER33802=1-20 and ER33810=2004-2005 or ER33802=51-89 and ER'
             '33808=8)'
   ;
   VALUE ER33837AF
         1 = 'Disability'
         2 = 'Retirement'
         3 = 'Survivor benefits; dependent of deceased recipient'
         4 = 'Any combination of codes 1-3 and 5-7'
         5 = 'Dependent of disabled recipient'
         6 = 'Dependent of retired recipient'
         7 = 'Other'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2005 or mover-out nonresponse by 2003 (ER33801=0); in an institution in 2005'
             '(ER33802=51-59); no Social Security income'
   ;
   VALUE ER33837DF
         1 = 'Only one job'
         2 = 'Two jobs'
         3 = 'Three jobs'
         4 = 'Four jobs or more'
         5 = 'Didn''t have a job'
         8 = 'Don''t know'
         9 = 'NA; refused'
         0 = 'Inap.: this person was a current Head/Spouse/Partner in 2005; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2005 or mover-out nonre'
             'sponse by 2003 (ER33801=0); OFUM in an institution in both 2003 and 2005 (ER33802=51-59 and ER33808=0); OFUM under age 16 (ER33804=001-015); OFUM associated with 2005 FU but moved out before 2004 (ER3'
             '3808=5, 6, or 8 and ER33810<2004) or OFUM moved in in 2005 (ER33808=1 and ER33810=2005)'
   ;
   VALUE ER33838F
         1 = 'This individual made most of the decisions'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.:  this person did not make most of the decisions; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2005 or mover-out nonresponse'
             ' by 2003 (ER33801=0); in an institution in both 2003 and 2005 (ER33802=51-59 and ER33808=0)'
   ;
   VALUE ER33842F
         1 = 'This individual was eligible to be followed in 2005'
         5 = 'This individual was not eligible to be followed in 2005'
         0 = 'Inap.:  main family or mover-out nonresponse in 2003 and not selected for recontact in 2005; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); born or moved in af'
             'ter the 2005 interview (ER33801>0 and ER33802=0).'
   ;
   VALUE ER33844F
         1 = 'This individual was eligible to be interviewed'
         0 = 'Inap.:  this individual was from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); not interviewed as part of 1997 CDS (ER33420=00, 02-98); main family nonresponse by'
             '2005 (ER33801=0 and ER33802=0)'
   ;
   VALUE ER33845F
         1 = 'Interview with eligible sample individual'
         2 = 'Interview with ineligible individual (i.e., a person thought to be sample but who was later found to be nonsample)'
         3 = 'Refusal by the sample individual; partial/passive refusal; deliberate avoidance of interviewer (e.g., always too busy, repeated broken appointments, or failure to return calls)'
         4 = 'Sample individual lost; tracking efforts exhausted'
         5 = 'Sample individual incapacitated, had a permanent health condition, or institutionalized for health or mental reasons'
         6 = 'Sample individual deceased after PSID interview completed but before TA interview'
         7 = 'Some household member contacted, but eligible respondent not available to do interview; appointment broken, but no evidence of deliberately avoiding interview'
        13 = 'Refusal by someone other than the sample individual'
        30 = 'Sample individual away on military leave or in job corps and not accessible for interviewing'
        34 = 'Sample individual incarcerated or in a youth, group, or detention home/center'
        36 = 'Sample individual was 18 years old but still in high school and dependent on family and therefore not eligible for an interview'
        95 = 'Office error--study ended, insufficient or inappropriate calls made, no mention of refusal'
        97 = 'Other (above codes take priority)'
         0 = 'Inap.:  this individual was from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); not interviewed as part of 1997 CDS (ER33420=00, 02-98); main family nonresponse by'
             '2005 (ER33801=0 and ER33802=0); PSID splitoff interview refusal in 2005 (ER33802=71-79 and ER33847=1)'
   ;
   VALUE ER33846F
         1 = 'This sample member was main family nonresponse and had been in the FU in 2003.'
         3 = 'This nonsample individual had been in the 2003 FU, and this FU became nonresponse in 2005.'
         4 = 'This sample member had been in an institution in 2003, but his or her family became nonresponse in 2005.'
         5 = 'This sample member, linked to a 2005 response family, was in an institution at the time of the 2005 interview.'
         6 = 'This sample member moved out or died between the 2003 and 2005 interviews.'
         8 = 'This nonsample individual moved out or died between the 2003 and 2005 interviews.'
         9 = 'This individual had not been born or moved in by the time of the 2005 interview; individual from Immigrant 17 sample (ER30001=4001-4462)'
        10 = 'This individual had become nonresponse by the time of the 2003 interview.'
        21 = 'Main family recontact: this person was selected for recontact in 2005, but the family was not successfully interviewed.'
        26 = 'Splitoff recontact: this sample member moved out of a 2005 recontact main family but was not successfully interviewed.'
        40 = 'Individual connected with the Latino sample (ER30001=7001-9308); this sample was dropped beginning in 1996.  Individual dropped from the Census (SEO) sample due to budgetary constraints; this group wa'
             's dropped beginning in 1997.'
        99 = 'NA; DK'
         0 = 'Inap.:  this individual was in a panel family in 2005 (ER33802=1-20).'
   ;
   VALUE ER33847F
         1 = 'Wave refusal by all eligible/available FU members.'
         2 = 'No one at home for contact during the interviewing period.'
         3 = 'Respondent absent; some FU member contacted, but not the appropriate respondent.'
         4 = 'Lost; unable to locate any member of the FU at all.'
         5 = 'FU is located too far away for interviewer contact.'
        10 = 'Panel refusal by all all eligible/available FU members.  These individuals will never be asked to participate in the study again, regardless of recontact efforts.'
        11 = 'This sample member was in the armed forces.'
        12 = 'This sample member was in an educational institution.'
        13 = 'This sample member was in a health care facility.'
        14 = 'This sample member was in jail or prison.'
        19 = 'This sample member was in some other type of institution; for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        21 = 'This nonsample individual became main family nonresponse because the Head or the Wife, whichever is the sample member, became institutionalized by joining the armed forces.'
        22 = 'This nonsample individual became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by entering an educational institution.'
        23 = 'This nonsample individual became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized by entering a health care facility.'
        24 = 'This nonsample individual became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized through imprisonment.'
        29 = 'This nonsample individual became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by some means other than the above; for example, he/she may have entere'
             'd a religious order. Cases in which the type of institution is unknown are included here, also.'
        31 = 'This sample member was unable to cooperate because of disability.'
        32 = 'This nonsample individual became main family nonresponse because the Head or Wife, whichever is sample, was unable to cooperate because of disability.'
        41 = 'This individual died between the 2003 and 2005 interviews; this individual died after becoming nonresponse for some other reason before the 2003 interview.'
        42 = 'This nonsample individual became main family nonresponse because the Head or Wife, whichever is sample, died.'
        45 = 'This individual was a sample member but has been adopted by unrelated nonsample persons and therefore has become nonsample.'
        51 = 'This individual, although followed for interview, was discovered to be nonsample:  office error.'
        52 = 'This individual should have been followed but was not:  office error.'
        53 = 'This individual was mistakenly included in two or more response families at once; this record is the duplicate, or erroneous, one.'
        54 = 'Listing error: this individual never existed or was not really living in the FU.'
        57 = 'Insufficient information that would permit recontact; no name or identifying information available'
        58 = 'Due to budgetary and/or time constraints, PSID staff decided not to take all of the usual steps to try to locate and/or persuade this FU.'
        59 = 'Limited number of contacts attempted:  miscellaneous office error (does not include codes 01-54 above or codes 91-99 below).'
        60 = 'This nonsample parent of a sample child is no longer eligible to be interviewed.'
        61 = 'This nonsample individual was associated with a family containing a person erroneously designated as followable; the erroneous person''s code is 45, 51, 53, 54, or 60.'
        80 = 'Individual connected with the Latino sample (ER30001=7001-9308); this sample was dropped beginning in 1996.  Individual dropped from the Census (SEO) sample due to budgetary constraints; this group wa'
             's dropped beginning in 1997.'
        91 = 'This individual moved out of the 2005 main family and was eligible to be followed, but the reason for nonresponse is NA.'
        92 = 'Individual moved out of the 2005 main family and was not eligible to be followed.'
        93 = 'All sample members of this FU united with other panel FUs; this individual was nonsample and therefore became nonresponse.'
        97 = 'This individual had not been born or moved in by the time of the 2005 interview (ER33801>0 and ER33802=0); individual from Immigrant 17 sample (ER30001=4001-4462)'
        98 = 'This individual became main family or mover-out nonresponse by 2003 and was not selected for recontact in 2005 (ER33701=0 and ER33801=0 and ER33842=0 or ER33701>0 and ER33702=71-89 and ER33801=0 and E'
             'R33842=0).'
        99 = 'NA; DK'
         0 = 'Inap.:  this individual was in a panel family in 2005 (ER33802=1-20)'
   ;
   VALUE ER33902F
    1 - 20 = 'Individuals in the family at the time of the 2007 interview'
   51 - 59 = 'Individuals in institutions at the time of the 2007 interview'
   71 - 80 = 'Individuals who moved out of the FU or out of institutions and established their own households between the 2005 and 2007 interviews'
   81 - 89 = 'Individuals who were living in 2005 but died by the time of the 2007 interview'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2007 or mover-out nonresponse by 2005 (ER33901=0)'
   ;
   VALUE ER33903F
        10 = 'Head in 2007; 2005 Head who was mover-out nonresponse by the time of the 2007 interview'
        20 = 'Legal Wife in 2007; 2005 Wife who was mover-out nonresponse by the time of the 2007 interview'
        22 = '"Wife"--female cohabitor who has lived with Head for 12 months or more; 2005 "Wife" who was mover-out nonresponse by the time of the 2007 interview'
        30 = 'Son or daughter of Head (includes adopted children but not stepchildren)'
        33 = 'Stepson or stepdaughter of Head (children of legal Wife [code 20] who are not children of Head)'
        35 = 'Son or daughter of "Wife" but not Head (includes only those children of mothers whose relationship to Head is 22 but who are not children of Head)'
        37 = 'Son-in-law or daughter-in-law of Head (includes stepchildren-in-law)'
        38 = 'Foster son or foster daughter, not legally adopted'
        40 = 'Brother or sister of Head (includes step and half sisters and brothers)'
        47 = 'Brother-in-law or sister-in-law of Head; i.e., brother or sister of legal Wife, or spouse of Head''s brother or sister'
        48 = 'Brother or sister of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        50 = 'Father or mother of Head (includes stepparents)'
        57 = 'Father-in-law or mother-in-law of Head (includes parents of legal wives [code 20] only)'
        58 = 'Father or mother of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        60 = 'Grandson or granddaughter of Head (includes grandchildren of legal Wife [code 20] only; those of a cohabitor are coded 97)'
        65 = 'Great-grandson or great-granddaughter of Head (includes great-grandchildren of legal Wife [code 20]; those of a cohabitor are coded 97)'
        66 = 'Grandfather or grandmother of Head (includes stepgrandparents)'
        67 = 'Grandfather or grandmother of legal Wife (code 20)'
        68 = 'Great-grandfather or great-grandmother of Head'
        69 = 'Great-grandfather or great-grandmother of legal Wife (code 20)'
        70 = 'Nephew or niece of Head'
        71 = 'Nephew or niece of legal Wife (code 20)'
        72 = 'Uncle or Aunt of Head'
        73 = 'Uncle or Aunt of legal Wife (code 20)'
        74 = 'Cousin of Head'
        75 = 'Cousin of legal Wife (code 20)'
        83 = 'Children of first-year cohabitor but not of Head (the parent of this child is coded 88)'
        88 = 'First-year cohabitor of Head'
        90 = 'Legal husband of Head'
        95 = 'Other relative of Head'
        96 = 'Other relative of legal Wife (code 20)'
        97 = 'Other relative of cohabitor (the cohabitor is code 22 or 88)'
        98 = 'Other nonrelatives (includes homosexual partners, friends of children of the FU, etc.)'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2007 or mover-out nonresponse by 2005 (ER33901=0)'
   ;
   VALUE ER33907F
         1 = 'Spouse in couple numbered 1'
         2 = 'Spouse in couple numbered 2'
         3 = 'Spouse in couple numbered 3'
         4 = 'Spouse in couple numbered 4'
         0 = 'Inap.:  not married or permanently cohabiting; spouse was not in FU at the time of the 2007 interview; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main fami'
             'ly nonresponse by 2007 or mover-out nonresponse by 2005 (ER33901=0)'
   ;
   VALUE ER33908F
         1 = 'Moved in or born between the 2005 and 2007 interviews; splitoff in 2007'
         2 = 'Appeared; moved in by the time the 2005 interview was taken but not included in FU for 2005 (i.e., listing error)'
         5 = 'Moved out of FU or out of an institution between the 2005 and 2007 interviews and was not included in a 2007 panel FU'
         6 = 'Moved out of FU and into an institution between the 2005 and 2007 interviews'
         7 = 'Living in 2005 but died by the time of the 2007 interview'
         8 = 'Disappeared; moved out prior to the 2005 interview, but included in FU for 2005 (usually a listing error)'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); in main family in both 2005 and 2007 (ER33802=1-20 and ER33902=1-20); in an institution in both 2005 and'
             ' 2007 (ER33802=51-59 and ER33902=51-59); main family nonresponse by 2007 or mover-out nonresponse by 2005 (ER33901=0); born or moved in after the 2007 interview (ER33901>0 and ER33902=0)'
   ;
   VALUE ER33911F
         1 = 'This individual was respondent'
         5 = 'This individual was not respondent; includes institutionalized individuals and mover-out nonresponse from 2007 (ER33902=51-89)'
         9 = 'NA; DK'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2007 or mover-out nonresponse by 2005 (ER33901=0)'
   ;
   VALUE ER33912F
         1 = 'Head who received TANF'
         2 = 'Wife/"Wife" who received TANF'
         3 = 'Other Family Unit Member who received TANF'
         0 = 'Inap.:  this individual did not receive TANF; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2007 or mover-out nonresponse by 2005 ('
             'ER33901=0); in an institution in both 2005 and 2007 (ER33902=51-59 and ER33908=0)'
   ;
   VALUE ER33913F
         1 = 'Working now'
         2 = 'Only temporarily laid off'
         3 = 'Looking for work, unemployed'
         4 = 'Retired'
         5 = 'Permanently disabled'
         6 = 'HouseWife; keeping house'
         7 = 'Student'
         8 = 'Other'
         9 = 'NA; DK'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2007 or mover-out nonresponse by 2005 (ER33901=0); mover-out nonresponse for'
             '2007, only if deceased (ER33902=81-89); in an institution in both 2005 and 2007 (ER33902=51-59 and ER33908=0); not a person aged 16 or older (ER33904=001-015); associated with 2007 FU but moved out be'
             'fore 2006 (ER33908=5, 6, or 8 and ER33910<2006) or moved in in 2007 (ER33908=1 and ER33910=2007)'
   ;
   VALUE ER33916F
         1 = 'Full-time student'
         2 = 'Part-time student'
         5 = 'Not enrolled in school'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2007 or mover-out nonresponse by 2005 (ER33901=0); Head or Wife/"Wife" in 200'
             '7 (ER33902=1-20 and ER33903=10, 20 or 22); in an institution in both 2005 and 2007 (ER33902=51-59 and ER33908=0); under age 16, or age 50 or older (ER33904=001-015, 050-125, or 999); associated with 2'
             '007 FU but moved out before 2006 (ER33908=5, 6, or 8 and ER33910<2006) or moved in in 2007 (ER33908=1 and ER33910=2007); last attended school before 2006 (ER33915=1901-2005, 9997, 9998, or 9999)'
   ;
   VALUE ER33917F
    1 - 17 = 'Highest grade or year of school completed'
        98 = 'DK'
        99 = 'NA'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2007 or mover-out nonresponse by 2005 (ER33901=0); in an institution in both'
             '2005 and 2007 (ER33902=51-59 and ER33908=0); not a person aged 16 or older (ER33904=001-015, 999); associated with 2007 FU but actually moved out before 2006 (ER33908=5, 6, or 8 and ER33910<2006) or m'
             'oved in in 2007 (ER33908=1 and ER33910=2007)'
   ;
   VALUE ER33918F
         1 = 'Yes, is in poor health'
         5 = 'No, is not in poor health'
         9 = 'NA'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2007 or mover-out nonresponse by 2005 (ER33901=0); in an institution or mover'
             '-out nonresponse in 2007 (ER33902=51-89); current Head or Wife (ER33902=1-2 and ER33903=10, 20, 22)'
   ;
   VALUE ER33919F
         1 = 'Employer provided health insurance'
         2 = 'Private health insurance purchased directly'
         3 = 'Medicare'
         4 = 'Medi-Gap/Supplemental'
         5 = 'Medicaid/Medical Assistance/[STATE PROGRAM]'
         6 = 'Military health care/TRICARE (Active)'
         7 = 'CHAMPUS/TRICARE/CHAMP-VA (Dependents, Veterans)'
         8 = 'Indian Health Insurance'
         9 = 'Other state-sponsored plan (not Medicaid)'
        10 = 'Other government program'
        97 = 'Other'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  not covered by health care plan; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2007 or mover-out nonresponse by 2005 (ER339'
             '01=0); moved into FU in 2007 (ER33902=1-20 and ER33910=2007); moved out before 2005 (ER33902=71-89 and ER33910>0 and ER33910<2005)'
   ;
   VALUE ER33920F
         1 = 'Employer provided health insurance'
         2 = 'Private health insurance purchased directly'
         3 = 'Medicare'
         4 = 'Medi-Gap/Supplemental'
         5 = 'Medicaid/Medical Assistance/[STATE PROGRAM]'
         6 = 'Military health care/TRICARE (Active)'
         7 = 'CHAMPUS/TRICARE/CHAMP-VA (Dependents, Veterans)'
         8 = 'Indian Health Insurance'
         9 = 'Other state-sponsored plan (not Medicaid)'
        10 = 'Other government program'
        97 = 'Other'
         0 = 'Inap.:  no second mention; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2007 or mover-out nonresponse by 2005 (ER33901=0); moved i'
             'nto FU in 2007 (ER33902=1-20 and ER33910=2007); moved out before 2005 (ER33902=71-89 and ER33910>0 and ER33910<2005); not covered by health care plan (ER33919=0); DK, NA, or RF to first mention (ER339'
             '19=98 or 99)'
   ;
   VALUE ER33921F
         1 = 'Employer provided health insurance'
         2 = 'Private health insurance purchased directly'
         3 = 'Medicare'
         4 = 'Medi-Gap/Supplemental'
         5 = 'Medicaid/Medical Assistance/[STATE PROGRAM]'
         6 = 'Military health care/TRICARE (Active)'
         7 = 'CHAMPUS/TRICARE/CHAMP-VA (Dependents, Veterans)'
         8 = 'Indian Health Insurance'
         9 = 'Other state-sponsored plan (not Medicaid)'
        10 = 'Other government program'
        97 = 'Other'
         0 = 'Inap.:  no third mention; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2007 or mover-out nonresponse by 2005 (ER33901=0); moved in'
             'to FU in 2007 (ER33902=1-20 and ER33910=2007); moved out before 2005 (ER33902=71-89 and ER33910>0 and ER33910<2005); not covered by health care plan (ER33919=0); DK, NA, or RF to first mention (ER3391'
             '9=98 or 99)'
   ;
   VALUE ER33922F
         1 = 'Employer provided health insurance'
         2 = 'Private health insurance purchased directly'
         3 = 'Medicare'
         4 = 'Medi-Gap/Supplemental'
         5 = 'Medicaid/Medical Assistance/[STATE PROGRAM]'
         6 = 'Military health care/TRICARE (Active)'
         7 = 'CHAMPUS/TRICARE/CHAMP-VA (Dependents, Veterans)'
         8 = 'Indian Health Insurance'
         9 = 'Other state-sponsored plan (not Medicaid)'
        10 = 'Other government program'
        97 = 'Other'
         0 = 'Inap.:  no fourth mention; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2007 or mover-out nonresponse by 2005 (ER33901=0); moved i'
             'nto FU in 2007 (ER33902=1-20 and ER33910=2007); moved out before 2005 (ER33902=71-89 and ER33910>0 and ER33910<2005); not covered by health care plan (ER33919=0); DK, NA, or RF to first mention (ER339'
             '19=98 or 99)'
   ;
   VALUE ER33923F
         1 = 'Yes, it is the state health insurance plan for uninsured children'
         5 = 'No, it is not the state health insurance plan for uninsured children'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2007 or mover-out nonresponse by 2005 (ER33901=0); moved into FU in 2007 (ER3'
             '3902=1-20 and ER33910=2007); moved out before 2005 (ER33902=71-89 and ER33910>0 and ER33910<2005); not covered by health care plan (ER33919=0); not covered by other health care plan and not less than'
             '18 years old (ER33919=1-8 and ER33920 NE 9-10 or 97 and ER33921 NE 9-10 or 97 and ER3922 NE 9-10 or 97 and ER33904>17);'
   ;
   VALUE ER33924F
    1 - 12 = 'Actual number of months covered in 2005'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  not covered in 2005; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2007 or mover-out nonresponse by 2005 (ER33901=0); moved'
             ' into FU in 2007 (ER33902=1-20 and ER33910=2007); moved out before 2005 (ER33902=71-89 and ER33910>0 and ER33910<2005); not covered by health care plan (ER33919=0)'
   ;
   VALUE ER33925F
    1 - 12 = 'Actual number of months covered in 2006'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  not covered in 2006; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2007 or mover-out nonresponse by 2005 (ER33901=0); moved'
             ' into FU in 2007 (ER33902=1-20 and ER33910=2007); moved out before 2005 (ER33902=71-89 and ER33910>0 and ER33910<2005); not covered by health care plan (ER33919=0)'
   ;
   VALUE ER33925AF
         1 = 'Disability'
         2 = 'Retirement'
         3 = 'Survivor benefits; dependent of deceased recipient'
         4 = 'Any combination of codes 1-3 and 5-7'
         5 = 'Dependent of disabled recipient'
         6 = 'Dependent of retired recipient'
         7 = 'Other'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2007 or mover-out nonresponse by 2005 (ER33901=0); in an institution in 2007'
             '(ER33902=51-59); no Social Security income'
   ;
   VALUE ER33925DF
         1 = 'Only one job'
         2 = 'Two jobs'
         3 = 'Three jobs'
         4 = 'Four jobs or more'
         5 = 'Didn''t have a job'
         8 = 'Don''t know'
         9 = 'NA; refused'
         0 = 'Inap.: this person was a current Head/Spouse/Partner in 2007; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2007 or mover-out nonre'
             'sponse by 2005 (ER33901=0); OFUM in an institution in both 2005 and 2007 (ER33902=51-59 and ER33908=0); OFUM under age 16 (ER33904=001-015); OFUM associated with 2007 FU but moved out before 2006 (ER3'
             '3908=5, 6, or 8 and ER33910<2006) or OFUM moved in in 2007 (ER33908=1 and ER33910=2007)'
   ;
   VALUE ER33926F
         1 = 'This individual is a 2007 Head, Wife, or "Wife" who was covered by Medicare or was aged 65 or older, was the respondent, and did not give a useable Medicare number in the prior wave but did in this wa'
             've.'
         2 = 'This individual is a 2007 Head, Wife, or "Wife" who was covered by Medicare or was aged 65 or older, was the respondent, did not give a useable Medicare number in the prior wave, and provided a Medica'
             're number in this wave but it was not useable (e.g., missing digits).'
         5 = 'This individual is a 2007 Head, Wife, or "Wife" who was covered by Medicare or was aged 65 or older, was the respondent, did not give a useable Medicare number in the prior wave and in the present wav'
             'e declined  to give his/her Medicare number (H62a=5), did not know/refused whether the number was a Medicare Claim or Railroad Retirement Board number, or did not know the number at H62c/H62e-f.'
         7 = 'This individual is associated with a responding FU and was a 2005 Head, Wife, or "Wife" who was covered by Medicare, was the respondent, and provided a useable Medicare number in the 2005 wave.'
         9 = 'This individual is a 2007 Head, Wife, or "Wife" who was covered by Medicare or was aged 65 or older, was the respondent, did not give a useable Medicare number in the prior wave, and in the present wa'
             've whether a Medicare number could be provided was NA or DK (H62a=8 or 9).'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2007 or mover-out nonresponse by 2005 (ER33901=0); moved out before 2005 (ER3'
             '3902=71-89 and ER33910>0 and ER33910<2005); not Head or Wife/"Wife" in 2007 (ER33903>22 or ER33902>50); under age 65 and not covered by Medicare (ER33904<65 or 999 and neither ER33919, ER33920, ER3392'
             '1, nor ER33922=3);  not the respondent (ER33911=5)'
   ;
   VALUE ER33926BF
         1 = 'Hour'
         2 = 'Day'
         3 = 'Week'
         4 = 'Two weeks'
         5 = 'Month'
         6 = 'Year'
         9 = 'DK; NA; refused'
         0 = 'Inap.:  individual did not work in 2005; was not in FU in 2005; under age 18 in 2007'
   ;
   VALUE ER33927F
         1 = 'This individual received asset income in 2005'
         0 = 'Inap.:  did not receive asset income in 2005; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2007 or mover-out nonresponse by 2005 ('
             'ER33901=0); in an institution in both 2005 and 2007 (ER33902=51-59 and ER33908=0); moved in after or moved out before 2005 (ER33902=1-20 and ER33910=2006-2007 or ER33902=51-89 and ER33908=8)'
   ;
   VALUE ER33927AF
    1 - 52 = 'Actual number of weeks worked in 2005'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  individual did not work in 2005; was not in FU in 2005; under age 18 in 2007; individual was HD or WF in FU in 2007'
   ;
   VALUE ER33928F
         1 = 'This individual received social security in 2005'
         0 = 'Inap.:  did not receive social security in 2005; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2007 or mover-out nonresponse by 200'
             '5 (ER33901=0); in an institution in both 2005 and 2007 (ER33902=51-59 and ER33908=0); moved in after or moved out before 2005 (ER33902=1-20 and ER33910=2006-2007 or ER33902=51-89 and ER33908=8)'
   ;
   VALUE ER33929F
         1 = 'This individual received pension income in 2005'
         0 = 'Inap.:  did not receive pension income in 2005; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2007 or mover-out nonresponse by 2005'
             ' (ER33901=0); in an institution in both 2005 and 2007 (ER33902=51-59 and ER33908=0); moved in after or moved out before 2005 (ER33902=1-20 and ER33910=2006-2007 or ER33902=51-89 and ER33908=8)'
   ;
   VALUE ER33930F
         1 = 'This individual received veteran''s income in 2005'
         0 = 'Inap.:  did not receive veteran''s income in 2005; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2007 or mover-out nonresponse by 20'
             '05 (ER33901=0); in an institution in both 2005 and 2007 (ER33902=51-59 and ER33908=0); moved in after or moved out before 2005 (ER33902=1-20 and ER33910=2006-2007 or ER33902=51-89 and ER33908=8)'
   ;
   VALUE ER33931F
         1 = 'This individual received Unemployment Compensation in 2005'
         0 = 'Inap.:  did not receive Unemployment Compensation in 2005; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2007 or mover-out nonrespo'
             'nse by 2005 (ER33901=0); in an institution in both 2005 and 2007 (ER33902=51-59 and ER33908=0); moved in after or moved out before 2005 (ER33902=1-20 and ER33910=2006-2007 or ER33902=51-89 and ER33908'
             '=8)'
   ;
   VALUE ER33932F
         1 = 'This individual received Workers Compensation in 2005'
         0 = 'Inap.:  did not receive Workers Compensation in 2005; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2007 or mover-out nonresponse b'
             'y 2005 (ER33901=0); in an institution in both 2005 and 2007 (ER33902=51-59 and ER33908=0); moved in after or moved out before 2005 (ER33902=1-20 and ER33910=2006-2007 or ER33902=51-89 and ER33908=8)'
   ;
   VALUE ER33933F
         1 = 'This individual received public assistance or state or local welfare in 2005'
         0 = 'Inap.:  did not receive public assistance or state or local welfare in 2005; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2007 or'
             'mover-out nonresponse by 2005 (ER33901=0); in an institution in both 2005 and 2007 (ER33902=51-59 and ER33908=0); moved in after or moved out before 2005 (ER33902=1-20 and ER33910=2006-2007 or ER33902'
             '=51-89 and ER33908=8)'
   ;
   VALUE ER33933AF
         1 = 'Alabama'
         2 = 'Alaska'
         4 = 'Arizona'
         5 = 'Arkansas'
         6 = 'California'
         8 = 'Colorado'
         9 = 'Connecticut'
        10 = 'Delaware'
        11 = 'District of Columbia'
        12 = 'Florida'
        13 = 'Georgia'
        15 = 'Hawaii'
        16 = 'Idaho'
        17 = 'Illinois'
        18 = 'Indiana'
        19 = 'Iowa'
        20 = 'Kansas'
        21 = 'Kentucky'
        22 = 'Louisiana'
        23 = 'Maine'
        24 = 'Maryland'
        25 = 'Massachusetts'
        26 = 'Michigan'
        27 = 'Minnesota'
        28 = 'Mississippi'
        29 = 'Missouri'
        30 = 'Montana'
        31 = 'Nebraska'
        32 = 'Nevada'
        33 = 'New Hampshire'
        34 = 'New Jersey'
        35 = 'New Mexico	'
        36 = 'New York'
        37 = 'North Carolina'
        38 = 'North Dakota'
        39 = 'Ohio'
        40 = 'Oklahoma'
        41 = 'Oregon'
        42 = 'Pennsylvania'
        44 = 'Rhode Island'
        45 = 'South Carolina'
        46 = 'South Dakota'
        47 = 'Tennessee'
        48 = 'Texas'
        49 = 'Utah'
        50 = 'Vermont'
        51 = 'Virginia'
        53 = 'Washington'
        54 = 'West Virginia'
        55 = 'Wisconsin'
        56 = 'Wyoming'
        99 = 'DK; NA; refused'
         0 = 'Inap.:  not receiving public assistance in 2005 (ER33933=0); not in FU in 2005.'
   ;
   VALUE ER33933BF
         1 = 'Received TANF assistance'
         8 = 'NA; DK'
         0 = 'INAP.: received no public assistance in 2005 (ER33933=0), or received another type of assistance; was not in FU in 2005.'
   ;
   VALUE ER33933CF
         1 = 'Received ADC assistance'
         8 = 'NA; DK'
         0 = 'INAP.: received no public assistance in 2005 (ER33933=0), or received another type of assistance; was not in FU in 2005.'
   ;
   VALUE ER33933DF
         1 = 'Received General Assistance'
         8 = 'NA; DK'
         0 = 'INAP.: received no public assistance in 2005 (ER33933=0), or received another type of assistance; was not in FU in 2005.'
   ;
   VALUE ER33933EF
         1 = 'Received Emergency Assistance'
         8 = 'NA; DK'
         0 = 'INAP.: received no public assistance in 2005 (ER33933=0), or received another type of assistance; was not in FU in 2005.'
   ;
   VALUE ER33933FF
         1 = 'Received Cuban/Haitian Refugee assistance'
         8 = 'NA; DK'
         0 = 'INAP.: received no public assistance in 2005 (ER33933=0), or received another type of assistance; was not in FU in 2005.'
   ;
   VALUE ER33933GF
         1 = 'Received Indian Assistance'
         8 = 'NA; DK'
         0 = 'INAP.: received no public assistance in 2005 (ER33933=0), or received another type of assistance; was not in FU in 2005.'
   ;
   VALUE ER33933HF
         1 = 'Received Other Assistance'
         8 = 'NA; DK'
         0 = 'INAP.: received no public assistance in 2005 (ER33933=0), or received another type of assistance; was not in FU in 2005.'
   ;
   VALUE ER33934F
         1 = 'This individual received Supplemental Security Income in 2005'
         0 = 'Inap.:  did not receive Supplemental Security Income in 2005; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2007 or mover-out nonre'
             'sponse by 2005 (ER33901=0); in an institution in both 2005 and 2007 (ER33902=51-59 and ER33908=0); moved in after or moved out before 2005 (ER33902=1-20 and ER33910=2006-2007 or ER33902=51-89 and ER33'
             '908=8)'
   ;
   VALUE ER33935F
         1 = 'This individual received other welfare in 2005'
         0 = 'Inap.:  did not receive other welfare in 2005; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2007 or mover-out nonresponse by 2005'
             '(ER33901=0); in an institution in both 2005 and 2007 (ER33902=51-59 and ER33908=0); moved in after or moved out before 2005 (ER33902=1-20 and ER33910=2006-2007 or ER33902=51-89 and ER33908=8)'
   ;
   VALUE ER33936F
         1 = 'This individual received child support, alimony, or separate maintenance in 2005'
         0 = 'Inap.:  did not receive child support, alimony, or separate maintenance in 2005; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2007'
             ' or mover-out nonresponse by 2005 (ER33901=0); in an institution in both 2005 and 2007 (ER33902=51-59 and ER33908=0); moved in after or moved out before 2005 (ER33902=1-20 and ER33910=2006-2007 or ER3'
             '3902=51-89 and ER33908=8)'
   ;
   VALUE ER33937F
         1 = 'This individual received help from relatives or friends in 2005'
         0 = 'Inap.:  did not receive help from relatives or friends in 2005; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2007 or mover-out non'
             'response by 2005 (ER33901=0); in an institution in both 2005 and 2007 (ER33902=51-59 and ER33908=0); moved in after or moved out before 2005 (ER33902=1-20 and ER33910=2006-2007 or ER33902=51-89 and ER'
             '33908=8)'
   ;
   VALUE ER33938F
         1 = 'This individual received other income in 2005'
         0 = 'Inap.:  did not receive other income in 2005; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2007 or mover-out nonresponse by 2005 ('
             'ER33901=0); in an institution in both 2005 and 2007 (ER33902=51-59 and ER33908=0); moved in after or moved out before 2005 (ER33902=1-20 and ER33910=2006-2007 or ER33902=51-89 and ER33908=8)'
   ;
   VALUE ER33942F
         1 = 'This individual was eligible to be followed in 2007'
         5 = 'This individual was not eligible to be followed in 2007'
         0 = 'Inap.:  main family or mover-out nonresponse in 2005 and not selected for recontact in 2007; from Latino sample (ER30001=7001-9308)'
   ;
   VALUE ER33944F
         1 = 'This individual was eligible to be interviewed for the TA interview in 2007'
         2 = 'This individual was eligible to be interviewed for the CDS interview in 2007'
         3 = 'Eligibility for either the TA interview or the CDS interview could not be determined for this individual (e.g., screener questions were refused, an adult in the household could not be contacted to ans'
             'wer screener questions)'
         0 = 'Inap.:  this individual was from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); not interviewed as part of 1997 CDS (ER33420=00, 02-98); main family nonresponse by'
             '2007 (ER33901=0 and ER33902=0); mover-out nonresponse in 2007 (ER33902=71-89)'
   ;
   VALUE ER33945F
         1 = 'Interview with eligible sample individual'
         3 = 'Refusal by the sample individual; partial/passive refusal; deliberate avoidance of interviewer (e.g., always too busy, repeated broken appointments, or failure to return calls)'
         4 = 'Sample individual lost; tracking efforts exhausted'
         5 = 'Sample individual incapacitated, had a permanent health condition, or institutionalized for health or mental reasons'
         6 = 'Sample individual deceased after PSID interview completed but before TA interview'
         7 = 'Some household member contacted, but eligible respondent not available to do interview; appointment broken, but no evidence of deliberately avoiding interview'
        13 = 'Refusal by someone other than the sample individual'
        30 = 'Sample individual away on military leave, in job corps, or in a non-detention facility'
        31 = 'Sample individual resided outside the US or in a remote area and uncontactable (e.g., no telephone)'
        34 = 'Sample individual incarcerated or in a youth, group, or detention home/center'
        70 = 'Sample individual was randomly dropped because two others in the family unit were also eligible (CDS only)'
        90 = 'Sample individual was initially thought to be ineligible because of nonresponse but discovered to be a resident in a response sample family after the interviewing period had ended.'
        95 = 'Office error--study ended, insufficient or inappropriate calls made, no mention of refusal'
         0 = 'Inap.:  this individual was from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); not interviewed as part of 1997 CDS (ER33420=00, 02-98); main family nonresponse by'
             '2007 (ER33901=0 and ER33902=0); mover-out nonresponse in 2007 (ER33902=71-89)'
   ;
   VALUE ER33948F
         1 = 'This sample member was main family nonresponse and had been in the FU in 2005.'
         3 = 'This nonsample individual had been in the 2005 FU, and this FU became nonresponse in 2007.'
         4 = 'This sample member had been in an institution in 2005, but his or her family became nonresponse in 2007.'
         5 = 'This sample member, linked to a 2007 response family, was in an institution at the time of the 2007 interview.'
         6 = 'This sample member moved out or died between the 2005 and 2007 interviews.'
         8 = 'This nonsample individual moved out or died between the 2005 and 2007 interviews.'
         9 = 'This individual had not been born or moved in by the time of the 2007 interview;  individual from Immigrant 17 sample (ER30001=4001-4462)'
        10 = 'This individual had become nonresponse by the time of the 2007 interview.'
        21 = 'Main family recontact: this person was selected for recontact in 2007, but the family was not successfully interviewed.'
        26 = 'Splitoff recontact: this sample member moved out of a 2007 recontact main family but was not successfully interviewed.'
        40 = 'Individual connected with the Latino sample (ER30001=7001-9308); this sample was dropped beginning in 1996.  Individual dropped from the Census (SEO) sample due to budgetary constraints; this group wa'
             's dropped beginning in 1997.'
        99 = 'NA; DK'
         0 = 'Inap.:  this individual was in a panel family in 2007 (ER33902=1-20).'
   ;
   VALUE ER33949F
         1 = 'Wave refusal by all eligible/available FU members.'
         2 = 'No one at home for contact during the interviewing period.'
         3 = 'Respondent absent; some FU member contacted, but not the appropriate respondent.'
         4 = 'Lost; unable to locate any member of the FU at all.'
         5 = 'FU is located too far away for interviewer contact.'
        10 = 'Panel refusal by all all eligible/available FU members.  These individuals will never be asked to participate in the study again, regardless of recontact efforts.'
        11 = 'This sample member was in the armed forces.'
        12 = 'This sample member was in an educational institution.'
        13 = 'This sample member was in a health care facility.'
        14 = 'This sample member was in jail or prison.'
        19 = 'This sample member was in some other type of institution; for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        21 = 'This nonsample individual became main family nonresponse because the Head or the Wife, whichever is the sample member, became institutionalized by joining the armed forces.'
        22 = 'This nonsample individual became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by entering an educational institution.'
        23 = 'This nonsample individual became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized by entering a health care facility.'
        24 = 'This nonsample individual became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized through imprisonment.'
        29 = 'This nonsample individual became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by some means other than the above; for example, he/she may have entere'
             'd a religious order. Cases in which the type of institution is unknown are included here, also.'
        31 = 'This sample member was unable to cooperate because of disability.'
        32 = 'This nonsample individual became main family nonresponse because the Head or Wife, whichever is sample, was unable to cooperate because of disability.'
        41 = 'This individual died between the 2005 and 2007 interviews; this individual died after becoming nonresponse for some other reason before the 2005 interview.'
        42 = 'This nonsample individual became main family nonresponse because the Head or Wife, whichever is sample, died.'
        45 = 'This individual was a sample member but has been adopted by unrelated nonsample persons and therefore has become nonsample.'
        51 = 'This individual, although followed for interview, was discovered to be nonsample:  office error.'
        52 = 'This individual should have been followed but was not:  office error.'
        53 = 'This individual was mistakenly included in two or more response families at once; this record is the duplicate, or erroneous, one.'
        54 = 'Listing error: this individual never existed or was not really living in the FU.'
        57 = 'Insufficient information that would permit recontact; no name or identifying information available'
        58 = 'Due to budgetary and/or time constraints, PSID staff decided not to take all of the usual steps to try to locate and/or persuade this FU.'
        59 = 'Limited number of contacts attempted:  miscellaneous office error (does not include codes 01-54 above or codes 91-99 below).'
        60 = 'This nonsample parent of a sample child is no longer eligible to be interviewed.'
        61 = 'This nonsample individual was associated with a family containing a person erroneously designated as followable; the erroneous person''s code is 45, 51, 53, 54, or 60.'
        80 = 'Individual connected with the Latino sample (ER30001=7001-9308); this sample was dropped beginning in 1996.  Individual dropped from the Census (SEO) sample due to budgetary constraints; this group wa'
             's dropped beginning in 1997.'
        91 = 'This individual moved out of the 2007 main family and was eligible to be followed, but the reason for nonresponse is NA.'
        92 = 'Individual moved out of the 2007 main family and was not eligible to be followed.'
        93 = 'All sample members of this FU united with other panel FUs; this individual was nonsample and therefore became nonresponse.'
        97 = 'This individual had not been born or moved in by the time of the 2007 interview (ER33901>0 and ER33902=0); individual from Immigrant 17 sample (ER30001=4001-4462)'
        98 = 'This individual became main family or mover-out nonresponse by 2005 and was not selected for recontact in 2007 (ER33801=0 and ER33901=0 and ER33942=0 or ER33801>0 and ER33802=71-89 and ER33901=0 and E'
             'R33942=0).'
        99 = 'NA; DK'
         0 = 'Inap.:  this individual was in a panel family in 2007 (ER33902=1-20)'
   ;
   VALUE ER34002F
    1 - 20 = 'Individuals in the family at the time of the 2009 interview'
   51 - 59 = 'Individuals in institutions at the time of the 2009 interview'
   71 - 80 = 'Individuals who moved out of the FU or out of institutions and established their own households between the 2007 and 2009 interviews'
   81 - 89 = 'Individuals who were living in 2007 but died by the time of the 2009 interview'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2009 or mover-out nonresponse by 2007 (ER34001=0)'
   ;
   VALUE ER34003F
        10 = 'Head in 2009; 2007 Head who was mover-out nonresponse by the time of the 2009 interview'
        20 = 'Legal Wife in 2009; 2007 Wife who was mover-out nonresponse by the time of the 2009 interview'
        22 = '"Wife"--female cohabitor who has lived with Head for 12 months or more; 2007 "Wife" who was mover-out nonresponse by the time of the 2009 interview'
        30 = 'Son or daughter of Head (includes adopted children but not stepchildren)'
        33 = 'Stepson or stepdaughter of Head (children of legal Wife [code 20] who are not children of Head)'
        35 = 'Son or daughter of "Wife" but not Head (includes only those children of mothers whose relationship to Head is 22 but who are not children of Head)'
        37 = 'Son-in-law or daughter-in-law of Head (includes stepchildren-in-law)'
        38 = 'Foster son or foster daughter, not legally adopted'
        40 = 'Brother or sister of Head (includes step and half sisters and brothers)'
        47 = 'Brother-in-law or sister-in-law of Head; i.e., brother or sister of legal Wife, or spouse of Head''s brother or sister'
        48 = 'Brother or sister of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        50 = 'Father or mother of Head (includes stepparents)'
        57 = 'Father-in-law or mother-in-law of Head (includes parents of legal wives [code 20] only)'
        58 = 'Father or mother of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        60 = 'Grandson or granddaughter of Head (includes grandchildren of legal Wife [code 20] only; those of a cohabitor are coded 97)'
        65 = 'Great-grandson or great-granddaughter of Head (includes great-grandchildren of legal Wife [code 20]; those of a cohabitor are coded 97)'
        66 = 'Grandfather or grandmother of Head (includes stepgrandparents)'
        67 = 'Grandfather or grandmother of legal Wife (code 20)'
        68 = 'Great-grandfather or great-grandmother of Head'
        69 = 'Great-grandfather or great-grandmother of legal Wife (code 20)'
        70 = 'Nephew or niece of Head'
        71 = 'Nephew or niece of legal Wife (code 20)'
        72 = 'Uncle or Aunt of Head'
        73 = 'Uncle or Aunt of legal Wife (code 20)'
        74 = 'Cousin of Head'
        75 = 'Cousin of legal Wife (code 20)'
        83 = 'Children of first-year cohabitor but not of Head (the parent of this child is coded 88)'
        88 = 'First-year cohabitor of Head'
        90 = 'Legal husband of Head'
        95 = 'Other relative of Head'
        96 = 'Other relative of legal Wife (code 20)'
        97 = 'Other relative of cohabitor (the cohabitor is code 22 or 88)'
        98 = 'Other nonrelatives (includes homosexual partners, friends of children of the FU, etc.)'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2009 or mover-out nonresponse by 2007 (ER34002=0)'
   ;
   VALUE ER34007F
         1 = 'Spouse in couple numbered 1'
         2 = 'Spouse in couple numbered 2'
         3 = 'Spouse in couple numbered 3'
         4 = 'Spouse in couple numbered 4'
         0 = 'Inap.:  not married or permanently cohabiting; spouse was not in FU at the time of the 2009 interview; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main fami'
             'ly nonresponse by 2009 or mover-out nonresponse by 2007 (ER34001=0)'
   ;
   VALUE ER34008F
         1 = 'Moved in or born between the 2007 and 2009 interviews; splitoff in 2009'
         2 = 'Appeared; moved in by the time the 2007 interview was taken but not included in FU for 2007 (i.e., listing error)'
         5 = 'Moved out of FU or out of an institution between the 2007 and 2009 interviews and was not included in a 2009 panel FU'
         6 = 'Moved out of FU and into an institution between the 2007 and 2009 interviews'
         7 = 'Living in 2007 but died by the time of the 2009 interview'
         8 = 'Disappeared; moved out prior to the 2007 interview, but included in FU for 2007 (usually a listing error)'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); in main family in both 2007 and 2009 (ER33902=1-20 and ER34002=1-20); in an institution in both 2007 and'
             ' 2009 (ER33902=51-59 and ER34002=51-59); main family nonresponse by 2009 or mover-out nonresponse by 2007 (ER34001=0); born or moved in after the 2009 interview (ER34001>0 and ER34002=0)'
   ;
   VALUE ER34011F
         1 = 'This individual was respondent'
         5 = 'This individual was not respondent; includes institutionalized individuals and mover-out nonresponse from 2009 (ER34002=51-89)'
         9 = 'NA; DK'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2009 or mover-out nonresponse by 2007 (ER34001=0)'
   ;
   VALUE ER34012F
    1 - 10 = 'Sequence number of the first other person in the Family Unit in 2009 that helped the Respondent complete the interview'
        97 = 'Other person outside the Family Unit helped the Respondent'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2009 or mover-out nonresponse by 2007 (ER34001=0); this individual was not th'
             'e respondent in 2009 (ER34011=5 or 9); this individual did not have a helper'
   ;
   VALUE ER34013F
    1 - 10 = 'Sequence number of the second other person in the Family Unit in 2009 that helped the Respondent complete the interview'
        97 = 'Other person outside the Family Unit helped the Respondent'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2009 or mover-out nonresponse by 2007 (ER34001=0); this individual was not th'
             'e respondent in 2009 (ER34011=5 or 9); this individual did not have a helper (ER34012=0); this individual did not have a second helper'
   ;
   VALUE ER34014F
    1 - 10 = 'Sequence number of the third other person in the Family Unit in 2009 that helped the Respondent complete the interview'
        97 = 'Other person outside the Family Unit helped the Respondent'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2009 or mover-out nonresponse by 2007 (ER34001=0); this individual was not th'
             'e respondent in 2009 (ER34011=5 or 9); this individual did not have a helper (ER34012=0); this individual did not have a second helper (ER34013=0); this individual did not have a third helper'
   ;
   VALUE ER34015F
         1 = 'Head who received TANF'
         2 = 'Wife/"Wife" who received TANF'
         3 = 'Other Family Unit Member who received TANF'
         0 = 'Inap.:  this individual did not receive TANF; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2009 or mover-out nonresponse by 2007 ('
             'ER34001=0); in an institution in both 2007 and 2009 (ER34002=51-59 and ER34008=0)'
   ;
   VALUE ER34016F
         1 = 'Working now'
         2 = 'Only temporarily laid off'
         3 = 'Looking for work, unemployed'
         4 = 'Retired'
         5 = 'Permanently disabled'
         6 = 'HouseWife; keeping house'
         7 = 'Student'
         8 = 'Other'
         9 = 'NA; DK'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2009 or mover-out nonresponse by 2007 (ER34001=0); mover-out nonresponse for'
             '2009, only if deceased (ER34002=81-89); in an institution in both 2007 and 2009 (ER34002=51-59 and ER34008=0); not a person aged 16 or older (ER34004=001-015); associated with 2009 FU but moved out be'
             'fore 2008 (ER34008=5, 6, or 8 and ER34010<2008) or moved in in 2009 (ER34008=1 and ER34010=2009)'
   ;
   VALUE ER34019F
         1 = 'Full-time student'
         2 = 'Part-time student'
         5 = 'Not enrolled in school'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2009 or mover-out nonresponse by 2007 (ER34001=0); Head or Wife/"Wife" in 200'
             '9 (ER34002=1-20 and ER34003=10, 20 or 22); in an institution in both 2007 and 2009 (ER34002=51-59 and ER34008=0); under age 16, or age 50 or older (ER34004=001-015, 050-125, or 999); associated with 2'
             '009 FU but moved out before 2008 (ER34008=5, 6, or 8 and ER34010<2008) or moved in in 2009 (ER34008=1 and ER34010=2009); last attended school before 2008 (ER34018=1901-2007, 9997, 9998, or 9999)'
   ;
   VALUE ER34020F
    1 - 17 = 'Highest grade or year of school completed'
        98 = 'DK'
        99 = 'NA'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2009 or mover-out nonresponse by 2007 (ER34001=0); in an institution in both'
             '2007 and 2009 (ER34002=51-59 and ER34008=0); not a person aged 16 or older (ER34004=001-015, 999); associated with 2009 FU but actually moved out before 2008 (ER34008=5, 6, or 8 and ER34010<2008) or m'
             'oved in in 2009 and was not a Head or Wife/"Wife" (ER34008=1 and ER34010=2009 and ER34002 GE 2 and ER34003 GE 30)'
   ;
   VALUE ER34021F
         1 = 'Yes, is in poor health'
         5 = 'No, is not in poor health'
         9 = 'NA'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2009 or mover-out nonresponse by 2007 (ER34001=0); in an institution or mover'
             '-out nonresponse in 2009 (ER34002=51-89); current Head or Wife (ER34002=1-2 and ER34003=10, 20, 22)'
   ;
   VALUE ER34022F
         1 = 'Employer provided health insurance'
         2 = 'Private health insurance purchased directly'
         3 = 'Medicare'
         4 = 'Medi-Gap/Supplemental'
         5 = 'Medicaid/Medical Assistance/[STATE PROGRAM]'
         6 = 'Military health care/TRICARE (Active)'
         7 = 'CHAMPUS/TRICARE/CHAMP-VA (Dependents, Veterans)'
         8 = 'Indian Health Insurance'
         9 = 'Other state-sponsored plan (not Medicaid)'
        10 = 'Other government program'
        97 = 'Other'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  not covered by health care plan; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2009 or mover-out nonresponse by 2007 (ER340'
             '01=0); moved out before 2007 (ER34002=71-89 and ER34010>0 and ER34010<2007)'
   ;
   VALUE ER34023F
         1 = 'Employer provided health insurance'
         2 = 'Private health insurance purchased directly'
         3 = 'Medicare'
         4 = 'Medi-Gap/Supplemental'
         5 = 'Medicaid/Medical Assistance/[STATE PROGRAM]'
         6 = 'Military health care/TRICARE (Active)'
         7 = 'CHAMPUS/TRICARE/CHAMP-VA (Dependents, Veterans)'
         8 = 'Indian Health Insurance'
         9 = 'Other state-sponsored plan (not Medicaid)'
        10 = 'Other government program'
        97 = 'Other'
         0 = 'Inap.:  no second mention; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2009 or mover-out nonresponse by 2007 (ER34001=0); moved o'
             'ut before 2007 (ER34002=71-89 and ER34010>0 and ER34010<2007); not covered by health care plan (ER34022=0); DK, NA, or RF to first mention (ER34022=98 or 99)'
   ;
   VALUE ER34024F
         1 = 'Employer provided health insurance'
         2 = 'Private health insurance purchased directly'
         3 = 'Medicare'
         4 = 'Medi-Gap/Supplemental'
         5 = 'Medicaid/Medical Assistance/[STATE PROGRAM]'
         6 = 'Military health care/TRICARE (Active)'
         7 = 'CHAMPUS/TRICARE/CHAMP-VA (Dependents, Veterans)'
         8 = 'Indian Health Insurance'
         9 = 'Other state-sponsored plan (not Medicaid)'
        10 = 'Other government program'
        97 = 'Other'
         0 = 'Inap.:  no third mention; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2009 or mover-out nonresponse by 2007 (ER34001=0); moved ou'
             't before 2007 (ER34002=71-89 and ER34010>0 and ER34010<2007); not covered by health care plan (ER34022=0); DK, NA, or RF to first mention (ER34022=98 or 99)'
   ;
   VALUE ER34025F
         1 = 'Employer provided health insurance'
         2 = 'Private health insurance purchased directly'
         3 = 'Medicare'
         4 = 'Medi-Gap/Supplemental'
         5 = 'Medicaid/Medical Assistance/[STATE PROGRAM]'
         6 = 'Military health care/TRICARE (Active)'
         7 = 'CHAMPUS/TRICARE/CHAMP-VA (Dependents, Veterans)'
         8 = 'Indian Health Insurance'
         9 = 'Other state-sponsored plan (not Medicaid)'
        10 = 'Other government program'
        97 = 'Other'
         0 = 'Inap.:  no fourth mention; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2009 or mover-out nonresponse by 2007 (ER34001=0); moved o'
             'ut before 2007 (ER34002=71-89 and ER34010>0 and ER34010<2007); not covered by health care plan (ER34022=0); DK, NA, or RF to first mention (ER34022=98 or 99)'
   ;
   VALUE ER34026F
         1 = 'Yes, it is the state health insurance plan for uninsured children'
         5 = 'No, it is not the state health insurance plan for uninsured children'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2009 or mover-out nonresponse by 2007 (ER34001=0); moved out before 2007 (ER3'
             '4002=71-89 and ER34010>0 and ER34010<2007); not covered by health care plan (ER34022=0); not covered by other health care plan and not less than 18 years old (ER34022=1-8 and ER33920 NE 9-10 or 97 and'
             ' ER33921 NE 9-10 or 97 and ER3922 NE 9-10 or 97 and ER34004>17)'
   ;
   VALUE ER34027F
    1 - 12 = 'Actual number of months covered in 2007'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  not covered in 2007; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2009 or mover-out nonresponse by 2007 (ER34001=0); moved'
             ' out before 2007 (ER34002=71-89 and ER34010>0 and ER34010<2007); not covered by health care plan (ER34022=0)'
   ;
   VALUE ER34028F
    1 - 12 = 'Actual number of months covered in 2008'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  not covered in 2008; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2009 or mover-out nonresponse by 2007 (ER34001=0); moved'
             ' out before 2007 (ER34002=71-89 and ER34010>0 and ER34010<2007); not covered by health care plan (ER34022=0)'
   ;
   VALUE ER34029F
         1 = 'This individual is a 2009 Head, Wife, or "Wife" who was covered by Medicare or was aged 65 or older, was the respondent, and did not give a useable Medicare number in prior waves but did in this wave.'
             ' '
         2 = 'This individual is a 2009 Head, Wife, or "Wife" who was covered by Medicare or was aged 65 or older, was the respondent, did not give a useable Medicare number in prior waves, and provided a Medicare'
             'number in this wave but it was not useable (e.g., missing digits).'
         5 = 'This individual is a 2009 Head, Wife, or "Wife" who was covered by Medicare or was aged 65 or older, was the respondent, did not give a useable Medicare number in prior waves and in the present wave d'
             'eclined to give his/her Medicare number (H62a=5), did not know/refused whether the number was a Medicare Claim or Railroad Retirement Board number, or did not know the number at H62c/H62e-f.'
         7 = 'This individual is associated with a responding FU and was a Head, Wife, or "Wife" in a prior wave, who was covered by Medicare, was the respondent, and provided a useable Medicare number in some prio'
             'r wave.'
         9 = 'This individual is a 2009 Head, Wife, or "Wife" who was covered by Medicare or was aged 65 or older, was the respondent, did not give a useable Medicare number in prior waves, and in the present wave'
             'whether a Medicare number could be provided was NA or DK (H62a=8 or 9).'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2009 or mover-out nonresponse by 2007 (ER34001=0); moved out before 2007 (ER3'
             '4002=71-89 and ER34010>0 and ER34010<2007); not Head or Wife/"Wife" in 2009 (ER34003>22 or ER34002>50); under age 65 and not covered by Medicare (ER34004<65 or 999 and neither ER34022, ER33920, ER3392'
             '1, nor ER33922=3);  not the respondent (ER34011=5)'
   ;
   VALUE ER34029AF
         1 = 'Only one job'
         2 = 'Two jobs'
         3 = 'Three jobs'
         4 = 'Four jobs or more'
         5 = 'Didn''t have a job'
         8 = 'Don''t know'
         9 = 'NA; refused'
         0 = 'Inap.: this person was a current Head/Spouse/Partner in 2009; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2009 or mover-out nonre'
             'sponse by 2007 (ER34001=0); OFUM in an institution in both 2007 and 2009 (ER34002=51-59 and ER34008=0); OFUM under age 16 (ER34004=001-015); OFUM associated with 2009 FU but moved out before 2008 (ER3'
             '4008=5, 6, or 8 and ER34010<2008) or OFUM moved in in 2009 (ER34008=1 and ER34010=2009)'
   ;
   VALUE ER34030F
         1 = 'Disability'
         2 = 'Retirement'
         3 = 'Survivor benefits; dependent of deceased recipient'
         4 = 'Any combination of codes 1-3 and 5-7'
         5 = 'Dependent of disabled recipient'
         6 = 'Dependent of retired recipient'
         7 = 'Other'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2009 or mover-out nonresponse by 2007 (ER34001=0); in an institution in 2009'
             '(ER34002=51-59); no Social Security income'
   ;
   VALUE ER34036F
         1 = 'This individual was eligible to be followed in 2009'
         5 = 'This individual was not eligible to be followed in 2009'
         0 = 'Inap.:  main family or mover-out nonresponse in 2007 and not selected for recontact in 2009; from Latino sample (ER30001=7001-9308)'
   ;
   VALUE ER34038F
         1 = 'This individual was eligible to be interviewed for the TA interview in 2009'
         0 = 'Inap.:  this individual was from Latino sample (ER30001= 7001-9308); not interviewed as part of 1997 CDS (ER33420=00, 02-98); main family nonresponse by 2009 (ER34001=0 and ER34002=0); mover-out nonre'
             'sponse in 2009 (ER34002=71-89)'
   ;
   VALUE ER34039F
         1 = 'Interview with eligible sample individual'
         3 = 'Refusal by the sample individual; partial/passive refusal; deliberate avoidance of interviewer (e.g., always too busy, repeated broken appointments, or failure to return calls)'
         4 = 'Sample individual lost; tracking efforts exhausted'
         5 = 'Sample individual incapacitated, had a permanent health condition, or institutionalized for health or mental reasons'
         6 = 'Sample individual deceased after PSID interview completed but before TA interview'
         7 = 'Some household member contacted, but eligible respondent not available to do interview; appointment broken, but no evidence of deliberately avoiding interview'
        13 = 'Refusal by someone other than the sample individual'
        30 = 'Sample individual away on military leave, in job corps, or in a non-detention facility'
        31 = 'Sample individual resided outside the US or in a remote area and uncontactable (e.g., no telephone)'
        34 = 'Sample individual incarcerated or in a youth, group, or detention home/center'
        70 = 'Sample individual was randomly dropped because two others in the family unit were also eligible (CDS only)'
        90 = 'Sample individual was initially thought to be ineligible because of nonresponse but discovered to be a resident in a response sample family after the interviewing period had ended.'
        95 = 'Office error--study ended, insufficient or inappropriate calls made, no mention of refusal'
         0 = 'Inap.:  this individual was from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); not interviewed as part of 1997 CDS (ER33420=00, 02-98); main family nonresponse by'
             '2009 (ER34001=0 and ER34002=0); mover-out nonresponse in 2009 (ER34002=71-89)'
   ;
   VALUE ER34040F
         1 = 'This individual was eligible to be interviewed for the DUST interview in 2009'
         5 = 'This individual was selected to be interviewed for the DUST interview in 2009 but was determined through screening that they were ineligible (ER34042=20-25).'
         0 = 'Inap.:  this individual was from  Latino sample (ER30001=7001-9308); main family nonresponse by 2009 (ER34001=0 and ER34002=0); mover-out nonresponse in 2009 (ER34002=71-89); this individual is neithe'
             'r Head nor Wife in 2009 (ER34002 GE 2 and ER34003 GT 20); either Head or Wife have birth year 1959 or later; Head and Wife are not a legally married pair'
   ;
   VALUE ER34041F
         1 = 'Selected for DUST'
         5 = 'Eligible but not selected for DUST'
         0 = 'Inap.:  this individual was from  Latino sample (ER30001=7001-9308); main family nonresponse by 2009 (ER34001=0 and ER34002=0); mover-out nonresponse in 2009 (ER34002=71-89); this individual is neithe'
             'r Head nor Wife in 2009 (ER34002 GE 2 and ER34003 GT 20); either Head or Wife have birth year 1959 or later; Head and Wife are not a legally married pair; not eligible for DUST (ER34040=0)'
   ;
   VALUE ER34042F
         1 = 'Interview with eligible individual'
         3 = 'Refusal by the eligible individual; partial/passive refusal; deliberate avoidance of interviewer (e.g., always too busy, repeated broken appointments, or failure to return calls)'
         4 = 'Many attempts to set an appointment but no evidence of refusal'
         5 = 'Individual lost; tracking efforts exhausted'
         6 = 'This individual is living with spouse but has a permanent condition that precludes ability to co-operate'
         7 = 'This individual is living with spouse but language for the main PSID interview was non-English or one spouse does not speak English'
         8 = 'Proxy R was used for main PSID interview'
        15 = 'Office error:  language wrongly coded as non-English in main PSID'
        16 = 'Office error:  coresident spouse has permanent condition and this individual was able to co-operate but was not interviewed'
        20 = 'Nonsample:  couple together for the 2009 PSID interview but one or both were deceased when the family was contacted for DUST.'
        21 = 'Nonsample:  couple together for the 2009 PSID interview but was separated or divorced by the time the family was contacted for DUST.'
        22 = 'Nonsample:  couple together for the 2009 PSID interview but one of them was institutionalized by the time the family was contacted for DUST.'
        23 = 'Nonsample:  couple were still married but were living in separate dwellings by the time the family was contacted for DUST.'
        25 = 'Nonsample:  age-ineligible couple but this individual and his/her spouse were wrongly listed as eligible and selected'
         0 = 'Inap.:   this individual was from  Latino sample (ER30001=7001-9308); main family nonresponse by 2009 (ER34001=0 and ER34002=0); mover-out nonresponse in 2009 (ER34002=71-89); this individual is neith'
             'er Head nor Wife in 2009 (ER34002 GE 2 and ER34003 GT 20); either Head or Wife have birth year 1959 or later; Head and Wife are not a legally married pair; not eligible for DUST (ER34040=0); not selec'
             'ted for DUST (ER34041=5)'
   ;
   VALUE ER34043F
         1 = 'This sample member was main family nonresponse and had been in the FU in 2007.'
         3 = 'This nonsample individual had been in the 2007 FU, and this FU became nonresponse in 2009.'
         4 = 'This sample member had been in an institution in 2007, but his or her family became nonresponse in 2009.'
         5 = 'This sample member, linked to a 2009 response family, was in an institution at the time of the 2009 interview.'
         6 = 'This sample member moved out or died between the 2007 and 2009 interviews.'
         8 = 'This nonsample individual moved out or died between the 2007 and 2009 interviews.'
         9 = 'This individual had not been born or moved in by the time of the 2009 interview; individual from Immigrant 17 sample (ER30001=4001-4462)'
        10 = 'This individual had become nonresponse by the time of the 2009 interview.'
        21 = 'Main family recontact: this person was selected for recontact in 2009, but the family was not successfully interviewed.'
        26 = 'Splitoff recontact: this sample member moved out of a 2009 recontact main family but was not successfully interviewed.'
        40 = 'Individual connected with the Latino sample (ER30001=7001-9308); this sample was dropped beginning in 1996.  Individual dropped from the Census (SEO) sample due to budgetary constraints; this group wa'
             's dropped beginning in 1997.'
        99 = 'NA; DK'
         0 = 'Inap.:  this individual was in a panel family in 2009 (ER34002=1-20).'
   ;
   VALUE ER34044F
         1 = 'Wave refusal by all eligible/available FU members.'
         2 = 'No one at home for contact during the interviewing period.'
         3 = 'Respondent absent; some FU member contacted, but not the appropriate respondent.'
         4 = 'Lost; unable to locate any member of the FU at all.'
         5 = 'FU is located too far away for interviewer contact.'
        10 = 'Panel refusal by all all eligible/available FU members.  These individuals will never be asked to participate in the study again, regardless of recontact efforts.'
        11 = 'This sample member was in the armed forces.'
        12 = 'This sample member was in an educational institution.'
        13 = 'This sample member was in a health care facility.'
        14 = 'This sample member was in jail or prison.'
        19 = 'This sample member was in some other type of institution; for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        21 = 'This nonsample individual became main family nonresponse because the Head or the Wife, whichever is the sample member, became institutionalized by joining the armed forces.'
        22 = 'This nonsample individual became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by entering an educational institution.'
        23 = 'This nonsample individual became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized by entering a health care facility.'
        24 = 'This nonsample individual became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized through imprisonment.'
        29 = 'This nonsample individual became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by some means other than the above; for example, he/she may have entere'
             'd a religious order. Cases in which the type of institution is unknown are included here, also.'
        31 = 'This sample member was unable to cooperate because of disability.'
        32 = 'This nonsample individual became main family nonresponse because the Head or Wife, whichever is sample, was unable to cooperate because of disability.'
        41 = 'This individual died between the 2007 and 2009 interviews; this individual died after becoming nonresponse for some other reason before the 2007 interview.'
        42 = 'This nonsample individual became main family nonresponse because the Head or Wife, whichever is sample, died.'
        45 = 'This individual was a sample member but has been adopted by unrelated nonsample persons and therefore has become nonsample.'
        51 = 'This individual, although followed for interview, was discovered to be nonsample:  office error.'
        52 = 'This individual should have been followed but was not:  office error.'
        53 = 'This individual was mistakenly included in two or more response families at once; this record is the duplicate, or erroneous, one.'
        54 = 'Listing error: this individual never existed or was not really living in the FU.'
        57 = 'Insufficient information that would permit recontact; no name or identifying information available'
        58 = 'Due to budgetary and/or time constraints, PSID staff decided not to take all of the usual steps to try to locate and/or persuade this FU.'
        59 = 'Limited number of contacts attempted:  miscellaneous office error (does not include codes 01-54 above or codes 91-99 below).'
        60 = 'This nonsample parent of a sample child is no longer eligible to be interviewed.'
        61 = 'This nonsample individual was associated with a family containing a person erroneously designated as followable; the erroneous person''s code is 45, 51, 53, 54, or 60.'
        80 = 'Individual connected with the Latino sample (ER30001=7001-9308); this sample was dropped beginning in 1996.  Individual dropped from the Census (SEO) sample due to budgetary constraints; this group wa'
             's dropped beginning in 1997.'
        91 = 'This individual moved out of the 2009 main family and was eligible to be followed, but the reason for nonresponse is NA.'
        92 = 'Individual moved out of the 2009 main family and was not eligible to be followed.'
        93 = 'All sample members of this FU united with other panel FUs; this individual was nonsample and therefore became nonresponse.'
        97 = 'This individual had not been born or moved in by the time of the 2009 interview (ER34001>0 and ER34002=0); individual from Immigrant 17 sample (ER30001=4001-4462)'
        98 = 'This individual became main family or mover-out nonresponse by 2007 and was not selected for recontact in 2009 (ER33901=0 and ER34001=0 and ER34036=0 or ER33901>0 and ER33902=71-89 and ER34001=0 and E'
             'R34036=0).'
        99 = 'NA; DK'
         0 = 'Inap.:  this individual was in a panel family in 2009 (ER34002=1-20)'
   ;
   VALUE ER34102F
    1 - 20 = 'Individuals in the family at the time of the 2011 interview'
   51 - 59 = 'Individuals in institutions at the time of the 2011 interview'
   71 - 80 = 'Individuals who moved out of the FU or out of institutions and established their own households between the 2009 and 2011 interviews'
   81 - 89 = 'Individuals who were living in 2009 but died by the time of the 2011 interview'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2011 or mover-out nonresponse by 2009 (ER34101=0)'
   ;
   VALUE ER34103F
        10 = 'Head in 2011; 2009 Head who was mover-out nonresponse by the time of the 2011 interview'
        20 = 'Legal Wife in 2011; 2009 Wife who was mover-out nonresponse by the time of the 2011 interview'
        22 = '"Wife"--female cohabitor who has lived with Head for 12 months or more; 2009 "Wife" who was mover-out nonresponse by the time of the 2011 interview'
        30 = 'Son or daughter of Head (includes adopted children but not stepchildren)'
        33 = 'Stepson or stepdaughter of Head (children of legal Wife [code 20] who are not children of Head)'
        35 = 'Son or daughter of "Wife" but not Head (includes only those children of mothers whose relationship to Head is 22 but who are not children of Head)'
        37 = 'Son-in-law or daughter-in-law of Head (includes stepchildren-in-law)'
        38 = 'Foster son or foster daughter, not legally adopted'
        40 = 'Brother or sister of Head (includes step and half sisters and brothers)'
        47 = 'Brother-in-law or sister-in-law of Head; i.e., brother or sister of legal Wife, or spouse of Head''s brother or sister'
        48 = 'Brother or sister of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        50 = 'Father or mother of Head (includes stepparents)'
        57 = 'Father-in-law or mother-in-law of Head (includes parents of legal wives [code 20] only)'
        58 = 'Father or mother of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        60 = 'Grandson or granddaughter of Head (includes grandchildren of legal Wife [code 20] only; those of a cohabitor are coded 97)'
        65 = 'Great-grandson or great-granddaughter of Head (includes great-grandchildren of legal Wife [code 20]; those of a cohabitor are coded 97)'
        66 = 'Grandfather or grandmother of Head (includes stepgrandparents)'
        67 = 'Grandfather or grandmother of legal Wife (code 20)'
        68 = 'Great-grandfather or great-grandmother of Head'
        69 = 'Great-grandfather or great-grandmother of legal Wife (code 20)'
        70 = 'Nephew or niece of Head'
        71 = 'Nephew or niece of legal Wife (code 20)'
        72 = 'Uncle or Aunt of Head'
        73 = 'Uncle or Aunt of legal Wife (code 20)'
        74 = 'Cousin of Head'
        75 = 'Cousin of legal Wife (code 20)'
        83 = 'Children of first-year cohabitor but not of Head (the parent of this child is coded 88)'
        88 = 'First-year cohabitor of Head'
        90 = 'Legal husband of Head'
        95 = 'Other relative of Head'
        96 = 'Other relative of legal Wife (code 20)'
        97 = 'Other relative of cohabitor (the cohabitor is code 22 or 88)'
        98 = 'Other nonrelatives (includes homosexual partners, friends of children of the FU, etc.)'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2011 or mover-out nonresponse by 2009 (ER34102=0)'
   ;
   VALUE ER34107F
         1 = 'Spouse in couple numbered 1'
         2 = 'Spouse in couple numbered 2'
         3 = 'Spouse in couple numbered 3'
         4 = 'Spouse in couple numbered 4'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2011 or mover-out nonresponse by 2009 (ER34101=0); spouse was not in FU at th'
             'e time of the 2011 interview; not married or permanently cohabiting'
   ;
   VALUE ER34108F
         1 = 'Moved in or born between the 2009 and 2011 interviews; splitoff in 2011'
         2 = 'Appeared; moved in by the time the 2009 interview was taken but not included in FU for 2009 (i.e., listing error)'
         5 = 'Moved out of FU or out of an institution between the 2009 and 2011 interviews and was not included in a 2011 panel FU'
         6 = 'Moved out of FU and into an institution between the 2009 and 2011 interviews'
         7 = 'Living in 2009 but died by the time of the 2011 interview'
         8 = 'Disappeared; moved out prior to the 2009 interview, but included in FU for 2009 (usually a listing error)'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); in main family in both 2009 and 2011 (ER34002=1-20 and ER34102=1-20); in an institution in both 2009 and'
             ' 2011 (ER34002=51-59 and ER34102=51-59); main family nonresponse by 2011 or mover-out nonresponse by 2009 (ER34101=0); born or moved in after the 2011 interview (ER34101>0 and ER34102=0)'
   ;
   VALUE ER34111F
         1 = 'This individual was respondent'
         5 = 'This individual was not respondent; includes institutionalized individuals and mover-out nonresponse from 2011 (ER34102=51-89)'
         9 = 'NA; DK'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2011 or mover-out nonresponse by 2009 (ER34101=0)'
   ;
   VALUE ER34112F
    1 - 10 = 'Sequence number of the first other person in the Family Unit in 2011 that helped the Respondent complete the interview'
        97 = 'Other person outside the Family Unit helped the Respondent'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2011 or mover-out nonresponse by 2009 (ER34101=0); this individual was not th'
             'e respondent in 2011 (ER34111=5 or 9); this individual did not have a helper'
   ;
   VALUE ER34113F
    1 - 10 = 'Sequence number of the second other person in the Family Unit in 2011 that helped the Respondent complete the interview'
        97 = 'Other person outside the Family Unit helped the Respondent'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2011 or mover-out nonresponse by 2009 (ER34101=0); this individual was not th'
             'e respondent in 2011 (ER34111=5 or 9); this individual did not have a helper (ER34112=0); this individual did not have a second helper'
   ;
   VALUE ER34114F
    1 - 10 = 'Sequence number of the third other person in the Family Unit in 2011 that helped the Respondent complete the interview'
        97 = 'Other person outside the Family Unit helped the Respondent'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2011 or mover-out nonresponse by 2009 (ER34101=0); this individual was not th'
             'e respondent in 2011 (ER34111=5 or 9); this individual did not have a helper (ER34112=0); this individual did not have a second helper (ER34113=0); this individual did not have a third helper'
   ;
   VALUE ER34115F
         1 = 'Head who received TANF'
         2 = 'Wife/"Wife" who received TANF'
         3 = 'Other Family Unit Member who received TANF'
         0 = 'Inap.:  this individual did not receive TANF; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2011 or mover-out nonresponse by 2009 ('
             'ER34101=0); in an institution in both 2009 and 2011 (ER34102=51-59 and ER34108=0)'
   ;
   VALUE ER34116F
         1 = 'Working now'
         2 = 'Only temporarily laid off'
         3 = 'Looking for work, unemployed'
         4 = 'Retired'
         5 = 'Permanently disabled'
         6 = 'HouseWife; keeping house'
         7 = 'Student'
         8 = 'Other'
         9 = 'NA; DK'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2011 or mover-out nonresponse by 2009 (ER34101=0); mover-out nonresponse for'
             '2011, only if deceased (ER34102=81-89); in an institution in both 2009 and 2011 (ER34102=51-59 and ER34108=0); not a person aged 16 or older (ER34104=001-015); associated with 2011 FU but moved out be'
             'fore 2010 (ER34108=5, 6, or 8 and ER34110<2010) or moved in in 2011 (ER34108=1 and ER34110=2011)'
   ;
   VALUE ER34119F
    1 - 17 = 'Highest grade or year of school completed'
        98 = 'DK'
        99 = 'NA'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2011 or mover-out nonresponse by 2009 (ER34101=0); in an institution in both'
             '2009 and 2011 (ER34102=51-59 and ER34108=0); not a person aged 16 or older (ER34104=001-015, 999); associated with 2011 FU but actually moved out before 2010 (ER34108=5, 6, or 8 and ER34110<2010) or m'
             'oved in in 2011 and was not a Head or Wife/"Wife" (ER34108=1 and ER34110=2011 and ER34102 GE 2 and ER34103 GE 30)'
   ;
   VALUE ER34120F
         1 = 'Yes, is in poor health'
         5 = 'No, is not in poor health'
         9 = 'NA'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2011 or mover-out nonresponse by 2009 (ER34101=0); in an institution or mover'
             '-out nonresponse in 2011 (ER34102=51-89); current Head or Wife (ER34102=1-2 and ER34103=10, 20, 22)'
   ;
   VALUE ER34121F
         1 = 'Employer provided health insurance'
         2 = 'Private health insurance purchased directly'
         3 = 'Medicare'
         4 = 'Medi-Gap/Supplemental'
         5 = 'Medicaid/Medical Assistance/[STATE PROGRAM]'
         6 = 'Military health care/TRICARE (Active)'
         7 = 'CHAMPUS/TRICARE/CHAMP-VA (Dependents, Veterans)'
         8 = 'Indian Health Insurance'
         9 = 'Other state-sponsored plan (not Medicaid)'
        10 = 'Other government program'
        97 = 'Other'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  not covered by health care plan; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2011 or mover-out nonresponse by 2009 (ER341'
             '01=0); moved out before 2009 (ER34102=71-89 and ER34110>0 and ER34110<2009)'
   ;
   VALUE ER34122F
         1 = 'Employer provided health insurance'
         2 = 'Private health insurance purchased directly'
         3 = 'Medicare'
         4 = 'Medi-Gap/Supplemental'
         5 = 'Medicaid/Medical Assistance/[STATE PROGRAM]'
         6 = 'Military health care/TRICARE (Active)'
         7 = 'CHAMPUS/TRICARE/CHAMP-VA (Dependents, Veterans)'
         8 = 'Indian Health Insurance'
         9 = 'Other state-sponsored plan (not Medicaid)'
        10 = 'Other government program'
        97 = 'Other'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2011 or mover-out nonresponse by 2009 (ER34101=0); moved out before 2009 (ER3'
             '4102=71-89 and ER34110>0 and ER34110<2009); not covered by health care plan (ER34121=0); DK, NA, or RF to first mention (ER34121=98 or 99); no second mention'
   ;
   VALUE ER34123F
         1 = 'Employer provided health insurance'
         2 = 'Private health insurance purchased directly'
         3 = 'Medicare'
         4 = 'Medi-Gap/Supplemental'
         5 = 'Medicaid/Medical Assistance/[STATE PROGRAM]'
         6 = 'Military health care/TRICARE (Active)'
         7 = 'CHAMPUS/TRICARE/CHAMP-VA (Dependents, Veterans)'
         8 = 'Indian Health Insurance'
         9 = 'Other state-sponsored plan (not Medicaid)'
        10 = 'Other government program'
        97 = 'Other'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2011 or mover-out nonresponse by 2009 (ER34101=0); moved out before 2009 (ER3'
             '4102=71-89 and ER34110>0 and ER34110<2009); not covered by health care plan (ER34121=0); DK, NA, or RF to first mention (ER34121=98 or 99); less than three mentions'
   ;
   VALUE ER34124F
         1 = 'Employer provided health insurance'
         2 = 'Private health insurance purchased directly'
         3 = 'Medicare'
         4 = 'Medi-Gap/Supplemental'
         5 = 'Medicaid/Medical Assistance/[STATE PROGRAM]'
         6 = 'Military health care/TRICARE (Active)'
         7 = 'CHAMPUS/TRICARE/CHAMP-VA (Dependents, Veterans)'
         8 = 'Indian Health Insurance'
         9 = 'Other state-sponsored plan (not Medicaid)'
        10 = 'Other government program'
        97 = 'Other'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2011 or mover-out nonresponse by 2009 (ER34101=0); moved out before 2009 (ER3'
             '4102=71-89 and ER34110>0 and ER34110<2009); not covered by health care plan (ER34121=0); DK, NA, or RF to first mention (ER34121=98 or 99); less than four mentions'
   ;
   VALUE ER34125F
         1 = 'Yes, this individual is covered by the state health insurance plan for uninsured children'
         5 = 'No, this individual is not covered by the state health insurance plan for uninsured children'
         8 = 'DK'
         9 = 'NA'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2011 or mover-out nonresponse by 2009 (ER34101=0); moved out before 2009 (ER3'
             '4102=71-89 and ER34110>0 and ER34110<2009); not covered by health care plan (ER34121=0); not covered by other health care plan and not less than 18 years old (ER34121=1-8 and ER33920 NE 9-10 or 97 and'
             ' ER33921 NE 9-10 or 97 and ER3922 NE 9-10 or 97 and ER34104>17)'
   ;
   VALUE ER34126F
    1 - 12 = 'Actual number of months covered in 2009'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2011 or mover-out nonresponse by 2009 (ER34101=0); moved out before 2009 (ER3'
             '4102=71-89 and ER34110>0 and ER34110<2009); not covered by health care plan (ER34121=0); not covered in 2009'
   ;
   VALUE ER34127F
    1 - 12 = 'Actual number of months covered in 2010'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2011 or mover-out nonresponse by 2009 (ER34101=0); moved out before 2009 (ER3'
             '4102=71-89 and ER34110>0 and ER34110<2009); not covered by health care plan (ER34121=0); not covered in 2010'
   ;
   VALUE ER34128F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2011 or mover-out nonresponse by 2009 (ER34101=0); moved out before 2009 (ER3'
             '4102=71-89 and ER34110>0 and ER34110<2009)'
   ;
   VALUE ER34129F
         1 = 'Employer provided health insurance'
         2 = 'Private health insurance purchased'
         3 = 'Medicare'
         4 = 'Medi-Gap/Supplemental'
         5 = 'Medicaid/[STATEMEDPROG]/[SCHIPNAME]'
         6 = 'Military Health Care/Tricare (Active duty)'
         7 = 'Tricare/Champus/Champ VA (Dependents, veterans)'
         8 = 'Indian Health Insurance'
         9 = 'Other state-sponsored plan (not Medicaid)'
        10 = 'Other government program'
        97 = 'Other health insurance'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2011 or mover-out nonresponse by 2009 (ER34101=0); moved out before 2009 (ER3'
             '4102=71-89 and ER34110>0 and ER34110<2009); does not have health insurance of health care coverage now (ER34128=5); DK, NA, or RF whether has health insurance or health care coverage now (ER34128=8 or'
             ' 9)'
   ;
   VALUE ER34130F
         1 = 'Employer provided health insurance'
         2 = 'Private health insurance purchased'
         3 = 'Medicare'
         4 = 'Medi-Gap/Supplemental'
         5 = 'Medicaid/[STATEMEDPROG]/[SCHIPNAME]'
         6 = 'Military Health Care/Tricare (Active duty)'
         7 = 'Tricare/Champus/Champ VA (Dependents, veterans)'
         8 = 'Indian Health Insurance'
         9 = 'Other state-sponsored plan (not Medicaid)'
        10 = 'Other government program'
        97 = 'Other health insurance'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2011 or mover-out nonresponse by 2009 (ER34101=0); moved out before 2009 (ER3'
             '4102=71-89 and ER34110>0 and ER34110<2009); does not have health insurance of health care coverage now (ER34128=5); DK, NA, or RF whether has health insurance or health care coverage now (ER34128=8 or'
             ' 9); NA, DK to first mention (ER34129=98 or 99); from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); no second mention'
   ;
   VALUE ER34131F
         1 = 'Employer provided health insurance'
         2 = 'Private health insurance purchased'
         3 = 'Medicare'
         4 = 'Medi-Gap/Supplemental'
         5 = 'Medicaid/[STATEMEDPROG]/[SCHIPNAME]'
         6 = 'Military Health Care/Tricare (Active duty)'
         7 = 'Tricare/Champus/Champ VA (Dependents, veterans)'
         8 = 'Indian Health Insurance'
         9 = 'Other state-sponsored plan (not Medicaid)'
        10 = 'Other government program'
        97 = 'Other health insurance'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2011 or mover-out nonresponse by 2009 (ER34101=0); moved out before 2009 (ER3'
             '4102=71-89 and ER34110>0 and ER34110<2009); does not have health insurance of health care coverage now (ER34128=5); DK, NA, or RF whether has health insurance or health care coverage now (ER34128=8 or'
             ' 9); NA, DK to first mention (ER34129=98 or 99); less than three mentions'
   ;
   VALUE ER34132F
    1 - 10 = 'Sequence number of the first person in the Family Unit in 2011 whose employer provided this individual''s health insurance/coverage.'
        96 = 'Parent of Family Unit member who lives outside of FU'
        97 = 'Other person outside of FU'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2011 or mover-out nonresponse by 2009 (ER34101=0); moved out before 2009 (ER3'
             '4102=71-89 and ER34110>0 and ER34110<2009); does not have health insurance of health care coverage now (ER34128=5); DK, NA, or RF whether has health insurance or health care coverage now (ER34128=8 or'
             ' 9); does not have employer provided health insurance (ER34129 ne 1 and ER34130 ne 1 and ER34131 ne 1)'
   ;
   VALUE ER34133F
    1 - 10 = 'Sequence number of the second person in the Family Unit in 2011 whose employer provided this individual''s health insurance/coverage.'
        96 = 'Parent of Family Unit member who lives outside of FU'
        97 = 'Other person outside of FU'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2011 or mover-out nonresponse by 2009 (ER34101=0); moved out before 2009 (ER3'
             '4102=71-89 and ER34110>0 and ER34110<2009); does not have health insurance of health care coverage now (ER34128=5); DK, NA, or RF whether has health insurance or health care coverage now (ER34128=8 or'
             ' 9); does not have employer provided health insurance (ER34129 ne 1 and ER34130 ne 1 and ER34131 ne 1); no second mention'
   ;
   VALUE ER34134F
    1 - 10 = 'Sequence number of the first person in the Family Unit in 2011 who was the policy holder on this individual''s private health insurance/coverage.'
        96 = 'Parent of Family Unit member who lives outside of FU'
        97 = 'Other person outside of FU'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2011 or mover-out nonresponse by 2009 (ER34101=0); moved out before 2009 (ER3'
             '4102=71-89 and ER34110>0 and ER34110<2009); does not have health insurance of health care coverage now (ER34128=5); DK, NA, or RF whether has health insurance or health care coverage now (ER34128=8 or'
             ' 9); does not have private health insurance (ER34129 ne 2 and ER34130 ne 2 and ER34131 ne 2)'
   ;
   VALUE ER34135F
    1 - 10 = 'Sequence number of the second person in the Family Unit in 2011 who was the policy holder on this individual''s private health insurance/coverage.'
        96 = 'Parent of Family Unit member who lives outside of FU'
        97 = 'Other person outside of FU'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2011 or mover-out nonresponse by 2009 (ER34101=0); moved out before 2009 (ER3'
             '4102=71-89 and ER34110>0 and ER34110<2009); does not have health insurance of health care coverage now (ER34128=5); DK, NA, or RF whether has health insurance or health care coverage now (ER34128=8 or'
             ' 9); does not have private health insurance (ER34129 ne 2 and ER34130 ne 2 and ER34131 ne 2); no second mention'
   ;
   VALUE ER34136F
         1 = 'This individual is a 2011 Head, Wife, or "Wife" who was covered by Medicare or was aged 65 or older, was the respondent, and did not give a useable Medicare number in prior waves but did in this wave.'
             ' '
         2 = 'This individual is a 2011 Head, Wife, or "Wife" who was covered by Medicare or was aged 65 or older, was the respondent, did not give a useable Medicare number in prior waves, and provided a Medicare'
             'number in this wave but it was not useable (e.g., missing digits).'
         5 = 'This individual is a 2011 Head, Wife, or "Wife" who was covered by Medicare or was aged 65 or older, was the respondent, did not give a useable Medicare number in prior waves and in the present wave d'
             'eclined to give his/her Medicare number (H62a=5), did not know/refused whether the number was a Medicare Claim or Railroad Retirement Board number, or did not know the number at H62c/H62e-f.'
         7 = 'This individual is associated with a responding FU and was a Head, Wife, or "Wife" in a prior wave, who was covered by Medicare, was the respondent, and provided a useable Medicare number in some prio'
             'r wave.'
         9 = 'This individual is a 2011 Head, Wife, or "Wife" who was covered by Medicare or was aged 65 or older, was the respondent, did not give a useable Medicare number in prior waves, and in the present wave'
             'whether a Medicare number could be provided was NA or DK (H62a=8 or 9).'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2011 or mover-out nonresponse by 2009 (ER34101=0); moved out before 2009 (ER3'
             '4102=71-89 and ER34110>0 and ER34110<2009); not Head or Wife/"Wife" in 2011 (ER34103>22 or ER34102>50); under age 65 and not covered by Medicare (ER34104<65 or 999 and neither ER34121, ER34122, ER3412'
             '3, ER34124, ER34129, ER34130, nor ER34131=3);  not the respondent (ER34111=5)'
   ;
   VALUE ER34136AF
         1 = 'Only one job'
         2 = 'Two jobs'
         3 = 'Three jobs'
         4 = 'Four jobs or more'
         5 = 'Didn''t have a job'
         8 = 'Don''t know'
         9 = 'NA; refused'
         0 = 'Inap.: this person was a current Head/Spouse/Partner in 2011; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2011 or mover-out nonre'
             'sponse by 2009 (ER34101=0); OFUM in an institution in both 2009 and 2011 (ER34102=51-59 and ER34108=0); OFUM under age 16 (ER34104=001-015); OFUM associated with 2011 FU but moved out before 2010 (ER3'
             '4108=5, 6, or 8 and ER34110<2010) or OFUM moved in in 2011 (ER34108=1 and ER34110=2011)'
   ;
   VALUE ER34148F
         1 = 'This individual was eligible to be followed in 2011'
         5 = 'This individual was not eligible to be followed in 2011'
         0 = 'Inap.:  main family or mover-out nonresponse in 2009 and not selected for recontact in 2011; from Latino sample (ER30001=7001-9308)'
   ;
   VALUE ER34150F
         1 = 'This individual was eligible to be interviewed for the TA interview in 2011'
         0 = 'Inap.:  this individual was from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); not interviewed as part of 1997 CDS (ER33420=00, 02-98); main family nonresponse by'
             '2011 (ER34101=0 and ER34102=0); mover-out nonresponse in 2011 (ER34102=71-89)'
   ;
   VALUE ER34151F
         1 = 'Interview with eligible sample individual'
         3 = 'Refusal by the sample individual; partial/passive refusal; deliberate avoidance of interviewer (e.g., always too busy, repeated broken appointments, or failure to return calls)'
         4 = 'Sample individual lost; tracking efforts exhausted'
         5 = 'Sample individual incapacitated, had a permanent health condition, or institutionalized for health or mental reasons'
         6 = 'Sample individual deceased after PSID interview completed but before TA interview'
         7 = 'Some household member contacted, but eligible respondent not available to do interview; appointment broken, but no evidence of deliberately avoiding interview'
        10 = 'Adamant refusal by the eligible sample member. These individuals will never be asked to participate in the TA study again, regardless of recontact efforts.'
        13 = 'Refusal by someone other than the sample individual'
        30 = 'Sample individual away on military leave, in job corps, or in a non-detention facility'
        31 = 'Sample individual resided outside the US or in a remote area and uncontactable (e.g., no telephone)'
        34 = 'Sample individual incarcerated or in a youth, group, or detention home/center'
        70 = 'Sample individual was randomly dropped because two others in the family unit were also eligible (CDS only)'
        90 = 'Sample individual was initially thought to be ineligible because of nonresponse but discovered to be a resident in a response sample family after the interviewing period had ended.'
        95 = 'Office error--study ended, insufficient or inappropriate calls made, no mention of refusal'
         0 = 'Inap.:  this individual was from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); not interviewed as part of 1997 CDS (ER33420=00, 02-98); main family nonresponse by'
             '2011 (ER34101=0 and ER34102=0); mover-out nonresponse in 2011 (ER34102=71-89)'
   ;
   VALUE ER34152F
         1 = 'This sample member was main family nonresponse and had been in the FU in 2009.'
         3 = 'This nonsample individual had been in the 2009 FU, and this FU became nonresponse in 2011.'
         4 = 'This sample member had been in an institution in 2009, but his or her family became nonresponse in 2011.'
         5 = 'This sample member, linked to a 2011 response family, was in an institution at the time of the 2011 interview.'
         6 = 'This sample member moved out or died between the 2009 and 2011 interviews.'
         8 = 'This nonsample individual moved out or died between the 2009 and 2011 interviews.'
         9 = 'This individual had not been born or moved in by the time of the 2011 interview; individual from Immigrant 17 sample (ER30001=4001-4462)'
        10 = 'This individual had become nonresponse by the time of the 2011 interview.'
        21 = 'Main family recontact: this person was selected for recontact in 2011, but the family was not successfully interviewed.'
        26 = 'Splitoff recontact: this sample member moved out of a 2011 recontact main family but was not successfully interviewed.'
        40 = 'Individual connected with the Latino sample (ER30001=7001-9308); this sample was dropped beginning in 1996.  Individual dropped from the Census (SEO) sample due to budgetary constraints; this group wa'
             's dropped beginning in 1997.'
        99 = 'NA; DK'
         0 = 'Inap.:  this individual was in a panel family in 2011 (ER34102=1-20).'
   ;
   VALUE ER34153F
         1 = 'Wave refusal by all eligible/available FU members.'
         2 = 'No one at home for contact during the interviewing period.'
         3 = 'Respondent absent; some FU member contacted, but not the appropriate respondent.'
         4 = 'Lost; unable to locate any member of the FU at all.'
         5 = 'FU is located too far away for interviewer contact.'
        10 = 'Panel refusal by all all eligible/available FU members.  These individuals will never be asked to participate in the study again, regardless of recontact efforts.'
        11 = 'This sample member was in the armed forces.'
        12 = 'This sample member was in an educational institution.'
        13 = 'This sample member was in a health care facility.'
        14 = 'This sample member was in jail or prison.'
        15 = 'Panel refusal by all all eligible/available FU members. Sample individual (or other FU member on their behalf) contacted the study or IRB (by letter, email, phone call to the 800#, or respondent-initi'
             'ated phone call to the interviewer) with a strong request to be removed from the study.'
        19 = 'This sample member was in some other type of institution; for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        21 = 'This nonsample individual became main family nonresponse because the Head or the Wife, whichever is the sample member, became institutionalized by joining the armed forces.'
        22 = 'This nonsample individual became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by entering an educational institution.'
        23 = 'This nonsample individual became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized by entering a health care facility.'
        24 = 'This nonsample individual became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized through imprisonment.'
        25 = 'This individual became main family nonresponse because the sample member contacted the study or IRB with a request to be removed from the study (sample individual is coded 15 for this wave).'
        29 = 'This nonsample individual became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by some means other than the above; for example, he/she may have entere'
             'd a religious order. Cases in which the type of institution is unknown are included here, also.'
        31 = 'This sample member was unable to cooperate because of disability.'
        32 = 'This nonsample individual became main family nonresponse because the Head or Wife, whichever is sample, was unable to cooperate because of disability.'
        41 = 'This individual died between the 2009 and 2011 interviews; this individual died after becoming nonresponse for some other reason before the 2009 interview.'
        42 = 'This nonsample individual became main family nonresponse because the Head or Wife, whichever is sample, died.'
        45 = 'This individual was a sample member but has been adopted by unrelated nonsample persons and therefore has become nonsample.'
        51 = 'This individual, although followed for interview, was discovered to be nonsample:  office error.'
        52 = 'This individual should have been followed but was not:  office error.'
        53 = 'This individual was mistakenly included in two or more response families at once; this record is the duplicate, or erroneous, one.'
        54 = 'Listing error: this individual never existed or was not really living in the FU.'
        57 = 'Insufficient information that would permit recontact; no name or identifying information available'
        58 = 'Due to budgetary and/or time constraints, PSID staff decided not to take all of the usual steps to try to locate and/or persuade this FU.'
        59 = 'Limited number of contacts attempted:  miscellaneous office error (does not include codes 01-54 above or codes 91-99 below).'
        60 = 'This nonsample parent of a sample child is no longer eligible to be interviewed.'
        61 = 'This nonsample individual was associated with a family containing a person erroneously designated as followable; the erroneous person''s code is 45, 51, 53, 54, or 60.'
        80 = 'Individual connected with the Latino sample (ER30001=7001-9308); this sample was dropped beginning in 1996.  Individual dropped from the Census (SEO) sample due to budgetary constraints; this group wa'
             's dropped beginning in 1997.'
        91 = 'This individual moved out of the 2011 main family and was eligible to be followed, but the reason for nonresponse is NA.'
        92 = 'Individual moved out of the 2011 main family and was not eligible to be followed.'
        93 = 'All sample members of this FU united with other panel FUs; this individual was nonsample and therefore became nonresponse.'
        97 = 'This individual had not been born or moved in by the time of the 2011 interview (ER34101>0 and ER34102=0); individual from Immigrant 17 sample (ER30001=4001-4462)'
        98 = 'This individual became main family or mover-out nonresponse by 2009 and was not selected for recontact in 2011 (ER34001=0 and ER34101=0 and ER34148=0 or ER34001>0 and ER34002=71-89 and ER34101=0 and E'
             'R34148=0).'
        99 = 'NA; DK'
         0 = 'Inap.:  this individual was in a panel family in 2011 (ER34102=1-20)'
   ;
   VALUE ER34202F
    1 - 20 = 'Individuals in the family at the time of the 2013 interview'
   51 - 59 = 'Individuals in institutions at the time of the 2013 interview'
   71 - 80 = 'Individuals who moved out of the FU or out of institutions and established their own households between the 2011 and 2013 interviews'
   81 - 89 = 'Individuals who were living in 2011 but died by the time of the 2013 interview'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2013 or mover-out nonresponse by 2011 (ER34201=0)'
   ;
   VALUE ER34203F
        10 = 'Head in 2013; 2011 Head who was mover-out nonresponse by the time of the 2013 interview'
        20 = 'Legal Wife in 2013; 2011 Wife who was mover-out nonresponse by the time of the 2013 interview'
        22 = '"Wife"--female cohabitor who has lived with Head for 12 months or more; 2011 "Wife" who was mover-out nonresponse by the time of the 2013 interview'
        30 = 'Son or daughter of Head (includes adopted children but not stepchildren)'
        33 = 'Stepson or stepdaughter of Head (children of legal Wife [code 20] who are not children of Head)'
        35 = 'Son or daughter of "Wife" but not Head (includes only those children of mothers whose relationship to Head is 22 but who are not children of Head)'
        37 = 'Son-in-law or daughter-in-law of Head (includes stepchildren-in-law)'
        38 = 'Foster son or foster daughter, not legally adopted'
        40 = 'Brother or sister of Head (includes step and half sisters and brothers)'
        47 = 'Brother-in-law or sister-in-law of Head; i.e., brother or sister of legal Wife, or spouse of Head''s brother or sister'
        48 = 'Brother or sister of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        50 = 'Father or mother of Head (includes stepparents)'
        57 = 'Father-in-law or mother-in-law of Head (includes parents of legal wives [code 20] only)'
        58 = 'Father or mother of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        60 = 'Grandson or granddaughter of Head (includes grandchildren of legal Wife [code 20] only; those of a cohabitor are coded 97)'
        65 = 'Great-grandson or great-granddaughter of Head (includes great-grandchildren of legal Wife [code 20]; those of a cohabitor are coded 97)'
        66 = 'Grandfather or grandmother of Head (includes stepgrandparents)'
        67 = 'Grandfather or grandmother of legal Wife (code 20)'
        68 = 'Great-grandfather or great-grandmother of Head'
        69 = 'Great-grandfather or great-grandmother of legal Wife (code 20)'
        70 = 'Nephew or niece of Head'
        71 = 'Nephew or niece of legal Wife (code 20)'
        72 = 'Uncle or Aunt of Head'
        73 = 'Uncle or Aunt of legal Wife (code 20)'
        74 = 'Cousin of Head'
        75 = 'Cousin of legal Wife (code 20)'
        83 = 'Children of first-year cohabitor but not of Head (the parent of this child is coded 88)'
        88 = 'First-year cohabitor of Head'
        90 = 'Legal husband of Head'
        95 = 'Other relative of Head'
        96 = 'Other relative of legal Wife (code 20)'
        97 = 'Other relative of cohabitor (the cohabitor is code 22 or 88)'
        98 = 'Other nonrelatives (includes homosexual partners, friends of children of the FU, etc.)'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2013 or mover-out nonresponse by 2011 (ER34202=0)'
   ;
   VALUE ER34207F
         1 = 'Spouse in couple numbered 1'
         2 = 'Spouse in couple numbered 2'
         3 = 'Spouse in couple numbered 3'
         4 = 'Spouse in couple numbered 4'
         0 = 'Inap.:  spouse was not in FU at the time of the 2013 interview; not married or permanently cohabiting; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main fami'
             'ly nonresponse by 2013 or mover-out nonresponse by 2011 (ER34201=0)'
   ;
   VALUE ER34208F
         1 = 'Moved in or born between the 2011 and 2013 interviews; splitoff in 2013'
         2 = 'Appeared; moved in by the time the 2011 interview was taken but not included in FU for 2011 (i.e., listing error)'
         5 = 'Moved out of FU or out of an institution between the 2011 and 2013 interviews and was not included in a 2013 panel FU'
         6 = 'Moved out of FU and into an institution between the 2011 and 2013 interviews'
         7 = 'Living in 2011 but died by the time of the 2013 interview'
         8 = 'Disappeared; moved out prior to the 2011 interview, but included in FU for 2011 (usually a listing error)'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2013 or mover-out nonresponse by 2011 (ER34201=0); in main family in both 201'
             '1 and 2013 (ER34102=1-20 and ER34202=1-20); in an institution in both 2011 and 2013 (ER34102=51-59 and ER34202=51-59); born or moved in after the 2013 interview (ER34201>0 and ER34202=0)'
   ;
   VALUE ER34211F
         1 = 'This individual was respondent'
         5 = 'This individual was not respondent; includes institutionalized individuals and mover-out nonresponse from 2013 (ER34202=51-89)'
         9 = 'DK; NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2013 or mover-out nonresponse by 2011 (ER34201=0)'
   ;
   VALUE ER34212F
    1 - 10 = 'Sequence number of the first other person in the Family Unit in 2013 who helped the Respondent complete the interview'
        97 = 'Other person outside the Family Unit helped the Respondent'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2013 or mover-out nonresponse by 2011 (ER34201=0); this individual was not th'
             'e respondent in 2013 (ER34211=5 or 9); this individual did not have a helper'
   ;
   VALUE ER34213F
    1 - 10 = 'Sequence number of the second other person in the Family Unit in 2013 who helped the Respondent complete the interview'
        97 = 'Other person outside the Family Unit helped the Respondent'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2013 or mover-out nonresponse by 2011 (ER34201=0); this individual was not th'
             'e respondent in 2013 (ER34211=5 or 9); this individual did not have a helper (ER34212=0); this individual did not have a second helper'
   ;
   VALUE ER34214F
    1 - 10 = 'Sequence number of the third other person in the Family Unit in 2013 who helped the Respondent complete the interview'
        97 = 'Other person outside the Family Unit helped the Respondent'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2013 or mover-out nonresponse by 2011 (ER34201=0); this individual was not th'
             'e respondent in 2013 (ER34211=5 or 9); this individual did not have a helper (ER34212=0); this individual did not have a second helperthis individual did not have a second helper (ER34213=0); this ind'
             'ividual did not have a third helper'
   ;
   VALUE ER34215F
         1 = 'Head who received TANF'
         2 = 'Wife/"Wife" who received TANF'
         3 = 'Other Family Unit Member who received TANF'
         0 = 'Inap.:  this individual did not receive TANF; DK, NA, or RF whether this individual received TANF; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family n'
             'onresponse by 2013 or mover-out nonresponse by 2011 (ER34201=0); in an institution in both 2011 and 2013 (ER34202=51-59 and ER34208=0);  OFUM under age 16 (ER34202=02-20 and ER34204 <16)'
   ;
   VALUE ER34216F
         1 = 'Working now'
         2 = 'Only temporarily laid off'
         3 = 'Looking for work, unemployed'
         4 = 'Retired'
         5 = 'Permanently disabled'
         6 = 'HouseWife; keeping house'
         7 = 'Student'
         8 = 'Other'
         9 = 'DK; NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2013 or mover-out nonresponse by 2011 (ER34201=0); mover-out nonresponse for'
             '2013, only if deceased (ER34202=81-89); in an institution in both 2011 and 2013 (ER34202=51-59 and ER34208=0); not a person aged 16 or older (ER34204=001-015); associated with 2013 FU but moved out be'
             'fore 2012 (ER34208=5, 6, or 8 and ER34210 <2012)'
   ;
   VALUE ER34219F
         1 = 'First grade'
         2 = 'Second grade'
         3 = 'Third grade'
         4 = 'Fourth grade'
         5 = 'Fifth grade'
         6 = 'Sixth grade'
         7 = 'Seventh grade'
         8 = 'Eighth grade'
         9 = 'Ninth grade'
        10 = 'Tenth grade'
        11 = 'Eleventh grade'
        12 = 'Twelfth grade, "High School", GED'
        13 = 'Less than one year college'
        14 = 'One year college'
        15 = 'Two years college'
        16 = 'Three years college'
        17 = 'Four years college'
        18 = 'Five years or more college'
        19 = 'College graduate'
        20 = 'Post-graduate work'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  none; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2013 or mover-out nonresponse by 2011 (ER34201=0); Head/Wife/"Wife" in'
             '2013 (ER34202=1-20 and ER34203=10, 20 or 22); mover-out nonresponse for 2013, only if deceased (ER34202=81-89); in an institution in both 2011 and 2013 (ER34202=51-59 and ER34208=0); under age 16 (ER3'
             '4204=001-015); associated with 2013 FU but moved out before 2012 (ER34208=5, 6, or 8 and ER34210 <2012) or moved in in 2013 (ER34208=1 and ER34210=2013)'
   ;
   VALUE ER34220F
         1 = 'Graduated from high school'
         2 = 'Got a GED'
         3 = 'Neither'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.:  current Head/Wife/"Wife" educated outside the U.S. only or had no education;  DK, NA, or RF where current Head/Wife/"Wife" received education; from Latino sample (ER30001=7001-9308); from Immi'
             'grant 2017 sample (ER30001=4001-4462); main family nonresponse by 2013 or mover-out nonresponse by 2011 (ER34201=0); mover-out nonresponse for 2013, only if deceased (ER34202=81-89); OFUM in an instit'
             'ution in both 2011 and 2013 (ER34202=51-59 and ER34208=0); OFUM under age 16 (ER34204=001-015); OFUM associated with 2013 FU but moved out before 2012 (ER34208=5, 6, or 8 and ER34210 <2012) or OFUM mo'
             'ved in in 2013 (ER34208=1 and ER34210=2013); OFUM highest grade or year of school completed is less than 12 (ER34219=0-11);  DK, NA, RF OFUM highest grade or year of school completed (ER34219=98 or 99'
             ')'
   ;
   VALUE ER34221F
         1 = 'Associate''s degree/AA'
         2 = 'Bachelor''s degree/BA/BS'
         3 = 'Master''s degree/MA/MS/MBA'
         4 = 'Doctorate/PhD'
         5 = 'LLB, JD (Law degrees)'
         6 = 'MD, DDS, DVM, DO (Medical degrees)'
         8 = 'Honorary degree'
        97 = 'Other - specify'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  current Head/Wife/"Wife" educated outside the U.S. only or had no education;  DK, NA, or RF where current Head/Wife/"Wife" received education; did not receive a college degree;  DK, NA, or RF'
             'whether received a college degree; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2013 or mover-out nonresponse by 2011 (ER34201=0);'
             ' mover-out nonresponse for 2013, only if deceased (ER34202=81-89); current Head/Wife/"Wife" or OFUM in an institution in both 2011 and 2013 (ER34202=51-59 and ER34208=0); OFUM under age 16 (ER34204=00'
             '1-015); OFUM associated with 2013 FU but moved out before 2012 (ER34208=5, 6, or 8 and ER34210 <2012) or OFUM moved in in 2013 (ER34208=1 and ER34210=2013); OFUM highest grade or year of school comple'
             'ted is less than one year of college (ER34219=0-13);  DK, NA, RF OFUM highest grade or year of school completed (ER34219=98 or 99)'
   ;
   VALUE ER34228F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.:  new Head/Wife/"Wife" this wave;  OFUM or same Head/Wife/"Wife" from last wave still in school; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main fami'
             'ly nonresponse by 2013 or mover-out nonresponse by 2011 (ER34201=0); mover-out nonresponse for 2013, only if deceased (ER34202=81-89); current Head/Wife/"Wife" or OFUM in an institution in both 2011 a'
             'nd 2013 (ER34202=51-59 and ER34208=0); OFUM under age 16 (ER34204=001-015); OFUM associated with 2013 FU but moved out before 2012 (ER34208=5, 6, or 8 and ER34210 <2012) or OFUM moved in in 2013 (ER34'
             '208=1 and ER34210=2013)'
   ;
   VALUE ER34229F
         1 = 'First grade'
         2 = 'Second grade'
         3 = 'Third grade'
         4 = 'Fourth grade'
         5 = 'Fifth grade'
         6 = 'Sixth grade'
         7 = 'Seventh grade'
         8 = 'Eighth grade'
         9 = 'Ninth grade'
        10 = 'Tenth grade'
        11 = 'Eleventh grade'
        12 = 'Twelfth grade, "High School", GED'
        13 = '1st year college (freshman)/ Less than one year college'
        14 = '2nd year college (sophomore)'
        15 = '3rd year college (junior)'
        16 = '4th year college (senior)'
        17 = '5th or higher year of college'
        18 = '1st year graduate school'
        19 = '2nd year graduate school'
        20 = '3rd year or higher graduate school'
        21 = 'College, no year reported'
        99 = 'DK; NA; refused'
         0 = 'Inap.:  new Head/Wife/"Wife" this wave; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2013 or mover-out nonresponse by 2011 (ER3420'
             '1=0); mover-out nonresponse for 2013, only if deceased (ER34202=81-89); current Head/Wife/"Wife" or OFUM in an institution in both 2011 and 2013 (ER34202=51-59 and ER34208=0); OFUM under age 16 (ER342'
             '04=001-015); OFUM associated with 2013 FU but moved out before 2012 (ER34208=5, 6, or 8 and ER34210 <2012) or OFUM moved in in 2013 (ER34208=1 and ER34210=2013); OFUM or same Head/Wife/"Wife" as last'
             'wave not still in school (ER34228=5);  DK, NA, or RF whether OFUM or same Head/Wife/"Wife" as last wave still in school (ER34228=8 or 9)'
   ;
   VALUE ER34230F
    1 - 17 = 'Highest grade or year of school completed'
        99 = 'DK; NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2013 or mover-out nonresponse by 2011 (ER34101=0); in an institution in both'
             '2011 and 2013 (ER34102=51-59 and ER34108=0); not a person aged 16 or older (ER34104=001-015, 999); associated with 2013 FU but actually moved out before 2012 (ER34108=5, 6, or 8 and ER34110<2012) or m'
             'oved in in 2013 and was not a Head or Wife/"Wife" (ER34108=1 and ER34110=2013 and ER34102 GE 2 and ER34103 GE 30)'
   ;
   VALUE ER34231F
         1 = 'Yes, is in poor health'
         5 = 'No, is not in poor health'
         9 = 'DK; NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2013 or mover-out nonresponse by 2011 (ER34201=0); in an institution or mover'
             '-out nonresponse in 2013 (ER34202=51-89); current Head/Wife/"Wife" (ER34202=1-2 and ER34203=10, 20, 22)'
   ;
   VALUE ER34232F
         1 = 'Yes, this individual is covered by the state health insurance plan for uninsured children'
         5 = 'No, this individual is not covered by the state health insurance plan for uninsured children'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.:  not covered by health insurance/does not have health care coverge; has the same health insurance or health care coverage as everyone else in the FU and is older than 18 years old; from Latino'
             'sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2013 or mover-out nonresponse by 2011 (ER34201=0); moved out before 2011 (ER34202=71-89 and ER342'
             '10 >0 and ER34210 <2011)'
   ;
   VALUE ER34233F
    1 - 12 = 'Actual number of months uninsured'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  was insured all months in 2011; born after 2011; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2013 or mover-out nonrespons'
             'e by 2011 (ER34201=0); moved out before 2011 (ER34202=71-89 and ER34210 >0 and ER34210 <2011)'
   ;
   VALUE ER34234F
    1 - 12 = 'Actual number of months uninsured'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  was insured all months in 2012; born after 2012; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2013 or mover-out nonrespons'
             'e by 2011 (ER34201=0); moved out before 2011 (ER34202=71-89 and ER34210 >0 and ER34210 <2011)'
   ;
   VALUE ER34235F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2013 or mover-out nonresponse by 2011 (ER34201=0); moved out before 2011 (ER3'
             '4202=71-89 and ER34210 >0 and ER34210 <2011)'
   ;
   VALUE ER34236F
         1 = 'Employer provided health insurance'
         2 = 'Private health insurance purchased'
         3 = 'Medicare'
         4 = 'Medi-Gap/Supplemental'
         5 = 'Medicaid/[STATEMEDPROG]/[SCHIPNAME]'
         8 = 'Indian Health Insurance'
         9 = 'Other state-sponsored plan (not Medicaid)'
        10 = 'Other government program'
        12 = 'Military Health Care/Tricare (Active duty)/ Military Health Care/Tricare (Active duty)/ VA (Veterans'' Administration)'
        97 = 'Other health insurance'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2013 or mover-out nonresponse by 2011 (ER34101=0); moved out before 2011 (ER3'
             '4102=71-89 and ER34110>0 and ER34110<2011); does not have health insurance of health care coverage now (ER34235=5); DK, NA, or RF whether has health insurance or health care coverage now (ER34235=8 or'
             ' 9)'
   ;
   VALUE ER34237F
         1 = 'Employer provided health insurance'
         2 = 'Private health insurance purchased'
         3 = 'Medicare'
         4 = 'Medi-Gap/Supplemental'
         5 = 'Medicaid/[STATEMEDPROG]/[SCHIPNAME]'
         8 = 'Indian Health Insurance'
         9 = 'Other state-sponsored plan (not Medicaid)'
        10 = 'Other government program'
        12 = 'Military Health Care/Tricare (Active duty)/ Military Health Care/ Tricare (Active duty)/ VA (Veterans'' Administration)'
        97 = 'Other health insurance'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2013 or mover-out nonresponse by 2011 (ER34101=0); moved out before 2011 (ER3'
             '4102=71-89 and ER34110>0 and ER34110<2011); does not have health insurance of health care coverage now (ER34235=5); DK, NA, or RF whether has health insurance or health care coverage now (ER34235=8 or'
             ' 9); NA, DK to first mention (ER34236=98 or 99); no second mention'
   ;
   VALUE ER34238F
         1 = 'Employer provided health insurance'
         2 = 'Private health insurance purchased'
         3 = 'Medicare'
         4 = 'Medi-Gap/Supplemental'
         5 = 'Medicaid/[STATEMEDPROG]/[SCHIPNAME]'
         8 = 'Indian Health Insurance'
         9 = 'Other state-sponsored plan (not Medicaid)'
        10 = 'Other government program'
        12 = 'Military Health Care/Tricare (Active duty)/ Military Health Care/ Tricare (Active duty)/ VA (Veterans'' Administration)'
        97 = 'Other health insurance'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2013 or mover-out nonresponse by 2011 (ER34101=0); moved out before 2011 (ER3'
             '4102=71-89 and ER34110>0 and ER34110<2011); does not have health insurance of health care coverage now (ER34235=5); DK, NA, or RF whether has health insurance or health care coverage now (ER34235=8 or'
             ' 9); NA, DK to first mention (ER34236=98 or 99); less than three mentions'
   ;
   VALUE ER34239F
    1 - 24 = 'Sequence number of the first person in the Family Unit in 2013 whose employer provided this individual''s health insurance/coverage.'
        96 = 'Parent of Family Unit member who lives outside of FU'
        97 = 'Other person outside of FU'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2013 or mover-out nonresponse by 2011 (ER34201=0); moved out before 2011 (ER3'
             '4202=71-89 and ER34210 >0 and ER34210 <2011); does not have health insurance of health care coverage now (ER34235=5); DK, NA, or RF whether has health insurance or health care coverage now (ER34235=8'
             'or 9); DK, NA, or RF type of health insurance/health care coverage (ER34236=98 or 99); does not have employer provided health insurance (ER34236 ne 1 and ER34237 ne 1 and ER34238 ne 1)'
   ;
   VALUE ER34240F
    1 - 24 = 'Sequence number of the second person in the Family Unit in 2013 whose employer provided this individual''s health insurance/coverage.'
        96 = 'Parent of Family Unit member who lives outside of FU'
        97 = 'Other person outside of FU'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2013 or mover-out nonresponse by 2011 (ER34201=0); moved out before 2011 (ER3'
             '4202=71-89 and ER34210 >0 and ER34210 <2011); does not have health insurance of health care coverage now (ER34235=5); DK, NA, or RF whether has health insurance or health care coverage now (ER34235=8'
             'or 9); DK, NA, or RF type of health insurance/health care coverage (ER34236=98 or 99); does not have employer provided health insurance (ER34236 ne 1 and ER34237 ne 1 and ER34238 ne 1); no second ment'
             'ion'
   ;
   VALUE ER34241F
    1 - 24 = 'Sequence number of the first person in the Family Unit in 2013 who was the policy holder on this individual''s private health insurance/coverage.'
        96 = 'Parent of Family Unit member who lives outside of FU'
        97 = 'Other person outside of FU'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2013 or mover-out nonresponse by 2011 (ER34201=0); moved out before 2011 (ER3'
             '4202=71-89 and ER34210 >0 and ER34210 <2011); does not have health insurance of health care coverage now (ER34235=5); DK, NA, or RF whether has health insurance or health care coverage now (ER34235=8'
             'or 9); DK, NA, or RF type of health insurance/health care coverage (ER34236=98 or 99); does not have private health insurance (ER34236 ne 2 and ER34237 ne 2 and ER34238 ne 2)'
   ;
   VALUE ER34242F
    1 - 24 = 'Sequence number of the second person in the Family Unit in 2013 who was the policy holder on this individual''s private health insurance/coverage.'
        96 = 'Parent of Family Unit member who lives outside of FU'
        97 = 'Other person outside of FU'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2013 or mover-out nonresponse by 2011 (ER34201=0); moved out before 2011 (ER3'
             '4202=71-89 and ER34210 >0 and ER34210 <2011); does not have health insurance of health care coverage now (ER34235=5); DK, NA, or RF whether has health insurance or health care coverage now (ER34235=8'
             'or 9); DK, NA, or RF type of health insurance/health care coverage (ER34236=98 or 99); does not have private health insurance (ER34236 ne 2 and ER34237 ne 2 and ER34238 ne 2); no second mention'
   ;
   VALUE ER34243F
         1 = 'This individual is a 2013 Head/Wife/"Wife" who was covered by Medicare or was aged 65 or older, was the respondent, and did not give a useable Medicare number in prior waves but did in this wave.'
         2 = 'This individual is a 2013 Head/Wife/"Wife" who was covered by Medicare or was aged 65 or older, was the respondent, did not give a useable Medicare number in prior waves, and provided a Medicare numbe'
             'r in this wave but it was not useable (e.g., missing digits).'
         5 = 'This individual is a 2013 Head/Wife/"Wife" who was covered by Medicare or was aged 65 or older, was the respondent, did not give a useable Medicare number in prior waves and in the present wave declin'
             'ed to give his/her Medicare number (H62a=5), did not know/refused whether the number was a Medicare Claim or Railroad Retirement Board number, or did not know the number at H62c/H62e-f.'
         7 = 'This individual is associated with a responding FU and was a Head/Wife/"Wife" in a prior wave, who was covered by Medicare, was the respondent, and provided a useable Medicare number in some prior wav'
             'e.'
         9 = 'This individual is a 2013 Head/Wife/"Wife" who was covered by Medicare or was aged 65 or older, was the respondent, did not give a useable Medicare number in prior waves, and in the present wave wheth'
             'er a Medicare number could be provided was NA or DK (H62a=8 or 9).'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2013 or mover-out nonresponse by 2011 (ER34201=0); moved out before 2011 (ER3'
             '4202=71-89 and ER34210 >0 and ER34210 <2011); not Head/Wife/"Wife" in 2013 (ER34203 >22 or ER34202 >50); under age 65 and not covered by Medicare (ER34204 <65 or 999 and neither ER34236, ER34237, ER34'
             '238=3);  not the respondent (ER34211=5)'
   ;
   VALUE ER34243AF
         1 = 'Only one job'
         2 = 'Two jobs'
         3 = 'Three jobs'
         4 = 'Four jobs or more'
         5 = 'Didn''t have a job'
         8 = 'Don''t know'
         9 = 'NA; refused'
         0 = 'Inap.: this person was a current Head/Spouse/Partner in 2013; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2013 or mover-out nonre'
             'sponse by 2011 (ER34201=0); OFUM in an institution in both 2011 and 2013 (ER34202=51-59 and ER34208=0); OFUM under age 16 (ER34204=001-015); OFUM associated with 2013 FU but moved out before 2012 (ER3'
             '4208=5, 6, or 8 and ER34210<2012) or OFUM moved in in 2013 (ER34208=1 and ER34210=2013)'
   ;
   VALUE ER34255F
         1 = 'This individual was eligible to be followed in 2013'
         5 = 'This individual was not eligible to be followed in 2013'
         0 = 'Inap.:  main family or mover-out nonresponse in 2011 and not selected for recontact in 2013; from Latino sample (ER30001=7001-9308)'
   ;
   VALUE ER34257F
         1 = 'This individual was eligible to be interviewed for the TA interview in 2013'
         0 = 'Inap.:  this individual was from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); not interviewed as part of 1997 CDS (ER33420=00, 02-98); main family nonresponse by'
             '2013 (ER34201=0 and ER34202=0); mover-out nonresponse in 2013 (ER34202=71-89)'
   ;
   VALUE ER34258F
         1 = 'Interview with eligible sample individual'
         3 = 'Refusal by the sample individual; partial/passive refusal; deliberate avoidance of interviewer (e.g., always too busy, repeated broken appointments, or failure to return calls)'
         4 = 'Sample individual lost; tracking efforts exhausted'
         5 = 'Sample individual incapacitated, had a permanent health condition, or institutionalized for health or mental reasons'
         6 = 'Sample individual deceased after PSID interview completed but before TA interview'
         7 = 'Some household member contacted, but eligible respondent not available to do interview; appointment broken, but no evidence of deliberately avoiding interview'
        10 = 'Adamant refusal by the eligible sample member. These individuals will never be asked to participate in the TA study again, regardless of recontact efforts.'
        13 = 'Refusal by someone other than the sample individual'
        30 = 'Sample individual away on military leave, in job corps, or in a non-detention facility'
        31 = 'Sample individual resided outside the US or in a remote area and uncontactable (e.g., no telephone)'
        34 = 'Sample individual incarcerated or in a youth, group, or detention home/center'
        70 = 'Sample individual was randomly dropped because two others in the family unit were also eligible (CDS only)'
        90 = 'Sample individual was initially thought to be ineligible because of nonresponse but discovered to be a resident in a response sample family after the interviewing period had ended.'
        95 = 'Office error--study ended, insufficient or inappropriate calls made, no mention of refusal'
         0 = 'Inap.:  this individual was from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); not interviewed as part of 1997 CDS (ER33420=00, 02-98); main family nonresponse by'
             '2013 (ER34201=0 and ER34202=0); mover-out nonresponse in 2013 (ER34202=71-89)'
   ;
   VALUE ER34259F
         1 = 'This individual was eligible to be interviewed for the CDS Interview in 2014'
         5 = 'This individual was released to the field but was not eligible to be interviewed for the CDS Interview in 2014 (ER34261 = 50-55)'
         0 = 'Inap.:  this individual was from the Immigrant 17 or Latino samples (ER30001=4001-4462, 7001-9308); main family nonresponse by 2013 (ER34201=0 and ER34202=0); mover-out nonresponse in 2013 (ER34202=71'
             '-89); not selected for the CDS 2014 interview'
   ;
   VALUE ER34260F
         1 = 'Deselected in double-sampling stage'
         2 = 'Double-sampled, second-phase weight of 2'
         3 = 'Not eligible for double-sampling (cases finalized prior to 2/24/2015 or Spanish language)'
         4 = 'Double-sampled, second-phase weight of 1'
         0 = 'Inap.:  this individual was from the Immigrant 17 or Latino samples (ER30001=4001-4462, 7001-9308); main family nonresponse by 2013 (ER34201=0 and ER34202=0); mover-out nonresponse in 2013 (ER34202=71'
             '-89); not eligible for the CDS 2014 interview (ER34259=0)'
   ;
   VALUE ER34261F
         1 = 'Completed case'
         2 = 'Partially completed case'
         3 = 'PCG refused all study components or PCG provided incomplete interview and refused all child components'
         4 = 'PCG provided incomplete interview, refused consent for child interview or refused in-home components'
         5 = 'Lost- family not located'
         6 = 'Individual incapacitated, had a permanent health condition'
         7 = 'Language barrier'
         8 = 'Individual resided outside the U.S. or in a remote area and uncontactable'
         9 = 'Many calls, attempts to set an appointment but no evidence of refusal; not reached/not able to reach for in-home-components'
        10 = 'Panel refusal by all all eligible/available FU members. These individuals will never be asked to participate in the CDS study again, regardless of recontact efforts.'
        15 = 'Panel refusal by all all eligible/available FU members. Sample individual (or other FU member on their behalf) contacted the study or IRB (by letter, email, phone call to the 800#, or respondent-initi'
             'ated phone call to the interviewer) with a strong request to be removed from CDS.'
        16 = 'Assessments completed but other interview components incomplete'
        17 = 'Field period ended, respondent not reached'
        18 = 'Office Error: (NI) This individual was initially thought to be ineligible because of nonresponse but discovered to be a resident in a response family after the CDS interviewing period had ended. These'
             ' individuals were never released to the field.'
        20 = 'Interview taken with a non-sample child'
        50 = 'Nonsample: This individual was deceased when contacted for the CDS 2014 study.'
        51 = 'Nonsample: This individual was institutionalized by the time he or she was contacted for the 2014 CDS study.'
        52 = 'Nonsample: Target child moved out to own household.'
        53 = 'Nonsample: Child discovered to be age-ineligible when contacted for CDS 2014 study.'
        54 = 'Nonsample: No PCG or the PCG discovered to be age-ineligible when contacted for CDS 2014 study.'
        55 = 'Nonsample: Child determined to be not followable but released to CDS.'
        56 = 'Nonsample: Eligible but not selected; case deselected in double-sample stage [Selection Status (ER34260=1)].'
         0 = 'Inap.:  this individual was from the Immigrant 17 or Latino samples (ER30001=4001-4462, 7001-9308); main family nonresponse by 2013 (ER34201=0 and ER34202=0); mover-out nonresponse in 2013 (ER34202=71'
             '-89); not eligible for the CDS 2014 interview (ER34259=0)'
   ;
   VALUE ER34261AF
         1 = 'This child has a completed or partial interview in CDS 2014'
         5 = 'This child was eligible for CDS 2014 but either not selected or the interview is not complete'
         0 = 'Inap.: This individual was not eligible for CDS 2014'
   ;
   VALUE ER34262F
         1 = 'This individual was eligible to be interviewed for the DUST interview in 2013'
         5 = 'This individual was selected to be interviewed for the DUST interview in 2013 but was determined through screening that he/she was ineligible (ER34263=20-25).'
         0 = 'Inap.:  either Head or Wife have birth year 1953 or later; this individual was from  Latino sample (ER30001=7001-9308); main family nonresponse by 2013 (ER34201=0 and ER34202=0); mover-out nonresponse'
             ' in 2013 (ER34202=71-89); this individual is neither Head nor Wife in 2013 (ER34202 ge 2 and ER34203 gt 20)'
   ;
   VALUE ER34263F
         1 = 'Completed interview (completed at least one diary)'
         3 = 'Refusal'
         4 = 'Many calls, attempts to set appt but no evidence of refusal'
         5 = 'Lost'
         6 = 'Office Error:  This individual should have been pursued'
        13 = 'Office Error:  This individual was initially thought to be ineligible because of nonresponse but discovered to be a resident in a response family as Head or Wife/"Wife" after the DUST interviewing per'
             'iod had ended'
        14 = 'Office Error: This individual''s case was mistakenly coded deceased but discovered to be a resident in a response family as Head or Wife/"Wife" after the DUST interviewing period had ended'
        15 = 'Office error:  mistakenly coded as a Non-English Core  PSID interview'
        16 = 'Office error:  this individual was mistakenly coded as permanent condition but should have been interviewed for DUST'
        17 = 'Office error:  this individual was mistakenly coded as institutional but should have been interviewed for DUST'
        18 = 'Office Error: this individual''s case was mistakenly coded as having a PSID proxy respondent but discovered that Head or Wife/"Wife" was respondent after the DUST interviewing period had ended'
        19 = 'Office Error: Field period ended, never released'
        20 = 'Nonsample: This individual was deceased when contacted for the 2013 DUST study'
        22 = 'Nonsample: This individual was institutionalized by the time he or she was contacted for the 2013 DUST study'
        24 = 'Nonsample: This non-sample individual moved out of the HH at the time of the DUST interview and was not pursued'
        25 = 'Nonsample:  age-ineligible couple but this individual and his/her spouse were wrongly listed as eligible and selected'
        26 = 'Nonsample: This individual has a permanent condition that precludes ability to co-operate'
        27 = 'Nonsample: This individual is a non-English speaker that precludes ability to co-operate'
        28 = 'Nonsample: Proxy R was used for main PSID interview'
         0 = 'Inap.:   either Head or Wife have birth year 1953 or later; this individual was from  Latino sample (ER30001=7001-9308); main family nonresponse by 2013 (ER34201=0 and ER34202=0); mover-out nonrespons'
             'e in 2013 (ER34202=71-89); this individual is neither Head nor Wife in 2013 (ER34202 ge 2 and ER34203 gt 20); not eligible for DUST (ER34262=0)'
   ;
   VALUE ER34264F
         1 = 'This individual was eligible to be interviewed for the Childhood Retrospective Circumstances Study (CRCS) in 2014'
         5 = 'Head/Wife/"Wife" was deceased by the time of CRCS contact; Head/Wife/"Wife"  was institutionalized by the time of the CRCS contact; proxy respondent was used for the main PSID interview; PSID intervie'
             'w was not conducted in English; Head/Wife/"Wife" was not age eligible (birth year 1995 or later); age and date of birth of the Head/Wife/"Wife was unknown and therefore was not eligible for the CRCS s'
             'tudy.'
         0 = 'Inap.:  this individual was from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2013 (ER34201=0 and ER34202=0); mover-out nonresponse in'
             '2013 (ER34202=71-89); this individual is neither Head nor Wife in 2013 (ER34202 ge 2 and ER34203 gt 20)'
   ;
   VALUE ER34265F
         1 = 'Completed interview'
         2 = 'Partial interview'
         3 = 'Refusal'
         4 = 'Never completed, no evidence of refusal'
         5 = 'Lost'
         6 = 'This individual has a permanent condition that precludes ability to co-operate'
         7 = 'Core interview was taken in English however, this individual is a non-English speaker that precludes ability to co-operate'
         8 = 'Incomplete PAPI interview'
         9 = 'Incomplete Web interview'
        10 = 'Adamant refusal by all eligible/available FU members. These individuals will never be asked to participate in the study again, regardless of recontact efforts.'
        15 = 'Adamant refusal by all eligible/available FU members. Sample individual (or other FU member on their behalf) contacted the study or IRB (by letter, email, phone call to the 800#, or respondent-initiat'
             'ed phone call to the interviewer) with a strong request to be removed from the study.'
        16 = 'Office Error: This individual was initially thought to be ineligible because of nonresponse but discovered to be a resident in a response family as Head or Wife after the CRCS interviewing period had'
             'ended.'
        17 = 'Office Error: This individual was mistakenly coded deceased but discovered to be a resident in a response family as Head or Wife/"Wife" after the CRCS interviewing period had ended.'
        18 = 'Office Error: This individual''s case was mistakenly coded as having a PSID  proxy respondent but discovered that Head or Wife/"Wife" was respondent after the CRCS interviewing period had ended.'
        19 = 'Office Error: Wrong Respondent.'
        20 = 'Nonsample: This Individual was deceased when contacted for the CRCS Study'
        21 = 'Nonsample:  This individual was institutionalized by the time he or she was contacted for CRCS'
        22 = 'Nonsample: Proxy R was used for main PSID interview'
        23 = 'Nonsample: Non-English Core  PSID interview'
        24 = 'Nonsample: Head or Wife/"Wife" was too young to be eligible for the CRCS study (birth year of 1995 or later)'
        25 = 'Nonsample: Head or Wife/"Wife''s" age and year of birth was unknown; therefore not eligible for CRCS study'
         0 = 'Inap.:  this individual was from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2013 (ER34201=0 and ER34202=0); mover-out nonresponse in'
             '2013 (ER34202=71-89); this individual is neither Head nor Wife in 2013 (ER34202 ge 2 and ER34203 gt 20)'
   ;
   VALUE ER34266F
         1 = 'This sample member was main family nonresponse and had been in the FU in 2011.'
         3 = 'This nonsample individual had been in the 2011 FU, and this FU became nonresponse in 2013.'
         4 = 'This sample member had been in an institution in 2011, but his or her family became nonresponse in 2013.'
         5 = 'This sample member, linked to a 2013 response family, was in an institution at the time of the 2013 interview.'
         6 = 'This sample member moved out or died between the 2011 and 2013 interviews.'
         8 = 'This nonsample individual moved out or died between the 2011 and 2013 interviews.'
         9 = 'This individual had not been born or moved in by the time of the 2013 interview; individual from Immigrant 17 sample (ER30001=4001-4462)'
        10 = 'This individual had become nonresponse by the time of the 2013 interview.'
        21 = 'Main family recontact: this person was selected for recontact in 2013, but the family was not successfully interviewed.'
        26 = 'Splitoff recontact: this sample member moved out of a 2013 recontact main family but was not successfully interviewed.'
        40 = 'Individual connected with the Latino sample (ER30001=7001-9308); this sample was dropped beginning in 1996.  Individual dropped from the Census (SEO) sample due to budgetary constraints; this group wa'
             's dropped beginning in 1997.'
        99 = 'DK; NA'
         0 = 'Inap.:  this individual was in a panel family in 2013 (ER34202=1-20).'
   ;
   VALUE ER34267F
         1 = 'Wave refusal by all eligible/available FU members.'
         2 = 'No one at home for contact during the interviewing period.'
         3 = 'Respondent absent; some FU member contacted, but not the appropriate respondent.'
         4 = 'Lost; unable to locate any member of the FU at all.'
         5 = 'FU is located too far away for interviewer contact.'
        10 = 'Panel refusal by all all eligible/available FU members.  These individuals will never be asked to participate in the study again, regardless of recontact efforts.'
        11 = 'This sample member was in the armed forces.'
        12 = 'This sample member was in an educational institution.'
        13 = 'This sample member was in a health care facility.'
        14 = 'This sample member was in jail or prison.'
        15 = 'Panel refusal by all all eligible/available FU members. Sample individual (or other FU member on their behalf) contacted the study or IRB (by letter, email, phone call to the 800#, or respondent-initi'
             'ated phone call to the interviewer) with a strong request to be removed from the study.'
        19 = 'This sample member was in some other type of institution; for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        21 = 'This nonsample individual became main family nonresponse because the Head or the Wife, whichever is the sample member, became institutionalized by joining the armed forces.'
        22 = 'This nonsample individual became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by entering an educational institution.'
        23 = 'This nonsample individual became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized by entering a health care facility.'
        24 = 'This nonsample individual became main family nonresponse because the Head or Wife, whichever is the sample member, became institutionalized through imprisonment.'
        25 = 'This individual became main family nonresponse because the sample member contacted the study or IRB with a request to be removed from the study (sample individual is coded 15 for this wave).'
        29 = 'This nonsample individual became main family nonresponse because the Head or Wife, whichever is sample, became institutionalized by some means other than the above; for example, he/she may have entere'
             'd a religious order. Cases in which the type of institution is unknown are included here, also.'
        31 = 'This sample member was unable to cooperate because of disability.'
        32 = 'This nonsample individual became main family nonresponse because the Head or Wife, whichever is sample, was unable to cooperate because of disability.'
        41 = 'This individual died between the 2011 and 2013 interviews; this individual died after becoming nonresponse for some other reason before the 2011 interview.'
        42 = 'This nonsample individual became main family nonresponse because the Head or Wife, whichever is sample, died.'
        45 = 'This individual was a sample member but has been adopted by unrelated nonsample persons and therefore has become nonsample.'
        51 = 'This individual, although followed for interview, was discovered to be nonsample:  office error.'
        52 = 'This individual should have been followed but was not:  office error.'
        53 = 'This individual was mistakenly included in two or more response families at once; this record is the duplicate, or erroneous, one.'
        54 = 'Listing error: this individual never existed or was not really living in the FU.'
        57 = 'Insufficient information that would permit recontact; no name or identifying information available'
        58 = 'Due to budgetary and/or time constraints, PSID staff decided not to take all of the usual steps to try to locate and/or persuade this FU.'
        59 = 'Limited number of contacts attempted:  miscellaneous office error (does not include codes 01-54 above or codes 91-99 below).'
        60 = 'This nonsample parent of a sample child is no longer eligible to be interviewed.'
        61 = 'This nonsample individual was associated with a family containing a person erroneously designated as followable; the erroneous person''s code is 45, 51, 53, 54, or 60.'
        80 = 'Individual connected with the Latino sample (ER30001=7001-9308); this sample was dropped beginning in 1996.  Individual dropped from the Census (SEO) sample due to budgetary constraints; this group wa'
             's dropped beginning in 1997.'
        91 = 'This individual moved out of the 2013 main family and was eligible to be followed, but the reason for nonresponse is NA.'
        92 = 'Individual moved out of the 2013 main family and was not eligible to be followed.'
        93 = 'All sample members of this FU united with other panel FUs; this individual was nonsample and therefore became nonresponse.'
        97 = 'This individual had not been born or moved in by the time of the 2013 interview (ER34201>0 and ER34202=0); individual from Immigrant 17 sample (ER30001=4001-4462)'
        98 = 'This individual became main family or mover-out nonresponse by 2011 and was not selected for recontact in 2013 (ER34101=0 and ER34201=0 and ER4255=0 or ER34101>0 and ER34201=71-89 and ER34201=0 and ER'
             '4255=0).'
        99 = 'DK; NA'
         0 = 'Inap.:  this individual was in a panel family in 2013 (ER34202=1-20)'
   ;
   VALUE ER34302F
    1 - 20 = 'Individuals in the family at the time of the 2015 interview'
   51 - 59 = 'Individuals in institutions at the time of the 2015 interview'
   71 - 80 = 'Individuals who moved out of the FU or out of institutions and established their own households between the 2013 and 2015 interviews'
   81 - 89 = 'Individuals who were living in 2013 but died by the time of the 2015 interview'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2015 or mover-out nonresponse by 2013 (ER34301=0)'
   ;
   VALUE ER34303F
        10 = 'Head in 2015; 2013 Head who was mover-out nonresponse by the time of the 2015 interview'
        20 = 'Legal Spouse in 2015; 2013 Spouse who was mover-out nonresponse by the time of the 2015 interview'
        22 = 'Partner--female cohabitor who has lived with Head for 12 months or more; 2013 Partner who was mover-out nonresponse by the time of the 2015 interview'
        30 = 'Son or daughter of Head (includes adopted children but not stepchildren)'
        33 = 'Stepson or stepdaughter of Head (children of legal Spouse [code 20] who are not children of Head)'
        35 = 'Son or daughter of Partner but not Head (includes only those children of mothers whose relationship to Head is 22 but who are not children of Head)'
        37 = 'Son-in-law or daughter-in-law of Head (includes stepchildren-in-law)'
        38 = 'Foster son or foster daughter, not legally adopted'
        40 = 'Brother or sister of Head (includes step and half sisters and brothers)'
        47 = 'Brother-in-law or sister-in-law of Head; i.e., brother or sister of legal Spouse, or spouse of Head''s brother or sister'
        48 = 'Brother or sister of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        50 = 'Father or mother of Head (includes stepparents)'
        57 = 'Father-in-law or mother-in-law of Head (includes parents of legal spouses [code 20] only)'
        58 = 'Father or mother of Head''s cohabitor (the cohabitor is coded 22 or 88)'
        60 = 'Grandson or granddaughter of Head (includes grandchildren of legal Spouse [code 20] only; those of a cohabitor are coded 97)'
        65 = 'Great-grandson or great-granddaughter of Head (includes great-grandchildren of legal Spouse [code 20]; those of a cohabitor are coded 97)'
        66 = 'Grandfather or grandmother of Head (includes stepgrandparents)'
        67 = 'Grandfather or grandmother of legal Spouse (code 20)'
        68 = 'Great-grandfather or great-grandmother of Head'
        69 = 'Great-grandfather or great-grandmother of legal Spouse (code 20)'
        70 = 'Nephew or niece of Head'
        71 = 'Nephew or niece of legal Spouse (code 20)'
        72 = 'Uncle or Aunt of Head'
        73 = 'Uncle or Aunt of legal Spouse (code 20)'
        74 = 'Cousin of Head'
        75 = 'Cousin of legal Spouse (code 20)'
        83 = 'Children of first-year cohabitor but not of Head (the parent of this child is coded 88)'
        88 = 'First-year cohabitor of Head'
        90 = 'Uncooperative legal spouse of Head (this individual is unable or unwilling to be designated as Head)'
        95 = 'Other relative of Head'
        96 = 'Other relative of legal Spouse (code 20)'
        97 = 'Other relative of cohabitor (the cohabitor is code 22 or 88)'
        98 = 'Other nonrelatives (includes same-sex partners, friends of children of the FU, etc.)'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2015 or mover-out nonresponse by 2013 (ER34302=0)'
   ;
   VALUE ER34304F
         1 = 'This person was identified by the interviewer as the same sex-partner of Head'
         0 = 'Inap.:  this person is not the same-sex partner of Head; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2015 or mover-out nonrespons'
             'e by 2013 (ER34301=0)'
   ;
   VALUE ER34308F
         1 = 'Spouse in couple numbered 1'
         2 = 'Spouse in couple numbered 2'
         3 = 'Spouse in couple numbered 3'
         4 = 'Spouse in couple numbered 4'
         0 = 'Inap.:  spouse was not in FU at the time of the 2015 interview; not married or permanently cohabiting; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main fami'
             'ly nonresponse by 2015 or mover-out nonresponse by 2013 (ER34301=0)'
   ;
   VALUE ER34309F
         1 = 'Moved in or born between the 2013 and 2015 interviews; splitoff in 2015'
         2 = 'Appeared; moved in by the time the 2013 interview was taken but not included in FU for 2013 (i.e., listing error)'
         5 = 'Moved out of FU or out of an institution between the 2013 and 2015 interviews and was not included in a 2015 panel FU'
         6 = 'Moved out of FU and into an institution between the 2013 and 2015 interviews'
         7 = 'Living in 2013 but died by the time of the 2015 interview'
         8 = 'Disappeared; moved out prior to the 2013 interview, but included in FU for 2013 (usually a listing error)'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2015 or mover-out nonresponse by 2013 (ER34301=0); in main family in both 201'
             '3 and 2015 (ER34202=1-20 and ER34302=1-20); in an institution in both 2013 and 2015 (ER34202=51-59 and ER34302=51-59); born or moved in after the 2015 interview (ER34301>0 and ER34302=0)'
   ;
   VALUE ER34312F
         1 = 'This individual was respondent'
         5 = 'This individual was not respondent; includes institutionalized individuals and mover-out nonresponse from 2015 (ER34302=51-89)'
         9 = 'DK; NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2015 or mover-out nonresponse by 2013 (ER34301=0)'
   ;
   VALUE ER34313F
    1 - 10 = 'Sequence number of the first other person in the Family Unit in 2015 who helped the Respondent complete the interview'
        97 = 'Other person outside the Family Unit helped the Respondent'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2015 or mover-out nonresponse by 2013 (ER34301=0); this individual was not th'
             'e respondent in 2015 (ER34312=5 or 9); this individual did not have a helper'
   ;
   VALUE ER34314F
    1 - 10 = 'Sequence number of the second other person in the Family Unit in 2015 who helped the Respondent complete the interview'
        97 = 'Other person outside the Family Unit helped the Respondent'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2015 or mover-out nonresponse by 2013 (ER34301=0); this individual was not th'
             'e respondent in 2015 (ER34312=5 or 9); this individual did not have a helper (ER34313=0); this individual did not have a second helper'
   ;
   VALUE ER34315F
    1 - 10 = 'Sequence number of the third other person in the Family Unit in 2015 who helped the Respondent complete the interview'
        97 = 'Other person outside the Family Unit helped the Respondent'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2015 or mover-out nonresponse by 2013 (ER34301=0); this individual was not th'
             'e respondent in 2015 (ER34312=5 or 9); this individual did not have a helper (ER34313=0); this individual did not have a second helperthis individual did not have a second helper (ER34314=0); this ind'
             'ividual did not have a third helper'
   ;
   VALUE ER34316F
         1 = 'Head who received TANF'
         2 = 'Spouse/Partner who received TANF'
         3 = 'Other Family Unit Member who received TANF'
         0 = 'Inap.:  this individual did not receive TANF; DK, NA, or RF whether this individual received TANF; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family n'
             'onresponse by 2015 or mover-out nonresponse by 2013 (ER34301=0); in an institution in both 2013 and 2015 (ER34302=51-59 and ER34309=0);  OFUM under age 16 (ER34302=02-20 and ER34305 <16)'
   ;
   VALUE ER34317F
         1 = 'Working now'
         2 = 'Only temporarily laid off'
         3 = 'Looking for work, unemployed'
         4 = 'Retired'
         5 = 'Permanently disabled'
         6 = 'HouseSpouse; keeping house'
         7 = 'Student'
         8 = 'Other'
         9 = 'DK; NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2015 or mover-out nonresponse by 2013 (ER34301=0); mover-out nonresponse for'
             '2015, only if deceased (ER34302=81-89); in an institution in both 2013 and 2015 (ER34302=51-59 and ER34309=0); not a person aged 16 or older (ER34305=001-015); associated with 2015 FU but moved out be'
             'fore 2014 (ER34309=5, 6, or 8 and ER34311 <2014)'
   ;
   VALUE ER34319F
         1 = 'United States only'
         2 = 'Outside U.S. only'
         3 = 'Both in the U.S. and outside'
         5 = 'Had no education'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.: this person was not a current Head/Spouse/Partner in 2015; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2015 or mover-out n'
             'onresponse by 2013 (ER34301=0); mover-out nonresponse for 2015, only if deceased (ER34302=81-89); OFUM in an institution in both 2013 and 2015 (ER34302=51-59 and ER34309=0); OFUM under age 16 (ER34305'
             '=001-015); OFUM associated with 2015 FU but moved out before 2014 (ER34309=5, 6, or 8 and ER34311<2014) or OFUM moved in in 2015 (ER34309=1 and ER34311=2015)'
   ;
   VALUE ER34320F
         1 = 'Graduated from high school'
         2 = 'Got a GED'
         3 = 'Neither'
         9 = 'DK; NA; refused'
         0 = 'Inap.:  this person was not a current Head/Spouse/Partner in 2015; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2015 or mover-out'
             'nonresponse by 2013 (ER34301=0); mover-out nonresponse for 2015, only if deceased (ER34302=81-89); OFUM in an institution in both 2013 and 2015 (ER34302=51-59 and ER34309=0); OFUM under age 16 (ER3430'
             '5=001-015); OFUM associated with 2015 FU but moved out before 2014 (ER34309=5, 6, or 8 and ER34311<2014) or OFUM moved in in 2015 (ER34309=1 and ER34311=2015); current Head/Spouse/Partner/eligible OFU'
             'M educated outside the U.S. only or had no education (ER34319=2 or 5);  NA or RF where current Head/Spouse/Partner/eligible OFUM received education (ER3419=9)'
   ;
   VALUE ER34321F
         1 = 'January'
         2 = 'February'
         3 = 'March'
         4 = 'April'
         5 = 'May'
         6 = 'June'
         7 = 'July'
         8 = 'August'
         9 = 'September'
        10 = 'October'
        11 = 'November'
        12 = 'December'
        21 = 'Winter'
        22 = 'Spring'
        23 = 'Summer'
        24 = 'Fall; autumn'
        99 = 'DK; NA; refused'
         0 = 'Inap.:  this person was not a current Head/Spouse/Partner in 2015; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2015 or mover-out'
             'nonresponse by 2013 (ER34301=0); mover-out nonresponse for 2015, only if deceased (ER34302=81-89); OFUM in an institution in both 2013 and 2015 (ER34302=51-59 and ER34309=0); OFUM under age 16 (ER3430'
             '5=001-015); OFUM associated with 2015 FU but moved out before 2014 (ER34309=5, 6, or 8 and ER34311<2014) or OFUM moved in in 2015 (ER34309=1 and ER34311=2015); current Head/Spouse/Partner/eligible OFU'
             'M educated outside the U.S. only or had no education (ER34319=2 or 5);  NA or RF where current Head/Spouse/Partner/eligible OFUM received education (ER3419=9); got a GED or neither got a GED nor gradu'
             'ated from high school (ER34320=2 or 3); DK, NA, or RF whether graduated from high school, got a GED, or neither graduated from high school nor got a GED (ER34320=9)'
   ;
   VALUE ER34323F
         1 = 'Finished first grade'
         2 = 'Finished second grade'
         3 = 'Finished third grade'
         4 = 'Finished fourth grade'
         5 = 'Finished fifth grade'
         6 = 'Finished sixth grade'
         7 = 'Finished seventh grade'
         8 = 'Finished eighth grade'
         9 = 'Finished ninth grade'
        10 = 'Finished tenth grade'
        11 = 'Finished eleventh grade'
        99 = 'DK; NA; refused'
         0 = 'Inap.:  this person was not a current Head/Spouse/Partner in 2015; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2015 or mover-out'
             'nonresponse by 2013 (ER34301=0); mover-out nonresponse for 2015, only if deceased (ER34302=81-89); OFUM in an institution in both 2013 and 2015 (ER34302=51-59 and ER34309=0); OFUM under age 16 (ER3430'
             '5=001-015); OFUM associated with 2015 FU but moved out before 2014 (ER34309=5, 6, or 8 and ER34311<2014) or OFUM moved in in 2015 (ER34309=1 and ER34311=2015); current Head/Spouse/Partner/eligible OFU'
             'M educated outside the U.S. only or had no education (ER34319=2 or 5);  NA or RF where current Head/Spouse/Partner/eligible OFUM received education (ER3419=9); graduated from high school or neither go'
             't a GED nor graduated from high school (ER34320=1 or 3); DK, NA, or RF whether graduated from high school, got a GED, or neither graduated from high school nor got a GED (ER34320=9)'
   ;
   VALUE ER34328F
         1 = 'Finished first grade'
         2 = 'Finished second grade'
         3 = 'Finished third grade'
         4 = 'Finished fourth grade'
         5 = 'Finished fifth grade'
         6 = 'Finished sixth grade'
         7 = 'Finished seventh grade'
         8 = 'Finished eighth grade'
         9 = 'Finished ninth grade'
        10 = 'Finished tenth grade'
        11 = 'Finished eleventh grade'
        99 = 'DK; NA; refused'
         0 = 'Inap.:  this person was not a current Head/Spouse/Partner in 2015; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2015 or mover-out'
             'nonresponse by 2013 (ER34301=0); mover-out nonresponse for 2015, only if deceased (ER34302=81-89); OFUM in an institution in both 2013 and 2015 (ER34302=51-59 and ER34309=0); OFUM under age 16 (ER3430'
             '5=001-015); OFUM associated with 2015 FU but moved out before 2014 (ER34309=5, 6, or 8 and ER34311<2014) or OFUM moved in in 2015 (ER34309=1 and ER34311=2015); current Head/Spouse/Partner/eligible OFU'
             'M educated outside the U.S. only or had no education (ER34319=2 or 5);  NA or RF where current Head/Spouse/Partner/eligible OFUM received education (ER3419=9); graduated from high school or got a GED'
             '(ER34320=1 or 2); DK, NA, or RF whether graduated from high school, got a GED, or neither graduated from high school nor got a GED (ER34320=9)'
   ;
   VALUE ER34331F
         1 = 'Yes'
         5 = 'No'
         9 = 'DK; NA; refused'
         0 = 'Inap.:  this person was not a current Head/Spouse/Partner in 2015; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2015 or mover-out'
             'nonresponse by 2013 (ER34301=0); mover-out nonresponse for 2015, only if deceased (ER34302=81-89); OFUM in an institution in both 2013 and 2015 (ER34302=51-59 and ER34309=0); OFUM under age 16 (ER3430'
             '5=001-015); OFUM associated with 2015 FU but moved out before 2014 (ER34309=5, 6, or 8 and ER34311<2014) or OFUM moved in in 2015 (ER34309=1 and ER34311=2015); current Head/Spouse/Partner/eligible OFU'
             'M educated outside the U.S. only or had no education (ER34319=2 or 5);  NA or RF where current Head/Spouse/Partner/eligible OFUM received education (ER3419=9); graduated from high school or got a GED'
             '(ER34320=1 or 2)'
   ;
   VALUE ER34335F
         1 = 'Yes'
         5 = 'No'
         9 = 'DK; NA; refused'
         0 = 'Inap.:  this person was not a current Head/Spouse/Partner in 2015; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2015 or mover-out'
             'nonresponse by 2013 (ER34301=0); mover-out nonresponse for 2015, only if deceased (ER34302=81-89); OFUM in an institution in both 2013 and 2015 (ER34302=51-59 and ER34309=0); OFUM under age 16 (ER3430'
             '5=001-015); OFUM associated with 2015 FU but moved out before 2014 (ER34309=5, 6, or 8 and ER34311<2014) or OFUM moved in in 2015 (ER34309=1 and ER34311=2015); current Head/Spouse/Partner/eligible OFU'
             'M educated outside the U.S. only or had no education (ER34319=2 or 5);  NA or RF where current Head/Spouse/Partner/eligible OFUM received education (ER3419=9); graduated from high school or got a GED'
             '(ER34320=1 or 2); has not attended college (ER34331=5); DK, NA, or RF whether attended college (ER34331=9); completed less than one year of college (ER34334=0)'
   ;
   VALUE ER34336F
         1 = 'Associate''s degree/AA'
         2 = 'Bachelor''s degree/BA/BS'
         3 = 'Master''s degree/MA/MS/MBA'
         4 = 'Doctorate/PhD'
         5 = 'LLB, JD (Law degrees)'
         6 = 'MD, DDS, DVM, DO (Medical degrees)'
         8 = 'Honorary degree'
        97 = 'Other - specify'
        99 = 'DK; NA; refused'
         0 = 'Inap.:  this person was not a current Head/Spouse/Partner in 2015; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2015 or mover-out'
             'nonresponse by 2013 (ER34301=0); mover-out nonresponse for 2015, only if deceased (ER34302=81-89); OFUM in an institution in both 2013 and 2015 (ER34302=51-59 and ER34309=0); OFUM under age 16 (ER3430'
             '5=001-015); OFUM associated with 2015 FU but moved out before 2014 (ER34309=5, 6, or 8 and ER34311<2014) or OFUM moved in in 2015 (ER34309=1 and ER34311=2015); current Head/Spouse/Partner/eligible OFU'
             'M educated outside the U.S. only or had no education (ER34319=2 or 5);  NA or RF where current Head/Spouse/Partner/eligible OFUM received education (ER3419=9); graduated from high school or got a GED'
             '(ER34320=1 or 2); has not attended college (ER34331=5); DK, NA, or RF whether attended college (ER34331=9); completed less than one year of college (ER34334=0); did not receive a college degree (ER343'
             '35=5); DK, NA, or RF whether received a college degree (ER34335=9)'
   ;
   VALUE ER34347F
         1 = 'Yes'
         5 = 'No'
         9 = 'DK; NA; refused'
         0 = 'Inap.:  this person was not a current Head/Spouse/Partner in 2015; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2015 or mover-out'
             'nonresponse by 2013 (ER34301=0); mover-out nonresponse for 2015, only if deceased (ER34302=81-89); OFUM in an institution in both 2013 and 2015 (ER34302=51-59 and ER34309=0); OFUM under age 16 (ER3430'
             '5=001-015); OFUM associated with 2015 FU but moved out before 2014 (ER34309=5, 6, or 8 and ER34311<2014) or OFUM moved in in 2015 (ER34309=1 and ER34311=2015); DK, NA, or RF where current Head/Spouse/'
             'Partner/eligible OFUM received education (ER3419=9); current Head/Spouse/Partner/eligible OFUM still in school (ER34332=96 or ER34333=9996)'
   ;
   VALUE ER34348F
         1 = 'First grade'
         2 = 'Second grade'
         3 = 'Third grade'
         4 = 'Fourth grade'
         5 = 'Fifth grade'
         6 = 'Sixth grade'
         7 = 'Seventh grade'
         8 = 'Eighth grade'
         9 = 'Ninth grade'
        10 = 'Tenth grade'
        11 = 'Eleventh grade'
        12 = 'Twelfth grade, "High School", GED'
        13 = '1st year college (freshman)'
        14 = '2nd year college (sophomore)'
        15 = '3rd year college (junior)'
        16 = '4th year college (senior)'
        17 = '5th or higher year of college'
        18 = 'Post-graduate work'
        99 = 'DK; NA; refused'
         0 = 'Inap.:  this person was not a current Head/Spouse/Partner in 2015; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2015 or mover-out'
             'nonresponse by 2013 (ER34301=0); mover-out nonresponse for 2015, only if deceased (ER34302=81-89); OFUM in an institution in both 2013 and 2015 (ER34302=51-59 and ER34309=0); OFUM under age 16 (ER3430'
             '5=001-015); OFUM associated with 2015 FU but moved out before 2014 (ER34309=5, 6, or 8 and ER34311<2014) or OFUM moved in in 2015 (ER34309=1 and ER34311=2015); DK, NA, or RF where current Head/Spouse/'
             'Partner/eligible OFUM received education (ER3419=9); current Head/Spouse/Partner/eligible OFUM not still in school (ER34332=96 and ER34333=9996 and ER34347=5 or 9)'
   ;
   VALUE ER34349F
    1 - 17 = 'Highest grade or year of school completed'
        99 = 'DK; NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2015 or mover-out nonresponse by 2013 (ER34201=0); in an institution in both'
             '2013 and 2015 (ER34202=51-59 and ER34208=0); not a person aged 16 or older (ER34204=001-015, 999); associated with 2015 FU but actually moved out before 2014 (ER34208=5, 6, or 8 and ER34210<2014) or m'
             'oved in in 2015 and was not a Head or Spouse/Partner (ER34208=1 and ER34210=2015 and ER34202 GE 2 andER34203 GE 30)'
   ;
   VALUE ER34350F
         1 = 'Yes'
         2 = 'IF VOL.:  Still in school'
         5 = 'No'
         9 = 'DK; NA; refused'
         0 = 'Inap.:  this person was a new Head/Spouse/Partner/eligible OFUM this wave; this person was not a current Head/Spouse/Partner in 2015; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample'
             ' (ER30001=4001-4462); main family nonresponse by 2015 or mover-out nonresponse by 2013 (ER34301=0); mover-out nonresponse for 2015, only if deceased (ER34302=81-89); OFUM in an institution in both 201'
             '3 and 2015 (ER34302=51-59 and ER34309=0); OFUM under age 16 (ER34305=001-015); OFUM associated with 2015 FU but moved out before 2014 (ER34309=5, 6, or 8 and ER34311<2014) or OFUM moved in in 2015 (ER'
             '34309=1 and ER34311=2015)'
   ;
   VALUE ER34351F
         1 = 'United States only'
         2 = 'Outside U.S. only'
         3 = 'Both in the U.S. and outside'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.:  this person was a new Head/Spouse/Partner/eligible OFUM this wave; this person was not a current Head/Spouse/Partner in 2015; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample'
             ' (ER30001=4001-4462); main family nonresponse by 2015 or mover-out nonresponse by 2013 (ER34301=0); mover-out nonresponse for 2015, only if deceased (ER34302=81-89); OFUM in an institution in both 201'
             '3 and 2015 (ER34302=51-59 and ER34309=0); OFUM under age 16 (ER34305=001-015); OFUM associated with 2015 FU but moved out before 2014 (ER34309=5, 6, or 8 and ER34311<2014) or OFUM moved in in 2015 (ER'
             '34309=1 and ER34311=2015); has not attended regular school since last interview (ER34350=5); DK, NA, or RF whether attended regular school since last interview (ER34350=9)'
   ;
   VALUE ER34352F
         1 = 'Graduated from high school'
         2 = 'Got a GED'
         3 = 'Neither'
         9 = 'DK; NA; refused'
         0 = 'Inap.:  preloaded completed education is high school or higher or DK, NA, or RF; this person was a new Head/Spouse/Partner/eligible OFUM this wave; this person was not a current Head/Spouse/Partner in'
             ' 2015; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2015 or mover-out nonresponse by 2013 (ER34301=0); mover-out nonresponse for 2'
             '015, only if deceased (ER34302=81-89); OFUM in an institution in both 2013 and 2015 (ER34302=51-59 and ER34309=0); OFUM under age 16 (ER34305=001-015); OFUM associated with 2015 FU but moved out befor'
             'e 2014 (ER34309=5, 6, or 8 and ER34311<2014) or OFUM moved in in 2015 (ER34309=1 and ER34311=2015); has not attended regular school since last interview (ER34350=5); DK, NA, or RF whether attended reg'
             'ular school since last interview (ER34350=8 or 9); returning Head/Spouse/Partner/eligible OFUM educated outside the U.S. only (ER34351=2);  NA or RF where returning Head/Spouse/Partner/eligible OFUM r'
             'eceived education (ER34351=9)'
   ;
   VALUE ER34360F
         1 = 'Finished first grade'
         2 = 'Finished second grade'
         3 = 'Finished third grade'
         4 = 'Finished fourth grade'
         5 = 'Finished fifth grade'
         6 = 'Finished sixth grade'
         7 = 'Finished seventh grade'
         8 = 'Finished eighth grade'
         9 = 'Finished ninth grade'
        10 = 'Finished tenth grade'
        11 = 'Finished eleventh grade'
        99 = 'DK; NA; refused'
         0 = 'Inap.:  finished no grades of regular school; preloaded completed education is high school or higher or DK, NA, or RF; this person was a new Head/Spouse/Partner/eligible OFUM this wave; this person wa'
             's not a current Head/Spouse/Partner in 2015; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2015 or mover-out nonresponse by 2013 (E'
             'R34301=0); mover-out nonresponse for 2015, only if deceased (ER34302=81-89); OFUM in an institution in both 2013 and 2015 (ER34302=51-59 and ER34309=0); OFUM under age 16 (ER34305=001-015); OFUM assoc'
             'iated with 2015 FU but moved out before 2014 (ER34309=5, 6, or 8 and ER34311<2014) or OFUM moved in in 2015 (ER34309=1 and ER34311=2015); has not attended regular school since last interview (ER34350='
             '5); DK, NA, or RF whether attended regular school since last interview (ER34350=8 or 9); returning Head/Spouse/Partner/eligible OFUM educated outside the U.S. only (ER34351=2);  NA or RF where returni'
             'ng Head/Spouse/Partner/eligible OFUM received education (ER34351=9); since last interview, graduated from high school or got a GED (ER34352=1 or 2); DK, NA, or RF whether, since last interview, gradua'
             'ted from high school, got a GED, or neither (ER34352=9)'
   ;
   VALUE ER34363F
         1 = 'Yes'
         5 = 'No'
         9 = 'DK; NA; refused'
         0 = 'Inap.:  this person was a new Head/Spouse/Partner/eligible OFUM this wave; this person was not a current Head/Spouse/Partner in 2015; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample'
             ' (ER30001=4001-4462); main family nonresponse by 2015 or mover-out nonresponse by 2013 (ER34301=0); mover-out nonresponse for 2015, only if deceased (ER34302=81-89); OFUM in an institution in both 201'
             '3 and 2015 (ER34302=51-59 and ER34309=0); OFUM under age 16 (ER34305=001-015); OFUM associated with 2015 FU but moved out before 2014 (ER34309=5, 6, or 8 and ER34311<2014) or OFUM moved in in 2015 (ER'
             '34309=1 and ER34311=2015); has not attended regular school since last interview (ER34350=5); DK, NA, or RF whether attended regular school since last interview (ER34350=8 or 9); returning Head/Spouse/'
             'Partner/eligible OFUM educated outside the U.S. only (ER34351=2);  NA or RF where returning Head/Spouse/Partner/eligible OFUM received education (ER34351=9)'
   ;
   VALUE ER34367F
         1 = 'Yes'
         5 = 'No'
         9 = 'DK; NA; refused'
         0 = 'Inap.:  this person was a new Head/Spouse/Partner/eligible OFUM this wave; this person was not a current Head/Spouse/Partner in 2015; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample'
             ' (ER30001=4001-4462); main family nonresponse by 2015 or mover-out nonresponse by 2013 (ER34301=0); mover-out nonresponse for 2015, only if deceased (ER34302=81-89); OFUM in an institution in both 201'
             '3 and 2015 (ER34302=51-59 and ER34309=0); OFUM under age 16 (ER34305=001-015); OFUM associated with 2015 FU but moved out before 2014 (ER34309=5, 6, or 8 and ER34311<2014) or OFUM moved in in 2015 (ER'
             '34309=1 and ER34311=2015); has not attended regular school since last interview (ER34350=5); DK, NA, or RF whether attended regular school since last interview (ER34350=8 or 9); returning Head/Spouse/'
             'Partner/eligible OFUM educated outside the U.S. only (ER34351=2);  NA or RF where returning Head/Spouse/Partner/eligible OFUM received education (ER34351=9); has not attended college since last interv'
             'iew (ER34363=5); DK, NA, or RF whether attended college since last interview (ER34363=9)'
   ;
   VALUE ER34368F
         1 = 'Associate''s degree/AA'
         2 = 'Bachelor''s degree/BA/BS'
         3 = 'Master''s degree/MA/MS/MBA'
         4 = 'Doctorate/PhD'
         5 = 'LLB, JD (Law degrees)'
         6 = 'MD, DDS, DVM, DO (Medical degrees)'
         8 = 'Honorary degree'
        97 = 'Other - specify'
        99 = 'DK; NA; refused'
         0 = 'Inap.:  this person was a new Head/Spouse/Partner/eligible OFUM this wave; this person was not a current Head/Spouse/Partner in 2015; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample'
             ' (ER30001=4001-4462); main family nonresponse by 2015 or mover-out nonresponse by 2013 (ER34301=0); mover-out nonresponse for 2015, only if deceased (ER34302=81-89); OFUM in an institution in both 201'
             '3 and 2015 (ER34302=51-59 and ER34309=0); OFUM under age 16 (ER34305=001-015); OFUM associated with 2015 FU but moved out before 2014 (ER34309=5, 6, or 8 and ER34311<2014) or OFUM moved in in 2015 (ER'
             '34309=1 and ER34311=2015); has not attended regular school since last interview (ER34350=5); DK, NA, or RF whether attended regular school since last interview (ER34350=8 or 9); returning Head/Spouse/'
             'Partner/eligible OFUM educated outside the U.S. only (ER34351=2);  NA or RF where returning Head/Spouse/Partner/eligible OFUM received education (ER34351=9); has not attended college since last interv'
             'iew (ER34363=5); DK, NA, or RF whether attended college since last interview (ER34363=9); has not received a college degree since last interview (ER34367=5); DK, NA, or RF whether received a college d'
             'egree since last interview (ER34367=9)'
   ;
   VALUE ER34379F
         1 = 'Yes'
         5 = 'No'
         9 = 'DK; NA; refused'
         0 = 'Inap.:  this person was a new Head/Spouse/Partner/eligible OFUM this wave; this person was not a current Head/Spouse/Partner in 2015; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample'
             ' (ER30001=4001-4462); main family nonresponse by 2015 or mover-out nonresponse by 2013 (ER34301=0); mover-out nonresponse for 2015, only if deceased (ER34302=81-89); OFUM in an institution in both 201'
             '3 and 2015 (ER34302=51-59 and ER34309=0); OFUM under age 16 (ER34305=001-015); OFUM associated with 2015 FU but moved out before 2014 (ER34309=5, 6, or 8 and ER34311<2014) or OFUM moved in in 2015 (ER'
             '34309=1 and ER34311=2015); still in school since last interview (ER34350=2 or ER34364=96 or ER34365=9996)'
   ;
   VALUE ER34380F
         1 = 'First grade'
         2 = 'Second grade'
         3 = 'Third grade'
         4 = 'Fourth grade'
         5 = 'Fifth grade'
         6 = 'Sixth grade'
         7 = 'Seventh grade'
         8 = 'Eighth grade'
         9 = 'Ninth grade'
        10 = 'Tenth grade'
        11 = 'Eleventh grade'
        12 = 'Twelfth grade, "High School", GED'
        13 = '1st year college (freshman)'
        14 = '2nd year college (sophomore)'
        15 = '3rd year college (junior)'
        16 = '4th year college (senior)'
        17 = '5th or higher year of college'
        18 = 'Post-graduate work'
        99 = 'DK; NA; refused'
         0 = 'Inap.:  this person was a new Head/Spouse/Partner/eligible OFUM this wave; this person was not a current Head/Spouse/Partner in 2015; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample'
             ' (ER30001=4001-4462); main family nonresponse by 2015 or mover-out nonresponse by 2013 (ER34301=0); mover-out nonresponse for 2015, only if deceased (ER34302=81-89); OFUM in an institution in both 201'
             '3 and 2015 (ER34302=51-59 and ER34309=0); OFUM under age 16 (ER34305=001-015); OFUM associated with 2015 FU but moved out before 2014 (ER34309=5, 6, or 8 and ER34311<2014) or OFUM moved in in 2015 (ER'
             '34309=1 and ER34311=2015); not still in school since last interview (ER34350=1, 5, or 9 and ER34364 ne 96 and ER34365 ne 9996 and ER34379=5 or 9)'
   ;
   VALUE ER34381F
         1 = 'Yes, is in poor health'
         5 = 'No, is not in poor health'
         9 = 'DK; NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2015 or mover-out nonresponse by 2013 (ER34301=0); in an institution or mover'
             '-out nonresponse in 2015 (ER34302=51-89); current Head/Spouse/Partner (ER34302=1-2 and ER34303=10, 20, 22)'
   ;
   VALUE ER34382F
         1 = 'Yes, this individual is covered by the state health insurance plan for uninsured children'
         5 = 'No, this individual is not covered by the state health insurance plan for uninsured children'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.:  not covered by health insurance/does not have health care coverge; has the same health insurance or health care coverage as everyone else in the FU and is older than 18 years old; from Latino'
             'sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2015 or mover-out nonresponse by 2013 (ER34301=0); moved out before 2013 (ER34302=71-89 and ER343'
             '11 >0 and ER34311 <2013)'
   ;
   VALUE ER34383F
    1 - 12 = 'Actual number of months uninsured'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  was insured all months in 2013; born after 2013; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2015 or mover-out nonrespons'
             'e by 2013 (ER34301=0); moved out before 2013 (ER34302=71-89 and ER34311 >0 and ER34311 <2013)'
   ;
   VALUE ER34384F
    1 - 12 = 'Actual number of months uninsured'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  was insured all months in 2014; born after 2014; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2015 or mover-out nonrespons'
             'e by 2013 (ER34301=0); moved out before 2013 (ER34302=71-89 and ER34311 >0 and ER34311 <2013)'
   ;
   VALUE ER34385F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2015 or mover-out nonresponse by 2013 (ER34301=0); moved out before 2013 (ER3'
             '4302=71-89 and ER34311 >0 and ER34311 <2013)'
   ;
   VALUE ER34386F
         1 = 'Employer provided health insurance'
         2 = 'Private health insurance purchased'
         3 = 'Medicare'
         4 = 'Medi-Gap/Supplemental'
         5 = 'Medicaid/[STATEMEDPROG]/[SCHIPNAME]'
         8 = 'Indian Health Insurance'
         9 = 'Other state-sponsored plan (not Medicaid)'
        10 = 'Other government program'
        12 = 'Military Health Care/Tricare (Active duty)/ Military Health Care/ Tricare (Active duty)/ VA (Veterans'' Administration)'
        97 = 'Other health insurance'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2015 or mover-out nonresponse by 2013 (ER34201=0); moved out before 2013 (ER3'
             '4202=71-89 and ER34210>0 and ER34210<2013); does not have health insurance of health care coverage now (ER34385=5); DK, NA, or RF whether has health insurance or health care coverage now (ER34385=8 or'
             ' 9)'
   ;
   VALUE ER34387F
         1 = 'Employer provided health insurance'
         2 = 'Private health insurance purchased'
         3 = 'Medicare'
         4 = 'Medi-Gap/Supplemental'
         5 = 'Medicaid/[STATEMEDPROG]/[SCHIPNAME]'
         8 = 'Indian Health Insurance'
         9 = 'Other state-sponsored plan (not Medicaid)'
        10 = 'Other government program'
        12 = 'Military Health Care/Tricare (Active duty)/ Military Health Care/ Tricare (Active duty)/ VA (Veterans'' Administration)'
        97 = 'Other health insurance'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2015 or mover-out nonresponse by 2013 (ER34201=0); moved out before 2013 (ER3'
             '4202=71-89 and ER34210>0 and ER34210<2013); does not have health insurance of health care coverage now (ER34385=5); DK, NA, or RF whether has health insurance or health care coverage now (ER34385=8 or'
             ' 9); NA, DK to first mention (ER34386=98 or 99); no second mention'
   ;
   VALUE ER34388F
         1 = 'Employer provided health insurance'
         2 = 'Private health insurance purchased'
         3 = 'Medicare'
         4 = 'Medi-Gap/Supplemental'
         5 = 'Medicaid/[STATEMEDPROG]/[SCHIPNAME]'
         8 = 'Indian Health Insurance'
         9 = 'Other state-sponsored plan (not Medicaid)'
        10 = 'Other government program'
        12 = 'Military Health Care/Tricare (Active duty)/ Military Health Care/ Tricare (Active duty)/ VA (Veterans'' Administration)'
        97 = 'Other health insurance'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2015 or mover-out nonresponse by 2013 (ER34201=0); moved out before 2013 (ER3'
             '4202=71-89 and ER34210>0 and ER34210<2013); does not have health insurance of health care coverage now (ER34385=5); DK, NA, or RF whether has health insurance or health care coverage now (ER34385=8 or'
             ' 9); NA, DK to first mention (ER34386=98 or 99); less than three mentions'
   ;
   VALUE ER34389F
    1 - 24 = 'Sequence number of the first person in the Family Unit in 2015 whose employer provided this individual''s health insurance/coverage.'
        96 = 'Parent of Family Unit member who lives outside of FU'
        97 = 'Other person outside of FU'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2015 or mover-out nonresponse by 2013 (ER34301=0); moved out before 2013 (ER3'
             '4302=71-89 and ER34311 >0 and ER34311 <2013); does not have health insurance of health care coverage now (ER34385=5); DK, NA, or RF whether has health insurance or health care coverage now (ER34385=8'
             'or 9); DK, NA, or RF type of health insurance/health care coverage (ER34386=98 or 99); does not have employer provided health insurance (ER34386 ne 1 and ER34387 ne 1 and ER34388 ne 1)'
   ;
   VALUE ER34390F
    1 - 24 = 'Sequence number of the second person in the Family Unit in 2015 whose employer provided this individual''s health insurance/coverage.'
        96 = 'Parent of Family Unit member who lives outside of FU'
        97 = 'Other person outside of FU'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2015 or mover-out nonresponse by 2013 (ER34301=0); moved out before 2013 (ER3'
             '4302=71-89 and ER34311 >0 and ER34311 <2013); does not have health insurance of health care coverage now (ER34385=5); DK, NA, or RF whether has health insurance or health care coverage now (ER34385=8'
             'or 9); DK, NA, or RF type of health insurance/health care coverage (ER34386=98 or 99); does not have employer provided health insurance (ER34386 ne 1 and ER34387 ne 1 and ER34388 ne 1); no second ment'
             'ion'
   ;
   VALUE ER34391F
    1 - 24 = 'Sequence number of the first person in the Family Unit in 2015 who was the policy holder on this individual''s private health insurance/coverage.'
        96 = 'Parent of Family Unit member who lives outside of FU'
        97 = 'Other person outside of FU'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2015 or mover-out nonresponse by 2013 (ER34301=0); moved out before 2013 (ER3'
             '4302=71-89 and ER34311 >0 and ER34311 <2013); does not have health insurance of health care coverage now (ER34385=5); DK, NA, or RF whether has health insurance or health care coverage now (ER34385=8'
             'or 9); DK, NA, or RF type of health insurance/health care coverage (ER34386=98 or 99); does not have private health insurance (ER34386 ne 2 and ER34387 ne 2 and ER34388 ne 2)'
   ;
   VALUE ER34392F
    1 - 24 = 'Sequence number of the second person in the Family Unit in 2015 who was the policy holder on this individual''s private health insurance/coverage.'
        96 = 'Parent of Family Unit member who lives outside of FU'
        97 = 'Other person outside of FU'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2015 or mover-out nonresponse by 2013 (ER34301=0); moved out before 2013 (ER3'
             '4302=71-89 and ER34311 >0 and ER34311 <2013); does not have health insurance of health care coverage now (ER34385=5); DK, NA, or RF whether has health insurance or health care coverage now (ER34385=8'
             'or 9); DK, NA, or RF type of health insurance/health care coverage (ER34386=98 or 99); does not have private health insurance (ER34386 ne 2 and ER34387 ne 2 and ER34388 ne 2); no second mention'
   ;
   VALUE ER34393F
         1 = 'This individual is a 2015 Head/Spouse/Partner who was covered by Medicare or was aged 65 or older, was the respondent, and did not give a useable Medicare number in prior waves but did in this wave.'
         2 = 'This individual is a 2015 Head/Spouse/Partner who was covered by Medicare or was aged 65 or older, was the respondent, did not give a useable Medicare number in prior waves, and provided a Medicare nu'
             'mber in this wave but it was not useable (e.g., missing digits).'
         5 = 'This individual is a 2015 Head/Spouse/Partner who was covered by Medicare or was aged 65 or older, was the respondent, did not give a useable Medicare number in prior waves and in the present wave dec'
             'lined to give his/her Medicare number (H62a=5), did not know/refused whether the number was a Medicare Claim or Railroad Retirement Board number, or did not know the number at H62c/H62e-f.'
         7 = 'This individual is associated with a responding FU and was a Head/Spouse/Partner in a prior wave, who was covered by Medicare, was the respondent, and provided a useable Medicare number in some prior'
             'wave.'
         9 = 'This individual is a 2015 Head/Spouse/Partner who was covered by Medicare or was aged 65 or older, was the respondent, did not give a useable Medicare number in prior waves, and in the present wave wh'
             'ether a Medicare number could be provided was NA or DK (H62a=8 or 9).'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2015 or mover-out nonresponse by 2013 (ER34301=0); moved out before 2013 (ER3'
             '4302=71-89 and ER34311 >0 and ER34311 <2013); not Head/Spouse/Partner in 2015 (ER34303 >22 or ER34302 >50); under age 65 and not covered by Medicare (ER34305 <65 or 999 and neither ER34386, ER34387, E'
             'R34388=3);  not the respondent (ER34312=5)'
   ;
   VALUE ER34393AF
         1 = 'Only one job'
         2 = 'Two jobs'
         3 = 'Three jobs'
         4 = 'Four jobs or more'
         5 = 'Didn''t have a job'
         8 = 'Don''t know'
         9 = 'NA; refused'
         0 = 'Inap.: this person was a current Head/Spouse/Partner in 2015; from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2015 or mover-out nonre'
             'sponse by 2013 (ER34301=0); OFUM in an institution in both 2013 and 2015 (ER34302=51-59 and ER34309=0); OFUM under age 16 (ER34305=001-015); OFUM associated with 2015 FU but moved out before 2014 (ER3'
             '4309=5, 6, or 8 and ER34311<2014) or OFUM moved in in 2015 (ER34309=1 and ER34311=2015)'
   ;
   VALUE ER34405F
         1 = 'This individual was eligible to be followed in 2015'
         5 = 'This individual was not eligible to be followed in 2015'
         0 = 'Inap.:  main family or mover-out nonresponse in 2013 and not selected for recontact in 2015; from Latino sample (ER30001=7001-9308)'
   ;
   VALUE ER34407F
         1 = 'This individual was eligible to be interviewed for the TAS interview in 2015'
         0 = 'Inap.:  this individual was from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); not interviewed as part of 1997 CDS (ER33420=00, 02-98); main family nonresponse by'
             '2015 (ER34301=0 and ER34302=0); mover-out nonresponse in 2015 (ER34302=71-89)'
   ;
   VALUE ER34408F
         1 = 'Interview with eligible sample individual'
         3 = 'Refusal by the sample individual; partial/passive refusal; deliberate avoidance of interviewer (e.g., always too busy, repeated broken appointments, or failure to return calls)'
         4 = 'Sample individual lost; tracking efforts exhausted'
         5 = 'Sample individual incapacitated, had a permanent health condition, or institutionalized for health or mental reasons'
         6 = 'Sample individual deceased after PSID interview completed but before TAS interview'
         7 = 'Some household member contacted, but eligible respondent not available to do interview; appointment broken, but no evidence of deliberately avoiding interview'
        10 = 'Adamant refusal by the eligible sample member. These individuals will never be asked to participate in the TAS study again, regardless of recontact efforts.'
        13 = 'Refusal by someone other than the sample individual'
        30 = 'Sample individual away on military leave, in job corps, or in a non-detention facility'
        31 = 'Sample individual resided outside the US or in a remote area and uncontactable (e.g., no telephone)'
        34 = 'Sample individual incarcerated or in a youth, group, or detention home/center'
        70 = 'Sample individual was randomly dropped because two others in the family unit were also eligible (CDS only)'
        90 = 'Sample individual was initially thought to be ineligible because of nonresponse but discovered to be a resident in a response sample family after the interviewing period had ended.'
        95 = 'Office error--study ended, insufficient or inappropriate calls made, no mention of refusal'
         0 = 'Inap.:  this individual was from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); not interviewed as part of 1997 CDS (ER33420=00, 02-98); main family nonresponse by'
             '2015 (ER34301=0 and ER34302=0); mover-out nonresponse in 2015 (ER34302=71-89)'
   ;
   VALUE ER34409F
         1 = 'This individual was eligible to be interviewed for the Well Being and Daily Life Supplement in 2016'
         5 = 'Head/Spouse/Partner was deceased by the time of Well Being contact; Head/Spouse/Partner was institutionalized by the time of the Well Being contact; proxy respondent was used for the main PSID intervi'
             'ew; PSID interview was not conducted in English; Head/Spouse/Partner was not age eligible (birth year 1986 or later); age and date of birth of the Head/Spouse/Partner was unknown and therefore was not'
             ' eligible for the Well Being study.'
         0 = 'Inap.: this individual was from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2015 (ER34301=0 and ER34302=0); mover-out nonresponse in 2'
             '015 (ER34302=71-89); this individual is neither Head nor Spouse/Partner in 2015 (ER34302 ge 2 and ER34303 gt 22)'
   ;
   VALUE ER34410F
         1 = 'Completed interview'
         2 = 'Partial interview'
         3 = 'Refusal'
         4 = 'Never completed, no evidence of refusal'
         5 = 'Lost'
         6 = 'This individual has a permanent condition that precludes ability to co-operate'
         7 = 'Core interview was taken in English however, this individual is a non-English speaker that precludes ability to co-operate'
         8 = 'Incomplete PAPI interview'
         9 = 'Incomplete Web interview'
        10 = 'Adamant refusal by all eligible/available FU members. These individuals will never be asked to participate in the study again, regardless of recontact efforts.'
        15 = 'Adamant refusal by all eligible/available FU members. Sample individual (or other FU member on their behalf) contacted the study or IRB (by letter, email, phone call to the 800#, or respondent-initiat'
             'ed phone call to the interviewer) with a strong request to be removed from the study.'
        16 = 'Office Error: This individual was initially thought to be ineligible because of nonresponse but discovered to be a resident in a response family as Head or Spouse/Partner after the WB interviewing per'
             'iod had ended.'
        17 = 'Office Error: This individual was mistakenly coded deceased but discovered to be a resident in a response family as Head or Spouse/Partner after the WB interviewing period had ended.'
        18 = 'Office Error: This individual''s case was mistakenly coded as having a PSID proxy respondent but discovered that Head or Spouse/Partner was respondent after the WB interviewing period had ended.'
        19 = 'Office Error: Wrong Respondent'
        20 = 'Office Error: Other'
        21 = 'R resides in a foreign country'
        30 = 'Nonsample: This Individual was deceased when contacted for the WB Study'
        31 = 'Nonsample: This individual was institutionalized by the time he or she was contacted for WB'
        32 = 'Nonsample: Proxy R was used for main PSID interview'
        33 = 'Nonsample: Non-English Core PSID interview'
        34 = 'Nonsample: Head or Spouse/Partner was too young to be eligible for the WB study (birth year of 1986 or later)'
        35 = 'Nonsample: Head or Spouse/Partner''s age and year of birth was unknown; therefore not eligible for WB study'
         0 = 'Inap.: this individual was from Latino sample (ER30001=7001-9308); from Immigrant 2017 sample (ER30001=4001-4462); main family nonresponse by 2015 (ER34301=0 and ER34302=0); mover-out nonresponse in 2'
             '015 (ER34302=71-89); this individual is neither Head nor Spouse/Partner in 2015 (ER34302 ge 2 and ER34303 gt 22)'
   ;
   VALUE ER34411F
         1 = 'This sample member was main family nonresponse and had been in the FU in 2013.'
         3 = 'This nonsample individual had been in the 2013 FU, and this FU became nonresponse in 2015.'
         4 = 'This sample member had been in an institution in 2013, but his or her family became nonresponse in 2015.'
         5 = 'This sample member, linked to a 2015 response family, was in an institution at the time of the 2015 interview.'
         6 = 'This sample member moved out or died between the 2013 and 2015 interviews.'
         8 = 'This nonsample individual moved out or died between the 2013 and 2015 interviews.'
         9 = 'This individual had not been born or moved in by the time of the 2015 interview; individual from Immigrant 17 sample (ER30001=4001-4462)'
        10 = 'This individual had become nonresponse by the time of the 2015 interview.'
        21 = 'Main family recontact: this person was selected for recontact in 2015, but the family was not successfully interviewed.'
        26 = 'Splitoff recontact: this sample member moved out of a 2015 recontact main family but was not successfully interviewed.'
        40 = 'Individual connected with the Latino sample (ER30001=7001-9308); this sample was dropped beginning in 1996.  Individual dropped from the Census (SEO) sample due to budgetary constraints; this group wa'
             's dropped beginning in 1997.'
        99 = 'DK; NA'
         0 = 'Inap.:  this individual was in a panel family in 2015 (ER34302=1-20).'
   ;
   VALUE ER34412F
         1 = 'Wave refusal by all eligible/available FU members.'
         2 = 'No one at home for contact during the interviewing period.'
         3 = 'Respondent absent; some FU member contacted, but not the appropriate respondent.'
         4 = 'Lost; unable to locate any member of the FU at all.'
         5 = 'FU is located too far away for interviewer contact.'
        10 = 'Panel refusal by all all eligible/available FU members.  These individuals will never be asked to participate in the study again, regardless of recontact efforts.'
        11 = 'This sample member was in the armed forces.'
        12 = 'This sample member was in an educational institution.'
        13 = 'This sample member was in a health care facility.'
        14 = 'This sample member was in jail or prison.'
        15 = 'Panel refusal by all all eligible/available FU members. Sample individual (or other FU member on their behalf) contacted the study or IRB (by letter, email, phone call to the 800#, or respondent-initi'
             'ated phone call to the interviewer) with a strong request to be removed from the study.'
        19 = 'This sample member was in some other type of institution; for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        21 = 'This nonsample individual became main family nonresponse because the Head or the Spouse, whichever is the sample member, became institutionalized by joining the armed forces.'
        22 = 'This nonsample individual became main family nonresponse because the Head or Spouse, whichever is sample, became institutionalized by entering an educational institution.'
        23 = 'This nonsample individual became main family nonresponse because the Head or Spouse, whichever is the sample member, became institutionalized by entering a health care facility.'
        24 = 'This nonsample individual became main family nonresponse because the Head or Spouse, whichever is the sample member, became institutionalized through imprisonment.'
        25 = 'This individual became main family nonresponse because the sample member contacted the study or IRB with a request to be removed from the study (sample individual is coded 15 for this wave).'
        29 = 'This nonsample individual became main family nonresponse because the Head or Spouse, whichever is sample, became institutionalized by some means other than the above; for example, he/she may have ente'
             'red a religious order. Cases in which the type of institution is unknown are included here, also.'
        31 = 'This sample member was unable to cooperate because of disability.'
        32 = 'This nonsample individual became main family nonresponse because the Head or Spouse, whichever is sample, was unable to cooperate because of disability.'
        41 = 'This individual died between the 2013 and 2015 interviews; this individual died after becoming nonresponse for some other reason before the 2013 interview.'
        42 = 'This nonsample individual became main family nonresponse because the Head or Spouse, whichever is sample, died.'
        45 = 'This individual was a sample member but has been adopted by unrelated nonsample persons and therefore has become nonsample.'
        51 = 'This individual, although followed for interview, was discovered to be nonsample:  office error.'
        52 = 'This individual should have been followed but was not:  office error.'
        53 = 'This individual was mistakenly included in two or more response families at once; this record is the duplicate, or erroneous, one.'
        54 = 'Listing error: this individual never existed or was not really living in the FU.'
        57 = 'Insufficient information that would permit recontact; no name or identifying information available'
        58 = 'Due to budgetary and/or time constraints, PSID staff decided not to take all of the usual steps to try to locate and/or persuade this FU.'
        59 = 'Limited number of contacts attempted:  miscellaneous office error (does not include codes 01-54 above or codes 91-99 below).'
        60 = 'This nonsample parent of a sample child is no longer eligible to be interviewed.'
        61 = 'This nonsample individual was associated with a family containing a person erroneously designated as followable; the erroneous person''s code is 45, 51, 53, 54, or 60.'
        80 = 'Individual connected with the Latino sample (ER30001=7001-9308); this sample was dropped beginning in 1996.  Individual dropped from the Census (SEO) sample due to budgetary constraints; this group wa'
             's dropped beginning in 1997.'
        91 = 'This individual moved out of the 2015 main family and was eligible to be followed, but the reason for nonresponse is NA.'
        92 = 'Individual moved out of the 2015 main family and was not eligible to be followed.'
        93 = 'All sample members of this FU united with other panel FUs; this individual was nonsample and therefore became nonresponse.'
        97 = 'This individual had not been born or moved in by the time of the 2015 interview (ER34301>0 and ER34302=0); individual from Immigrant 17 sample (ER30001=4001-4462)'
        98 = 'This individual became main family or mover-out nonresponse by 2013 and was not selected for recontact in 2015 (ER34201=0 and ER34301=0 and ER34405=0 or ER34201>0 and ER34301=71-89 and ER34301=0 and E'
             'R34405=0).'
        99 = 'DK; NA'
         0 = 'Inap.:  this individual was in a panel family in 2015 (ER34302=1-20)'
   ;
   VALUE ER34502F
    1 - 20 = 'Individuals in the family at the time of the 2017 interview'
   51 - 59 = 'Individuals in institutions at the time of the 2017 interview'
   71 - 80 = 'Individuals who moved out of the FU or out of institutions and established their own households between the 2015 and 2017 interviews'
   81 - 89 = 'Individuals who were living in 2015 but died by the time of the 2017 interview'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0)'
   ;
   VALUE ER34503F
        10 = 'Reference Person in 2017; 2015 Reference Person who was mover-out nonresponse by the time of the 2017 interview'
        20 = 'Legal Spouse in 2017; 2015 Spouse who was mover-out nonresponse by the time of the 2017 interview'
        22 = 'Partner--cohabitor who has lived with Reference Person for 12 months or more; 2015 Partner who was mover-out nonresponse by the time of the 2017 interview'
        30 = 'Son or daughter of Reference Person (includes adopted children but not stepchildren)'
        33 = 'Stepson or stepdaughter of Reference Person (children of legal Spouse [code 20] who are not children of Reference Person)'
        35 = 'Son or daughter of Partner but not Reference Person (includes only those children of mothers whose relationship to Reference Person is 22 but who are not children of Reference Person)'
        37 = 'Son-in-law or daughter-in-law of Reference Person (includes stepchildren-in-law)'
        38 = 'Foster son or foster daughter, not legally adopted'
        40 = 'Brother or sister of Reference Person (includes step and half sisters and brothers)'
        47 = 'Brother-in-law or sister-in-law of Reference Person (i.e., brother or sister of legal Spouse; spouse of HD''s brother or sister; spouse of legal Spouse''s brother or sister)'
        48 = 'Brother or sister of Reference Person''s cohabitor (the cohabitor is coded 22 or 88)'
        50 = 'Father or mother of Reference Person (includes stepparents)'
        57 = 'Father-in-law or mother-in-law of Reference Person (includes parents of legal spouses [code 20] only)'
        58 = 'Father or mother of Reference Person''s cohabitor (the cohabitor is coded 22 or 88)'
        60 = 'Grandson or granddaughter of Reference Person (includes grandchildren of legal Spouse [code 20] only; those of a cohabitor are coded 97)'
        65 = 'Great-grandson or great-granddaughter of Reference Person (includes great-grandchildren of legal Spouse [code 20]; those of a cohabitor are coded 97)'
        66 = 'Grandfather or grandmother of Reference Person (includes stepgrandparents)'
        67 = 'Grandfather or grandmother of legal Spouse (code 20)'
        68 = 'Great-grandfather or great-grandmother of Reference Person'
        69 = 'Great-grandfather or great-grandmother of legal Spouse (code 20)'
        70 = 'Nephew or niece of Reference Person'
        71 = 'Nephew or niece of legal Spouse (code 20)'
        72 = 'Uncle or Aunt of Reference Person'
        73 = 'Uncle or Aunt of legal Spouse (code 20)'
        74 = 'Cousin of Reference Person'
        75 = 'Cousin of legal Spouse (code 20)'
        83 = 'Children of first-year cohabitor but not of Reference Person (the parent of this child is coded 88)'
        88 = 'First-year cohabitor of Reference Person'
        90 = 'Uncooperative legal spouse of Reference Person (this individual is unable or unwilling to be designated as Reference Person or Spouse)'
        92 = 'Uncooperative partner of Reference Person (this individual is unable or unwilling to be designated as Partner)'
        95 = 'Other relative of Reference Person'
        96 = 'Other relative of legal Spouse (code 20)'
        97 = 'Other relative of cohabitor (the cohabitor is code 22 or 88)'
        98 = 'Other nonrelatives (includes friends of children of the FU, boyfriend/girlfriend of son/daughter, et al.)'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34502=0)'
   ;
   VALUE ER34507F
         1 = 'Spouse in couple numbered 1'
         2 = 'Spouse in couple numbered 2'
         3 = 'Spouse in couple numbered 3'
         4 = 'Spouse in couple numbered 4'
         0 = 'Inap.:  spouse was not in FU at the time of the 2017 interview; not married or permanently cohabiting; from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse'
             'by 2015 (ER34501=0)'
   ;
   VALUE ER34508F
         1 = 'Moved in or born between the 2015 and 2017 interviews; Splitoff in 2017; Immigrant 2017 Sample individual'
         2 = 'Appeared; moved in by the time the 2015 interview was taken but not included in FU for 2015 (e.g., listing error)'
         5 = 'Moved out of FU or out of an institution between the 2015 and 2017 interviews and was not included in a 2017 panel FU'
         6 = 'Moved out of FU and into an institution between the 2015 and 2017 interviews'
         7 = 'Living in 2015 but died by the time of the 2017 interview'
         8 = 'Disappeared; moved out prior to the 2015 interview, but included in FU for 2015 (usually a listing error)'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); in main family in both 2015 and 2017 (ER34302=1-20 and ER34502=1-20); in a'
             'n institution in both 2015 and 2017 (ER34302=51-59 and ER34502=51-59)'
   ;
   VALUE ER34511F
         1 = 'This individual was respondent'
         5 = 'This individual was not respondent; includes institutionalized individuals and mover-out nonresponse from 2017 (ER34502=51-89)'
         9 = 'DK; NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0)'
   ;
   VALUE ER34512F
    1 - 10 = 'Sequence number of the first other person in the Family Unit in 2017 who helped the Respondent complete the interview'
        97 = 'Other person outside the Family Unit helped the Respondent'
         0 = 'Inap.:  this individual did not have a helper; from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); this individual was not the respond'
             'ent in 2017 (ER34511=5 or 9)'
   ;
   VALUE ER34513F
    1 - 10 = 'Sequence number of the second other person in the Family Unit in 2017 who helped the Respondent complete the interview'
        97 = 'Other person outside the Family Unit helped the Respondent'
         0 = 'Inap.:  this individual did not have a second helper; from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); this individual was not the'
             'respondent in 2017 (ER34511=5 or 9); this individual did not have a helper (ER34512=0)'
   ;
   VALUE ER34514F
    1 - 10 = 'Sequence number of the third other person in the Family Unit in 2017 who helped the Respondent complete the interview'
        97 = 'Other person outside the Family Unit helped the Respondent'
         0 = 'Inap.:  this individual did not have a third helper; from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); this individual was not the r'
             'espondent in 2017 (ER34511=5 or 9); this individual did not have a helper (ER34512=0); this individual did not have a second helper (ER34513=0)'
   ;
   VALUE ER34515F
         1 = 'Reference Person who received TANF'
         2 = 'Spouse/Partner who received TANF'
         3 = 'Other Family Unit Member who received TANF'
         0 = 'Inap.:  this individual did not receive TANF; DK, NA, or RF whether this individual received TANF; from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2'
             '015 (ER34501=0); in an institution in both 2015 and 2017 (ER34502=51-59 and ER34508=0);  OFUM under age 16 (ER34502=02-20 and ER34504 <16)'
   ;
   VALUE ER34516F
         1 = 'Working now'
         2 = 'Only temporarily laid off'
         3 = 'Looking for work, unemployed'
         4 = 'Retired'
         5 = 'Permanently disabled'
         6 = 'Keeping house'
         7 = 'Student'
         8 = 'Other'
         9 = 'DK; NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); individual was alive at the time of the 2015 interview but passed away by'
             'the time of the 2017 interview (ER34502=81-89); in an institution in both 2015 and 2017 (ER34502=51-59 and ER34508=0); not a person aged 16 or older (ER34504=001-015); associated with 2017 FU but move'
             'd out before 2016 (ER34508=5, 6, or 8 and ER34510 <2016)'
   ;
   VALUE ER34518F
         1 = 'United States only'
         2 = 'Outside U.S. only'
         3 = 'Both in the U.S. and outside'
         5 = 'Had no education'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.: this person was not a current Reference Person/Spouse/Partner in 2017; from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); indi'
             'vidual was alive at the time of the 2015 interview but passed away by the time of the 2017 interview (ER34502=81-89); OFUM in an institution in both 2015 and 2017 (ER34502=51-59 and ER34508=0); OFUM a'
             'ge 15 or younger or age 50 or older (ER34504=001-015 or 050-125); OFUM associated with 2017 FU but moved out before 2016 (ER34508=5, 6, or 8 and ER34510<2016) or OFUM moved in in 2017 (ER34508=1 and E'
             'R34510=2017)'
   ;
   VALUE ER34519F
         1 = 'Graduated from high school'
         2 = 'Got a GED'
         3 = 'Neither'
         9 = 'DK; NA; refused'
         0 = 'Inap.:  this person was not a current Reference Person/Spouse/Partner in 2017; from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); ind'
             'ividual was alive at the time of the 2015 interview but passed away by the time of the 2017 interview (ER34502=81-89); OFUM in an institution in both 2015 and 2017 (ER34502=51-59 and ER34508=0); OFUM'
             'age 15 or younger or age 50 or older (ER34504=001-015 or 050-125); OFUM associated with 2017 FU but moved out before 2016 (ER34508=5, 6, or 8 and ER34510<2016) or OFUM moved in in 2017 (ER34508=1 and'
             'ER34510=2017); current Reference Person/Spouse/Partner/eligible OFUM educated outside the U.S. only or had no education (ER34518=2 or 5);  NA or RF where current Reference Person/Spouse/Partner/eligib'
             'le OFUM received education (ER3419=9)'
   ;
   VALUE ER34520F
         1 = 'January'
         2 = 'February'
         3 = 'March'
         4 = 'April'
         5 = 'May'
         6 = 'June'
         7 = 'July'
         8 = 'August'
         9 = 'September'
        10 = 'October'
        11 = 'November'
        12 = 'December'
        21 = 'Winter'
        22 = 'Spring'
        23 = 'Summer'
        24 = 'Fall; autumn'
        99 = 'DK; NA; refused'
         0 = 'Inap.:  this person was not a current Reference Person/Spouse/Partner in 2017; from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); ind'
             'ividual was alive at the time of the 2015 interview but passed away by the time of the 2017 interview (ER34502=81-89); OFUM in an institution in both 2015 and 2017 (ER34502=51-59 and ER34508=0); OFUM'
             'age 15 or younger or age 50 or older (ER34504=001-015 or 050-125); OFUM associated with 2017 FU but moved out before 2016 (ER34508=5, 6, or 8 and ER34510<2016) or OFUM moved in in 2017 (ER34508=1 and'
             'ER34510=2017); current Reference Person/Spouse/Partner/eligible OFUM educated outside the U.S. only or had no education (ER34518=2 or 5);  NA or RF where current Reference Person/Spouse/Partner/eligib'
             'le OFUM received education (ER3419=9); got a GED or neither got a GED nor graduated from high school (ER34519=2 or 3); DK, NA, or RF whether graduated from high school, got a GED, or neither graduated'
             ' from high school nor got a GED (ER34519=9)'
   ;
   VALUE ER34522F
         1 = 'Finished first grade'
         2 = 'Finished second grade'
         3 = 'Finished third grade'
         4 = 'Finished fourth grade'
         5 = 'Finished fifth grade'
         6 = 'Finished sixth grade'
         7 = 'Finished seventh grade'
         8 = 'Finished eighth grade'
         9 = 'Finished ninth grade'
        10 = 'Finished tenth grade'
        11 = 'Finished eleventh grade'
        99 = 'DK; NA; refused'
         0 = 'Inap.:  no grades of regular school finished before getting GED; this person was not a current Reference Person/Spouse/Partner in 2017; from Latino sample (ER30001=7001-9308); main family nonresponse'
             'by 2017 or mover-out nonresponse by 2015 (ER34501=0); individual was alive at the time of the 2015 interview but passed away by the time of the 2017 interview (ER34502=81-89); OFUM in an institution i'
             'n both 2015 and 2017 (ER34502=51-59 and ER34508=0); OFUM age 15 or younger or age 50 or older (ER34504=001-015 or 050-125); OFUM associated with 2017 FU but moved out before 2016 (ER34508=5, 6, or 8 a'
             'nd ER34510<2016) or OFUM moved in in 2017 (ER34508=1 and ER34510=2017); current Reference Person/Spouse/Partner/eligible OFUM educated outside the U.S. only or had no education (ER34518=2 or 5);  NA o'
             'r RF where current Reference Person/Spouse/Partner/eligible OFUM received education (ER3419=9); graduated from high school or neither got a GED nor graduated from high school (ER34519=1 or 3); DK, NA,'
             ' or RF whether graduated from high school, got a GED, or neither graduated from high school nor got a GED (ER34519=9)'
   ;
   VALUE ER34527F
         1 = 'Finished first grade'
         2 = 'Finished second grade'
         3 = 'Finished third grade'
         4 = 'Finished fourth grade'
         5 = 'Finished fifth grade'
         6 = 'Finished sixth grade'
         7 = 'Finished seventh grade'
         8 = 'Finished eighth grade'
         9 = 'Finished ninth grade'
        10 = 'Finished tenth grade'
        11 = 'Finished eleventh grade'
        99 = 'DK; NA; refused'
         0 = 'Inap.:  finished no grades of regular school; this person was not a current Reference Person/Spouse/Partner in 2017; from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-ou'
             't nonresponse by 2015 (ER34501=0); individual was alive at the time of the 2015 interview but passed away by the time of the 2017 interview (ER34502=81-89); OFUM in an institution in both 2015 and 201'
             '7 (ER34502=51-59 and ER34508=0); OFUM age 15 or younger or age 50 or older (ER34504=001-015 or 050-125); OFUM associated with 2017 FU but moved out before 2016 (ER34508=5, 6, or 8 and ER34510<2016) or'
             ' OFUM moved in in 2017 (ER34508=1 and ER34510=2017); current Reference Person/Spouse/Partner/eligible OFUM educated outside the U.S. only or had no education (ER34518=2 or 5);  NA or RF where current'
             'Reference Person/Spouse/Partner/eligible OFUM received education (ER3419=9); graduated from high school or got a GED (ER34519=1 or 2); DK, NA, or RF whether graduated from high school, got a GED, or n'
             'either graduated from high school nor got a GED (ER34519=9)'
   ;
   VALUE ER34530F
         1 = 'Yes'
         5 = 'No'
         9 = 'DK; NA; refused'
         0 = 'Inap.:  this person was not a current Reference Person/Spouse/Partner in 2017; from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); ind'
             'ividual was alive at the time of the 2015 interview but passed away by the time of the 2017 interview (ER34502=81-89); OFUM in an institution in both 2015 and 2017 (ER34502=51-59 and ER34508=0); OFUM'
             'age 15 or younger or age 50 or older (ER34504=001-015 or 050-125); OFUM associated with 2017 FU but moved out before 2016 (ER34508=5, 6, or 8 and ER34510<2016) or OFUM moved in in 2017 (ER34508=1 and'
             'ER34510=2017); current Reference Person/Spouse/Partner/eligible OFUM educated outside the U.S. only or had no education (ER34518=2 or 5);  NA or RF where current Reference Person/Spouse/Partner/eligib'
             'le OFUM received education (ER3419=9)'
   ;
   VALUE ER34534F
         1 = 'Yes'
         5 = 'No'
         9 = 'DK; NA; refused'
         0 = 'Inap.:  this person was not a current Reference Person/Spouse/Partner in 2017; from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); ind'
             'ividual was alive at the time of the 2015 interview but passed away by the time of the 2017 interview (ER34502=81-89); OFUM in an institution in both 2015 and 2017 (ER34502=51-59 and ER34508=0); OFUM'
             'age 15 or younger or age 50 or older (ER34504=001-015 or 050-125); OFUM associated with 2017 FU but moved out before 2016 (ER34508=5, 6, or 8 and ER34510<2016) or OFUM moved in in 2017 (ER34508=1 and'
             'ER34510=2017); current Reference Person/Spouse/Partner/eligible OFUM educated outside the U.S. only or had no education (ER34518=2 or 5);  NA or RF where current Reference Person/Spouse/Partner/eligib'
             'le OFUM received education (ER3419=9); has not attended college (ER34530=5); DK, NA, or RF whether attended college (ER34530=9); completed less than one year of college (ER34533=0)'
   ;
   VALUE ER34535F
         1 = 'Associate''s degree/AA'
         2 = 'Bachelor''s degree/BA/BS'
         3 = 'Master''s degree/MA/MS/MBA'
         4 = 'Doctorate/PhD'
         5 = 'LLB, JD (Law degrees)'
         6 = 'MD, DDS, DVM, DO (Medical degrees)'
         8 = 'Honorary degree'
        97 = 'Other - specify'
        99 = 'DK; NA; refused'
         0 = 'Inap.:  this person was not a current Reference Person/Spouse/Partner in 2017; from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); ind'
             'ividual was alive at the time of the 2015 interview but passed away by the time of the 2017 interview (ER34502=81-89); OFUM in an institution in both 2015 and 2017 (ER34502=51-59 and ER34508=0); OFUM'
             'age 15 or younger or age 50 or older (ER34504=001-015 or 050-125); OFUM associated with 2017 FU but moved out before 2016 (ER34508=5, 6, or 8 and ER34510<2016) or OFUM moved in in 2017 (ER34508=1 and'
             'ER34510=2017); current Reference Person/Spouse/Partner/eligible OFUM educated outside the U.S. only or had no education (ER34518=2 or 5);  NA or RF where current Reference Person/Spouse/Partner/eligib'
             'le OFUM received education (ER3419=9); has not attended college (ER34530=5); DK, NA, or RF whether attended college (ER34530=9); completed less than one year of college (ER34533=0); did not receive a'
             'college degree (ER34534=5); DK, NA, or RF whether received a college degree (ER34534=9)'
   ;
   VALUE ER34546F
         1 = 'Yes'
         5 = 'No'
         9 = 'DK; NA; refused'
         0 = 'Inap.:  this person was not a current Reference Person/Spouse/Partner in 2017; from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); ind'
             'ividual was alive at the time of the 2015 interview but passed away by the time of the 2017 interview (ER34502=81-89); OFUM in an institution in both 2015 and 2017 (ER34502=51-59 and ER34508=0); OFUM'
             'age 15 or younger or age 50 or older (ER34504=001-015 or 050-125); OFUM associated with 2017 FU but moved out before 2016 (ER34508=5, 6, or 8 and ER34510<2016) or OFUM moved in in 2017 (ER34508=1 and'
             'ER34510=2017); current Reference Person/Spouse/Partner/eligible OFUM had no education (ER3419=5); NA or RF where current Reference Person/Spouse/Partner/eligible OFUM received education (ER3419=9); cu'
             'rrent Reference Person/Spouse/Partner/eligible OFUM still in school (ER34531=96 or ER34532=9996)'
   ;
   VALUE ER34547F
         1 = 'First grade'
         2 = 'Second grade'
         3 = 'Third grade'
         4 = 'Fourth grade'
         5 = 'Fifth grade'
         6 = 'Sixth grade'
         7 = 'Seventh grade'
         8 = 'Eighth grade'
         9 = 'Ninth grade'
        10 = 'Tenth grade'
        11 = 'Eleventh grade'
        12 = 'Twelfth grade, "High School", GED'
        13 = '1st year college (freshman)'
        14 = '2nd year college (sophomore)'
        15 = '3rd year college (junior)'
        16 = '4th year college (senior)'
        17 = '5th or higher year of college'
        18 = 'Post-graduate work'
        99 = 'DK; NA; refused'
         0 = 'Inap.:  this person was not a current Reference Person/Spouse/Partner in 2017; from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); ind'
             'ividual was alive at the time of the 2015 interview but passed away by the time of the 2017 interview (ER34502=81-89); OFUM in an institution in both 2015 and 2017 (ER34502=51-59 and ER34508=0); OFUM'
             'age 15 or younger or age 50 or older (ER34504=001-015 or 050-125); OFUM associated with 2017 FU but moved out before 2016 (ER34508=5, 6, or 8 and ER34510<2016) or OFUM moved in in 2017 (ER34508=1 and'
             'ER34510=2017); DK, NA, or RF where current Reference Person/Spouse/Partner/eligible OFUM received education (ER3419=9); current Reference Person/Spouse/Partner/eligible OFUM not still in school (ER345'
             '31=96 and ER34532=9996 and ER34546=5 or 9)'
   ;
   VALUE ER34548F
    1 - 17 = 'Highest grade or year of school completed'
        99 = 'DK; NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34301=0); in an institution in both 2015 and 2017 (ER34302=51-59 and ER34508=0); not'
             ' a person aged 16 or older (ER34504=001-015, 999); associated with 2017 FU but actually moved out before 2016 (ER34508=5, 6, or 8 and ER34510<2016) or moved in in 2017 and was not a Reference Person o'
             'r Spouse/Partner (ER34508=1 and ER34510=2017 and ER34302 GE 2 and ER34303 GE 30)'
   ;
   VALUE ER34549F
         1 = 'Yes'
         2 = 'IF VOL.:  Still in school'
         5 = 'No'
         9 = 'DK; NA; refused'
         0 = 'Inap.:  this person was a new Reference Person/Spouse/Partner/eligible OFUM this wave; this person was not a current Reference Person/Spouse/Partner in 2017; from Latino sample (ER30001=7001-9308); ma'
             'in family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); individual was alive at the time of the 2015 interview but passed away by the time of the 2017 interview (ER34502=81-89); OF'
             'UM in an institution in both 2015 and 2017 (ER34502=51-59 and ER34508=0); OFUM age 15 or younger or age 50 or older (ER34504=001-015 or 050-125); OFUM associated with 2017 FU but moved out before 2016'
             ' (ER34508=5, 6, or 8 and ER34510<2016) or OFUM moved in in 2017 (ER34508=1 and ER34510=2017)'
   ;
   VALUE ER34550F
         1 = 'United States only'
         2 = 'Outside U.S. only'
         3 = 'Both in the U.S. and outside'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.:  this person was a new Reference Person/Spouse/Partner/eligible OFUM this wave; this person was not a current Reference Person/Spouse/Partner in 2017; from Latino sample (ER30001=7001-9308); ma'
             'in family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); individual was alive at the time of the 2015 interview but passed away by the time of the 2017 interview (ER34502=81-89); OF'
             'UM in an institution in both 2015 and 2017 (ER34502=51-59 and ER34508=0); OFUM age 15 or younger or age 50 or older (ER34504=001-015 or 050-125); OFUM associated with 2017 FU but moved out before 2016'
             ' (ER34508=5, 6, or 8 and ER34510<2016) or OFUM moved in in 2017 (ER34508=1 and ER34510=2017); has not attended regular school since last interview (ER34549=5); DK, NA, or RF whether attended regular s'
             'chool since last interview (ER34549=9)'
   ;
   VALUE ER34551F
         1 = 'Graduated from high school'
         2 = 'Got a GED'
         3 = 'Neither'
         9 = 'DK; NA; refused'
         0 = 'Inap.:  preloaded completed education is high school or higher, GED, or DK, NA, or RF; this person was a new Reference Person/Spouse/Partner/eligible OFUM this wave; this person was not a current Refe'
             'rence Person/Spouse/Partner in 2017; from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); individual was alive at the time of the 2015'
             'interview but passed away by the time of the 2017 interview (ER34502=81-89); OFUM in an institution in both 2015 and 2017 (ER34502=51-59 and ER34508=0); OFUM age 15 or younger or age 50 or older (ER34'
             '504=001-015 or 050-125); OFUM associated with 2017 FU but moved out before 2016 (ER34508=5, 6, or 8 and ER34510<2016) or OFUM moved in in 2017 (ER34508=1 and ER34510=2017); has not attended regular sc'
             'hool since last interview (ER34549=5); DK, NA, or RF whether attended regular school since last interview (ER34549=8 or 9); returning Reference Person/Spouse/Partner/eligible OFUM educated outside the'
             ' U.S. only (ER34550=2);  NA or RF where returning Reference Person/Spouse/Partner/eligible OFUM received education (ER34550=9)'
   ;
   VALUE ER34559F
         1 = 'Finished first grade'
         2 = 'Finished second grade'
         3 = 'Finished third grade'
         4 = 'Finished fourth grade'
         5 = 'Finished fifth grade'
         6 = 'Finished sixth grade'
         7 = 'Finished seventh grade'
         8 = 'Finished eighth grade'
         9 = 'Finished ninth grade'
        10 = 'Finished tenth grade'
        11 = 'Finished eleventh grade'
        99 = 'DK; NA; refused'
         0 = 'Inap.:  finished no grades of regular school; preloaded completed education is high school or higher, GED, or DK, NA, or RF; this person was a new Reference Person/Spouse/Partner/eligible OFUM this wa'
             've; this person was not a current Reference Person/Spouse/Partner in 2017; from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); individ'
             'ual was alive at the time of the 2015 interview but passed away by the time of the 2017 interview (ER34502=81-89); OFUM in an institution in both 2015 and 2017 (ER34502=51-59 and ER34508=0); OFUM age'
             '15 or younger or age 50 or older (ER34504=001-015 or 050-125); OFUM associated with 2017 FU but moved out before 2016 (ER34508=5, 6, or 8 and ER34510<2016) or OFUM moved in in 2017 (ER34508=1 and ER34'
             '510=2017); has not attended regular school since last interview (ER34549=5); DK, NA, or RF whether attended regular school since last interview (ER34549=8 or 9); returning Reference Person/Spouse/Part'
             'ner/eligible OFUM educated outside the U.S. only (ER34550=2);  NA or RF where returning Reference Person/Spouse/Partner/eligible OFUM received education (ER34550=9); since last interview, graduated fr'
             'om high school or got a GED (ER34551=1 or 2); DK, NA, or RF whether, since last interview, graduated from high school, got a GED, or neither (ER34551=9)'
   ;
   VALUE ER34562F
         1 = 'Yes'
         5 = 'No'
         9 = 'DK; NA; refused'
         0 = 'Inap.:  this person was a new Reference Person/Spouse/Partner/eligible OFUM this wave; this person was not a current Reference Person/Spouse/Partner in 2017; from Latino sample (ER30001=7001-9308); ma'
             'in family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); individual was alive at the time of the 2015 interview but passed away by the time of the 2017 interview (ER34502=81-89); OF'
             'UM in an institution in both 2015 and 2017 (ER34502=51-59 and ER34508=0); OFUM age 15 or younger or age 50 or older (ER34504=001-015 or 050-125); OFUM associated with 2017 FU but moved out before 2016'
             ' (ER34508=5, 6, or 8 and ER34510<2016) or OFUM moved in in 2017 (ER34508=1 and ER34510=2017); has not attended regular school since last interview (ER34549=5); DK, NA, or RF whether attended regular s'
             'chool since last interview (ER34549=8 or 9); returning Reference Person/Spouse/Partner/eligible OFUM educated outside the U.S. only (ER34550=2);  NA or RF where returning Reference Person/Spouse/Partn'
             'er/eligible OFUM received education (ER34550=9)'
   ;
   VALUE ER34566F
         1 = 'Yes'
         5 = 'No'
         9 = 'DK; NA; refused'
         0 = 'Inap.:  this person was a new Reference Person/Spouse/Partner/eligible OFUM this wave; this person was not a current Reference Person/Spouse/Partner in 2017; from Latino sample (ER30001=7001-9308); ma'
             'in family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); individual was alive at the time of the 2015 interview but passed away by the time of the 2017 interview (ER34502=81-89); OF'
             'UM in an institution in both 2015 and 2017 (ER34502=51-59 and ER34508=0); OFUM age 15 or younger or age 50 or older (ER34504=001-015 or 050-125); OFUM associated with 2017 FU but moved out before 2016'
             ' (ER34508=5, 6, or 8 and ER34510<2016) or OFUM moved in in 2017 (ER34508=1 and ER34510=2017); has not attended regular school since last interview (ER34549=5); DK, NA, or RF whether attended regular s'
             'chool since last interview (ER34549=8 or 9); returning Reference Person/Spouse/Partner/eligible OFUM educated outside the U.S. only (ER34550=2);  NA or RF where returning Reference Person/Spouse/Partn'
             'er/eligible OFUM received education (ER34550=9); has not attended college since last interview (ER34562=5); DK, NA, or RF whether attended college since last interview (ER34562=9); less than one year'
             'of college (ER34565=0)'
   ;
   VALUE ER34567F
         1 = 'Associate''s degree/AA'
         2 = 'Bachelor''s degree/BA/BS'
         3 = 'Master''s degree/MA/MS/MBA'
         4 = 'Doctorate/PhD'
         5 = 'LLB, JD (Law degrees)'
         6 = 'MD, DDS, DVM, DO (Medical degrees)'
         8 = 'Honorary degree'
        97 = 'Other - specify'
        99 = 'DK; NA; refused'
         0 = 'Inap.:  this person was a new Reference Person/Spouse/Partner/eligible OFUM this wave; this person was not a current Reference Person/Spouse/Partner in 2017; from Latino sample (ER30001=7001-9308); ma'
             'in family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); individual was alive at the time of the 2015 interview but passed away by the time of the 2017 interview (ER34502=81-89); OF'
             'UM in an institution in both 2015 and 2017 (ER34502=51-59 and ER34508=0); OFUM age 15 or younger or age 50 or older (ER34504=001-015 or 050-125); OFUM associated with 2017 FU but moved out before 2016'
             ' (ER34508=5, 6, or 8 and ER34510<2016) or OFUM moved in in 2017 (ER34508=1 and ER34510=2017); has not attended regular school since last interview (ER34549=5); DK, NA, or RF whether attended regular s'
             'chool since last interview (ER34549=8 or 9); returning Reference Person/Spouse/Partner/eligible OFUM educated outside the U.S. only (ER34550=2);  NA or RF where returning Reference Person/Spouse/Partn'
             'er/eligible OFUM received education (ER34550=9); has not attended college since last interview (ER34562=5); DK, NA, or RF whether attended college since last interview (ER34562=9); less than one year'
             'of college (ER34565=0); has not received a college degree since last interview (ER34566=5); DK, NA, or RF whether received a college degree since last interview (ER34566=9)'
   ;
   VALUE ER34578F
         1 = 'Yes'
         5 = 'No'
         9 = 'DK; NA; refused'
         0 = 'Inap.:  this person was a new Reference Person/Spouse/Partner/eligible OFUM this wave; this person was not a current Reference Person/Spouse/Partner in 2017; from Latino sample (ER30001=7001-9308); ma'
             'in family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); individual was alive at the time of the 2015 interview but passed away by the time of the 2017 interview (ER34502=81-89); OF'
             'UM in an institution in both 2015 and 2017 (ER34502=51-59 and ER34508=0); OFUM age 15 or younger or age 50 or older (ER34504=001-015 or 050-125); OFUM associated with 2017 FU but moved out before 2016'
             ' (ER34508=5, 6, or 8 and ER34510<2016) or OFUM moved in in 2017 (ER34508=1 and ER34510=2017); still in school since last interview (ER34549=2 or ER34563=96 or ER34564=9996)'
   ;
   VALUE ER34579F
         1 = 'First grade'
         2 = 'Second grade'
         3 = 'Third grade'
         4 = 'Fourth grade'
         5 = 'Fifth grade'
         6 = 'Sixth grade'
         7 = 'Seventh grade'
         8 = 'Eighth grade'
         9 = 'Ninth grade'
        10 = 'Tenth grade'
        11 = 'Eleventh grade'
        12 = 'Twelfth grade, "High School", GED'
        13 = '1st year college (freshman)'
        14 = '2nd year college (sophomore)'
        15 = '3rd year college (junior)'
        16 = '4th year college (senior)'
        17 = '5th or higher year of college'
        18 = 'Post-graduate work'
        99 = 'DK; NA; refused'
         0 = 'Inap.:  this person was a new Reference Person/Spouse/Partner/eligible OFUM this wave; this person was not a current Reference Person/Spouse/Partner in 2017; from Latino sample (ER30001=7001-9308); ma'
             'in family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); individual was alive at the time of the 2015 interview but passed away by the time of the 2017 interview (ER34502=81-89); OF'
             'UM in an institution in both 2015 and 2017 (ER34502=51-59 and ER34508=0); OFUM age 15 or younger or age 50 or older (ER34504=001-015 or 050-125); OFUM associated with 2017 FU but moved out before 2016'
             ' (ER34508=5, 6, or 8 and ER34510<2016) or OFUM moved in in 2017 (ER34508=1 and ER34510=2017); not still in school since last interview (ER34549=1 or 5 and ER34563 ne 96 and ER34564 ne 9996 and ER34578'
             '=5); DK, NA, or RF whether still in school since last interview (ER34578=9)'
   ;
   VALUE ER34580F
         1 = 'Yes, is in poor health'
         5 = 'No, is not in poor health'
         9 = 'DK; NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); in an institution or mover-out nonresponse in 2017 (ER34502=51-89); curren'
             't Reference Person/Spouse/Partner (ER34502=1-2 and ER34503=10, 20, or 22)'
   ;
   VALUE ER34581F
         1 = '65 years of age or older'
         5 = '64 years of age or younger;  DK/NA age'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); mover-out deceased individual in 2017 (ER34502=81-89)'
   ;
   VALUE ER34582F
         1 = 'Yes, a change'
         5 = 'No, no change'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); mover-out deceased individual in 2017 (ER34502=81-89); individual is less'
             'than 65 years old or DK/NA age (ER34581=5)'
   ;
   VALUE ER34583F
         1 = 'Yes, a change'
         5 = 'No, no change'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); mover-out deceased individual in 2017 (ER34502=81-89); individual is less'
             'than 65 years old or DK/NA age (ER34581=5)'
   ;
   VALUE ER34584F
         1 = 'Yes, a change'
         5 = 'No, no change'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); mover-out deceased individual in 2017 (ER34502=81-89); individual is less'
             'than 65 years old or DK/NA age (ER34581=5)'
   ;
   VALUE ER34585F
         1 = 'Yes, a change'
         5 = 'No, no change'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); mover-out deceased individual in 2017 (ER34502=81-89); individual is less'
             'than 65 years old or DK/NA age (ER34581=5)'
   ;
   VALUE ER34586F
         1 = 'Yes, a change'
         5 = 'No, no change'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); mover-out deceased individual in 2017 (ER34502=81-89); individual is less'
             'than 65 years old or DK/NA age (ER34581=5)'
   ;
   VALUE ER34587F
         1 = 'Yes, a change'
         5 = 'No, no change'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); mover-out deceased individual in 2017 (ER34502=81-89); individual is less'
             'than 65 years old or DK/NA age (ER34581=5)'
   ;
   VALUE ER34588F
         1 = 'Yes, a change'
         5 = 'No, no change'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); mover-out deceased individual in 2017 (ER34502=81-89); individual is less'
             'than 65 years old or DK/NA age (ER34581=5)'
   ;
   VALUE ER34589F
         1 = 'Yes, a change'
         5 = 'No, no change'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); mover-out deceased individual in 2017 (ER34502=81-89); individual is less'
             'than 65 years old or DK/NA age (ER34581=5)'
   ;
   VALUE ER34590F
         1 = 'Two or more problems endorsed'
         5 = 'Fewer than two problems endorsed'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); mover-out deceased individual in 2017 (ER34502=81-89); individual is less'
             'than 65 years old or DK/NA age (ER34581=5)'
   ;
   VALUE ER34591F
         1 = 'Yes, this individual is covered by the state health insurance plan for uninsured children'
         5 = 'No, this individual is not covered by the state health insurance plan for uninsured children'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.:  not covered by health insurance/does not have health care coverage; has the same health insurance or health care coverage as everyone else in the FU and is older than 18 years old; from Latino'
             ' sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); mover-out (ER34502=71-89)'
   ;
   VALUE ER34592F
    1 - 12 = 'Actual number of months uninsured'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  was insured all months in 2015; born after 2015; from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); mover-out (ER34502=71-89)'
             ' '
   ;
   VALUE ER34593F
    1 - 12 = 'Actual number of months uninsured'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  was insured all months in 2016; born after 2016; from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); mover-out (ER34502=71-89)'
             ' '
   ;
   VALUE ER34594F
         1 = 'Yes'
         5 = 'No'
         8 = 'DK'
         9 = 'NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); mover-out (ER34502=71-89)'
   ;
   VALUE ER34595F
         1 = 'Employer provided health insurance (current or former employer)'
         2 = 'Private health insurance purchased'
         3 = 'Medicare'
         4 = 'Medi-Gap/Supplemental'
         5 = 'Medicaid/[STATEMEDPROG]/[SCHIPNAME]'
         8 = 'Indian Health Insurance'
         9 = 'Other state-sponsored plan (not Medicaid)'
        10 = 'Other government program'
        12 = 'Military Health Care/Tricare (active duty); Tricare/Champus/ChampVA (dependents, veterans); Veterans Administration (VA)'
        97 = 'Other health insurance'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34301=0); mover-out (ER34502=71-89); does not currently have health insurance or hea'
             'lth care coverage (ER34594=5); DK, NA, or RF whether currently has health insurance or health care coverage (ER34594=8 or 9)'
   ;
   VALUE ER34596F
         1 = 'Employer provided health insurance (current or former employer)'
         2 = 'Private health insurance purchased'
         3 = 'Medicare'
         4 = 'Medi-Gap/Supplemental'
         5 = 'Medicaid/[STATEMEDPROG]/[SCHIPNAME]'
         8 = 'Indian Health Insurance'
         9 = 'Other state-sponsored plan (not Medicaid)'
        10 = 'Other government program'
        12 = 'Military Health Care/Tricare (active duty); Tricare/Champus/ChampVA (dependents, veterans); Veterans Administration (VA)'
        97 = 'Other health insurance'
         0 = 'Inap.:  no second mention; from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34301=0); mover-out (ER34502=71-89); does not currently have heal'
             'th insurance or health care coverage (ER34594=5); DK, NA, or RF whether currently has health insurance or health care coverage (ER34594=8 or 9); DK, NA, or RF to first mention (ER34595=98 or 99)'
   ;
   VALUE ER34597F
         1 = 'Employer provided health insurance (current or former employer)'
         2 = 'Private health insurance purchased'
         3 = 'Medicare'
         4 = 'Medi-Gap/Supplemental'
         5 = 'Medicaid/[STATEMEDPROG]/[SCHIPNAME]'
         8 = 'Indian Health Insurance'
         9 = 'Other state-sponsored plan (not Medicaid)'
        10 = 'Other government program'
        12 = 'Military Health Care/Tricare (active duty); Tricare/Champus/ChampVA (dependents, veterans); Veterans Administration (VA)'
        97 = 'Other health insurance'
         0 = 'Inap.:  fewer than three mentions; from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34301=0); mover-out (ER34502=71-89); does not currently h'
             'ave health insurance or health care coverage (ER34594=5); DK, NA, or RF whether currently has health insurance or health care coverage (ER34594=8 or 9); DK, NA, or RF to first mention (ER34595=98 or 9'
             '9)'
   ;
   VALUE ER34598F
    1 - 24 = 'Sequence number of the first person in the Family Unit in 2017 whose employer provided this individual''s health insurance/coverage.'
        96 = 'Parent of Family Unit member who lives outside of FU'
        97 = 'Other person outside of FU'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); mover-out (ER34502=71-89); does not currently have health insurance of hea'
             'lth care coverage (ER34594=5); DK, NA, or RF whether currently has health insurance or health care coverage now (ER34594=8 or 9); DK, NA, or RF type of health insurance/health care coverage (ER34595=9'
             '8 or 99); does not have employer provided health insurance (ER34595 ne 1 and ER34596 ne 1 and ER34597 ne 1)'
   ;
   VALUE ER34599F
    1 - 24 = 'Sequence number of the second person in the Family Unit in 2017 whose employer provided this individual''s health insurance/coverage.'
        96 = 'Parent of Family Unit member who lives outside of FU'
        97 = 'Other person outside of FU'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  no second mention; from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); mover-out (ER34502=71-89); does not currently have heal'
             'th insurance of health care coverage (ER34594=5); DK, NA, or RF whether currently has health insurance or health care coverage (ER34594=8 or 9); DK, NA, or RF type of health insurance/health care cove'
             'rage (ER34595=98 or 99); does not have employer provided health insurance (ER34595 ne 1 and ER34596 ne 1 and ER34597 ne 1); no second mention'
   ;
   VALUE ER34600F
    1 - 24 = 'Sequence number of the first person in the Family Unit in 2017 who was the policy holder on this individual''s private health insurance/coverage.'
        96 = 'Parent of Family Unit member who lives outside of FU'
        97 = 'Other person outside of FU'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); mover-out (ER34502=71-89); does not currently have health insurance of hea'
             'lth care coverage (ER34594=5); DK, NA, or RF whether currently has health insurance or health care coverage (ER34594=8 or 9); DK, NA, or RF type of health insurance/health care coverage (ER34595=98 or'
             ' 99); does not have private health insurance (ER34595 ne 2 and ER34596 ne 2 and ER34597 ne 2)'
   ;
   VALUE ER34601F
    1 - 24 = 'Sequence number of the second person in the Family Unit in 2017 who was the policy holder on this individual''s private health insurance/coverage.'
        96 = 'Parent of Family Unit member who lives outside of FU'
        97 = 'Other person outside of FU'
        98 = 'DK'
        99 = 'NA; refused'
         0 = 'Inap.:  no second mention; from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); mover-out (ER34502=71-89); does not currently have heal'
             'th insurance of health care coverage (ER34594=5); DK, NA, or RF whether currently has health insurance or health care coverage (ER34594=8 or 9); DK, NA, or RF type of health insurance/health care cove'
             'rage (ER34595=98 or 99); does not have private health insurance (ER34595 ne 2 and ER34596 ne 2 and ER34597 ne 2)'
   ;
   VALUE ER34602F
         1 = 'This individual is a 2017 Reference Person/Spouse/Partner who was covered by Medicare or was aged 65 or older, was the respondent, and did not give a useable Medicare number in prior waves but did in'
             'this wave.'
         2 = 'This individual is a 2017 Reference Person/Spouse/Partner who was covered by Medicare or was aged 65 or older, was the respondent, did not give a useable Medicare number in prior waves, and provided a'
             ' Medicare number in this wave but it was not useable (e.g., missing digits).'
         5 = 'This individual is a 2017 Reference Person/Spouse/Partner who was covered by Medicare or was aged 65 or older, was the respondent, did not give a useable Medicare number in prior waves and in the pres'
             'ent wave declined to give his/her Medicare number (H62a=5), did not know/refused whether the number was a Medicare Claim or Railroad Retirement Board number, or did not know the number at H62c/H62e-f.'
             ' '
         7 = 'This individual is associated with a responding FU and was a Reference Person/Spouse/Partner in a prior wave, who was covered by Medicare, was the respondent, and provided a useable Medicare number in'
             ' some prior wave.'
         9 = 'This individual is a 2017 Reference Person/Spouse/Partner who was covered by Medicare or was aged 65 or older, was the respondent, did not give a useable Medicare number in prior waves, and in the pre'
             'sent wave whether a Medicare number could be provided was DK, NA, or RF (H62a=8 or 9).'
         0 = 'Inap.:  from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); mover-out (ER34502=71-89); not Reference Person/Spouse/Partner in 2017 (ER'
             '34503 >22 or ER34502 >50); under age 65 and not covered by Medicare (ER34504 <65 or 999 and neither ER34595, ER34596, ER34597=3);  not the respondent (ER34511=5)'
   ;
   VALUE ER34611F
         1 = 'Only one job'
         2 = 'Two jobs'
         3 = 'Three jobs'
         4 = 'Four jobs or more'
         5 = 'Didn''t have a job'
         8 = 'Don''t know'
         9 = 'NA; refused'
         0 = 'Inap.: this person was a current Reference Person/Spouse/Partner in 2017; from Latino sample (ER30001=7001-9308); main family nonresponse by 2017 or mover-out nonresponse by 2015 (ER34501=0); OFUM in'
             'an institution in both 2015 and 2017 (ER34502=51-59 and ER34508=0); OFUM under age 16 (ER34504=001-015); OFUM associated with 2017 FU but moved out before 2016 (ER34508=5, 6, or 8 and ER34510<2016) or'
             ' OFUM moved in in 2017 (ER34508=1 and ER34510=2017)'
   ;
   VALUE ER34644F
         1 = 'This individual was eligible to be followed in 2017'
         5 = 'This individual was not eligible to be followed in 2017'
         0 = 'Inap.:  main family or mover-out nonresponse in 2015 and not selected for recontact in 2017; from Latino sample (ER30001=7001-9308)'
   ;
   VALUE ER34646F
         1 = 'This individual was eligible to be interviewed for the TAS interview in 2017'
         0 = 'Inap.:  coded permanent condition in a previous wave of CDS or TAS; this individual was from the Immigrant 2017 or Latino sample (ER30001=4000-4699 or 7001-9308); main family nonresponse by 2017 (ER34'
             '501=0 and ER34502=0); mover-out nonresponse in 2017 (ER34502=71-89);  under age 18 or over age 28 as of December 31st 2017 (ER34506<1989 or >1999); not eligible to be followed in 2017 (ER34644=5)'
   ;
   VALUE ER34647F
         1 = 'Interview with eligible sample individual'
         3 = 'Refusal by the sample individual; partial/passive refusal; deliberate avoidance of interviewer (e.g., always too busy, repeated broken appointments, or failure to return calls)'
         4 = 'Sample individual lost; tracking efforts exhausted'
         5 = 'Sample individual incapacitated, had a permanent health condition, or institutionalized for health or mental reasons'
         6 = 'Sample individual deceased after PSID interview completed but before TAS interview'
         7 = 'Some household member contacted, but eligible respondent not available to do interview; appointment broken, but no evidence of deliberately avoiding interview'
         8 = 'Sample individual unable to partcipate due to a language barrier'
        10 = 'Adamant refusal by the eligible sample member. These individuals will never be asked to participate in the TAS study again, regardless of recontact efforts.'
        13 = 'Refusal by someone other than the sample individual'
        30 = 'Sample individual away on military leave, in job corps, on a religious mission or in a non-detention facility'
        31 = 'Sample individual resided outside the US or in a remote area and uncontactable (e.g., no telephone)'
        34 = 'Sample individual incarcerated or in a youth, group, or detention home/center'
        70 = 'Sample individual was randomly dropped because two others in the family unit were also eligible (CDS only)'
        90 = 'Sample individual was initially thought to be ineligible because of nonresponse or age but discovered to be age eligible and a resident in a response sample family after the interviewing period had en'
             'ded'
        95 = 'Office error--study ended, insufficient or inappropriate calls made, no mention of refusal'
         0 = 'Inap.:  coded permanent condition in a previous wave of CDS or TAS; this individual was from the Immigrant 2017 or Latino sample (ER30001=4000-4699 or 7001-9308); main family nonresponse by 2017 (ER34'
             '501=0 and ER34502=0); mover-out nonresponse in 2017 (ER34502=71-89);  under age 18 or over age 28 as of December 31st 2017 (ER34506<1989 or >1999); not eligible to be followed in 2017 (ER34644=5)'
   ;
   VALUE ER34648F
         1 = 'This sample member was main family nonresponse and had been in the FU in 2015.'
         3 = 'This nonsample individual had been in the 2015 FU, and this FU became nonresponse in 2017.'
         4 = 'This sample member had been in an institution in 2015, but his or her family became nonresponse in 2017.'
         5 = 'This sample member, linked to a 2017 response family, was in an institution at the time of the 2017 interview.'
         6 = 'This sample member moved out or died between the 2015 and 2017 interviews.'
         8 = 'This nonsample individual moved out or died between the 2015 and 2017 interviews.'
        10 = 'This individual had become nonresponse by the time of the 2017 interview.'
        21 = 'Main family recontact: this person was selected for recontact in 2017, but the family was not successfully interviewed.'
        26 = 'Splitoff recontact: this sample member moved out of a 2017 recontact main family but was not successfully interviewed.'
        40 = 'Individual connected with the Latino sample (ER30001=7001-9308); this sample was dropped beginning in 1996.  Individual dropped from the Census (SEO) sample due to budgetary constraints; this group wa'
             's dropped beginning in 1997.'
        99 = 'DK; NA'
         0 = 'Inap.:  this individual was in a panel family in 2017 (ER34502=1-20).'
   ;
   VALUE ER34649F
         1 = 'Wave refusal by all eligible/available FU members.'
         2 = 'No one at home for contact during the interviewing period.'
         3 = 'Respondent absent; some FU member contacted, but not the appropriate respondent.'
         4 = 'Lost; unable to locate any member of the FU at all.'
         5 = 'FU is located too far away for interviewer contact.'
        10 = 'Panel refusal by all all eligible/available FU members.  These individuals will never be asked to participate in the study again, regardless of recontact efforts.'
        11 = 'This sample member was in the armed forces.'
        12 = 'This sample member was in an educational institution.'
        13 = 'This sample member was in a health care facility.'
        14 = 'This sample member was in jail or prison.'
        15 = 'Panel refusal by all all eligible/available FU members. Sample individual (or other FU member on their behalf) contacted the study or IRB (by letter, email, phone call to the 800#, or respondent-initi'
             'ated phone call to the interviewer) with a strong request to be removed from the study.'
        19 = 'This sample member was in some other type of institution; for example, a religious order. Cases in which the type of institution is unknown are included here, also.'
        21 = 'This nonsample individual became main family nonresponse because the Reference Person or the Spouse, whichever is the sample member, became institutionalized by joining the armed forces.'
        22 = 'This nonsample individual became main family nonresponse because the Reference Person or Spouse, whichever is sample, became institutionalized by entering an educational institution.'
        23 = 'This nonsample individual became main family nonresponse because the Reference Person or Spouse, whichever is the sample member, became institutionalized by entering a health care facility.'
        24 = 'This nonsample individual became main family nonresponse because the Reference Person or Spouse, whichever is the sample member, became institutionalized through imprisonment.'
        25 = 'This individual became main family nonresponse because the sample member contacted the study or IRB with a request to be removed from the study (sample individual is coded 15 for this wave).'
        29 = 'This nonsample individual became main family nonresponse because the Reference Person or Spouse, whichever is sample, became institutionalized by some means other than the above; for example, he/she m'
             'ay have entered a religious order. Cases in which the type of institution is unknown are included here, also.'
        31 = 'This sample member was unable to cooperate because of disability.'
        32 = 'This nonsample individual became main family nonresponse because the Reference Person or Spouse, whichever is sample, was unable to cooperate because of disability.'
        41 = 'This individual died between the 2015 and 2017 interviews; this individual died after becoming nonresponse for some other reason before the 2015 interview.'
        42 = 'This nonsample individual became main family nonresponse because the Reference Person or Spouse, whichever is sample, died.'
        45 = 'This individual was a sample member but has been adopted by unrelated nonsample persons and therefore has become nonsample.'
        51 = 'This individual, although followed for interview, was discovered to be nonsample:  office error.'
        52 = 'This individual should have been followed but was not:  office error.'
        53 = 'This individual was mistakenly included in two or more response families at once; this record is the duplicate, or erroneous, one.'
        54 = 'Listing error: this individual never existed or was not really living in the FU.'
        57 = 'Insufficient information that would permit recontact; no name or identifying information available'
        58 = 'Due to budgetary and/or time constraints, PSID staff decided not to take all of the usual steps to try to locate and/or persuade this FU.'
        59 = 'Limited number of contacts attempted:  miscellaneous office error (does not include codes 01-54 above or codes 91-99 below).'
        60 = 'This nonsample parent of a sample child is no longer eligible to be interviewed.'
        61 = 'This nonsample individual was associated with a family containing a person erroneously designated as followable; the erroneous person''s code is 45, 51, 53, 54, or 60.'
        80 = 'Individual connected with the Latino sample (ER30001=7001-9308); this sample was dropped beginning in 1996.  Individual dropped from the Census (SEO) sample due to budgetary constraints; this group wa'
             's dropped beginning in 1997.'
        91 = 'This individual moved out of the 2017 main family and was eligible to be followed, but the reason for nonresponse is NA.'
        92 = 'Individual moved out of the 2017 main family and was not eligible to be followed.'
        93 = 'All sample members of this FU united with other panel FUs; this individual was nonsample and therefore became nonresponse.'
        98 = 'This individual became main family or mover-out nonresponse by 2015 and was not selected for recontact in 2017 (ER34301=0 and ER34501=0 and ER34644=0 or ER34301>0 and ER34501=71-89 and ER34501=0 and E'
             'R34644=0).'
        99 = 'DK; NA'
         0 = 'Inap.:  this individual was in a panel family in 2017 (ER34502=1-20)'
   ;
RUN ;

FORMAT 
    ER30000    ER30000F.
    ER30003    ER30003F.
    ER30005    ER30005F.
    ER30006    ER30006F.
    ER30009    ER30009F.
    ER30010    ER30010F.
    ER30011    ER30011F.
    ER30014    ER30014F.
    ER30016    ER30016F.
    ER30017    ER30017F.
    ER30018    ER30018F.
    ER30021    ER30021F.
    ER30022    ER30022F.
    ER30024    ER30024F.
    ER30025    ER30025F.
    ER30028    ER30028F.
    ER30029    ER30029F.
    ER30030    ER30030F.
    ER30031    ER30031F.
    ER30032    ER30032F.
    ER30035    ER30035F.
    ER30040    ER30040F.
    ER30041    ER30041F.
    ER30044    ER30044F.
    ER30045    ER30045F.
    ER30047    ER30047F.
    ER30048    ER30048F.
    ER30051    ER30051F.
    ER30052    ER30052F.
    ER30053    ER30053F.
    ER30054    ER30054F.
    ER30055    ER30055F.
    ER30056    ER30056F.
    ER30059    ER30059F.
    ER30064    ER30064F.
    ER30065    ER30065F.
    ER30068    ER30068F.
    ER30069    ER30069F.
    ER30071    ER30071F.
    ER30072    ER30072F.
    ER30075    ER30075F.
    ER30076    ER30076F.
    ER30077    ER30077F.
    ER30078    ER30078F.
    ER30079    ER30079F.
    ER30080    ER30080F.
    ER30083    ER30083F.
    ER30088    ER30088F.
    ER30089    ER30089F.
    ER30092    ER30092F.
    ER30093    ER30093F.
    ER30095    ER30095F.
    ER30096    ER30096F.
    ER30099    ER30099F.
    ER30100    ER30100F.
    ER30101    ER30101F.
    ER30102    ER30102F.
    ER30103    ER30103F.
    ER30104    ER30104F.
    ER30105    ER30105F.
    ER30108    ER30108F.
    ER30110    ER30110F.
    ER30114    ER30114F.
    ER30115    ER30115F.
    ER30118    ER30118F.
    ER30119    ER30119F.
    ER30121    ER30121F.
    ER30122    ER30122F.
    ER30125    ER30125F.
    ER30126    ER30126F.
    ER30127    ER30127F.
    ER30128    ER30128F.
    ER30129    ER30129F.
    ER30135    ER30135F.
    ER30136    ER30136F.
    ER30139    ER30139F.
    ER30140    ER30140F.
    ER30142    ER30142F.
    ER30143    ER30143F.
    ER30146    ER30146F.
    ER30147    ER30147F.
    ER30148    ER30148F.
    ER30149    ER30149F.
    ER30150    ER30150F.
    ER30151    ER30151F.
    ER30157    ER30157F.
    ER30158    ER30158F.
    ER30161    ER30161F.
    ER30162    ER30162F.
    ER30164    ER30164F.
    ER30165    ER30165F.
    ER30168    ER30168F.
    ER30169    ER30169F.
    ER30170    ER30170F.
    ER30171    ER30171F.
    ER30172    ER30172F.
    ER30181    ER30181F.
    ER30185    ER30185F.
    ER30186    ER30186F.
    ER30189    ER30189F.
    ER30190    ER30190F.
    ER30192    ER30192F.
    ER30193    ER30193F.
    ER30196    ER30196F.
    ER30197    ER30197F.
    ER30198    ER30198F.
    ER30199    ER30199F.
    ER30200    ER30200F.
    ER30201    ER30201F.
    ER30208    ER30208F.
    ER30214    ER30214F.
    ER30215    ER30215F.
    ER30218    ER30218F.
    ER30219    ER30219F.
    ER30221    ER30221F.
    ER30222    ER30222F.
    ER30225    ER30225F.
    ER30226    ER30226F.
    ER30227    ER30227F.
    ER30228    ER30228F.
    ER30229    ER30229F.
    ER30230    ER30230F.
    ER30237    ER30237F.
    ER30243    ER30243F.
    ER30244    ER30244F.
    ER30247    ER30247F.
    ER30248    ER30248F.
    ER30250    ER30250F.
    ER30251    ER30251F.
    ER30254    ER30254F.
    ER30255    ER30255F.
    ER30256    ER30256F.
    ER30257    ER30257F.
    ER30259    ER30259F.
    ER30260    ER30260F.
    ER30261    ER30261F.
    ER30262    ER30262F.
    ER30263    ER30263F.
    ER30264    ER30264F.
    ER30265    ER30265F.
    ER30266    ER30266F.
    ER30267    ER30267F.
    ER30274    ER30274F.
    ER30280    ER30280F.
    ER30281    ER30281F.
    ER30284    ER30284F.
    ER30285    ER30285F.
    ER30287    ER30287F.
    ER30288    ER30288F.
    ER30291    ER30291F.
    ER30292    ER30292F.
    ER30293    ER30293F.
    ER30294    ER30294F.
    ER30295    ER30295F.
    ER30296    ER30296F.
    ER30297    ER30297F.
    ER30304    ER30304F.
    ER30310    ER30310F.
    ER30311    ER30311F.
    ER30314    ER30314F.
    ER30315    ER30315F.
    ER30317    ER30317F.
    ER30318    ER30318F.
    ER30321    ER30321F.
    ER30322    ER30322F.
    ER30323    ER30323F.
    ER30324    ER30324F.
    ER30325    ER30325F.
    ER30326    ER30326F.
    ER30327    ER30327F.
    ER30334    ER30334F.
    ER30340    ER30340F.
    ER30341    ER30341F.
    ER30344    ER30344F.
    ER30345    ER30345F.
    ER30347    ER30347F.
    ER30348    ER30348F.
    ER30351    ER30351F.
    ER30352    ER30352F.
    ER30353    ER30353F.
    ER30354    ER30354F.
    ER30355    ER30355F.
    ER30356    ER30356F.
    ER30357    ER30357F.
    ER30364    ER30364F.
    ER30370    ER30370F.
    ER30371    ER30371F.
    ER30374    ER30374F.
    ER30375    ER30375F.
    ER30377    ER30377F.
    ER30378    ER30378F.
    ER30381    ER30381F.
    ER30382    ER30382F.
    ER30383    ER30383F.
    ER30384    ER30384F.
    ER30385    ER30385F.
    ER30390    ER30390F.
    ER30396    ER30396F.
    ER30397    ER30397F.
    ER30400    ER30400F.
    ER30401    ER30401F.
    ER30405    ER30405F.
    ER30406    ER30406F.
    ER30409    ER30409F.
    ER30410    ER30410F.
    ER30411    ER30411F.
    ER30412    ER30412F.
    ER30413    ER30413F.
    ER30414    ER30414F.
    ER30419    ER30419F.
    ER30426    ER30426F.
    ER30427    ER30427F.
    ER30430    ER30430F.
    ER30431    ER30431F.
    ER30435    ER30435F.
    ER30436    ER30436F.
    ER30439    ER30439F.
    ER30440    ER30440F.
    ER30441    ER30441F.
    ER30442    ER30442F.
    ER30443    ER30443F.
    ER30444    ER30444F.
    ER30449    ER30449F.
    ER30450    ER30450F.
    ER30460    ER30460F.
    ER30461    ER30461F.
    ER30464    ER30464F.
    ER30465    ER30465F.
    ER30469    ER30469F.
    ER30470    ER30470F.
    ER30473    ER30473F.
    ER30474    ER30474F.
    ER30477    ER30477F.
    ER30478    ER30478F.
    ER30479    ER30479F.
    ER30484    ER30484F.
    ER30485    ER30485F.
    ER30495    ER30495F.
    ER30496    ER30496F.
    ER30499    ER30499F.
    ER30500    ER30500F.
    ER30504    ER30504F.
    ER30505    ER30505F.
    ER30508    ER30508F.
    ER30509    ER30509F.
    ER30512    ER30512F.
    ER30513    ER30513F.
    ER30514    ER30514F.
    ER30519    ER30519F.
    ER30520    ER30520F.
    ER30526    ER30526F.
    ER30527    ER30527F.
    ER30532    ER30532F.
    ER30533    ER30533F.
    ER30536    ER30536F.
    ER30537    ER30537F.
    ER30541    ER30541F.
    ER30542    ER30542F.
    ER30545    ER30545F.
    ER30548    ER30548F.
    ER30549    ER30549F.
    ER30550    ER30550F.
    ER30555    ER30555F.
    ER30556    ER30556F.
    ER30562    ER30562F.
    ER30567    ER30567F.
    ER30568    ER30568F.
    ER30571    ER30571F.
    ER30572    ER30572F.
    ER30576    ER30576F.
    ER30577    ER30577F.
    ER30580    ER30580F.
    ER30583    ER30583F.
    ER30584    ER30584F.
    ER30585    ER30585F.
    ER30590    ER30590F.
    ER30591    ER30591F.
    ER30597    ER30597F.
    ER30598    ER30598F.
    ER30603    ER30603F.
    ER30604    ER30604F.
    ER30607    ER30607F.
    ER30608    ER30608F.
    ER30612    ER30612F.
    ER30613    ER30613F.
    ER30616    ER30616F.
    ER30619    ER30619F.
    ER30620    ER30620F.
    ER30621    ER30621F.
    ER30626    ER30626F.
    ER30627    ER30627F.
    ER30633    ER30633F.
    ER30634    ER30634F.
    ER30639    ER30639F.
    ER30640    ER30640F.
    ER30643    ER30643F.
    ER30644    ER30644F.
    ER30648    ER30648F.
    ER30649    ER30649F.
    ER30653    ER30653F.
    ER30656    ER30656F.
    ER30657    ER30657F.
    ER30658    ER30658F.
    ER30663    ER30663F.
    ER30664    ER30664F.
    ER30670    ER30670F.
    ER30671    ER30671F.
    ER30681    ER30681F.
    ER30682    ER30682F.
    ER30683    ER30683F.
    ER30684    ER30684F.
    ER30685    ER30685F.
    ER30690    ER30690F.
    ER30691    ER30691F.
    ER30695    ER30695F.
    ER30696    ER30696F.
    ER30699    ER30699F.
    ER30702    ER30702F.
    ER30703    ER30703F.
    ER30704    ER30704F.
    ER30708    ER30708F.
    ER30711    ER30711F.
    ER30712    ER30712F.
    ER30718    ER30718F.
    ER30719    ER30719F.
    ER30724    ER30724F.
    ER30725    ER30725F.
    ER30727    ER30727F.
    ER30728    ER30728F.
    ER30729    ER30729F.
    ER30734    ER30734F.
    ER30735    ER30735F.
    ER30739    ER30739F.
    ER30740    ER30740F.
    ER30744    ER30744F.
    ER30747    ER30747F.
    ER30748    ER30748F.
    ER30749    ER30749F.
    ER30753    ER30753F.
    ER30756    ER30756F.
    ER30757    ER30757F.
    ER30763    ER30763F.
    ER30764    ER30764F.
    ER30770    ER30770F.
    ER30771    ER30771F.
    ER30772    ER30772F.
    ER30773    ER30773F.
    ER30774    ER30774F.
    ER30775    ER30775F.
    ER30776    ER30776F.
    ER30777    ER30777F.
    ER30778    ER30778F.
    ER30779    ER30779F.
    ER30781    ER30781F.
    ER30783    ER30783F.
    ER30785    ER30785F.
    ER30787    ER30787F.
    ER30789    ER30789F.
    ER30791    ER30791F.
    ER30793    ER30793F.
    ER30794    ER30794F.
    ER30799    ER30799F.
    ER30800    ER30800F.
    ER30801    ER30801F.
    ER30802    ER30802F.
    ER30807    ER30807F.
    ER30808    ER30808F.
    ER30812    ER30812F.
    ER30813    ER30813F.
    ER30816    ER30816F.
    ER30819    ER30819F.
    ER30820    ER30820F.
    ER30824    ER30824F.
    ER30826    ER30826F.
    ER30827    ER30827F.
    ER30828    ER30828F.
    ER30829    ER30829F.
    ER30830    ER30830F.
    ER30831    ER30831F.
    ER30832    ER30832F.
    ER30833    ER30833F.
    ER30834    ER30834F.
    ER30835    ER30835F.
    ER30836    ER30836F.
    ER30837    ER30837F.
    ER30839    ER30839F.
    ER30841    ER30841F.
    ER30843    ER30843F.
    ER30845    ER30845F.
    ER30847    ER30847F.
    ER30849    ER30849F.
    ER30851    ER30851F.
    ER30852    ER30852F.
    ER30859    ER30859F.
    ER30861    ER30861F.
    ER30862    ER30862F.
    ER30863    ER30863F.
    ER32000    ER32000F.
    ER32001    ER32001F.
    ER32002    ER32002F.
    ER32022    ER32022F.
    ER32034    ER32034F.
    ER32037    ER32037F.
    ER32044    ER32044F.
    ER32049    ER32049F.
    ER33102    ER33102F.
    ER33103    ER33103F.
    ER33107    ER33107F.
    ER33108    ER33108F.
    ER33111    ER33111F.
    ER33114    ER33114F.
    ER33115    ER33115F.
    ER33116    ER33116F.
    ER33117    ER33117F.
    ER33118    ER33118F.
    ER33125    ER33125F.
    ER33126    ER33126F.
    ER33127    ER33127F.
    ER33128    ER33128F.
    ER33129    ER33129F.
    ER33130    ER33130F.
    ER33131    ER33131F.
    ER33132    ER33132F.
    ER33133    ER33133F.
    ER33134    ER33134F.
    ER33135    ER33135F.
    ER33136    ER33136F.
    ER33137    ER33137F.
    ER33138    ER33138F.
    ER33140    ER33140F.
    ER33142    ER33142F.
    ER33144    ER33144F.
    ER33146    ER33146F.
    ER33148    ER33148F.
    ER33202    ER33202F.
    ER33203    ER33203F.
    ER33207    ER33207F.
    ER33208    ER33208F.
    ER33211    ER33211F.
    ER33214    ER33214F.
    ER33215    ER33215F.
    ER33216    ER33216F.
    ER33217    ER33217F.
    ER33218    ER33218F.
    ER33220    ER33220F.
    ER33221    ER33221F.
    ER33226    ER33226F.
    ER33230    ER33230F.
    ER33245    ER33245F.
    ER33246    ER33246F.
    ER33247    ER33247F.
    ER33259    ER33259F.
    ER33260    ER33260F.
    ER33261    ER33261F.
    ER33264    ER33264F.
    ER33265    ER33265F.
    ER33266    ER33266F.
    ER33267    ER33267F.
    ER33268    ER33268F.
    ER33269    ER33269F.
    ER33272    ER33272F.
    ER33273    ER33273F.
    ER33274    ER33274F.
    ER33281    ER33281F.
    ER33282    ER33282F.
    ER33283    ER33283F.
    ER33284    ER33284F.
    ER33285    ER33285F.
    ER33286    ER33286F.
    ER33287    ER33287F.
    ER33288    ER33288F.
    ER33289    ER33289F.
    ER33290    ER33290F.
    ER33291    ER33291F.
    ER33292    ER33292F.
    ER33293    ER33293F.
    ER33294    ER33294F.
    ER33295    ER33295F.
    ER33296    ER33296F.
    ER33297    ER33297F.
    ER33298    ER33298F.
    ER33299    ER33299F.
    ER33302    ER33302F.
    ER33303    ER33303F.
    ER33307    ER33307F.
    ER33308    ER33308F.
    ER33311    ER33311F.
    ER33314    ER33314F.
    ER33315    ER33315F.
    ER33316    ER33316F.
    ER33317    ER33317F.
    ER33322    ER33322F.
    ER33324    ER33324F.
    ER33325    ER33325F.
    ER33326    ER33326F.
    ER33327    ER33327F.
    ER33328    ER33328F.
    ER33329    ER33329F.
    ER33330    ER33330F.
    ER33331    ER33331F.
    ER33332    ER33332F.
    ER33333    ER33333F.
    ER33334    ER33334F.
    ER33335    ER33335F.
    ER33336    ER33336F.
    ER33338    ER33338F.
    ER33340    ER33340F.
    ER33342    ER33342F.
    ER33344    ER33344F.
    ER33346    ER33346F.
    ER33402    ER33402F.
    ER33403    ER33403F.
    ER33407    ER33407F.
    ER33408    ER33408F.
    ER33411    ER33411F.
    ER33414    ER33414F.
    ER33415    ER33415F.
    ER33416    ER33416F.
    ER33417    ER33417F.
    ER33418    ER33418F.
    ER33419    ER33419F.
    ER33420    ER33420F.
    ER33434    ER33434F.
    ER33436    ER33436F.
    ER33437    ER33437F.
    ER33502    ER33502F.
    ER33503    ER33503F.
    ER33507    ER33507F.
    ER33508    ER33508F.
    ER33511    ER33511F.
    ER33512    ER33512F.
    ER33515    ER33515F.
    ER33516    ER33516F.
    ER33517    ER33517F.
    ER33518    ER33518F.
    ER33519    ER33519F.
    ER33520    ER33520F.
    ER33521    ER33521F.
    ER33522    ER33522F.
    ER33523    ER33523F.
    ER33532A   ER33532AF.
    ER33532B   ER33532BF.
    ER33532C   ER33532CF.
    ER33532D   ER33532DF.
    ER33532E   ER33532EF.
    ER33532F   ER33532FF.
    ER33532G   ER33532GF.
    ER33532H   ER33532HF.
    ER33532I   ER33532IF.
    ER33532X   ER33532XF.
    ER33533    ER33533F.
    ER33534    ER33534F.
    ER33535    ER33535F.
    ER33536    ER33536F.
    ER33536B   ER33536BF.
    ER33536C   ER33536CF.
    ER33536P   ER33536PF.
    ER33537    ER33537F.
    ER33537M   ER33537MF.
    ER33538    ER33538F.
    ER33542    ER33542F.
    ER33544    ER33544F.
    ER33545    ER33545F.
    ER33602    ER33602F.
    ER33603    ER33603F.
    ER33607    ER33607F.
    ER33608    ER33608F.
    ER33611    ER33611F.
    ER33612    ER33612F.
    ER33615    ER33615F.
    ER33616    ER33616F.
    ER33617    ER33617F.
    ER33618    ER33618F.
    ER33619    ER33619F.
    ER33620    ER33620F.
    ER33621    ER33621F.
    ER33622    ER33622F.
    ER33623    ER33623F.
    ER33623A   ER33623AF.
    ER33623B   ER33623BF.
    ER33623C   ER33623CF.
    ER33623D   ER33623DF.
    ER33623E   ER33623EF.
    ER33623F   ER33623FF.
    ER33623G   ER33623GF.
    ER33623H   ER33623HF.
    ER33623I   ER33623IF.
    ER33623X   ER33623XF.
    ER33624    ER33624F.
    ER33625    ER33625F.
    ER33626    ER33626F.
    ER33627    ER33627F.
    ER33627B   ER33627BF.
    ER33627C   ER33627CF.
    ER33627P   ER33627PF.
    ER33628    ER33628F.
    ER33628M   ER33628MF.
    ER33629    ER33629F.
    ER33633    ER33633F.
    ER33635    ER33635F.
    ER33636    ER33636F.
    ER33638    ER33638F.
    ER33702    ER33702F.
    ER33703    ER33703F.
    ER33707    ER33707F.
    ER33708    ER33708F.
    ER33711    ER33711F.
    ER33712    ER33712F.
    ER33715    ER33715F.
    ER33716    ER33716F.
    ER33717    ER33717F.
    ER33718    ER33718F.
    ER33719    ER33719F.
    ER33720    ER33720F.
    ER33721    ER33721F.
    ER33722    ER33722F.
    ER33723    ER33723F.
    ER33724    ER33724F.
    ER33724A   ER33724AF.
    ER33724B   ER33724BF.
    ER33724C   ER33724CF.
    ER33724D   ER33724DF.
    ER33724E   ER33724EF.
    ER33724F   ER33724FF.
    ER33724G   ER33724GF.
    ER33724H   ER33724HF.
    ER33724I   ER33724IF.
    ER33725    ER33725F.
    ER33726    ER33726F.
    ER33727    ER33727F.
    ER33727B   ER33727BF.
    ER33727C   ER33727CF.
    ER33727P   ER33727PF.
    ER33728    ER33728F.
    ER33728M   ER33728MF.
    ER33729    ER33729F.
    ER33730    ER33730F.
    ER33731    ER33731F.
    ER33732    ER33732F.
    ER33736    ER33736F.
    ER33738    ER33738F.
    ER33739    ER33739F.
    ER33741    ER33741F.
    ER33802    ER33802F.
    ER33803    ER33803F.
    ER33807    ER33807F.
    ER33808    ER33808F.
    ER33811    ER33811F.
    ER33812    ER33812F.
    ER33813    ER33813F.
    ER33816    ER33816F.
    ER33817    ER33817F.
    ER33818    ER33818F.
    ER33819    ER33819F.
    ER33820    ER33820F.
    ER33821    ER33821F.
    ER33822    ER33822F.
    ER33823    ER33823F.
    ER33824    ER33824F.
    ER33825    ER33825F.
    ER33826    ER33826F.
    ER33826B   ER33826BF.
    ER33827    ER33827F.
    ER33827F   ER33827FF.
    ER33827S   ER33827SF.
    ER33828    ER33828F.
    ER33829    ER33829F.
    ER33830    ER33830F.
    ER33831    ER33831F.
    ER33832    ER33832F.
    ER33833    ER33833F.
    ER33833A   ER33833AF.
    ER33833B   ER33833BF.
    ER33833C   ER33833CF.
    ER33833D   ER33833DF.
    ER33833E   ER33833EF.
    ER33833F   ER33833FF.
    ER33833G   ER33833GF.
    ER33833H   ER33833HF.
    ER33834    ER33834F.
    ER33835    ER33835F.
    ER33836    ER33836F.
    ER33837    ER33837F.
    ER33837A   ER33837AF.
    ER33837D   ER33837DF.
    ER33838    ER33838F.
    ER33842    ER33842F.
    ER33844    ER33844F.
    ER33845    ER33845F.
    ER33846    ER33846F.
    ER33847    ER33847F.
    ER33902    ER33902F.
    ER33903    ER33903F.
    ER33907    ER33907F.
    ER33908    ER33908F.
    ER33911    ER33911F.
    ER33912    ER33912F.
    ER33913    ER33913F.
    ER33916    ER33916F.
    ER33917    ER33917F.
    ER33918    ER33918F.
    ER33919    ER33919F.
    ER33920    ER33920F.
    ER33921    ER33921F.
    ER33922    ER33922F.
    ER33923    ER33923F.
    ER33924    ER33924F.
    ER33925    ER33925F.
    ER33925A   ER33925AF.
    ER33925D   ER33925DF.
    ER33926    ER33926F.
    ER33926B   ER33926BF.
    ER33927    ER33927F.
    ER33927A   ER33927AF.
    ER33928    ER33928F.
    ER33929    ER33929F.
    ER33930    ER33930F.
    ER33931    ER33931F.
    ER33932    ER33932F.
    ER33933    ER33933F.
    ER33933A   ER33933AF.
    ER33933B   ER33933BF.
    ER33933C   ER33933CF.
    ER33933D   ER33933DF.
    ER33933E   ER33933EF.
    ER33933F   ER33933FF.
    ER33933G   ER33933GF.
    ER33933H   ER33933HF.
    ER33934    ER33934F.
    ER33935    ER33935F.
    ER33936    ER33936F.
    ER33937    ER33937F.
    ER33938    ER33938F.
    ER33942    ER33942F.
    ER33944    ER33944F.
    ER33945    ER33945F.
    ER33948    ER33948F.
    ER33949    ER33949F.
    ER34002    ER34002F.
    ER34003    ER34003F.
    ER34007    ER34007F.
    ER34008    ER34008F.
    ER34011    ER34011F.
    ER34012    ER34012F.
    ER34013    ER34013F.
    ER34014    ER34014F.
    ER34015    ER34015F.
    ER34016    ER34016F.
    ER34019    ER34019F.
    ER34020    ER34020F.
    ER34021    ER34021F.
    ER34022    ER34022F.
    ER34023    ER34023F.
    ER34024    ER34024F.
    ER34025    ER34025F.
    ER34026    ER34026F.
    ER34027    ER34027F.
    ER34028    ER34028F.
    ER34029    ER34029F.
    ER34029A   ER34029AF.
    ER34030    ER34030F.
    ER34036    ER34036F.
    ER34038    ER34038F.
    ER34039    ER34039F.
    ER34040    ER34040F.
    ER34041    ER34041F.
    ER34042    ER34042F.
    ER34043    ER34043F.
    ER34044    ER34044F.
    ER34102    ER34102F.
    ER34103    ER34103F.
    ER34107    ER34107F.
    ER34108    ER34108F.
    ER34111    ER34111F.
    ER34112    ER34112F.
    ER34113    ER34113F.
    ER34114    ER34114F.
    ER34115    ER34115F.
    ER34116    ER34116F.
    ER34119    ER34119F.
    ER34120    ER34120F.
    ER34121    ER34121F.
    ER34122    ER34122F.
    ER34123    ER34123F.
    ER34124    ER34124F.
    ER34125    ER34125F.
    ER34126    ER34126F.
    ER34127    ER34127F.
    ER34128    ER34128F.
    ER34129    ER34129F.
    ER34130    ER34130F.
    ER34131    ER34131F.
    ER34132    ER34132F.
    ER34133    ER34133F.
    ER34134    ER34134F.
    ER34135    ER34135F.
    ER34136    ER34136F.
    ER34136A   ER34136AF.
    ER34148    ER34148F.
    ER34150    ER34150F.
    ER34151    ER34151F.
    ER34152    ER34152F.
    ER34153    ER34153F.
    ER34202    ER34202F.
    ER34203    ER34203F.
    ER34207    ER34207F.
    ER34208    ER34208F.
    ER34211    ER34211F.
    ER34212    ER34212F.
    ER34213    ER34213F.
    ER34214    ER34214F.
    ER34215    ER34215F.
    ER34216    ER34216F.
    ER34219    ER34219F.
    ER34220    ER34220F.
    ER34221    ER34221F.
    ER34228    ER34228F.
    ER34229    ER34229F.
    ER34230    ER34230F.
    ER34231    ER34231F.
    ER34232    ER34232F.
    ER34233    ER34233F.
    ER34234    ER34234F.
    ER34235    ER34235F.
    ER34236    ER34236F.
    ER34237    ER34237F.
    ER34238    ER34238F.
    ER34239    ER34239F.
    ER34240    ER34240F.
    ER34241    ER34241F.
    ER34242    ER34242F.
    ER34243    ER34243F.
    ER34243A   ER34243AF.
    ER34255    ER34255F.
    ER34257    ER34257F.
    ER34258    ER34258F.
    ER34259    ER34259F.
    ER34260    ER34260F.
    ER34261    ER34261F.
    ER34261A   ER34261AF.
    ER34262    ER34262F.
    ER34263    ER34263F.
    ER34264    ER34264F.
    ER34265    ER34265F.
    ER34266    ER34266F.
    ER34267    ER34267F.
    ER34302    ER34302F.
    ER34303    ER34303F.
    ER34304    ER34304F.
    ER34308    ER34308F.
    ER34309    ER34309F.
    ER34312    ER34312F.
    ER34313    ER34313F.
    ER34314    ER34314F.
    ER34315    ER34315F.
    ER34316    ER34316F.
    ER34317    ER34317F.
    ER34319    ER34319F.
    ER34320    ER34320F.
    ER34321    ER34321F.
    ER34323    ER34323F.
    ER34328    ER34328F.
    ER34331    ER34331F.
    ER34335    ER34335F.
    ER34336    ER34336F.
    ER34347    ER34347F.
    ER34348    ER34348F.
    ER34349    ER34349F.
    ER34350    ER34350F.
    ER34351    ER34351F.
    ER34352    ER34352F.
    ER34360    ER34360F.
    ER34363    ER34363F.
    ER34367    ER34367F.
    ER34368    ER34368F.
    ER34379    ER34379F.
    ER34380    ER34380F.
    ER34381    ER34381F.
    ER34382    ER34382F.
    ER34383    ER34383F.
    ER34384    ER34384F.
    ER34385    ER34385F.
    ER34386    ER34386F.
    ER34387    ER34387F.
    ER34388    ER34388F.
    ER34389    ER34389F.
    ER34390    ER34390F.
    ER34391    ER34391F.
    ER34392    ER34392F.
    ER34393    ER34393F.
    ER34393A   ER34393AF.
    ER34405    ER34405F.
    ER34407    ER34407F.
    ER34408    ER34408F.
    ER34409    ER34409F.
    ER34410    ER34410F.
    ER34411    ER34411F.
    ER34412    ER34412F.
    ER34502    ER34502F.
    ER34503    ER34503F.
    ER34507    ER34507F.
    ER34508    ER34508F.
    ER34511    ER34511F.
    ER34512    ER34512F.
    ER34513    ER34513F.
    ER34514    ER34514F.
    ER34515    ER34515F.
    ER34516    ER34516F.
    ER34518    ER34518F.
    ER34519    ER34519F.
    ER34520    ER34520F.
    ER34522    ER34522F.
    ER34527    ER34527F.
    ER34530    ER34530F.
    ER34534    ER34534F.
    ER34535    ER34535F.
    ER34546    ER34546F.
    ER34547    ER34547F.
    ER34548    ER34548F.
    ER34549    ER34549F.
    ER34550    ER34550F.
    ER34551    ER34551F.
    ER34559    ER34559F.
    ER34562    ER34562F.
    ER34566    ER34566F.
    ER34567    ER34567F.
    ER34578    ER34578F.
    ER34579    ER34579F.
    ER34580    ER34580F.
    ER34581    ER34581F.
    ER34582    ER34582F.
    ER34583    ER34583F.
    ER34584    ER34584F.
    ER34585    ER34585F.
    ER34586    ER34586F.
    ER34587    ER34587F.
    ER34588    ER34588F.
    ER34589    ER34589F.
    ER34590    ER34590F.
    ER34591    ER34591F.
    ER34592    ER34592F.
    ER34593    ER34593F.
    ER34594    ER34594F.
    ER34595    ER34595F.
    ER34596    ER34596F.
    ER34597    ER34597F.
    ER34598    ER34598F.
    ER34599    ER34599F.
    ER34600    ER34600F.
    ER34601    ER34601F.
    ER34602    ER34602F.
    ER34611    ER34611F.
    ER34644    ER34644F.
    ER34646    ER34646F.
    ER34647    ER34647F.
    ER34648    ER34648F.
    ER34649    ER34649F.
;
