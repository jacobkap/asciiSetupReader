/* PSID DATA CENTER *****************************************************
   JOBID            : 260682                            
   DATA_DOMAIN      : IND                               
   USER_WHERE       : NULL                              
   FILE_TYPE        : All Individuals Data              
   OUTPUT_DATA_TYPE : ASCII                             
   STATEMENTS       : SAS Statements                    
   CODEBOOK_TYPE    : PDF                               
   N_OF_VARIABLES   : 1534                              
   N_OF_OBSERVATIONS: 80666                             
   MAX_REC_LENGTH   : 4080                              
   DATE & TIME      : June 6, 2019 @ 15:14:11
************************************************************************/

FILENAME J260682 "[path]\J260682.txt" ;

DATA J260682 ;
   ATTRIB
      ER30000       LABEL="RELEASE NUMBER"                           FORMAT=F1.  
      ER30001       LABEL="1968 INTERVIEW NUMBER"                    FORMAT=F4.  
      ER30002       LABEL="PERSON NUMBER                         68" FORMAT=F3.  
      ER32000       LABEL="SEX OF INDIVIDUAL"                        FORMAT=F1.  
      ER32001       LABEL="WTR ALWAYS IN RESPONDING FAMILY UNIT"     FORMAT=F1.  
      ER32002       LABEL="WTR EVER CODED INSTITUTIONAL"             FORMAT=F1.  
      ER32014       LABEL="BIRTH WEIGHT OF THIS INDIVIDUAL"          FORMAT=F3.  
      ER32021       LABEL="YEAR BIRTH INFO MOST RECENTLY UPDATED"    FORMAT=F4.  
      ER32022       LABEL="# LIVE BIRTHS TO THIS INDIVIDUAL"         FORMAT=F2.  
      ER32024       LABEL="YEAR 1ST/ONLY CHILD BORN"                 FORMAT=F4.  
      ER32026       LABEL="YEAR YOUNGEST CHILD BORN"                 FORMAT=F4.  
      ER32028       LABEL="YEAR 2ND YOUNGEST CHILD BORN"             FORMAT=F4.  
      ER32030       LABEL="YEAR 3RD YOUNGEST CHILD BORN"             FORMAT=F4.  
      ER32032       LABEL="YEAR 4TH YOUNGEST CHILD BORN"             FORMAT=F4.  
      ER32033       LABEL="YEAR MARITAL INFO MOST RECENTLY UPDATED"  FORMAT=F4.  
      ER32034       LABEL="# MARRIAGES OF THIS INDIVIDUAL"           FORMAT=F2.  
      ER32036       LABEL="YEAR FIRST/ONLY MARRIAGE BEGAN"           FORMAT=F4.  
      ER32037       LABEL="STATUS OF FIRST/ONLY MARRIAGE"            FORMAT=F1.  
      ER32039       LABEL="YEAR FIRST/ONLY MARRIAGE ENDED"           FORMAT=F4.  
      ER32041       LABEL="YEAR SEPARATED FIRST/ONLY MARRIAGE"       FORMAT=F4.  
      ER32043       LABEL="YEAR MOST RECENT MARRIAGE BEGAN"          FORMAT=F4.  
      ER32044       LABEL="STATUS OF MOST RECENT MARRIAGE"           FORMAT=F1.  
      ER32046       LABEL="YEAR MOST RECENT MARRIAGE ENDED"          FORMAT=F4.  
      ER32048       LABEL="YEAR SEPARATED MOST RECENT MARRIAGE"      FORMAT=F4.  
      ER32049       LABEL="LAST KNOWN MARITAL STATUS"                FORMAT=F1.  
      ER32051       LABEL="YEAR MOST RECENT PREGNANCY INTENTION REC" FORMAT=F4.  
      ER30003       LABEL="RELATIONSHIP TO HEAD                  68" FORMAT=F1.  
      ER30004       LABEL="AGE OF INDIVIDUAL                     68" FORMAT=F3.  
      ER30005       LABEL="MARR PAIRS INDICATOR                  68" FORMAT=F1.  
      ER30006       LABEL="WHETHER MOVED IN                      68" FORMAT=F1.  
      ER30008       LABEL="YEAR MOVED IN                         68" FORMAT=F4.  
      ER30009       LABEL="IN SCHOOL                             68" FORMAT=F1.  
      ER30010       LABEL="YRS SCHL COMPL                        68" FORMAT=F2.  
      ER30011       LABEL="TYPE OF INCOME                        68" FORMAT=F1.  
      ER30012       LABEL="MONEY INCOME IND                      68" FORMAT=F4.  
      ER30013       LABEL="HOURS WORKED IND                      68" FORMAT=F4.  
      ER30014       LABEL="SHARE EXPENSES                        68" FORMAT=F1.  
      ER30016       LABEL="EXTRA EARNER NR.                      68" FORMAT=F1.  
      ER30017       LABEL="TYPE OF IND RECORD                    68" FORMAT=F2.  
      ER30018       LABEL="WHY NONRESPONSE                       68" FORMAT=F2.  
      ER30019       LABEL="INDIVIDUAL WEIGHT                     68" FORMAT=F4.1 
      ER30020       LABEL="1969 INTERVIEW NUMBER"                    FORMAT=F4.  
      ER30021       LABEL="SEQUENCE NUMBER                       69" FORMAT=F2.  
      ER30022       LABEL="RELATIONSHIP TO HEAD                  69" FORMAT=F1.  
      ER30023       LABEL="AGE OF INDIVIDUAL                     69" FORMAT=F3.  
      ER30024       LABEL="MARR PAIRS INDICATOR                  69" FORMAT=F1.  
      ER30025       LABEL="WHETHER MOVED IN/OUT                  69" FORMAT=F1.  
      ER30027       LABEL="YEAR MOVED IN/OUT                     69" FORMAT=F4.  
      ER30028       LABEL="STOPPED SCHOOL                        69" FORMAT=F1.  
      ER30029       LABEL="HRS/WK HOUSEWRK                       69" FORMAT=F2.  
      ER30030       LABEL="DISABLED OR RQ CARE                   69" FORMAT=F1.  
      ER30031       LABEL="RESPONDENT?                           69" FORMAT=F1.  
      ER30032       LABEL="TYPE OF INCOME                        69" FORMAT=F1.  
      ER30033       LABEL="MONEY INCOME                          69" FORMAT=F5.  
      ER30034       LABEL="HRS WORKED IN 68                      69" FORMAT=F4.  
      ER30035       LABEL="SHARE EXPENSES                        69" FORMAT=F1.  
      ER30038       LABEL="YR S/O FAM FORMED                     69" FORMAT=F4.  
      ER30039       LABEL="MAIN FAM ID FOR S/O                   69" FORMAT=F4.  
      ER30040       LABEL="TYPE OF IND RECORD                    69" FORMAT=F2.  
      ER30041       LABEL="WHY NONRESPONSE                       69" FORMAT=F2.  
      ER30042       LABEL="INDIVIDUAL WEIGHT                     69" FORMAT=F4.1 
      ER30043       LABEL="1970 INTERVIEW NUMBER"                    FORMAT=F4.  
      ER30044       LABEL="SEQUENCE NUMBER                       70" FORMAT=F2.  
      ER30045       LABEL="RELATIONSHIP TO HEAD                  70" FORMAT=F1.  
      ER30046       LABEL="AGE OF INDIVIDUAL                     70" FORMAT=F3.  
      ER30047       LABEL="MARR PAIRS INDICATOR                  70" FORMAT=F1.  
      ER30048       LABEL="WHETHER MOVED IN/OUT                  70" FORMAT=F1.  
      ER30050       LABEL="YEAR MOVED IN/OUT                     70" FORMAT=F4.  
      ER30051       LABEL="STOPPED SCHOOL                        70" FORMAT=F1.  
      ER30052       LABEL="GRADE FINISHED                        70" FORMAT=F2.  
      ER30053       LABEL="HRS/WK HOUSEWK                        70" FORMAT=F2.  
      ER30054       LABEL="DISABLED OR RQ CARE                   70" FORMAT=F1.  
      ER30055       LABEL="RESPONDENT?                           70" FORMAT=F1.  
      ER30056       LABEL="TYPE OF INCOME                        70" FORMAT=F1.  
      ER30057       LABEL="MONEY INCOME                          70" FORMAT=F5.  
      ER30058       LABEL="HOURS WORKED                          70" FORMAT=F4.  
      ER30059       LABEL="SHARE EXPENSES                        70" FORMAT=F1.  
      ER30062       LABEL="YR S/O FAM FORMED                     70" FORMAT=F4.  
      ER30063       LABEL="MAIN FAM ID FOR S/O                   70" FORMAT=F4.  
      ER30064       LABEL="TYPE OF IND RECORD                    70" FORMAT=F2.  
      ER30065       LABEL="WHY NONRESPONSE                       70" FORMAT=F2.  
      ER30066       LABEL="INDIVIDUAL WEIGHT                     70" FORMAT=F4.1 
      ER30067       LABEL="1971 INTERVIEW NUMBER"                    FORMAT=F4.  
      ER30068       LABEL="SEQUENCE NUMBER                       71" FORMAT=F2.  
      ER30069       LABEL="RELATIONSHIP TO HEAD                  71" FORMAT=F1.  
      ER30070       LABEL="AGE OF INDIVIDUAL                     71" FORMAT=F3.  
      ER30071       LABEL="MARR PAIRS INDICATOR                  71" FORMAT=F1.  
      ER30072       LABEL="WHETHER MOVED IN/OUT                  71" FORMAT=F1.  
      ER30074       LABEL="YEAR MOVED IN/OUT                     71" FORMAT=F4.  
      ER30075       LABEL="STOPPED SCHOOL                        71" FORMAT=F1.  
      ER30076       LABEL="GRADE FINISHED                        71" FORMAT=F2.  
      ER30077       LABEL="HRS/WK HSWK                           71" FORMAT=F2.  
      ER30078       LABEL="DISABLED OR REQ CR                    71" FORMAT=F1.  
      ER30079       LABEL="RESPONDENT?                           71" FORMAT=F1.  
      ER30080       LABEL="TYPE OF INCOME                        71" FORMAT=F1.  
      ER30081       LABEL="MONEY INCOME                          71" FORMAT=F5.  
      ER30082       LABEL="HOURS WORKED                          71" FORMAT=F4.  
      ER30083       LABEL="SHARE EXPENSES                        71" FORMAT=F1.  
      ER30086       LABEL="YR S/O FAM FORMED                     71" FORMAT=F4.  
      ER30087       LABEL="MAIN FAM ID FOR S/O                   71" FORMAT=F4.  
      ER30088       LABEL="TYPE OF IND RECORD                    71" FORMAT=F2.  
      ER30089       LABEL="WHY NONRESPONSE                       71" FORMAT=F2.  
      ER30090       LABEL="INDIVIDUAL WEIGHT                     71" FORMAT=F4.1 
      ER30091       LABEL="1972 INTERVIEW NUMBER"                    FORMAT=F4.  
      ER30092       LABEL="SEQUENCE NUMBER                       72" FORMAT=F2.  
      ER30093       LABEL="RELATIONSHIP TO HEAD                  72" FORMAT=F1.  
      ER30094       LABEL="AGE OF INDIVIDUAL                     72" FORMAT=F3.  
      ER30095       LABEL="MARR PAIRS INDICATOR                  72" FORMAT=F1.  
      ER30096       LABEL="WHETHER MOVED IN/OUT                  72" FORMAT=F1.  
      ER30098       LABEL="YEAR MOVED IN/OUT                     72" FORMAT=F4.  
      ER30099       LABEL="STOPPED SCHOOL                        72" FORMAT=F1.  
      ER30100       LABEL="GRADE FINISHED                        72" FORMAT=F2.  
      ER30101       LABEL="WHO DID WORK?                         72" FORMAT=F1.  
      ER30102       LABEL="HRS/WK HSWRK                          72" FORMAT=F2.  
      ER30103       LABEL="DISABLED OR REQ CR                    72" FORMAT=F1.  
      ER30104       LABEL="RESPONDENT?                           72" FORMAT=F1.  
      ER30105       LABEL="TYPE OF INCOME                        72" FORMAT=F1.  
      ER30106       LABEL="MONEY INCOME                          72" FORMAT=F5.  
      ER30107       LABEL="HOURS WORKED                          72" FORMAT=F4.  
      ER30108       LABEL="SHARE EXPENSES?                       72" FORMAT=F1.  
      ER30110       LABEL="COMPLETED EDUCATION                   72" FORMAT=F2.  
      ER30112       LABEL="YR S/O FAM FORMED                     72" FORMAT=F4.  
      ER30113       LABEL="MAIN FAM ID FOR S/O                   72" FORMAT=F4.  
      ER30114       LABEL="TYPE OF IND RECORD                    72" FORMAT=F2.  
      ER30115       LABEL="WHY NONRESPONSE                       72" FORMAT=F2.  
      ER30116       LABEL="INDIVIDUAL WEIGHT                     72" FORMAT=F4.1 
      ER30117       LABEL="1973 INTERVIEW NUMBER"                    FORMAT=F4.  
      ER30118       LABEL="SEQUENCE NUMBER                       73" FORMAT=F2.  
      ER30119       LABEL="RELATIONSHIP TO HEAD                  73" FORMAT=F1.  
      ER30120       LABEL="AGE OF INDIVIDUAL                     73" FORMAT=F3.  
      ER30121       LABEL="MARR PAIRS INDICATOR                  73" FORMAT=F1.  
      ER30122       LABEL="WHETHER MOVED IN/OUT                  73" FORMAT=F1.  
      ER30124       LABEL="YEAR MOVED IN/OUT                     73" FORMAT=F4.  
      ER30125       LABEL="STOPPED SCHOOL                        73" FORMAT=F1.  
      ER30126       LABEL="GRADE FINISHED                        73" FORMAT=F2.  
      ER30127       LABEL="HR/WK HOUSEWORK                       73" FORMAT=F2.  
      ER30128       LABEL="RESPONDENT?                           73" FORMAT=F1.  
      ER30129       LABEL="TYPE OF INCOME                        73" FORMAT=F1.  
      ER30130       LABEL="MONEY INCOME                          73" FORMAT=F5.  
      ER30131       LABEL="HOURS WORKED                          73" FORMAT=F4.  
      ER30133       LABEL="YR S/O FAM FORMED                     73" FORMAT=F4.  
      ER30134       LABEL="MAIN FAM ID FOR S/O                   73" FORMAT=F4.  
      ER30135       LABEL="TYPE OF IND RECORD                    73" FORMAT=F2.  
      ER30136       LABEL="WHY NONRESPONSE                       73" FORMAT=F2.  
      ER30137       LABEL="INDIVIDUAL WEIGHT                     73" FORMAT=F4.1 
      ER30138       LABEL="1974 INTERVIEW NUMBER"                    FORMAT=F4.  
      ER30139       LABEL="SEQUENCE NUMBER                       74" FORMAT=F2.  
      ER30140       LABEL="RELATIONSHIP TO HEAD                  74" FORMAT=F1.  
      ER30141       LABEL="AGE OF INDIVIDUAL                     74" FORMAT=F3.  
      ER30142       LABEL="MARR PAIRS INDICATOR                  74" FORMAT=F1.  
      ER30143       LABEL="WHETHER MOVED IN/OUT                  74" FORMAT=F1.  
      ER30145       LABEL="YEAR MOVED IN/OUT                     74" FORMAT=F4.  
      ER30146       LABEL="STOP SCHOOL?                          74" FORMAT=F1.  
      ER30147       LABEL="HIGHEST GRADE                         74" FORMAT=F2.  
      ER30148       LABEL="HRS/WK HOUSEWORK                      74" FORMAT=F2.  
      ER30149       LABEL="RESPONDENT?                           74" FORMAT=F1.  
      ER30150       LABEL="TYPE OF INCOME                        74" FORMAT=F1.  
      ER30151       LABEL="WTR WELFARE INCOME                    74" FORMAT=F1.  
      ER30152       LABEL="TOTAL MONEY INCOME                    74" FORMAT=F5.  
      ER30153       LABEL="TOT ANN HRS                           74" FORMAT=F4.  
      ER30155       LABEL="YR S/O FAM FORMED                     74" FORMAT=F4.  
      ER30156       LABEL="MAIN FAM ID FOR S/O                   74" FORMAT=F4.  
      ER30157       LABEL="TYPE OF IND RECORD                    74" FORMAT=F2.  
      ER30158       LABEL="WHY NONRESPONSE                       74" FORMAT=F2.  
      ER30159       LABEL="INDIVIDUAL WEIGHT                     74" FORMAT=F4.1 
      ER30160       LABEL="1975 INTERVIEW NUMBER"                    FORMAT=F4.  
      ER30161       LABEL="SEQUENCE NUMBER                       75" FORMAT=F2.  
      ER30162       LABEL="RELATIONSHIP TO HEAD                  75" FORMAT=F1.  
      ER30163       LABEL="AGE OF INDIVIDUAL                     75" FORMAT=F3.  
      ER30164       LABEL="MARR PAIRS INDICATOR                  75" FORMAT=F1.  
      ER30165       LABEL="WHETHER MOVED IN/OUT                  75" FORMAT=F1.  
      ER30167       LABEL="YEAR MOVED IN/OUT                     75" FORMAT=F4.  
      ER30168       LABEL="STOPPED SCHOOL?                       75" FORMAT=F1.  
      ER30169       LABEL="HIGHEST GRAD FINISHED                 75" FORMAT=F2.  
      ER30170       LABEL="RESPONDENT?                           75" FORMAT=F1.  
      ER30171       LABEL="LABOR/ASSET TYPE INC                  75" FORMAT=F1.  
      ER30172       LABEL="TRANSFER TYPE INC                     75" FORMAT=F1.  
      ER30173       LABEL="TAXABLE INCOME                        75" FORMAT=F5.  
      ER30175       LABEL="TRANSFER INCOME                       75" FORMAT=F5.  
      ER30177       LABEL="HRS WORKED IN 74                      75" FORMAT=F4.  
      ER30179       LABEL="HRS UNEMP IN 74                       75" FORMAT=F4.  
      ER30181       LABEL="COMPLETED EDUCATION                   75" FORMAT=F2.  
      ER30183       LABEL="YR S/O FAM FORMED                     75" FORMAT=F4.  
      ER30184       LABEL="MAIN FAM ID FOR S/O                   75" FORMAT=F4.  
      ER30185       LABEL="TYPE OF IND RECORD                    75" FORMAT=F2.  
      ER30186       LABEL="WHY NONRESPONSE                       75" FORMAT=F2.  
      ER30187       LABEL="INDIVIDUAL WEIGHT                     75" FORMAT=F4.1 
      ER30188       LABEL="1976 INTERVIEW NUMBER"                    FORMAT=F4.  
      ER30189       LABEL="SEQUENCE NUMBER                       76" FORMAT=F2.  
      ER30190       LABEL="RELATIONSHIP TO HEAD                  76" FORMAT=F1.  
      ER30191       LABEL="AGE OF INDIVIDUAL                     76" FORMAT=F3.  
      ER30192       LABEL="MARR PAIRS INDICATOR                  76" FORMAT=F1.  
      ER30193       LABEL="WHETHER MOVED IN/OUT                  76" FORMAT=F1.  
      ER30195       LABEL="YEAR MOVED IN/OUT                     76" FORMAT=F4.  
      ER30196       LABEL="STOP SCHOOL?                          76" FORMAT=F1.  
      ER30197       LABEL="HIGHEST GRADE FINISH                  76" FORMAT=F2.  
      ER30198       LABEL="HRS HOUSEWORK/WK                      76" FORMAT=F2.  
      ER30199       LABEL="EXTRA CARE?                           76" FORMAT=F1.  
      ER30200       LABEL="RESPONDENT?                           76" FORMAT=F1.  
      ER30201       LABEL="TAXABLE Y SOURCE                      76" FORMAT=F1.  
      ER30202       LABEL="TOTAL TAXABLE Y                       76" FORMAT=F5.  
      ER30204       LABEL="HRS WRKED LAST YR                     76" FORMAT=F4.  
      ER30206       LABEL="HRS UNEMP LAST YR                     76" FORMAT=F4.  
      ER30208       LABEL="TRANSFER Y SOURCE                     76" FORMAT=F1.  
      ER30209       LABEL="TOTAL TRANSFER Y                      76" FORMAT=F5.  
      ER30212       LABEL="YR S/O FAM FORMED                     76" FORMAT=F4.  
      ER30213       LABEL="MAIN FAM ID FOR S/O                   76" FORMAT=F4.  
      ER30214       LABEL="TYPE OF IND RECORD                    76" FORMAT=F2.  
      ER30215       LABEL="WHY NONRESPONSE                       76" FORMAT=F2.  
      ER30216       LABEL="INDIVIDUAL WEIGHT                     76" FORMAT=F4.1 
      ER30217       LABEL="1977 INTERVIEW NUMBER"                    FORMAT=F4.  
      ER30218       LABEL="SEQUENCE NUMBER                       77" FORMAT=F2.  
      ER30219       LABEL="RELATIONSHIP TO HEAD                  77" FORMAT=F1.  
      ER30220       LABEL="AGE OF INDIVIDUAL                     77" FORMAT=F3.  
      ER30221       LABEL="MARR PAIRS INDICATOR                  77" FORMAT=F1.  
      ER30222       LABEL="WHETHER MOVED IN/OUT                  77" FORMAT=F1.  
      ER30224       LABEL="YEAR MOVED IN/OUT                     77" FORMAT=F4.  
      ER30225       LABEL="STOP SCHOOL?                          77" FORMAT=F1.  
      ER30226       LABEL="HIGHEST GRADE FINISH                  77" FORMAT=F2.  
      ER30227       LABEL="HRS HOUSEWORK/WK                      77" FORMAT=F2.  
      ER30228       LABEL="NEEDS EXTRA CARE?                     77" FORMAT=F1.  
      ER30229       LABEL="RESPONDENT?                           77" FORMAT=F1.  
      ER30230       LABEL="TAXABLE Y SOURCE                      77" FORMAT=F1.  
      ER30231       LABEL="TOTAL TAXABLE Y                       77" FORMAT=F5.  
      ER30233       LABEL="HRS WORKED LAST YR                    77" FORMAT=F4.  
      ER30235       LABEL="HRS UNEMP LAST YR                     77" FORMAT=F4.  
      ER30237       LABEL="TRANSFER Y SOURCE                     77" FORMAT=F2.  
      ER30238       LABEL="TOTAL TRANSFER Y                      77" FORMAT=F5.  
      ER30241       LABEL="YR S/O FAM FORMED                     77" FORMAT=F4.  
      ER30242       LABEL="MAIN FAM ID FOR S/O                   77" FORMAT=F4.  
      ER30243       LABEL="TYPE OF IND RECORD                    77" FORMAT=F2.  
      ER30244       LABEL="WHY NONRESPONSE                       77" FORMAT=F2.  
      ER30245       LABEL="INDIVIDUAL WEIGHT                     77" FORMAT=F4.1 
      ER30246       LABEL="1978 INTERVIEW NUMBER"                    FORMAT=F4.  
      ER30247       LABEL="SEQUENCE NUMBER                       78" FORMAT=F2.  
      ER30248       LABEL="RELATIONSHIP TO HEAD                  78" FORMAT=F1.  
      ER30249       LABEL="AGE OF INDIVIDUAL                     78" FORMAT=F3.  
      ER30250       LABEL="MARR PAIRS INDICATOR                  78" FORMAT=F1.  
      ER30251       LABEL="WHETHER MOVED IN/OUT                  78" FORMAT=F1.  
      ER30253       LABEL="YEAR MOVED IN/OUT                     78" FORMAT=F4.  
      ER30254       LABEL="STOP SCHOOL?                          78" FORMAT=F1.  
      ER30255       LABEL="HIGHEST GRADE FINISH                  78" FORMAT=F2.  
      ER30256       LABEL="HRS HOUSEWORK/WK                      78" FORMAT=F2.  
      ER30257       LABEL="LOOKING FOR WORK?                     78" FORMAT=F1.  
      ER30259       LABEL="WHETHER HEALTH LIMIT                  78" FORMAT=F1.  
      ER30260       LABEL="HOW MUCH LIMIT?                       78" FORMAT=F1.  
      ER30261       LABEL="# YEARS WITH CONDITN                  78" FORMAT=F2.  
      ER30262       LABEL="CONDITN BETTER OR                     78" FORMAT=F1.  
      ER30263       LABEL="NEED EXTRA CARE?                      78" FORMAT=F1.  
      ER30264       LABEL="MEAN EXTRA COSTS?                     78" FORMAT=F1.  
      ER30265       LABEL="ARE COSTS SMALL OR                    78" FORMAT=F1.  
      ER30266       LABEL="RESPONDENT?                           78" FORMAT=F1.  
      ER30267       LABEL="TYPE TAXABLE INCOM                    78" FORMAT=F1.  
      ER30268       LABEL="TOTAL TAXABLE INCOM                   78" FORMAT=F5.  
      ER30270       LABEL="HOURS WORKED IN 77                    78" FORMAT=F4.  
      ER30272       LABEL="TOT HRS UNEMPLYD 77                   78" FORMAT=F4.  
      ER30274       LABEL="TYPE TRANSFR INCOM                    78" FORMAT=F2.  
      ER30275       LABEL="TOTAL TRANSFR INCOM                   78" FORMAT=F5.  
      ER30278       LABEL="YR S/O FAM FORMED                     78" FORMAT=F4.  
      ER30279       LABEL="MAIN FAM ID FOR S/O                   78" FORMAT=F4.  
      ER30280       LABEL="TYPE OF IND RECORD                    78" FORMAT=F2.  
      ER30281       LABEL="WHY NONRESPONSE                       78" FORMAT=F2.  
      ER30282       LABEL="INDIVIDUAL WEIGHT                     78" FORMAT=F4.1 
      ER30283       LABEL="1979 INTERVIEW NUMBER"                    FORMAT=F4.  
      ER30284       LABEL="SEQUENCE NUMBER                       79" FORMAT=F2.  
      ER30285       LABEL="RELATIONSHIP TO HEAD                  79" FORMAT=F1.  
      ER30286       LABEL="AGE OF INDIVIDUAL                     79" FORMAT=F3.  
      ER30287       LABEL="MARR PAIRS INDICATOR                  79" FORMAT=F1.  
      ER30288       LABEL="WHETHER MOVED IN/OUT                  79" FORMAT=F1.  
      ER30290       LABEL="YEAR MOVED IN/OUT                     79" FORMAT=F4.  
      ER30291       LABEL="HRS HSWRK                             79" FORMAT=F2.  
      ER30292       LABEL="RESPONDENT?                           79" FORMAT=F1.  
      ER30293       LABEL="EMPL STATUS                           79" FORMAT=F1.  
      ER30294       LABEL="K4 STUDENT?                           79" FORMAT=F1.  
      ER30295       LABEL="K48 # WKS IN SCHOOL                   79" FORMAT=F2.  
      ER30296       LABEL="K49 EDUCATION                         79" FORMAT=F2.  
      ER30297       LABEL="TYPE TAXABLE INCOME                   79" FORMAT=F1.  
      ER30298       LABEL="TOT TAXABLE INCOME                    79" FORMAT=F5.  
      ER30300       LABEL="TOT HRS WRKD 78                       79" FORMAT=F4.  
      ER30302       LABEL="TOT HRS UNEMP 78                      79" FORMAT=F4.  
      ER30304       LABEL="TYPE TRANSFER INC                     79" FORMAT=F2.  
      ER30305       LABEL="TOT TRANSFER INC                      79" FORMAT=F5.  
      ER30308       LABEL="YR S/O FAM FORMED                     79" FORMAT=F4.  
      ER30309       LABEL="MAIN FAM ID FOR S/O                   79" FORMAT=F4.  
      ER30310       LABEL="TYPE OF IND RECORD                    79" FORMAT=F2.  
      ER30311       LABEL="WHY NONRESPONSE                       79" FORMAT=F2.  
      ER30312       LABEL="INDIVIDUAL WEIGHT                     79" FORMAT=F4.1 
      ER30313       LABEL="1980 INTERVIEW NUMBER"                    FORMAT=F4.  
      ER30314       LABEL="SEQUENCE NUMBER                       80" FORMAT=F2.  
      ER30315       LABEL="RELATIONSHIP TO HEAD                  80" FORMAT=F1.  
      ER30316       LABEL="AGE OF INDIVIDUAL                     80" FORMAT=F3.  
      ER30317       LABEL="MARR PAIRS INDICATOR                  80" FORMAT=F1.  
      ER30318       LABEL="WHETHER MOVED IN/OUT                  80" FORMAT=F1.  
      ER30320       LABEL="YEAR MOVED IN/OUT                     80" FORMAT=F4.  
      ER30321       LABEL="HR/WEEK HOUSEWORK                     80" FORMAT=F2.  
      ER30322       LABEL="RESPONDENT?                           80" FORMAT=F1.  
      ER30323       LABEL="1980 EMPL STATUS                      80" FORMAT=F1.  
      ER30324       LABEL="IND A STUDENT?                        80" FORMAT=F1.  
      ER30325       LABEL="WEEKS IN SCHOOL(K51)?                 80" FORMAT=F2.  
      ER30326       LABEL="EDUCATION ATTAINED                    80" FORMAT=F2.  
      ER30327       LABEL="TYPE TAXABLE Y 1979                   80" FORMAT=F1.  
      ER30328       LABEL="1979 TOT TAXABLE Y                    80" FORMAT=F5.  
      ER30330       LABEL="HOURS WORKED IN 1979                  80" FORMAT=F4.  
      ER30332       LABEL="HOURS UNEMP IN 1979                   80" FORMAT=F4.  
      ER30334       LABEL="TYPE TRANSFER Y 79                    80" FORMAT=F2.  
      ER30335       LABEL="TOTAL TRANSFER Y 79                   80" FORMAT=F5.  
      ER30338       LABEL="YR S/O FAM FORMED                     80" FORMAT=F4.  
      ER30339       LABEL="MAIN FAM ID FOR S/O                   80" FORMAT=F4.  
      ER30340       LABEL="TYPE OF IND RECORD                    80" FORMAT=F2.  
      ER30341       LABEL="WHY NONRESPONSE                       80" FORMAT=F2.  
      ER30342       LABEL="INDIVIDUAL WEIGHT                     80" FORMAT=F4.1 
      ER30343       LABEL="1981 INTERVIEW NUMBER"                    FORMAT=F4.  
      ER30344       LABEL="SEQUENCE NUMBER                       81" FORMAT=F2.  
      ER30345       LABEL="RELATIONSHIP TO HEAD                  81" FORMAT=F1.  
      ER30346       LABEL="AGE OF INDIVIDUAL                     81" FORMAT=F3.  
      ER30347       LABEL="MARR PAIRS INDICATOR                  81" FORMAT=F1.  
      ER30348       LABEL="WHETHER MOVED IN/OUT                  81" FORMAT=F1.  
      ER30350       LABEL="YEAR MOVED IN/OUT                     81" FORMAT=F4.  
      ER30351       LABEL="HR/WEEK ON HOUSEWRK                   81" FORMAT=F2.  
      ER30352       LABEL="RESPONDENT?                           81" FORMAT=F1.  
      ER30353       LABEL="EMPLOYMENT STAT                       81" FORMAT=F1.  
      ER30354       LABEL="WHETHER STUDENT                       81" FORMAT=F1.  
      ER30355       LABEL="# WEEKS IN SCHOOL                     81" FORMAT=F2.  
      ER30356       LABEL="COMPLETED EDUC                        81" FORMAT=F2.  
      ER30357       LABEL="TYPE TXBL INCOME 1980                 81" FORMAT=F1.  
      ER30358       LABEL="TOT TXBL INCOME 80                    81" FORMAT=F5.  
      ER30360       LABEL="ANN WORK HRS 80                       81" FORMAT=F4.  
      ER30362       LABEL="ANN UNEMP HRS 80                      81" FORMAT=F4.  
      ER30364       LABEL="TYPE TRANSFER Y 80                    81" FORMAT=F2.  
      ER30365       LABEL="TOT TRANSFER Y 80                     81" FORMAT=F5.  
      ER30368       LABEL="YEAR S/O FAM FORMED                   81" FORMAT=F4.  
      ER30369       LABEL="MAIN FAM ID FOR S/O                   81" FORMAT=F4.  
      ER30370       LABEL="TYPE OF IND RECORD                    81" FORMAT=F2.  
      ER30371       LABEL="WHY NONRESPONSE                       81" FORMAT=F2.  
      ER30372       LABEL="INDIVIDUAL WEIGHT                     81" FORMAT=F4.1 
      ER30373       LABEL="1982 INTERVIEW NUMBER"                    FORMAT=F4.  
      ER30374       LABEL="SEQUENCE NUMBER                       82" FORMAT=F2.  
      ER30375       LABEL="RELATIONSHIP TO HEAD                  82" FORMAT=F1.  
      ER30376       LABEL="AGE OF INDIVIDUAL                     82" FORMAT=F3.  
      ER30377       LABEL="MARR PAIRS INDICATOR                  82" FORMAT=F1.  
      ER30378       LABEL="WHETHER MOVED IN/OUT                  82" FORMAT=F1.  
      ER30380       LABEL="YEAR MOVED IN/OUT                     82" FORMAT=F4.  
      ER30381       LABEL="RESPONDENT?                           82" FORMAT=F1.  
      ER30382       LABEL="EMPLOYMENT STATUS                     82" FORMAT=F1.  
      ER30383       LABEL="WHETHER STUDENT                       82" FORMAT=F1.  
      ER30384       LABEL="COMPLETED EDUCATION                   82" FORMAT=F2.  
      ER30385       LABEL="TYPE TXBL INCOME 81                   82" FORMAT=F1.  
      ER30386       LABEL="TOT TXBL INCOME 81                    82" FORMAT=F5.  
      ER30388       LABEL="ANN WORK HRS 81                       82" FORMAT=F4.  
      ER30390       LABEL="TYPE TRANSFER Y 81                    82" FORMAT=F2.  
      ER30391       LABEL="TOT TRANSFER Y 81                     82" FORMAT=F5.  
      ER30394       LABEL="YEAR S/O FAM FORMED                   82" FORMAT=F4.  
      ER30395       LABEL="MAIN FAM ID FOR S/O                   82" FORMAT=F4.  
      ER30396       LABEL="TYPE OF IND RECORD                    82" FORMAT=F2.  
      ER30397       LABEL="WHY NONRESPONSE                       82" FORMAT=F2.  
      ER30398       LABEL="INDIVIDUAL WEIGHT                     82" FORMAT=F4.1 
      ER30399       LABEL="1983 INTERVIEW NUMBER"                    FORMAT=F4.  
      ER30400       LABEL="SEQUENCE NUMBER                       83" FORMAT=F2.  
      ER30401       LABEL="RELATIONSHIP TO HEAD                  83" FORMAT=F2.  
      ER30402       LABEL="AGE OF INDIVIDUAL                     83" FORMAT=F3.  
      ER30405       LABEL="MARR PAIRS INDICATOR                  83" FORMAT=F1.  
      ER30406       LABEL="WHETHER MOVED IN/OUT                  83" FORMAT=F1.  
      ER30408       LABEL="YEAR MOVED IN/OUT                     83" FORMAT=F4.  
      ER30409       LABEL="WEEKLY HOUSEWORK                      83" FORMAT=F2.  
      ER30410       LABEL="RESPONDENT?                           83" FORMAT=F1.  
      ER30411       LABEL="EMPLOYMENT STATUS                     83" FORMAT=F1.  
      ER30412       LABEL="WHETHER STUDENT                       83" FORMAT=F1.  
      ER30413       LABEL="COMPLETED EDUCATION                   83" FORMAT=F2.  
      ER30414       LABEL="TYPE TXBL INCOME 82                   83" FORMAT=F1.  
      ER30415       LABEL="TOT TXBL INCOME 82                    83" FORMAT=F6.  
      ER30417       LABEL="ANN WORK HRS 82                       83" FORMAT=F4.  
      ER30419       LABEL="TYPE TRANSFER Y 82                    83" FORMAT=F2.  
      ER30420       LABEL="TOT TRANSFER Y 82                     83" FORMAT=F5.  
      ER30423       LABEL="YEAR S/O FAM FORMED                   83" FORMAT=F4.  
      ER30424       LABEL="MAIN FAM ID FOR S/O                   83" FORMAT=F4.  
      ER30426       LABEL="TYPE OF IND RECORD                    83" FORMAT=F2.  
      ER30427       LABEL="WHY NONRESPONSE                       83" FORMAT=F2.  
      ER30428       LABEL="INDIVIDUAL WEIGHT                     83" FORMAT=F4.1 
      ER30429       LABEL="1984 INTERVIEW NUMBER"                    FORMAT=F4.  
      ER30430       LABEL="SEQUENCE NUMBER                       84" FORMAT=F2.  
      ER30431       LABEL="RELATIONSHIP TO HEAD                  84" FORMAT=F2.  
      ER30432       LABEL="AGE OF INDIVIDUAL                     84" FORMAT=F3.  
      ER30435       LABEL="MARR PAIRS INDICATOR                  84" FORMAT=F1.  
      ER30436       LABEL="WHETHER MOVED IN/OUT                  84" FORMAT=F1.  
      ER30438       LABEL="YEAR MOVED IN/OUT                     84" FORMAT=F4.  
      ER30439       LABEL="WEEKLY HOUSEWORK                      84" FORMAT=F2.  
      ER30440       LABEL="RESPONDENT?                           84" FORMAT=F1.  
      ER30441       LABEL="EMPLOYMENT STAT                       84" FORMAT=F1.  
      ER30442       LABEL="WHETHER STUDENT                       84" FORMAT=F1.  
      ER30443       LABEL="COMPLETED EDUC                        84" FORMAT=F2.  
      ER30444       LABEL="TYPE TXBL INCOME                      84" FORMAT=F1.  
      ER30445       LABEL="TOT TXBL INCOME                       84" FORMAT=F6.  
      ER30447       LABEL="ANN WORK HRS                          84" FORMAT=F4.  
      ER30449       LABEL="TYPE TRANSFER Y                       84" FORMAT=F2.  
      ER30450       LABEL="F33 TYPE SOC SEC RCD                  84" FORMAT=F1.  
      ER30451       LABEL="F34 AMT SOC SEC RCD                   84" FORMAT=F5.  
      ER30453       LABEL="TOT TRANSFER EXC SS                   84" FORMAT=F5.  
      ER30455       LABEL="SUM SS+TRANSFER Y                     84" FORMAT=F5.  
      ER30457       LABEL="YEAR S/O FAM FORMED                   84" FORMAT=F4.  
      ER30458       LABEL="MAIN FAM ID FOR S/O                   84" FORMAT=F4.  
      ER30460       LABEL="TYPE OF IND RECORD                    84" FORMAT=F2.  
      ER30461       LABEL="WHY NONRESPONSE                       84" FORMAT=F2.  
      ER30462       LABEL="INDIVIDUAL WEIGHT                     84" FORMAT=F4.1 
      ER30463       LABEL="1985 INTERVIEW NUMBER"                    FORMAT=F4.  
      ER30464       LABEL="SEQUENCE NUMBER                       85" FORMAT=F2.  
      ER30465       LABEL="RELATIONSHIP TO HEAD                  85" FORMAT=F2.  
      ER30466       LABEL="AGE OF INDIVIDUAL                     85" FORMAT=F3.  
      ER30469       LABEL="MARR PAIRS INDICATOR                  85" FORMAT=F1.  
      ER30470       LABEL="WHETHER MOVED IN/OUT                  85" FORMAT=F1.  
      ER30472       LABEL="YEAR MOVED IN/OUT                     85" FORMAT=F4.  
      ER30473       LABEL="WEEKLY HOUSEWORK                      85" FORMAT=F2.  
      ER30474       LABEL="EMPLOYMENT STAT                       85" FORMAT=F1.  
      ER30476       LABEL="F88 YR LAST IN SCH                    85" FORMAT=F4.  
      ER30477       LABEL="WHETHER STUDENT                       85" FORMAT=F1.  
      ER30478       LABEL="COMPLETED EDUCATION                   85" FORMAT=F2.  
      ER30479       LABEL="TYPE TXBL INCOME                      85" FORMAT=F1.  
      ER30480       LABEL="TOT TXBL INCOME                       85" FORMAT=F6.  
      ER30482       LABEL="ANN WORK HRS                          85" FORMAT=F4.  
      ER30484       LABEL="TYPE TRANSFER Y                       85" FORMAT=F2.  
      ER30485       LABEL="K31 TYPE SOC SEC RCD                  85" FORMAT=F1.  
      ER30486       LABEL="K33 AMT SOC SEC RCD                   85" FORMAT=F5.  
      ER30488       LABEL="TOT TRANSFR EXC SS                    85" FORMAT=F5.  
      ER30490       LABEL="TOTAL TRNSFR INCOME                   85" FORMAT=F5.  
      ER30492       LABEL="YEAR S/O FAM FORMED                   85" FORMAT=F4.  
      ER30493       LABEL="MAIN FAM ID FOR S/O                   85" FORMAT=F4.  
      ER30495       LABEL="TYPE OF IND RECORD                    85" FORMAT=F2.  
      ER30496       LABEL="WHY NONRESPONSE                       85" FORMAT=F2.  
      ER30497       LABEL="INDIVIDUAL WEIGHT                     85" FORMAT=F4.1 
      ER30498       LABEL="1986 INTERVIEW NUMBER"                    FORMAT=F4.  
      ER30499       LABEL="SEQUENCE NUMBER                       86" FORMAT=F2.  
      ER30500       LABEL="RELATIONSHIP TO HEAD                  86" FORMAT=F2.  
      ER30501       LABEL="AGE OF INDIVIDUAL                     86" FORMAT=F3.  
      ER30504       LABEL="MARR PAIRS INDICATOR                  86" FORMAT=F1.  
      ER30505       LABEL="WHETHER MOVED IN/OUT                  86" FORMAT=F1.  
      ER30507       LABEL="YEAR MOVED IN/OUT                     86" FORMAT=F4.  
      ER30508       LABEL="WEEKLY HOUSEWORK                      86" FORMAT=F2.  
      ER30509       LABEL="EMPLOYMENT STAT                       86" FORMAT=F1.  
      ER30511       LABEL="G88 YR LAST IN SCH                    86" FORMAT=F4.  
      ER30512       LABEL="WHETHER STUDENT                       86" FORMAT=F1.  
      ER30513       LABEL="COMPLETED EDUCATION                   86" FORMAT=F2.  
      ER30514       LABEL="TYPE TXBL INCOME                      86" FORMAT=F1.  
      ER30515       LABEL="TOT TXBL INCOME                       86" FORMAT=F6.  
      ER30517       LABEL="ANN WORK HRS                          86" FORMAT=F4.  
      ER30519       LABEL="TYPE TRANSFER Y                       86" FORMAT=F2.  
      ER30520       LABEL="G31 TYPE SOC SEC RCD                  86" FORMAT=F1.  
      ER30521       LABEL="G34 AMT SOC SEC RCD                   86" FORMAT=F5.  
      ER30523       LABEL="TOT TRANSFR EXC SS                    86" FORMAT=F5.  
      ER30525       LABEL="TOTAL TRNSFR INCOME                   86" FORMAT=F5.  
      ER30526       LABEL="H32/35 WTR MEDICAID                   86" FORMAT=F1.  
      ER30527       LABEL="H1/37/69 HLTH STATUS                  86" FORMAT=F1.  
      ER30529       LABEL="YEAR S/O FAM FORMED                   86" FORMAT=F4.  
      ER30530       LABEL="MAIN FAM ID FOR S/O                   86" FORMAT=F4.  
      ER30532       LABEL="TYPE OF IND RECORD                    86" FORMAT=F2.  
      ER30533       LABEL="WHY NONRESPONSE                       86" FORMAT=F2.  
      ER30534       LABEL="INDIVIDUAL WEIGHT                     86" FORMAT=F4.1 
      ER30535       LABEL="1987 INTERVIEW NUMBER"                    FORMAT=F4.  
      ER30536       LABEL="SEQUENCE NUMBER                       87" FORMAT=F2.  
      ER30537       LABEL="RELATIONSHIP TO HEAD                  87" FORMAT=F2.  
      ER30538       LABEL="AGE OF INDIVIDUAL                     87" FORMAT=F3.  
      ER30541       LABEL="MARR PAIRS INDICATOR                  87" FORMAT=F1.  
      ER30542       LABEL="WHETHER MOVED IN/OUT                  87" FORMAT=F1.  
      ER30544       LABEL="YEAR MOVED IN/OUT                     87" FORMAT=F4.  
      ER30545       LABEL="EMPLOYMENT STAT                       87" FORMAT=F1.  
      ER30547       LABEL="G88 YR LAST IN SCH                    87" FORMAT=F4.  
      ER30548       LABEL="WHETHER STUDENT                       87" FORMAT=F1.  
      ER30549       LABEL="COMPLETED EDUCATION                   87" FORMAT=F2.  
      ER30550       LABEL="TYPE TXBL INCOME                      87" FORMAT=F1.  
      ER30551       LABEL="TOT TXBL INCOME                       87" FORMAT=F6.  
      ER30553       LABEL="ANN WORK HRS                          87" FORMAT=F4.  
      ER30555       LABEL="TYPE TRANSFER Y                       87" FORMAT=F2.  
      ER30556       LABEL="G33 TYPE SOC SEC RCD                  87" FORMAT=F1.  
      ER30557       LABEL="G34 AMT SOC SEC RCD                   87" FORMAT=F5.  
      ER30559       LABEL="TOT TRANSFR EXC SS                    87" FORMAT=F5.  
      ER30561       LABEL="TOTAL TRNSFR INCOME                   87" FORMAT=F5.  
      ER30562       LABEL="H11 HD MED COVERAGE?                  87" FORMAT=F1.  
      ER30564       LABEL="YEAR S/O FAM FORMED                   87" FORMAT=F4.  
      ER30565       LABEL="MAIN FAM ID FOR S/O                   87" FORMAT=F4.  
      ER30567       LABEL="TYPE OF IND RECORD                    87" FORMAT=F2.  
      ER30568       LABEL="WHY NONRESPONSE                       87" FORMAT=F2.  
      ER30569       LABEL="INDIVIDUAL WEIGHT                     87" FORMAT=F4.1 
      ER30570       LABEL="1988 INTERVIEW NUMBER"                    FORMAT=F4.  
      ER30571       LABEL="SEQUENCE NUMBER                       88" FORMAT=F2.  
      ER30572       LABEL="RELATION TO HEAD                      88" FORMAT=F2.  
      ER30573       LABEL="AGE OF INDIVIDUAL                     88" FORMAT=F3.  
      ER30576       LABEL="MARITAL INDICATOR-IND                 88" FORMAT=F1.  
      ER30577       LABEL="MOVED IN/OUT                          88" FORMAT=F1.  
      ER30579       LABEL="YEAR MOVED IN/OUT                     88" FORMAT=F4.  
      ER30580       LABEL="EMPLOYMENT STAT-IND                   88" FORMAT=F1.  
      ER30582       LABEL="G88 YR LAST IN SCH-IND                88" FORMAT=F4.  
      ER30583       LABEL="WHETHER STUDENT-IND                   88" FORMAT=F1.  
      ER30584       LABEL="COMPLETED EDUC-IND                    88" FORMAT=F2.  
      ER30585       LABEL="TYPE TXBL INCOME                      88" FORMAT=F1.  
      ER30586       LABEL="TOT TXBL INCOME-IND                   88" FORMAT=F6.  
      ER30588       LABEL="ANN WORK HRS-IND                      88" FORMAT=F4.  
      ER30590       LABEL="TYPE TRANSFER Y-IND                   88" FORMAT=F2.  
      ER30591       LABEL="G31 TYPE SOC SEC RCD                  88" FORMAT=F1.  
      ER30592       LABEL="G34 AMT SOC SEC RCD                   88" FORMAT=F5.  
      ER30594       LABEL="TOT TRNSFR EXC SS-IND                 88" FORMAT=F5.  
      ER30596       LABEL="TOTAL TRNSFR Y-IND                    88" FORMAT=F5.  
      ER30597       LABEL="H5 OFUM MED COVERAGE?                 88" FORMAT=F1.  
      ER30598       LABEL="H13 OFUM HEALTH GOOD                  88" FORMAT=F1.  
      ER30600       LABEL="YEAR S/O FAM FORMED                   88" FORMAT=F4.  
      ER30601       LABEL="MAIN FAM ID FOR S/O                   88" FORMAT=F4.  
      ER30603       LABEL="TYPE OF IND RECORD                    88" FORMAT=F2.  
      ER30604       LABEL="WHY NONRESPONSE                       88" FORMAT=F2.  
      ER30605       LABEL="INDIVIDUAL WEIGHT                     88" FORMAT=F4.1 
      ER30606       LABEL="1989 INTERVIEW NUMBER"                    FORMAT=F4.  
      ER30607       LABEL="SEQUENCE NUMBER                       89" FORMAT=F2.  
      ER30608       LABEL="RELATION TO HEAD                      89" FORMAT=F2.  
      ER30609       LABEL="AGE OF INDIVIDUAL                     89" FORMAT=F3.  
      ER30612       LABEL="MARITAL INDICATOR-IND                 89" FORMAT=F1.  
      ER30613       LABEL="MOVED IN/OUT                          89" FORMAT=F1.  
      ER30615       LABEL="YEAR MOVED IN/OUT                     89" FORMAT=F4.  
      ER30616       LABEL="EMPLOYMENT STAT-IND                   89" FORMAT=F1.  
      ER30618       LABEL="G88 YR LAST IN SCH-IND                89" FORMAT=F4.  
      ER30619       LABEL="WHETHER STUDENT-IND                   89" FORMAT=F1.  
      ER30620       LABEL="COMPLETED EDUC-IND                    89" FORMAT=F2.  
      ER30621       LABEL="TYPE TXBL INCOME                      89" FORMAT=F1.  
      ER30622       LABEL="TOT TXBL INCOME-IND                   89" FORMAT=F6.  
      ER30624       LABEL="ANN WORK HRS-IND                      89" FORMAT=F4.  
      ER30626       LABEL="TYPE TRANSFER Y-IND                   89" FORMAT=F2.  
      ER30627       LABEL="G31 TYPE SOC SEC RCD                  89" FORMAT=F1.  
      ER30628       LABEL="G34 AMT SOC SEC RCD                   89" FORMAT=F5.  
      ER30630       LABEL="TOT TRNSFR EXC SS-IND                 89" FORMAT=F5.  
      ER30632       LABEL="TOTAL TRNSFR Y-IND                    89" FORMAT=F5.  
      ER30633       LABEL="H5 OFUM MED COVERAGE?                 89" FORMAT=F1.  
      ER30634       LABEL="H13 OFUM HEALTH GOOD                  89" FORMAT=F1.  
      ER30636       LABEL="YEAR S/O FAM FORMED                   89" FORMAT=F4.  
      ER30637       LABEL="MAIN FAM ID FOR S/O                   89" FORMAT=F4.  
      ER30639       LABEL="TYPE OF IND RECORD                    89" FORMAT=F2.  
      ER30640       LABEL="WHY NONRESPONSE                       89" FORMAT=F2.  
      ER30641       LABEL="INDIVIDUAL WEIGHT                     89" FORMAT=F4.1 
      ER30642       LABEL="1990 INTERVIEW NUMBER"                    FORMAT=F5.  
      ER30643       LABEL="SEQUENCE NUMBER                       90" FORMAT=F2.  
      ER30644       LABEL="RELATION TO HEAD                      90" FORMAT=F2.  
      ER30645       LABEL="AGE OF INDIVIDUAL                     90" FORMAT=F3.  
      ER30648       LABEL="MARITAL INDICATOR-IND                 90" FORMAT=F1.  
      ER30649       LABEL="MOVED IN/OUT                          90" FORMAT=F1.  
      ER30651       LABEL="YEAR MOVED IN/OUT                     90" FORMAT=F4.  
      ER30653       LABEL="EMPLOYMENT STAT-IND                   90" FORMAT=F1.  
      ER30655       LABEL="G88 YR LAST IN SCH-IND                90" FORMAT=F4.  
      ER30656       LABEL="WHETHER STUDENT-IND                   90" FORMAT=F1.  
      ER30657       LABEL="COMPLETED EDUC-IND                    90" FORMAT=F2.  
      ER30658       LABEL="TYPE TXBL INCOME                      90" FORMAT=F1.  
      ER30659       LABEL="TOT TXBL INCOME-IND                   90" FORMAT=F6.  
      ER30661       LABEL="ANN WORK HRS-IND                      90" FORMAT=F4.  
      ER30663       LABEL="TYPE TRANSFER Y-IND                   90" FORMAT=F2.  
      ER30664       LABEL="G31 TYPE SOC SEC RCD                  90" FORMAT=F1.  
      ER30665       LABEL="G34 AMT SOC SEC RCD                   90" FORMAT=F5.  
      ER30667       LABEL="TOT TRNSFR EXC SS-IND                 90" FORMAT=F5.  
      ER30669       LABEL="TOTAL TRNSFR Y-IND                    90" FORMAT=F5.  
      ER30670       LABEL="H5 OFUM MED COVERAGE?                 90" FORMAT=F1.  
      ER30671       LABEL="H13 OFUM HEALTH GOOD                  90" FORMAT=F1.  
      ER30678       LABEL="YEAR S/O FAM FORMED                   90" FORMAT=F4.  
      ER30679       LABEL="MAIN FAM ID FOR S/O                   90" FORMAT=F5.  
      ER30681       LABEL="FOLLOW STATUS                         90" FORMAT=F1.  
      ER30682       LABEL="RETND SELF ADMIN QNAIRE               90" FORMAT=F1.  
      ER30683       LABEL="MEDICARE PERMISSION                   90" FORMAT=F1.  
      ER30684       LABEL="TYPE OF IND RECORD                    90" FORMAT=F2.  
      ER30685       LABEL="WHY NONRESPONSE                       90" FORMAT=F2.  
      ER30686       LABEL="CORE IND WEIGHT                       90" FORMAT=F7.3 
      ER30687       LABEL="LATINO IND WEIGHT                     90" FORMAT=F5.3 
      ER30688       LABEL="COMBINED IND WEIGHT                   90" FORMAT=F7.3 
      ER30689       LABEL="1991 INTERVIEW NUMBER"                    FORMAT=F4.  
      ER30690       LABEL="SEQUENCE NUMBER                       91" FORMAT=F2.  
      ER30691       LABEL="RELATION TO HEAD                      91" FORMAT=F2.  
      ER30692       LABEL="AGE OF INDIVIDUAL                     91" FORMAT=F3.  
      ER30695       LABEL="MARITAL INDICATOR-IND                 91" FORMAT=F1.  
      ER30696       LABEL="MOVED IN/OUT                          91" FORMAT=F1.  
      ER30698       LABEL="YEAR MOVED IN/OUT                     91" FORMAT=F4.  
      ER30699       LABEL="EMPLOYMENT STAT-IND                   91" FORMAT=F1.  
      ER30701       LABEL="G88 YR LAST IN SCH-IND                91" FORMAT=F4.  
      ER30702       LABEL="WHETHER STUDENT-IND                   91" FORMAT=F1.  
      ER30703       LABEL="COMPLETED EDUC-IND                    91" FORMAT=F2.  
      ER30704       LABEL="TYPE TXBL INCOME                      91" FORMAT=F1.  
      ER30705       LABEL="TOT LABOR INCOME-IND                  91" FORMAT=F6.  
      ER30707       LABEL="TOT ASSET INCOME-IND                  91" FORMAT=F6.  
      ER30708       LABEL="ACC TOT ASSET Y-IND                   91" FORMAT=F1.  
      ER30709       LABEL="ANN WORK HRS-IND                      91" FORMAT=F4.  
      ER30711       LABEL="TYPE TRANSFER Y-IND                   91" FORMAT=F2.  
      ER30712       LABEL="G31 TYPE SOC SEC RCD                  91" FORMAT=F1.  
      ER30713       LABEL="G34 AMT SOC SEC RCD                   91" FORMAT=F5.  
      ER30715       LABEL="TOT TRNSFR EXC SS-IND                 91" FORMAT=F5.  
      ER30717       LABEL="TOTAL TRNSFR Y-IND                    91" FORMAT=F5.  
      ER30718       LABEL="H5 IND MED COVERAGE?                  91" FORMAT=F1.  
      ER30719       LABEL="H13 OFUM HEALTH GOOD                  91" FORMAT=F1.  
      ER30721       LABEL="YEAR S/O FAM FORMED                   91" FORMAT=F4.  
      ER30722       LABEL="MAIN FAM ID FOR S/O                   91" FORMAT=F5.  
      ER30724       LABEL="FOLLOW STATUS                         91" FORMAT=F1.  
      ER30725       LABEL="MEDICARE PERMISSION                   91" FORMAT=F1.  
      ER30727       LABEL="WHETHER HEALTH SUPP RECD              91" FORMAT=F1.  
      ER30728       LABEL="TYPE OF IND RECORD                    91" FORMAT=F2.  
      ER30729       LABEL="WHY NONRESPONSE                       91" FORMAT=F2.  
      ER30730       LABEL="CORE IND WEIGHT                       91" FORMAT=F7.3 
      ER30731       LABEL="LATINO IND WEIGHT                     91" FORMAT=F5.3 
      ER30732       LABEL="COMBINED IND WEIGHT                   91" FORMAT=F7.3 
      ER30733       LABEL="1992 INTERVIEW NUMBER"                    FORMAT=F4.  
      ER30734       LABEL="SEQUENCE NUMBER                       92" FORMAT=F2.  
      ER30735       LABEL="RELATION TO HEAD                      92" FORMAT=F2.  
      ER30736       LABEL="AGE OF INDIVIDUAL                     92" FORMAT=F3.  
      ER30739       LABEL="MARR PAIRS INDICATOR                  92" FORMAT=F1.  
      ER30740       LABEL="MOVED IN/OUT                          92" FORMAT=F1.  
      ER30742       LABEL="YEAR MOVED IN/OUT                     92" FORMAT=F4.  
      ER30744       LABEL="EMPLOYMENT STAT                       92" FORMAT=F1.  
      ER30746       LABEL="G88 YR LAST IN SCH                    92" FORMAT=F4.  
      ER30747       LABEL="WHETHER STUDENT                       92" FORMAT=F1.  
      ER30748       LABEL="COMPLETED EDUCATION                   92" FORMAT=F2.  
      ER30749       LABEL="TYPE TXBL INC BUILT                   92" FORMAT=F1.  
      ER30750       LABEL="TOT LABOR INCOME                      92" FORMAT=F6.  
      ER30752       LABEL="TOT ASSET INCOME                      92" FORMAT=F6.  
      ER30753       LABEL="ACC TOT ASSET INCOME                  92" FORMAT=F1.  
      ER30754       LABEL="ANN WORK HRS                          92" FORMAT=F4.  
      ER30756       LABEL="TYPE TRANSFER Y BUILT                 92" FORMAT=F2.  
      ER30757       LABEL="G33 TYPE SOC SEC RCD                  92" FORMAT=F1.  
      ER30758       LABEL="G34 AMT SOC SEC RCD                   92" FORMAT=F5.  
      ER30760       LABEL="TOT TRANSFR EXC SS                    92" FORMAT=F5.  
      ER30762       LABEL="TOTAL TRNSFR INCOME                   92" FORMAT=F5.  
      ER30763       LABEL="H25 IND MED COVERAGE?                 92" FORMAT=F1.  
      ER30764       LABEL="H53 OFUM HEALTH GOOD                  92" FORMAT=F1.  
      ER30770       LABEL="H6A BATHING                           92" FORMAT=F1.  
      ER30771       LABEL="H6B DRESSING                          92" FORMAT=F1.  
      ER30772       LABEL="H6C EATING                            92" FORMAT=F1.  
      ER30773       LABEL="H6D GET OUT OF BED/CHAIR              92" FORMAT=F1.  
      ER30774       LABEL="H6E WALKING                           92" FORMAT=F1.  
      ER30775       LABEL="H6F GET OUTSIDE                       92" FORMAT=F1.  
      ER30776       LABEL="H6G USE/GET TO TOILET                 92" FORMAT=F1.  
      ER30777       LABEL="H7 CKPT                               92" FORMAT=F1.  
      ER30778       LABEL="H8 GET HELP W ACTIVITIES              92" FORMAT=F1.  
      ER30779       LABEL="H9 PROB PREPARE MEALS                 92" FORMAT=F1.  
      ER30781       LABEL="H11 PROB SHOP PERS ITEM               92" FORMAT=F1.  
      ER30783       LABEL="H13 PROB MANAGE MONEY                 92" FORMAT=F1.  
      ER30785       LABEL="H15 PROB USE PHONE                    92" FORMAT=F1.  
      ER30787       LABEL="H17 PROB HEAVY HOUSEWORK              92" FORMAT=F1.  
      ER30789       LABEL="H19 PROB LIGHT HOUSEWORK              92" FORMAT=F1.  
      ER30791       LABEL="H21 HOME HLTH CARE 1991              92"  FORMAT=F1.  
      ER30793       LABEL="H23 #WKS IN NURSING HOME              92" FORMAT=F2.  
      ER30794       LABEL="H24 IN NURS HOME BEFR 91              92" FORMAT=F1.  
      ER30796       LABEL="YEAR S/O FAM FORMED                   92" FORMAT=F4.  
      ER30797       LABEL="MAIN FAM ID FOR S/O                   92" FORMAT=F5.  
      ER30799       LABEL="FOLLOW STATUS                         92" FORMAT=F1.  
      ER30800       LABEL="MEDICARE PERMISSION                   92" FORMAT=F1.  
      ER30801       LABEL="TYPE OF IND RECORD                    92" FORMAT=F2.  
      ER30802       LABEL="WHY NONRESPONSE                       92" FORMAT=F2.  
      ER30803       LABEL="CORE IND WEIGHT                       92" FORMAT=F7.3 
      ER30804       LABEL="LATINO IND WEIGHT                     92" FORMAT=F5.3 
      ER30805       LABEL="COMBINED IND WEIGHT                   92" FORMAT=F7.3 
      ER30806       LABEL="1993 INTERVIEW NUMBER"                    FORMAT=F5.  
      ER30807       LABEL="SEQUENCE NUMBER                       93" FORMAT=F2.  
      ER30808       LABEL="RELATION TO HEAD                      93" FORMAT=F2.  
      ER30809       LABEL="AGE OF INDIVIDUAL                     93" FORMAT=F3.  
      ER30812       LABEL="MARITAL PAIRS INDICATOR               93" FORMAT=F1.  
      ER30813       LABEL="MOVED IN/OUT                          93" FORMAT=F1.  
      ER30815       LABEL="YEAR MOVED IN/OUT                     93" FORMAT=F4.  
      ER30816       LABEL="EMPLOYMENT STATUS                     93" FORMAT=F1.  
      ER30818       LABEL="G88 YR LAST IN SCHOOL                 93" FORMAT=F4.  
      ER30819       LABEL="WHETHER STUDENT                       93" FORMAT=F1.  
      ER30820       LABEL="YRS COMPLETED EDUCATION               93" FORMAT=F2.  
      ER30821       LABEL="TOTAL LABOR INCOME                    93" FORMAT=F6.  
      ER30822       LABEL="TOTAL ASSET INCOME                    93" FORMAT=F7.  
      ER30823       LABEL="TOTAL ANNUAL WORK HRS                 93" FORMAT=F4.  
      ER30824       LABEL="TYPE TRANSFER INCOME                  93" FORMAT=F2.  
      ER30825       LABEL="TOTAL TRANSFER INCOME                 93" FORMAT=F6.  
      ER30826       LABEL="HAS MEDICAL COVERAGE?                 93" FORMAT=F1.  
      ER30827       LABEL="HEALTH GOOD?                          93" FORMAT=F1.  
      ER30828       LABEL="H6A BATHING                           93" FORMAT=F1.  
      ER30829       LABEL="H6B DRESSING                          93" FORMAT=F1.  
      ER30830       LABEL="H6C EATING                            93" FORMAT=F1.  
      ER30831       LABEL="H6D GET OUT OF BED/CHAIR              93" FORMAT=F1.  
      ER30832       LABEL="H6E WALKING                           93" FORMAT=F1.  
      ER30833       LABEL="H6F GET OUTSIDE                       93" FORMAT=F1.  
      ER30834       LABEL="H6G USE/GET TO TOILET                 93" FORMAT=F1.  
      ER30835       LABEL="H7 CKPT                               93" FORMAT=F1.  
      ER30836       LABEL="H8 GET HELP W ACTIVITIES              93" FORMAT=F1.  
      ER30837       LABEL="H9 PROB PREPARE MEALS                 93" FORMAT=F1.  
      ER30839       LABEL="H11 PROB SHOP PERS ITEM               93" FORMAT=F1.  
      ER30841       LABEL="H13 PROB MANAGE MONEY                 93" FORMAT=F1.  
      ER30843       LABEL="H15 PROB USE PHONE                    93" FORMAT=F1.  
      ER30845       LABEL="H17 PROB HEAVY HOUSEWORK              93" FORMAT=F1.  
      ER30847       LABEL="H19 PROB LIGHT HOUSEWORK              93" FORMAT=F1.  
      ER30849       LABEL="H21 HOME HLTH CARE 1992              93"  FORMAT=F1.  
      ER30851       LABEL="H23 #WKS IN NURSING HOME              93" FORMAT=F2.  
      ER30852       LABEL="H24 IN NURS HOME BEFR 92              93" FORMAT=F1.  
      ER30857       LABEL="YEAR S/O FAM FORMED                   93" FORMAT=F4.  
      ER30858       LABEL="MAIN FAM ID FOR S/O                   93" FORMAT=F5.  
      ER30859       LABEL="FOLLOW STATUS                         93" FORMAT=F1.  
      ER30861       LABEL="MEDICARE PERMISSION                   93" FORMAT=F1.  
      ER30862       LABEL="TYPE OF IND RECORD                    93" FORMAT=F2.  
      ER30863       LABEL="WHY NONRESPONSE                       93" FORMAT=F2.  
      ER33101       LABEL="1994 INTERVIEW NUMBER"                    FORMAT=F5.  
      ER33102       LABEL="SEQUENCE NUMBER                       94" FORMAT=F2.  
      ER33103       LABEL="RELATION TO HEAD                      94" FORMAT=F2.  
      ER33104       LABEL="AGE OF INDIVIDUAL                     94" FORMAT=F3.  
      ER33107       LABEL="MARITAL PAIRS INDICAT                 94" FORMAT=F1.  
      ER33108       LABEL="MOVED IN/OUT                          94" FORMAT=F1.  
      ER33110       LABEL="YEAR MOVED IN/OUT                     94" FORMAT=F4.  
      ER33111       LABEL="EMPLOYMENT STATUS                     94" FORMAT=F1.  
      ER33113       LABEL="G88 YR LAST IN SCHOOL                 94" FORMAT=F4.  
      ER33114       LABEL="WHETHER STUDENT                       94" FORMAT=F1.  
      ER33115       LABEL="YRS COMPLETED EDUC                    94" FORMAT=F2.  
      ER33116       LABEL="HAS MEDICAL COVERAGE?                 94" FORMAT=F1.  
      ER33117       LABEL="HEALTH GOOD?                          94" FORMAT=F1.  
      ER33118       LABEL="MEDICARE PERMISSION                   94" FORMAT=F1.  
      ER33123       LABEL="YEAR S/O FAM FORMED                   94" FORMAT=F4.  
      ER33124       LABEL="MAIN FAM ID FOR S/O                   94" FORMAT=F5.  
      ER33125       LABEL="FOLLOW STATUS                         94" FORMAT=F1.  
      ER33126       LABEL="TYPE OF IND RECORD                    94" FORMAT=F2.  
      ER33127       LABEL="WHY NONRESPONSE                       94" FORMAT=F2.  
      ER33128       LABEL="H1 HEALTH STATUS                      94" FORMAT=F1.  
      ER33129       LABEL="H6A BATHING                           94" FORMAT=F1.  
      ER33130       LABEL="H6B DRESSING                          94" FORMAT=F1.  
      ER33131       LABEL="H6C EATING                            94" FORMAT=F1.  
      ER33132       LABEL="H6D GET OUT OF BED/CHAIR              94" FORMAT=F1.  
      ER33133       LABEL="H6E WALKING                           94" FORMAT=F1.  
      ER33134       LABEL="H6F GET OUTSIDE                       94" FORMAT=F1.  
      ER33135       LABEL="H6G USE/GET TO TOILET                 94" FORMAT=F1.  
      ER33136       LABEL="H7 CKPT                               94" FORMAT=F1.  
      ER33137       LABEL="H8 GET HELP W ACTIVITIES              94" FORMAT=F1.  
      ER33138       LABEL="H9 PROB PREPARE MEALS                 94" FORMAT=F1.  
      ER33140       LABEL="H11 PROB SHOP PERS ITEM               94" FORMAT=F1.  
      ER33142       LABEL="H13 PROB MANAGE MONEY                 94" FORMAT=F1.  
      ER33144       LABEL="H15 PROB USE PHONE                    94" FORMAT=F1.  
      ER33146       LABEL="H17 PROB HEAVY HOUSEWORK              94" FORMAT=F1.  
      ER33148       LABEL="H19 PROB LIGHT HOUSEWORK              94" FORMAT=F1.  
      ER33201       LABEL="1995 INTERVIEW NUMBER"                    FORMAT=F5.  
      ER33202       LABEL="SEQUENCE NUMBER                       95" FORMAT=F2.  
      ER33203       LABEL="RELATION TO HEAD                      95" FORMAT=F2.  
      ER33204       LABEL="AGE OF INDIVIDUAL                     95" FORMAT=F3.  
      ER33207       LABEL="MARITAL PAIRS INDICATOR               95" FORMAT=F1.  
      ER33208       LABEL="WHETHER MOVED IN/OUT                  95" FORMAT=F1.  
      ER33210       LABEL="YEAR MOVED IN/OUT                     95" FORMAT=F4.  
      ER33211       LABEL="EMPLOYMENT STATUS                     95" FORMAT=F1.  
      ER33213       LABEL="YEAR LAST IN SCHOOL                   95" FORMAT=F4.  
      ER33214       LABEL="WHETHER STUDENT                       95" FORMAT=F1.  
      ER33215       LABEL="YEARS COMPLETED EDUCATION             95" FORMAT=F2.  
      ER33216       LABEL="HAS MEDICAL COVERAGE?                 95" FORMAT=F1.  
      ER33217       LABEL="HEALTH GOOD?                          95" FORMAT=F1.  
      ER33218       LABEL="MEDICARE PERMISSION                   95" FORMAT=F1.  
      ER33220       LABEL="M3 CURRENTLY ATTENDING SCHOOL         95" FORMAT=F1.  
      ER33221       LABEL="M5 FULL-TIME OR PART-TIME STUDENT     95" FORMAT=F1.  
      ER33225       LABEL="M7 YEAR LAST ATTENDED SCHOOL          95" FORMAT=F4.  
      ER33226       LABEL="M9 LAST ENROLLED FULL OR PART TIME    95" FORMAT=F1.  
      ER33230       LABEL="M14 EVER ATTEND PRIVATE SCHOOL K-12   95" FORMAT=F1.  
      ER33245       LABEL="M17 ATTENDED SPEC CLASS/SCHL GIFTED   95" FORMAT=F1.  
      ER33246       LABEL="M18 REPEAT GRADE/SCHOOL RECOMMENDED   95" FORMAT=F1.  
      ER33247       LABEL="M19 WHICH GRADE REPEATED 1            95" FORMAT=F2.  
      ER33259       LABEL="M20 EVER CLASSIFIED NEED SPECIAL ED   95" FORMAT=F1.  
      ER33260       LABEL="M21 LEARN DISAB PERCEPT/SPEECH IMPAIR 95" FORMAT=F1.  
      ER33261       LABEL="M22 EVER ENROLLED IN HEAD START       95" FORMAT=F1.  
      ER33264       LABEL="M25 OTHER NURSERY PRESCHOOL DAY CARE  95" FORMAT=F1.  
      ER33265       LABEL="M26 SUSPENDED OR EXPELLED FROM SCHOOL 95" FORMAT=F1.  
      ER33266       LABEL="M27 EVER BOOKED/CHARGED BREAKING LAW  95" FORMAT=F1.  
      ER33267       LABEL="M28 SPENT TIME IN CORRECTIONS INST    95" FORMAT=F1.  
      ER33268       LABEL="M29 TIMES SENT TO YOUTH CORRECT INST  95" FORMAT=F2.  
      ER33269       LABEL="M30 TIMES SENT TO ADULT CORRECT INST  95" FORMAT=F2.  
      ER33271       LABEL="M31 YEAR LAST RELEASED                95" FORMAT=F4.  
      ER33272       LABEL="M33 TIMES FAM ASKED TALK SCHOOL BEHAV 95" FORMAT=F1.  
      ER33273       LABEL="M34 PARTICIPATE EXTRACURRICULAR ACT   95" FORMAT=F1.  
      ER33274       LABEL="M34A HOW OFTEN PARTIC EXTRACUR ACT    95" FORMAT=F1.  
      ER33279       LABEL="YEAR S/O FAM FORMED                   95" FORMAT=F4.  
      ER33280       LABEL="MAIN FAM ID FOR S/O                   95" FORMAT=F5.  
      ER33281       LABEL="FOLLOW STATUS                         95" FORMAT=F1.  
      ER33282       LABEL="TYPE OF IND RECORD                    95" FORMAT=F2.  
      ER33283       LABEL="WHY NONRESPONSE                       95" FORMAT=F2.  
      ER33284       LABEL="H1 HEALTH STATUS                      95" FORMAT=F1.  
      ER33285       LABEL="H6A BATHING                           95" FORMAT=F1.  
      ER33286       LABEL="H6B DRESSING                          95" FORMAT=F1.  
      ER33287       LABEL="H6C EATING                            95" FORMAT=F1.  
      ER33288       LABEL="H6D GET OUT OF BED/CHAIR              95" FORMAT=F1.  
      ER33289       LABEL="H6E WALKING                           95" FORMAT=F1.  
      ER33290       LABEL="H6F GET OUTSIDE                       95" FORMAT=F1.  
      ER33291       LABEL="H6G USE/GET TO TOILET                 95" FORMAT=F1.  
      ER33292       LABEL="H7 CKPT                               95" FORMAT=F1.  
      ER33293       LABEL="H8 GET HELP W ACTIVITIES              95" FORMAT=F1.  
      ER33294       LABEL="H9 PROB PREPARE MEALS                 95" FORMAT=F1.  
      ER33295       LABEL="H11 PROB SHOP PERS ITEM               95" FORMAT=F1.  
      ER33296       LABEL="H13 PROB MANAGE MONEY                 95" FORMAT=F1.  
      ER33297       LABEL="H15 PROB USE PHONE                    95" FORMAT=F1.  
      ER33298       LABEL="H17 PROB HEAVY HOUSEWORK              95" FORMAT=F1.  
      ER33299       LABEL="H19 PROB LIGHT HOUSEWORK              95" FORMAT=F1.  
      ER33301       LABEL="1996 INTERVIEW NUMBER"                    FORMAT=F4.  
      ER33302       LABEL="SEQUENCE NUMBER                       96" FORMAT=F2.  
      ER33303       LABEL="RELATION TO HEAD                      96" FORMAT=F2.  
      ER33304       LABEL="AGE OF INDIVIDUAL                     96" FORMAT=F3.  
      ER33307       LABEL="MARITAL PAIRS INDICATOR               96" FORMAT=F1.  
      ER33308       LABEL="WHETHER MOVED IN/OUT                  96" FORMAT=F1.  
      ER33310       LABEL="YEAR MOVED IN/OUT                     96" FORMAT=F4.  
      ER33311       LABEL="EMPLOYMENT STATUS                     96" FORMAT=F1.  
      ER33313       LABEL="YEAR LAST IN SCHOOL                   96" FORMAT=F4.  
      ER33314       LABEL="WHETHER STUDENT                       96" FORMAT=F1.  
      ER33315       LABEL="YEARS COMPLETED EDUCATION             96" FORMAT=F2.  
      ER33316       LABEL="HAS MEDICAL COVERAGE?                 96" FORMAT=F1.  
      ER33317       LABEL="HEALTH GOOD?                          96" FORMAT=F1.  
      ER33320       LABEL="YEAR S/O FAM FORMED                   96" FORMAT=F4.  
      ER33321       LABEL="MAIN FAM ID FOR S/O                   96" FORMAT=F5.  
      ER33322       LABEL="FOLLOW STATUS                         96" FORMAT=F1.  
      ER33324       LABEL="TYPE OF IND RECORD                    96" FORMAT=F2.  
      ER33325       LABEL="WHY NONRESPONSE                       96" FORMAT=F2.  
      ER33326       LABEL="H1 HEALTH STATUS                      96" FORMAT=F1.  
      ER33327       LABEL="H6A BATHING                           96" FORMAT=F1.  
      ER33328       LABEL="H6B DRESSING                          96" FORMAT=F1.  
      ER33329       LABEL="H6C EATING                            96" FORMAT=F1.  
      ER33330       LABEL="H6D GET OUT OF BED/CHAIR              96" FORMAT=F1.  
      ER33331       LABEL="H6E WALKING                           96" FORMAT=F1.  
      ER33332       LABEL="H6F GET OUTSIDE                       96" FORMAT=F1.  
      ER33333       LABEL="H6G USE/GET TO TOILET                 96" FORMAT=F1.  
      ER33334       LABEL="H7 CKPT                               96" FORMAT=F1.  
      ER33335       LABEL="H8 GET HELP W ACTIVITIES              96" FORMAT=F1.  
      ER33336       LABEL="H9 PROB PREPARE MEALS                 96" FORMAT=F1.  
      ER33338       LABEL="H11 PROB SHOP PERS ITEM               96" FORMAT=F1.  
      ER33340       LABEL="H13 PROB MANAGE MONEY                 96" FORMAT=F1.  
      ER33342       LABEL="H15 PROB USE PHONE                    96" FORMAT=F1.  
      ER33344       LABEL="H17 PROB HEAVY HOUSEWORK              96" FORMAT=F1.  
      ER33346       LABEL="H19 PROB LIGHT HOUSEWORK              96" FORMAT=F1.  
      ER33401       LABEL="1997 INTERVIEW NUMBER"                    FORMAT=F5.  
      ER33402       LABEL="SEQUENCE NUMBER                       97" FORMAT=F2.  
      ER33403       LABEL="RELATION TO HEAD                      97" FORMAT=F2.  
      ER33404       LABEL="AGE OF INDIVIDUAL                     97" FORMAT=F3.  
      ER33407       LABEL="MARITAL PAIRS INDICATOR               97" FORMAT=F1.  
      ER33408       LABEL="WHETHER MOVED IN/OUT                  97" FORMAT=F1.  
      ER33410       LABEL="YEAR MOVED IN/OUT                     97" FORMAT=F4.  
      ER33411       LABEL="EMPLOYMENT STATUS                     97" FORMAT=F1.  
      ER33413       LABEL="YEAR LAST IN SCHOOL                   97" FORMAT=F4.  
      ER33414       LABEL="WHETHER STUDENT                       97" FORMAT=F1.  
      ER33415       LABEL="YEARS COMPLETED EDUCATION             97" FORMAT=F2.  
      ER33416       LABEL="HAS MEDICAL COVERAGE?                 97" FORMAT=F1.  
      ER33417       LABEL="HEALTH GOOD?                          97" FORMAT=F1.  
      ER33418       LABEL="WHETHER ELIGIBLE FOR CDS              97" FORMAT=F1.  
      ER33419       LABEL="WHETHER SELECTED FOR CDS              97" FORMAT=F1.  
      ER33420       LABEL="RESULT OF CDS INTERVIEW               97" FORMAT=F2.  
      ER33430       LABEL="CORE/IMM INDIVIDUAL LONGITUDINAL WT   97" FORMAT=F7.3 
      ER33432       LABEL="YEAR S/O FAM FORMED                   97" FORMAT=F4.  
      ER33433       LABEL="MAIN FAM ID FOR S/O                   97" FORMAT=F5.  
      ER33434       LABEL="FOLLOW STATUS                         97" FORMAT=F1.  
      ER33436       LABEL="TYPE OF IND RECORD                    97" FORMAT=F2.  
      ER33437       LABEL="WHY NONRESPONSE                       97" FORMAT=F2.  
      ER33438       LABEL="CORE/IMM INDIVIDUAL CROSS-SECTION WT  97" FORMAT=F6.  
      ER33501       LABEL="1999 INTERVIEW NUMBER"                    FORMAT=F5.  
      ER33502       LABEL="SEQUENCE NUMBER                       99" FORMAT=F2.  
      ER33503       LABEL="RELATION TO HEAD                      99" FORMAT=F2.  
      ER33504       LABEL="AGE OF INDIVIDUAL                     99" FORMAT=F3.  
      ER33507       LABEL="MARITAL PAIRS INDICATOR               99" FORMAT=F1.  
      ER33508       LABEL="WHETHER MOVED IN/OUT                  99" FORMAT=F1.  
      ER33510       LABEL="YEAR MOVED IN/OUT                     99" FORMAT=F4.  
      ER33511       LABEL="RESPONDENT?                           99" FORMAT=F1.  
      ER33512       LABEL="EMPLOYMENT STATUS                     99" FORMAT=F1.  
      ER33514       LABEL="YEAR LAST IN SCHOOL                   99" FORMAT=F4.  
      ER33515       LABEL="WHETHER STUDENT                       99" FORMAT=F1.  
      ER33516       LABEL="YEARS COMPLETED EDUCATION             99" FORMAT=F2.  
      ER33517       LABEL="HEALTH GOOD?                          99" FORMAT=F1.  
      ER33518       LABEL="H61 TYPE HEALTH INSURANCE MENTION 1   99" FORMAT=F2.  
      ER33519       LABEL="H61 TYPE HEALTH INSURANCE MENTION 2   99" FORMAT=F2.  
      ER33520       LABEL="H61 TYPE HEALTH INSURANCE MENTION 3   99" FORMAT=F2.  
      ER33521       LABEL="H61 TYPE HEALTH INSURANCE MENTION 4   99" FORMAT=F2.  
      ER33522       LABEL="H62 MOS COVERED BY INSURANCE IN 97    99" FORMAT=F2.  
      ER33523       LABEL="H62A MOS COVERED BY INSURANCE IN 98   99" FORMAT=F2.  
      ER33532A      LABEL="R2 WTR RECEIVED PUB ASSTNCE IN 1997   99" FORMAT=F1.  
      ER33532B      LABEL="R3 STATE WHERE RECD PUB ASSTNCE 1997  99" FORMAT=F2.  
      ER33532C      LABEL="R4 WTR RECD TANF IN 1997              99" FORMAT=F1.  
      ER33532D      LABEL="R4 WTR RECD ADC IN 1997               99" FORMAT=F1.  
      ER33532E      LABEL="R4 WTR RECD GENERAL ASSISTANCE 1997   99" FORMAT=F1.  
      ER33532F      LABEL="R4 WTR RECD EMERGENCY ASSISTANCE 1997 99" FORMAT=F1.  
      ER33532G      LABEL="R4 WTR RECD CUBAN/HAITIAN REF 1997    99" FORMAT=F1.  
      ER33532H      LABEL="R4 WTR RECD INDIAN ASSISTANCE IN 1997 99" FORMAT=F1.  
      ER33532I      LABEL="R4 WTR RECD OTHER ASSISTANCE IN 1997  99" FORMAT=F1.  
      ER33532J      LABEL="R5 REPRTD PUB ASSISTNCE AMT-YRLY 1997 99" FORMAT=F5.  
      ER33532K      LABEL="R5 REPRTD PUB ASSISTNCE AMT-MLY 1997  99" FORMAT=F4.  
      ER33532X      LABEL="R6 TOTAL MOS RECD PUB ASSISTANCE 1997 99" FORMAT=F2.  
      ER33532Y      LABEL="ANNUALIZED PUBLIC ASSISTANCE AMT 1997 99" FORMAT=F5.  
      ER33533       LABEL="R8 WTR RECEIVED SSI IN 1997           99" FORMAT=F1.  
      ER33534       LABEL="R12 WTR RECEIVED CHILD SUPPORT IN 97  99" FORMAT=F1.  
      ER33535       LABEL="R16 WTR RECEIVED HELP FROM RELS IN 97 99" FORMAT=F1.  
      ER33536       LABEL="R20 WTR RECEIVED OTHER HELP IN 1997   99" FORMAT=F1.  
      ER33536A      LABEL="R26/R33/R41 REP EARNINGS ANT IN 1997  99" FORMAT=F10.2
      ER33536B      LABEL="R26/R33/R41 REP EARNINGS UNIT 1997    99" FORMAT=F1.  
      ER33536C      LABEL="R27/R34/R42 WEEKS WORKED IN 1997      99" FORMAT=F2.  
      ER33536P      LABEL="R28/R35/R43 TOT MOS RECD ERNGS 1997   99" FORMAT=F2.  
      ER33536Q      LABEL="R29/R36/R44 HRS PER WK WORKED 1997    99" FORMAT=F3.  
      ER33537       LABEL="R48A WTR STOPPED WELFARE IN 1997      99" FORMAT=F1.  
      ER33537M      LABEL="R30/R37/R45 TOTAL MOS UNEMPLOYED 1997 99" FORMAT=F2.  
      ER33537N      LABEL="TOTAL ANNUAL EARNINGS IN 1997         99" FORMAT=F7.  
      ER33537O      LABEL="CALCULATED HOURLY WAGE RATE IN 1997   99" FORMAT=F6.2 
      ER33538       LABEL="R58A WTR STOPPED FOOD STAMPS IN 1997  99" FORMAT=F1.  
      ER33540       LABEL="YEAR S/O FAM FORMED                   99" FORMAT=F4.  
      ER33541       LABEL="MAIN FAM ID FOR S/O                   99" FORMAT=F5.  
      ER33542       LABEL="FOLLOW STATUS                         99" FORMAT=F1.  
      ER33544       LABEL="TYPE OF IND RECORD                    99" FORMAT=F2.  
      ER33545       LABEL="WHY NONRESPONSE                       99" FORMAT=F2.  
      ER33546       LABEL="CORE/IMM INDIVIDUAL LONGITUDINAL WT   99" FORMAT=F7.3 
      ER33547       LABEL="CORE/IMM INDIVIDUAL CROSS-SECTION WT  99" FORMAT=F5.  
      ER33601       LABEL="2001 INTERVIEW NUMBER"                    FORMAT=F4.  
      ER33602       LABEL="SEQUENCE NUMBER                       01" FORMAT=F2.  
      ER33603       LABEL="RELATION TO HEAD                      01" FORMAT=F2.  
      ER33604       LABEL="AGE OF INDIVIDUAL                     01" FORMAT=F3.  
      ER33607       LABEL="MARITAL PAIRS INDICATOR               01" FORMAT=F1.  
      ER33608       LABEL="WHETHER MOVED IN/OUT                  01" FORMAT=F1.  
      ER33610       LABEL="YEAR MOVED IN/OUT                     01" FORMAT=F4.  
      ER33611       LABEL="RESPONDENT?                           01" FORMAT=F1.  
      ER33612       LABEL="EMPLOYMENT STATUS                     01" FORMAT=F1.  
      ER33614       LABEL="YEAR LAST IN SCHOOL                   01" FORMAT=F4.  
      ER33615       LABEL="WHETHER STUDENT                       01" FORMAT=F1.  
      ER33616       LABEL="YEARS COMPLETED EDUCATION             01" FORMAT=F2.  
      ER33617       LABEL="HEALTH GOOD?                          01" FORMAT=F1.  
      ER33618       LABEL="H61 TYPE HEALTH INSURANCE MENTION 1   01" FORMAT=F2.  
      ER33619       LABEL="H61 TYPE HEALTH INSURANCE MENTION 2   01" FORMAT=F2.  
      ER33620       LABEL="H61 TYPE HEALTH INSURANCE MENTION 3   01" FORMAT=F2.  
      ER33621       LABEL="H61 TYPE HEALTH INSURANCE MENTION 4   01" FORMAT=F2.  
      ER33622       LABEL="H62 MOS COVERED BY INSURANCE IN 99    01" FORMAT=F2.  
      ER33623       LABEL="H62A MOS COVERED BY INSURANCE IN 00   01" FORMAT=F2.  
      ER33623A      LABEL="R2 WTR RECEIVED PUB ASSTNCE IN 1999   01" FORMAT=F1.  
      ER33623B      LABEL="R3 STATE WHERE RECD PUB ASSTNCE 1999  01" FORMAT=F2.  
      ER33623C      LABEL="R4 WTR RECD TANF IN 1999              01" FORMAT=F1.  
      ER33623D      LABEL="R4 WTR RECD ADC IN 1999               01" FORMAT=F1.  
      ER33623E      LABEL="R4 WTR RECD GENERAL ASSISTANCE 1999   01" FORMAT=F1.  
      ER33623F      LABEL="R4 WTR RECD EMERGENCY ASSISTANCE 1999 01" FORMAT=F1.  
      ER33623G      LABEL="R4 WTR RECD CUBAN/HAITIAN REF 1999    01" FORMAT=F1.  
      ER33623H      LABEL="R4 WTR RECD INDIAN ASSISTANCE IN 1999 01" FORMAT=F1.  
      ER33623I      LABEL="R4 WTR RECD OTHER ASSISTANCE IN 1999  01" FORMAT=F1.  
      ER33623J      LABEL="R5 REPRTD PUB ASSISTNCE AMT-YRLY 1999 01" FORMAT=F5.  
      ER33623K      LABEL="R5 REPRTD PUB ASSISTNCE AMT-MLY 1999  01" FORMAT=F3.  
      ER33623X      LABEL="R6 TOTAL MOS RECD PUB ASSISTANCE 1999 01" FORMAT=F2.  
      ER33623Y      LABEL="ANNUALIZED PUBLIC ASSISTANCE AMT 1999 01" FORMAT=F5.  
      ER33624       LABEL="R8 WTR RECEIVED SSI IN 1999           01" FORMAT=F1.  
      ER33625       LABEL="R12 WTR RECEIVED CHILD SUPPORT IN 99  01" FORMAT=F1.  
      ER33626       LABEL="R16 WTR RECEIVED HELP FROM RELS IN 99 01" FORMAT=F1.  
      ER33627       LABEL="R20 WTR RECEIVED OTHER HELP IN 1999   01" FORMAT=F1.  
      ER33627A      LABEL="R26/R33/R41 REP EARNINGS AMT IN 1999  01" FORMAT=F10.2
      ER33627B      LABEL="R26/R33/R41 REP EARNINGS UNIT 1999    01" FORMAT=F1.  
      ER33627C      LABEL="R27/R34/R42 WEEKS WORKED IN 1999      01" FORMAT=F2.  
      ER33627P      LABEL="R28/R35/R43 TOT MOS RECD ERNGS 1999   01" FORMAT=F2.  
      ER33627Q      LABEL="R29/R36/R44 HRS PER WK WORKED 1999    01" FORMAT=F3.  
      ER33628       LABEL="R48A WTR STOPPED WELFARE IN 1999      01" FORMAT=F1.  
      ER33628M      LABEL="R30/R37/R45 TOTAL MOS UNEMPLOYED 1999 01" FORMAT=F2.  
      ER33628N      LABEL="TOTAL ANNUAL EARNINGS IN 1999         01" FORMAT=F7.  
      ER33628O      LABEL="CALCULATED HOURLY WAGE RATE IN 1999   01" FORMAT=F6.2 
      ER33629       LABEL="R58A WTR STOPPED FOOD STAMPS IN 1999  01" FORMAT=F1.  
      ER33631       LABEL="YEAR S/O FAM FORMED                   01" FORMAT=F4.  
      ER33632       LABEL="MAIN FAM ID FOR S/O                   01" FORMAT=F5.  
      ER33633       LABEL="FOLLOW STATUS                         01" FORMAT=F1.  
      ER33635       LABEL="TYPE OF IND RECORD                    01" FORMAT=F2.  
      ER33636       LABEL="WHY NONRESPONSE                       01" FORMAT=F2.  
      ER33637       LABEL="CORE/IMM INDIVIDUAL LONGITUDINAL WT   01" FORMAT=F7.3 
      ER33638       LABEL="RESULT OF CDS INTERVIEW               01" FORMAT=F2.  
      ER33639       LABEL="CORE/IMM INDIVIDUAL CROSS-SECTION WT  01" FORMAT=F5.  
      ER33701       LABEL="2003 INTERVIEW NUMBER"                    FORMAT=F5.  
      ER33702       LABEL="SEQUENCE NUMBER                       03" FORMAT=F2.  
      ER33703       LABEL="RELATION TO HEAD                      03" FORMAT=F2.  
      ER33704       LABEL="AGE OF INDIVIDUAL                     03" FORMAT=F3.  
      ER33707       LABEL="MARITAL PAIRS INDICATOR               03" FORMAT=F1.  
      ER33708       LABEL="WHETHER MOVED IN/OUT                  03" FORMAT=F1.  
      ER33710       LABEL="YEAR MOVED IN/OUT                     03" FORMAT=F4.  
      ER33711       LABEL="RESPONDENT?                           03" FORMAT=F1.  
      ER33712       LABEL="EMPLOYMENT STATUS                     03" FORMAT=F1.  
      ER33714       LABEL="YEAR LAST IN SCHOOL                   03" FORMAT=F4.  
      ER33715       LABEL="WHETHER STUDENT                       03" FORMAT=F1.  
      ER33716       LABEL="YEARS COMPLETED EDUCATION             03" FORMAT=F2.  
      ER33717       LABEL="HEALTH GOOD?                          03" FORMAT=F1.  
      ER33718       LABEL="H61 TYPE HEALTH INSURANCE MENTION 1   03" FORMAT=F2.  
      ER33719       LABEL="H61 TYPE HEALTH INSURANCE MENTION 2   03" FORMAT=F2.  
      ER33720       LABEL="H61 TYPE HEALTH INSURANCE MENTION 3   03" FORMAT=F2.  
      ER33721       LABEL="H61 TYPE HEALTH INSURANCE MENTION 4   03" FORMAT=F2.  
      ER33722       LABEL="H62 MOS COVERED BY INSURANCE IN 01    03" FORMAT=F2.  
      ER33723       LABEL="H62A MOS COVERED BY INSURANCE IN 02   03" FORMAT=F2.  
      ER33724       LABEL="R2 WTR RECEIVED TANF IN 2001          03" FORMAT=F1.  
      ER33724A      LABEL="R3 STATE WHERE RECD PUB ASSTNCE 2001  03" FORMAT=F2.  
      ER33724B      LABEL="R4 WTR RECD TANF IN 2001              03" FORMAT=F1.  
      ER33724C      LABEL="R4 WTR RECD ADC IN 2001               03" FORMAT=F1.  
      ER33724D      LABEL="R4 WTR RECD GEN ASSISTANCE IN 2001    03" FORMAT=F1.  
      ER33724E      LABEL="R4 WTR RECD EMERG ASSISTANCE IN 2001  03" FORMAT=F1.  
      ER33724F      LABEL="R4 WTR RECD CUBAN/HAITIAN REF 2001    03" FORMAT=F1.  
      ER33724G      LABEL="R4 WTR RECD INDIAN ASSIST IN 2001     03" FORMAT=F1.  
      ER33724H      LABEL="R4 WTR RECD OTHER ASSISTANCE IN 2001  03" FORMAT=F1.  
      ER33724I      LABEL="R8 WTR RECEIVED SSI IN 2001           03" FORMAT=F1.  
      ER33725       LABEL="R12 WTR RECEIVED CHILD SUPPORT IN 01  03" FORMAT=F1.  
      ER33726       LABEL="R16 WTR RECEIVED HELP FROM RELS IN 01 03" FORMAT=F1.  
      ER33727       LABEL="R20 WTR RECEIVED OTHER HELP IN 2001   03" FORMAT=F1.  
      ER33727A      LABEL="R26/R41 REPORTED ERNINGS AMOUNT IN 01 03" FORMAT=F8.  
      ER33727B      LABEL="R26/R41 REPORTED ERNINGS TIME UNIT 01 03" FORMAT=F1.  
      ER33727C      LABEL="R42 WEEKS WORKED IN 2001              03" FORMAT=F2.  
      ER33727P      LABEL="R43 TOTAL MOS RECD EARNINGS IN 2001   03" FORMAT=F2.  
      ER33727Q      LABEL="R44 HOURS PER WEEK WORKED IN 2001     03" FORMAT=F3.  
      ER33728       LABEL="R48A WTR STOP PUB ASSTNCE SINCE 2001  03" FORMAT=F1.  
      ER33728M      LABEL="R45 TOTAL MOS UNEMPLOYED IN 2001      03" FORMAT=F2.  
      ER33728N      LABEL="TOTAL ANNUAL EARNINGS IN 2001         03" FORMAT=F7.  
      ER33728O      LABEL="CALCULATED HOURLY WAGE RATE IN 2001   03" FORMAT=F6.2 
      ER33729       LABEL="R58A WTR STOPPED FOOD STAMPS IN 2001  03" FORMAT=F1.  
      ER33730       LABEL="R78A WTR REC MEAL FOR ELDERLY IN 2002 03" FORMAT=F1.  
      ER33731       LABEL="R80A WTR REC SCHOOL LUNCH IN 2002     03" FORMAT=F1.  
      ER33732       LABEL="R81A WTR REC SCHOOL BREAKFAST IN 2002 03" FORMAT=F1.  
      ER33734       LABEL="YEAR S/O FAM FORMED                   03" FORMAT=F4.  
      ER33735       LABEL="MAIN FAM ID FOR S/O                   03" FORMAT=F5.  
      ER33736       LABEL="FOLLOW STATUS                         03" FORMAT=F1.  
      ER33738       LABEL="TYPE OF IND RECORD                    03" FORMAT=F2.  
      ER33739       LABEL="WHY NONRESPONSE                       03" FORMAT=F2.  
      ER33740       LABEL="CORE/IMM INDIVIDUAL LONGITUDINAL WT   03" FORMAT=F7.3 
      ER33741       LABEL="M13D WTR DECIDER FOR CHARITABLE GIVNG 03" FORMAT=F1.  
      ER33742       LABEL="CORE/IMM INDIVIDUAL CROSS-SECTION WT  03" FORMAT=F5.  
      ER33801       LABEL="2005 INTERVIEW NUMBER"                    FORMAT=F5.  
      ER33802       LABEL="SEQUENCE NUMBER                       05" FORMAT=F2.  
      ER33803       LABEL="RELATION TO HEAD                      05" FORMAT=F2.  
      ER33804       LABEL="AGE OF INDIVIDUAL                     05" FORMAT=F3.  
      ER33807       LABEL="MARITAL PAIRS INDICATOR               05" FORMAT=F1.  
      ER33808       LABEL="WHETHER MOVED IN/OUT                  05" FORMAT=F1.  
      ER33810       LABEL="YEAR MOVED IN/OUT                     05" FORMAT=F4.  
      ER33811       LABEL="RESPONDENT?                           05" FORMAT=F1.  
      ER33812       LABEL="WTR COVERED BY TANF PAYMENTS IN 2004  05" FORMAT=F1.  
      ER33813       LABEL="EMPLOYMENT STATUS                     05" FORMAT=F1.  
      ER33815       LABEL="YEAR LAST IN SCHOOL                   05" FORMAT=F4.  
      ER33816       LABEL="WHETHER STUDENT                       05" FORMAT=F1.  
      ER33817       LABEL="YEARS COMPLETED EDUCATION             05" FORMAT=F2.  
      ER33818       LABEL="HEALTH GOOD?                          05" FORMAT=F1.  
      ER33819       LABEL="H61 TYPE HEALTH INSURANCE MENTION 1   05" FORMAT=F2.  
      ER33820       LABEL="H61 TYPE HEALTH INSURANCE MENTION 2   05" FORMAT=F2.  
      ER33821       LABEL="H61 TYPE HEALTH INSURANCE MENTION 3   05" FORMAT=F2.  
      ER33822       LABEL="H61 TYPE HEALTH INSURANCE MENTION 4   05" FORMAT=F2.  
      ER33823       LABEL="H61A WTR STATE INSURNCE PLAN FOR KIDS 05" FORMAT=F1.  
      ER33824       LABEL="H61B MOS COVERED BY INSURANCE IN 03   05" FORMAT=F2.  
      ER33825       LABEL="H61C MOS COVERED BY INSURANCE IN 04   05" FORMAT=F2.  
      ER33826       LABEL="WHETHER MEDICARE NUMBER GIVEN         05" FORMAT=F1.  
      ER33826A      LABEL="R2/R11 EARNINGS AMT REPORTED IN 2003  05" FORMAT=F8.  
      ER33826B      LABEL="R2/R11 EARNINGS PER UNIT IN 2003      05" FORMAT=F1.  
      ER33827       LABEL="R4/R17 WTR REC ASSET INC 2003         05" FORMAT=F1.  
      ER33827E      LABEL="R5/R18 ASSET INC AMT 2003             05" FORMAT=F8.  
      ER33827F      LABEL="R5/R18 ASSET INC PER 2003             05" FORMAT=F1.  
      ER33827S      LABEL="R12 OFUM WKS WORKED 2003              05" FORMAT=F2.  
      ER33827U      LABEL="R14 OFUM HRS PER WK WORKED 2003       05" FORMAT=F3.  
      ER33828       LABEL="R21 WTR RECEIVED SOCL SECURITY IN 03  05" FORMAT=F1.  
      ER33829       LABEL="R26 WTR RECEIVED NON-VA PENSION IN 03 05" FORMAT=F1.  
      ER33830       LABEL="R30 WTR RECEIVED VA PENSION IN 2003   05" FORMAT=F1.  
      ER33831       LABEL="R34 WTR RECEIVED UNEMP COMP IN 2003   05" FORMAT=F1.  
      ER33832       LABEL="R38 WTR RECEIVED WORKERS COMP IN 2003 05" FORMAT=F1.  
      ER33833       LABEL="R42 WTR RECEIVED TANF/GA IN 2003      05" FORMAT=F1.  
      ER33833A      LABEL="R43 STATE WHERE RECD PUB ASSTNCE 2003 05" FORMAT=F2.  
      ER33833B      LABEL="R44 WTR RECD TANF IN 2003             05" FORMAT=F1.  
      ER33833C      LABEL="R44 WTR RECD ADC IN 2003              05" FORMAT=F1.  
      ER33833D      LABEL="R44 WTR RECD GEN ASSISTANCE IN 2003   05" FORMAT=F1.  
      ER33833E      LABEL="R44 WTR RECD EMERG ASSISTANCE IN 2003 05" FORMAT=F1.  
      ER33833F      LABEL="R44 WTR RECD CUBAN/HAITIAN REF 2003   05" FORMAT=F1.  
      ER33833G      LABEL="R44 WTR RECD INDIAN ASSIST IN 2003    05" FORMAT=F1.  
      ER33833H      LABEL="R44 WTR RECD OTHER ASSISTANCE IN 2003 05" FORMAT=F1.  
      ER33834       LABEL="R48 WTR RECEIVED SSI IN 2003          05" FORMAT=F1.  
      ER33835       LABEL="R52 WTR RECEIVED OTHER WELFARE IN 03  05" FORMAT=F1.  
      ER33836       LABEL="R56 WTR RECEIVED CHILD SUPPORT IN 03  05" FORMAT=F1.  
      ER33837       LABEL="R60 WTR RECD HELP FRM RELS/OTRS IN 03 05" FORMAT=F1.  
      ER33837A      LABEL="G33 TYPE SOC SEC RCD                  05" FORMAT=F1.  
      ER33837B      LABEL="G34 AMT SOC SEC RCD                   05" FORMAT=F5.  
      ER33837D      LABEL="G76 NUMBER OF JOBS IN PY              05" FORMAT=F1.  
      ER33837E      LABEL="G84A_G94B IMPUTED INTEREST            05" FORMAT=F6.  
      ER33837G      LABEL="G84B IMPUTED TANF                     05" FORMAT=F6.  
      ER33837I      LABEL="G84C_G94C IMPUTED SSI                 05" FORMAT=F6.  
      ER33837K      LABEL="G84D_G94D IMPUTED WELFARE             05" FORMAT=F6.  
      ER33837M      LABEL="G84F IMPUTED VETERANS BEN             05" FORMAT=F6.  
      ER33837O      LABEL="G84G IMPUTED PENSION/ANN              05" FORMAT=F6.  
      ER33837Q      LABEL="G84H IMPUTED UNEMP COMP               05" FORMAT=F6.  
      ER33837S      LABEL="G84J IMPUTED WORKERS COMP             05" FORMAT=F6.  
      ER33837U      LABEL="G84K IMPUTED CHILD SUPPORT            05" FORMAT=F6.  
      ER33837W      LABEL="G84L IMPUTED HELP FROM RELS           05" FORMAT=F6.  
      ER33837Y      LABEL="G84M_G94F IMPUTED OTHER INCOME        05" FORMAT=F6.  
      ER33838       LABEL="M13D WTR DECIDER FOR CHARITABLE GIVNG 05" FORMAT=F1.  
      ER33838A      LABEL="OFUM BUSINESS LABOR INCOME - IMPUTED  05" FORMAT=F7.  
      ER33838B      LABEL="OFUM BUSINESS ASSET INCOME - IMPUTED  05" FORMAT=F7.  
      ER33838C      LABEL="OFUM TOTAL LABOR INCOME- IMPUTED      05" FORMAT=F7.  
      ER33838E      LABEL="OFUM TOTAL ASSET INCOME - IMPUTED     05" FORMAT=F6.  
      ER33838F      LABEL="OFUM TOTAL TAXABLE INCOME - IMPUTED   05" FORMAT=F7.  
      ER33838G      LABEL="OFUM TOTAL TRANSFER INCOME -IMPUTED   05" FORMAT=F6.  
      ER33840       LABEL="YEAR S/O FAM FORMED                   05" FORMAT=F4.  
      ER33841       LABEL="MAIN FAM ID FOR S/O                   05" FORMAT=F5.  
      ER33842       LABEL="FOLLOW STATUS                         05" FORMAT=F1.  
      ER33844       LABEL="WTR ELGBLE FOR CDS TRANSITN TO ADULT  05" FORMAT=F1.  
      ER33845       LABEL="RESULT OF CDS TRANS-ADULT IW ATTEMPT  05" FORMAT=F2.  
      ER33846       LABEL="TYPE OF IND RECORD                    05" FORMAT=F2.  
      ER33847       LABEL="WHY NONRESPONSE                       05" FORMAT=F2.  
      ER33848       LABEL="CORE/IMM INDIVIDUAL LONGITUDINAL WT   05" FORMAT=F7.3 
      ER33849       LABEL="CORE/IMM INDIVIDUAL CROSS-SECTION WT  05" FORMAT=F5.  
      ER33901       LABEL="2007 INTERVIEW NUMBER"                    FORMAT=F5.  
      ER33902       LABEL="SEQUENCE NUMBER                       07" FORMAT=F2.  
      ER33903       LABEL="RELATION TO HEAD                      07" FORMAT=F2.  
      ER33904       LABEL="AGE OF INDIVIDUAL                     07" FORMAT=F3.  
      ER33907       LABEL="MARITAL PAIRS INDICATOR               07" FORMAT=F1.  
      ER33908       LABEL="WHETHER MOVED IN/OUT                  07" FORMAT=F1.  
      ER33910       LABEL="YEAR MOVED IN/OUT                     07" FORMAT=F4.  
      ER33911       LABEL="RESPONDENT?                           07" FORMAT=F1.  
      ER33912       LABEL="WTR COVERED BY TANF PAYMENTS IN 2006  07" FORMAT=F1.  
      ER33913       LABEL="EMPLOYMENT STATUS                     07" FORMAT=F1.  
      ER33915       LABEL="YEAR LAST IN SCHOOL                   07" FORMAT=F4.  
      ER33916       LABEL="WHETHER STUDENT                       07" FORMAT=F1.  
      ER33917       LABEL="YEARS COMPLETED EDUCATION             07" FORMAT=F2.  
      ER33918       LABEL="HEALTH GOOD?                          07" FORMAT=F1.  
      ER33919       LABEL="H61 TYPE HEALTH INSURANCE MENTION 1   07" FORMAT=F2.  
      ER33920       LABEL="H61 TYPE HEALTH INSURANCE MENTION 2   07" FORMAT=F2.  
      ER33921       LABEL="H61 TYPE HEALTH INSURANCE MENTION 3   07" FORMAT=F2.  
      ER33922       LABEL="H61 TYPE HEALTH INSURANCE MENTION 4   07" FORMAT=F2.  
      ER33923       LABEL="H61A WTR STATE INSURNCE PLAN FOR KIDS 07" FORMAT=F1.  
      ER33924       LABEL="H61B MOS COVERED BY INSURANCE IN 05   07" FORMAT=F2.  
      ER33925       LABEL="H61C MOS COVERED BY INSURANCE IN 06   07" FORMAT=F2.  
      ER33925A      LABEL="G33 TYPE SOC SEC RCD                  07" FORMAT=F1.  
      ER33925B      LABEL="G34 AMT SOC SEC RCD                   07" FORMAT=F5.  
      ER33925D      LABEL="G76 NUMBER OF JOBS IN PY              07" FORMAT=F1.  
      ER33925E      LABEL="G84A_G94B IMPUTED INTEREST            07" FORMAT=F6.  
      ER33925G      LABEL="G84B IMPUTED TANF                     07" FORMAT=F6.  
      ER33925I      LABEL="G84C_G94C IMPUTED SSI                 07" FORMAT=F6.  
      ER33925K      LABEL="G84D_G94D IMPUTED WELFARE             07" FORMAT=F6.  
      ER33925M      LABEL="G84F IMPUTED VETERANS BEN             07" FORMAT=F6.  
      ER33925O      LABEL="G84G IMPUTED PENSION/ANN              07" FORMAT=F6.  
      ER33925Q      LABEL="G84H IMPUTED UNEMP COMP               07" FORMAT=F6.  
      ER33925S      LABEL="G84J IMPUTED WORKERS COMP             07" FORMAT=F6.  
      ER33925U      LABEL="G84K IMPUTED CHILD SUPPORT            07" FORMAT=F6.  
      ER33925W      LABEL="G84L IMPUTED HELP FROM RELS           07" FORMAT=F6.  
      ER33925Y      LABEL="G84M_G94F IMPUTED OTHER INCOME        07" FORMAT=F6.  
      ER33926       LABEL="WHETHER MEDICARE NUMBER GIVEN         07" FORMAT=F1.  
      ER33926A      LABEL="R2/R11 EARNINGS AMT REPORTED IN 2005  07" FORMAT=F10.2
      ER33926B      LABEL="R2/R11 EARNINGS PER UNIT IN 2005      07" FORMAT=F1.  
      ER33927       LABEL="R17 WTR RECEIVED ASSET INCOME IN 05   07" FORMAT=F1.  
      ER33927A      LABEL="R12 OFUM WKS WORKED 2005              07" FORMAT=F2.  
      ER33927C      LABEL="R14 OFUM HRS PER WK WORKED 2005       07" FORMAT=F3.  
      ER33928       LABEL="R21 WTR RECEIVED SOCL SECURITY IN 05  07" FORMAT=F1.  
      ER33929       LABEL="R26 WTR RECEIVED NON-VA PENSION IN 05 07" FORMAT=F1.  
      ER33930       LABEL="R30 WTR RECEIVED VA PENSION IN 2005   07" FORMAT=F1.  
      ER33931       LABEL="R34 WTR RECEIVED UNEMP COMP IN 2005   07" FORMAT=F1.  
      ER33932       LABEL="R38 WTR RECEIVED WORKERS COMP IN 2005 07" FORMAT=F1.  
      ER33933       LABEL="R42 WTR RECEIVED TANF/GA IN 2005      07" FORMAT=F1.  
      ER33933A      LABEL="R43 STATE WHERE RECD PUB ASSTNCE 2005 07" FORMAT=F2.  
      ER33933B      LABEL="R44 WTR RECD TANF IN 2005             07" FORMAT=F1.  
      ER33933C      LABEL="R44 WTR RECD ADC IN 2005              07" FORMAT=F1.  
      ER33933D      LABEL="R44 WTR RECD GEN ASSISTANCE IN 2005   07" FORMAT=F1.  
      ER33933E      LABEL="R44 WTR RECD EMERG ASSISTANCE IN 2005 07" FORMAT=F1.  
      ER33933F      LABEL="R44 WTR RECD CUBAN/HAITIAN REF 2005   07" FORMAT=F1.  
      ER33933G      LABEL="R44 WTR RECD INDIAN ASSIST IN 2005    07" FORMAT=F1.  
      ER33933H      LABEL="R44 WTR RECD OTHER ASSISTANCE IN 2005 07" FORMAT=F1.  
      ER33934       LABEL="R48 WTR RECEIVED SSI IN 2005          07" FORMAT=F1.  
      ER33935       LABEL="R52 WTR RECEIVED OTHER WELFARE IN 05  07" FORMAT=F1.  
      ER33936       LABEL="R56 WTR RECEIVED CHILD SUPPORT IN 05  07" FORMAT=F1.  
      ER33937       LABEL="R60 WTR RECD HELP FRM RELS/OTRS IN 05 07" FORMAT=F1.  
      ER33938       LABEL="R64 WTR RECD AMT ANYTHING ELSE IN 05  07" FORMAT=F1.  
      ER33938A      LABEL="OFUM BUSINESS LABOR INCOME - IMPUTED  07" FORMAT=F7.  
      ER33938B      LABEL="OFUM BUSINESS ASSET INCOME - IMPUTED  07" FORMAT=F7.  
      ER33938C      LABEL="OFUM TOTAL LABOR INCOME- IMPUTED      07" FORMAT=F7.  
      ER33938E      LABEL="OFUM TOTAL ASSET INCOME - IMPUTED     07" FORMAT=F6.  
      ER33938F      LABEL="OFUM TOTAL TAXABLE INCOME - IMPUTED   07" FORMAT=F7.  
      ER33938G      LABEL="OFUM TOTAL TRANSFER INCOME -IMPUTED   07" FORMAT=F6.  
      ER33940       LABEL="YEAR S/O FAM FORMED                   07" FORMAT=F4.  
      ER33941       LABEL="MAIN FAM ID FOR S/O                   07" FORMAT=F5.  
      ER33942       LABEL="FOLLOW STATUS                         07" FORMAT=F1.  
      ER33944       LABEL="WTR ELGBLE FOR CDS/TA                 07" FORMAT=F1.  
      ER33945       LABEL="RESULT OF CDS/TA IW ATTEMPT           07" FORMAT=F2.  
      ER33948       LABEL="TYPE OF IND RECORD                    07" FORMAT=F2.  
      ER33949       LABEL="WHY NONRESPONSE                       07" FORMAT=F2.  
      ER33950       LABEL="CORE/IMM INDIVIDUAL LONGITUDINAL WT   07" FORMAT=F7.3 
      ER33951       LABEL="CORE/IMM INDIVIDUAL CROSS-SECTION WT  07" FORMAT=F5.  
      ER34001       LABEL="2009 INTERVIEW NUMBER"                    FORMAT=F5.  
      ER34002       LABEL="SEQUENCE NUMBER                       09" FORMAT=F2.  
      ER34003       LABEL="RELATION TO HEAD                      09" FORMAT=F2.  
      ER34004       LABEL="AGE OF INDIVIDUAL                     09" FORMAT=F3.  
      ER34007       LABEL="MARITAL PAIRS INDICATOR               09" FORMAT=F1.  
      ER34008       LABEL="WHETHER MOVED IN/OUT                  09" FORMAT=F1.  
      ER34010       LABEL="YEAR MOVED IN/OUT                     09" FORMAT=F4.  
      ER34011       LABEL="RESPONDENT?                           09" FORMAT=F1.  
      ER34012       LABEL="SN 1ST PERSON WHO HELPED WITH IW      09" FORMAT=F2.  
      ER34013       LABEL="SN 2ND PERSON WHO HELPED WITH IW      09" FORMAT=F2.  
      ER34014       LABEL="SN 3RD PERSON WHO HELPED WITH IW      09" FORMAT=F2.  
      ER34015       LABEL="WTR COVERED BY TANF PAYMENTS IN 2008  09" FORMAT=F1.  
      ER34016       LABEL="EMPLOYMENT STATUS                     09" FORMAT=F1.  
      ER34018       LABEL="YEAR LAST IN SCHOOL                   09" FORMAT=F4.  
      ER34019       LABEL="WHETHER STUDENT                       09" FORMAT=F1.  
      ER34020       LABEL="YEARS COMPLETED EDUCATION             09" FORMAT=F2.  
      ER34021       LABEL="HEALTH GOOD?                          09" FORMAT=F1.  
      ER34022       LABEL="H61 TYPE HEALTH INSURANCE MENTION 1   09" FORMAT=F2.  
      ER34023       LABEL="H61 TYPE HEALTH INSURANCE MENTION 2   09" FORMAT=F2.  
      ER34024       LABEL="H61 TYPE HEALTH INSURANCE MENTION 3   09" FORMAT=F2.  
      ER34025       LABEL="H61 TYPE HEALTH INSURANCE MENTION 4   09" FORMAT=F2.  
      ER34026       LABEL="H61A WTR STATE INSURNCE PLAN FOR KIDS 09" FORMAT=F1.  
      ER34027       LABEL="H61B MOS COVERED BY INSURANCE IN 07   09" FORMAT=F2.  
      ER34028       LABEL="H61C MOS COVERED BY INSURANCE IN 08   09" FORMAT=F2.  
      ER34029       LABEL="WHETHER MEDICARE NUMBER GIVEN         09" FORMAT=F1.  
      ER34029A      LABEL="G76 NUMBER OF JOBS IN PY              09" FORMAT=F1.  
      ER34029B      LABEL="G84A_G94B IMPUTED INTEREST            09" FORMAT=F6.  
      ER34029D      LABEL="G84B IMPUTED TANF                     09" FORMAT=F6.  
      ER34029F      LABEL="G84C_G94C IMPUTED SSI                 09" FORMAT=F6.  
      ER34029H      LABEL="G84D_G94D IMPUTED WELFARE             09" FORMAT=F6.  
      ER34029J      LABEL="G84F IMPUTED VETERANS BEN             09" FORMAT=F6.  
      ER34029L      LABEL="G84G IMPUTED PENSION/ANN              09" FORMAT=F6.  
      ER34029N      LABEL="G84H IMPUTED UNEMP COMP               09" FORMAT=F6.  
      ER34029P      LABEL="G84J IMPUTED WORKERS COMP             09" FORMAT=F6.  
      ER34029R      LABEL="G84K IMPUTED CHILD SUPPORT            09" FORMAT=F6.  
      ER34029T      LABEL="G84L IMPUTED HELP FROM RELS           09" FORMAT=F6.  
      ER34029V      LABEL="G84M_G94F IMPUTED OTHER INCOME        09" FORMAT=F6.  
      ER34029X      LABEL="OFUM BUSINESS LABOR INCOME - IMPUTED  09" FORMAT=F7.  
      ER34029Y      LABEL="OFUM BUSINESS ASSET INCOME - IMPUTED  09" FORMAT=F7.  
      ER34030       LABEL="G33 TYPE SOC SEC RCD                  09" FORMAT=F1.  
      ER34031       LABEL="G34 AMT SOC SEC RCD                   09" FORMAT=F5.  
      ER34032A      LABEL="OFUM TOTAL LABOR INCOME- IMPUTED      09" FORMAT=F7.  
      ER34032C      LABEL="OFUM TOTAL ASSET INCOME - IMPUTED     09" FORMAT=F6.  
      ER34032D      LABEL="OFUM TOTAL TAXABLE INCOME - IMPUTED   09" FORMAT=F7.  
      ER34032E      LABEL="OFUM TOTAL TRANSFER INCOME -IMPUTED   09" FORMAT=F6.  
      ER34034       LABEL="YEAR S/O FAM FORMED                   09" FORMAT=F4.  
      ER34035       LABEL="MAIN FAM ID FOR S/O                   09" FORMAT=F5.  
      ER34036       LABEL="FOLLOW STATUS                         09" FORMAT=F1.  
      ER34038       LABEL="WTR ELIGIBLE FOR TA                   09" FORMAT=F1.  
      ER34039       LABEL="RESULT OF TA IW ATTEMPT               09" FORMAT=F2.  
      ER34040       LABEL="WTR ELIGIBLE FOR DUST                 09" FORMAT=F1.  
      ER34041       LABEL="WHETHER SELECTED FOR DUST             09" FORMAT=F1.  
      ER34042       LABEL="RESULT OF DUST IW ATTEMPT             09" FORMAT=F2.  
      ER34043       LABEL="TYPE OF IND RECORD                    09" FORMAT=F2.  
      ER34044       LABEL="WHY NONRESPONSE                       09" FORMAT=F2.  
      ER34045       LABEL="CORE/IMM INDIVIDUAL LONGITUDINAL WT   09" FORMAT=F7.3 
      ER34046       LABEL="CORE/IMM INDIVIDUAL CROSS-SECTION WT  09" FORMAT=F5.  
      ER34101       LABEL="2011 INTERVIEW NUMBER"                    FORMAT=F5.  
      ER34102       LABEL="SEQUENCE NUMBER                       11" FORMAT=F2.  
      ER34103       LABEL="RELATION TO HEAD                      11" FORMAT=F2.  
      ER34104       LABEL="AGE OF INDIVIDUAL                     11" FORMAT=F3.  
      ER34107       LABEL="MARITAL PAIRS INDICATOR               11" FORMAT=F1.  
      ER34108       LABEL="WHETHER MOVED IN/OUT                  11" FORMAT=F1.  
      ER34110       LABEL="YEAR MOVED IN/OUT                     11" FORMAT=F4.  
      ER34111       LABEL="RESPONDENT?                           11" FORMAT=F1.  
      ER34112       LABEL="SN 1ST PERSON WHO HELPED WITH IW      11" FORMAT=F2.  
      ER34113       LABEL="SN 2ND PERSON WHO HELPED WITH IW      11" FORMAT=F2.  
      ER34114       LABEL="SN 3RD PERSON WHO HELPED WITH IW      11" FORMAT=F2.  
      ER34115       LABEL="WTR COVERED BY TANF PAYMENTS IN 2010  11" FORMAT=F1.  
      ER34116       LABEL="EMPLOYMENT STATUS                     11" FORMAT=F1.  
      ER34118       LABEL="YEAR LAST IN SCHOOL                   11" FORMAT=F4.  
      ER34119       LABEL="YEARS COMPLETED EDUCATION             11" FORMAT=F2.  
      ER34120       LABEL="HEALTH GOOD?                          11" FORMAT=F1.  
      ER34121       LABEL="H61 TYPE HEALTH INSURANCE MENTION 1   11" FORMAT=F2.  
      ER34122       LABEL="H61 TYPE HEALTH INSURANCE MENTION 2   11" FORMAT=F2.  
      ER34123       LABEL="H61 TYPE HEALTH INSURANCE MENTION 3   11" FORMAT=F2.  
      ER34124       LABEL="H61 TYPE HEALTH INSURANCE MENTION 4   11" FORMAT=F2.  
      ER34125       LABEL="H61A WTR STATE INSURNCE PLAN FOR KIDS 11" FORMAT=F1.  
      ER34126       LABEL="H61B MOS COVERED BY INSURANCE IN 09   11" FORMAT=F2.  
      ER34127       LABEL="H61C MOS COVERED BY INSURANCE IN 10   11" FORMAT=F2.  
      ER34128       LABEL="H61D WTR COVERED BY INSURANCE NOW     11" FORMAT=F1.  
      ER34129       LABEL="H61E TYPE CURRENT HEALTH INS MEN 1    11" FORMAT=F2.  
      ER34130       LABEL="H61E TYPE CURRENT HEALTH INS MEN 2    11" FORMAT=F2.  
      ER34131       LABEL="H61E TYPE CURRENT HEALTH INS MEN 3    11" FORMAT=F2.  
      ER34132       LABEL="H61F SN 1ST PERSON EMP PROVIDES INS   11" FORMAT=F2.  
      ER34133       LABEL="H61F SN 2ND PERSON EMP PROVIDES INS   11" FORMAT=F2.  
      ER34134       LABEL="H61G SN 1ST PERSON POLICY HOLDER      11" FORMAT=F2.  
      ER34135       LABEL="H61G SN 2ND PERSON POLICY HOLDER      11" FORMAT=F2.  
      ER34136       LABEL="WHETHER MEDICARE NUMBER GIVEN         11" FORMAT=F1.  
      ER34136A      LABEL="G76 NUMBER OF JOBS IN PY              11" FORMAT=F1.  
      ER34136B      LABEL="G84A_G94B IMPUTED INTEREST            11" FORMAT=F6.  
      ER34136D      LABEL="G84B IMPUTED-TANF                    11"  FORMAT=F6.  
      ER34136F      LABEL="G84C_G94C IMPUTED SSI                 11" FORMAT=F6.  
      ER34136H      LABEL="G84D_G94D IMPUTED WELFARE             11" FORMAT=F6.  
      ER34136J      LABEL="G84F IMPUTED VETERANS BEN             11" FORMAT=F6.  
      ER34136L      LABEL="G84G IMPUTED PENSION/ANN              11" FORMAT=F6.  
      ER34136N      LABEL="G84H IMPUTED UNEMP COMP               11" FORMAT=F6.  
      ER34136P      LABEL="G84J IMPUTED WORKERS COMP             11" FORMAT=F6.  
      ER34136R      LABEL="G84K IMPUTED CHILD SUPPORT            11" FORMAT=F6.  
      ER34136T      LABEL="G84L IMPUTED HELP FROM RELS           11" FORMAT=F6.  
      ER34136V      LABEL="G84M_G94F IMPUTED OTHER INCOME        11" FORMAT=F6.  
      ER34136X      LABEL="OFUM BUSINESS LABOR INCOME - IMPUTED  11" FORMAT=F7.  
      ER34136Y      LABEL="OFUM BUSINESS ASSET INCOME - IMPUTED  11" FORMAT=F7.  
      ER34143       LABEL="G34 AMT SOC SEC RCD                   11" FORMAT=F5.  
      ER34144A      LABEL="OFUM TOTAL LABOR INCOME- IMPUTED      11" FORMAT=F7.  
      ER34144C      LABEL="OFUM TOTAL ASSET INCOME - IMPUTED     11" FORMAT=F6.  
      ER34144D      LABEL="OFUM TOTAL TAXABLE INCOME - IMPUTED   11" FORMAT=F7.  
      ER34144E      LABEL="OFUM TOTAL TRANSFER INCOME -IMPUTED   11" FORMAT=F6.  
      ER34146       LABEL="YEAR S/O FAM FORMED                   11" FORMAT=F4.  
      ER34147       LABEL="MAIN FAM ID FOR S/O                   11" FORMAT=F5.  
      ER34148       LABEL="FOLLOW STATUS                         11" FORMAT=F1.  
      ER34150       LABEL="WTR ELGBLE FOR CDS/TA                 11" FORMAT=F1.  
      ER34151       LABEL="RESULT OF CDS/TA IW ATTEMPT           11" FORMAT=F2.  
      ER34152       LABEL="TYPE OF IND RECORD                    11" FORMAT=F2.  
      ER34153       LABEL="WHY NONRESPONSE                       11" FORMAT=F2.  
      ER34154       LABEL="CORE/IMM INDIVIDUAL LONGITUDINAL WT   11" FORMAT=F7.3 
      ER34155       LABEL="CORE/IMM INDIVIDUAL CROSS-SECTION WT  11" FORMAT=F5.  
      ER34201       LABEL="2013 INTERVIEW NUMBER"                    FORMAT=F5.  
      ER34202       LABEL="SEQUENCE NUMBER                       13" FORMAT=F2.  
      ER34203       LABEL="RELATION TO HEAD                      13" FORMAT=F2.  
      ER34204       LABEL="AGE OF INDIVIDUAL                     13" FORMAT=F3.  
      ER34207       LABEL="MARITAL PAIRS INDICATOR               13" FORMAT=F1.  
      ER34208       LABEL="WHETHER MOVED IN/OUT                  13" FORMAT=F1.  
      ER34210       LABEL="YEAR MOVED IN/OUT                     13" FORMAT=F4.  
      ER34211       LABEL="RESPONDENT?                           13" FORMAT=F1.  
      ER34212       LABEL="SN 1ST PERSON WHO HELPED WITH IW      13" FORMAT=F2.  
      ER34213       LABEL="SN 2ND PERSON WHO HELPED WITH IW      13" FORMAT=F2.  
      ER34214       LABEL="SN 3RD PERSON WHO HELPED WITH IW      13" FORMAT=F2.  
      ER34215       LABEL="WTR COVERED BY TANF PAYMENTS IN 2012  13" FORMAT=F1.  
      ER34216       LABEL="EMPLOYMENT STATUS                     13" FORMAT=F1.  
      ER34218       LABEL="YEAR LAST IN SCHOOL                   13" FORMAT=F4.  
      ER34219       LABEL="HIGHEST GRADE OF SCHOOL COMPLETED     13" FORMAT=F2.  
      ER34220       LABEL="WTR REC HS DIPLOMA/GED/NEITHER        13" FORMAT=F1.  
      ER34221       LABEL="TYPE OF HIGHEST DEGREE                13" FORMAT=F2.  
      ER34223       LABEL="YEAR GRADUATED BACHELOR DEGREE        13" FORMAT=F4.  
      ER34226       LABEL="YEAR GRADUATED HIGHEST DEGREE         13" FORMAT=F4.  
      ER34227       LABEL="HIGHEST DEGREE MAJOR                  13" FORMAT=F3.  
      ER34228       LABEL="WTR CURRENTLY ENROLLED IN SCHOOL      13" FORMAT=F1.  
      ER34229       LABEL="GRADE CURRENTLY ENROLLED              13" FORMAT=F2.  
      ER34230       LABEL="YEARS COMPLETED EDUCATION             13" FORMAT=F2.  
      ER34231       LABEL="HEALTH GOOD?                          13" FORMAT=F1.  
      ER34232       LABEL="H61E2 WTR STATE INSURNCE PLN FOR KIDS 13" FORMAT=F1.  
      ER34233       LABEL="H61M MONTHS UNINSURED IN 11           13" FORMAT=F2.  
      ER34234       LABEL="H61N MONTHS UNINSURED IN 12           13" FORMAT=F2.  
      ER34235       LABEL="H61D3 WTR COVERED BY INSURANCE NOW    13" FORMAT=F1.  
      ER34236       LABEL="H61E TYPE CURRENT HEALTH INS MEN 1    13" FORMAT=F2.  
      ER34237       LABEL="H61E TYPE CURRENT HEALTH INS MEN 2    13" FORMAT=F2.  
      ER34238       LABEL="H61E TYPE CURRENT HEALTH INS MEN 3    13" FORMAT=F2.  
      ER34239       LABEL="H61F SN 1ST PERSON EMP PROVIDES INS   13" FORMAT=F2.  
      ER34240       LABEL="H61F SN 2ND PERSON EMP PROVIDES INS   13" FORMAT=F2.  
      ER34241       LABEL="H61G SN 1ST PERSON POLICY HOLDER      13" FORMAT=F2.  
      ER34242       LABEL="H61G SN 2ND PERSON POLICY HOLDER      13" FORMAT=F2.  
      ER34243       LABEL="WHETHER MEDICARE NUMBER GIVEN         13" FORMAT=F1.  
      ER34243A      LABEL="G76 NUMBER OF JOBS IN PY              13" FORMAT=F1.  
      ER34243B      LABEL="G84A_G94B IMPUTED INTEREST            13" FORMAT=F6.  
      ER34243D      LABEL="G84B IMPUTED TANF                     13" FORMAT=F6.  
      ER34243F      LABEL="G84C_G94C IMPUTED SSI                 13" FORMAT=F6.  
      ER34243H      LABEL="G84D_G94D IMPUTED WELFARE             13" FORMAT=F6.  
      ER34243J      LABEL="G84F IMPUTED VETERANS BEN             13" FORMAT=F6.  
      ER34243L      LABEL="G84G IMPUTED PENSION/ANN              13" FORMAT=F6.  
      ER34243N      LABEL="G84H IMPUTED UNEMP COMP               13" FORMAT=F6.  
      ER34243P      LABEL="G84J IMPUTED WORKERS COMP             13" FORMAT=F6.  
      ER34243R      LABEL="G84K IMPUTED CHILD SUPPORT            13" FORMAT=F6.  
      ER34243T      LABEL="G84L IMPUTED HELP FROM RELS           13" FORMAT=F6.  
      ER34243V      LABEL="G84M_G94F IMPUTED OTHER INCOME        13" FORMAT=F6.  
      ER34243X      LABEL="OFUM BUSINESS LABOR INCOME - IMPUTED  13" FORMAT=F7.  
      ER34243Y      LABEL="OFUM BUSINESS ASSET INCOME - IMPUTED  13" FORMAT=F7.  
      ER34250       LABEL="G34 AMT SOC SEC RCD                   13" FORMAT=F5.  
      ER34251A      LABEL="OFUM TOTAL LABOR INCOME- IMPUTED      13" FORMAT=F7.  
      ER34251C      LABEL="OFUM TOTAL ASSET INCOME - IMPUTED     13" FORMAT=F6.  
      ER34251D      LABEL="OFUM TOTAL TAXABLE INCOME - IMPUTED   13" FORMAT=F7.  
      ER34251E      LABEL="OFUM TOTAL TRANSFER INCOME -IMPUTED   13" FORMAT=F6.  
      ER34253       LABEL="YEAR S/O FAM FORMED                   13" FORMAT=F4.  
      ER34254       LABEL="MAIN FAM ID FOR S/O                   13" FORMAT=F5.  
      ER34255       LABEL="FOLLOW STATUS                         13" FORMAT=F1.  
      ER34257       LABEL="WTR ELIGIBLE FOR TA                   13" FORMAT=F1.  
      ER34258       LABEL="RESULT OF TA IW ATTEMPT               13" FORMAT=F2.  
      ER34259       LABEL="WTR ELIGIBLE FOR CDS 2014             13" FORMAT=F1.  
      ER34260       LABEL="SELECTION STATUS FOR CDS 2014         13" FORMAT=F1.  
      ER34261       LABEL="RESULT OF CDS 2014 IW ATTEMPT         13" FORMAT=F2.  
      ER34261A      LABEL="WTR CDS 2014 IW CODED COMPLETE        13" FORMAT=F1.  
      ER34262       LABEL="WTR ELIGIBLE FOR DUST 2013            13" FORMAT=F1.  
      ER34263       LABEL="RESULT OF DUST 2013 IW ATTEMPT        13" FORMAT=F2.  
      ER34264       LABEL="WTR ELIG FOR CRCS 2014               13"  FORMAT=F1.  
      ER34265       LABEL="RESULT OF CRCS IW ATTEMPT 14        13"   FORMAT=F2.  
      ER34266       LABEL="TYPE OF IND RECORD                    13" FORMAT=F2.  
      ER34267       LABEL="WHY NONRESPONSE                       13" FORMAT=F2.  
      ER34268       LABEL="CORE/IMM INDIVIDUAL LONGITUDINAL WT   13" FORMAT=F7.3 
      ER34269       LABEL="CORE/IMM INDIVIDUAL CROSS-SECTION WT  13" FORMAT=F5.  
      ER34301       LABEL="2015 INTERVIEW NUMBER"                    FORMAT=F5.  
      ER34302       LABEL="SEQUENCE NUMBER                       15" FORMAT=F2.  
      ER34303       LABEL="RELATION TO HEAD                      15" FORMAT=F2.  
      ER34304       LABEL="WTR SAME SEX PARTNER OF HD            15" FORMAT=F1.  
      ER34305       LABEL="AGE OF INDIVIDUAL                     15" FORMAT=F3.  
      ER34308       LABEL="MARITAL PAIRS INDICATOR               15" FORMAT=F1.  
      ER34309       LABEL="WHETHER MOVED IN/OUT                  15" FORMAT=F1.  
      ER34311       LABEL="YEAR MOVED IN/OUT                     15" FORMAT=F4.  
      ER34312       LABEL="RESPONDENT?                           15" FORMAT=F1.  
      ER34313       LABEL="SN 1ST PERSON WHO HELPED WITH IW      15" FORMAT=F2.  
      ER34314       LABEL="SN 2ND PERSON WHO HELPED WITH IW      15" FORMAT=F2.  
      ER34315       LABEL="SN 3RD PERSON WHO HELPED WITH IW      15" FORMAT=F2.  
      ER34316       LABEL="WTR COVERED BY TANF PAYMENTS IN 2014  15" FORMAT=F1.  
      ER34317       LABEL="EMPLOYMENT STATUS                     15" FORMAT=F1.  
      ER34318       LABEL="YEAR HIGHEST EDUCATION UPDATED        15" FORMAT=F4.  
      ER34319       LABEL="WHETHER EDUCATED IN US                15" FORMAT=F1.  
      ER34320       LABEL="WTR REC HS DIPLOMA/GED/NEITHER        15" FORMAT=F1.  
      ER34321       LABEL="MONTH GRADUATED HIGH SCHOOL           15" FORMAT=F2.  
      ER34322       LABEL="YEAR GRADUATED HIGH SCHOOL            15" FORMAT=F4.  
      ER34323       LABEL="GRADE LEVEL IF GED                    15" FORMAT=F2.  
      ER34325       LABEL="YEAR LAST IN SCHOOL IF GED            15" FORMAT=F4.  
      ER34327       LABEL="YEAR RECEIVED GED                     15" FORMAT=F4.  
      ER34328       LABEL="GRADE OF SCHOOL FINISHED IF NEITHER   15" FORMAT=F2.  
      ER34330       LABEL="YEAR LAST IN SCHOOL IF NEITHER        15" FORMAT=F4.  
      ER34331       LABEL="WTR ATTENDED COLLEGE                  15" FORMAT=F1.  
      ER34335       LABEL="WTR RECEIVED COLLEGE DEGREE           15" FORMAT=F1.  
      ER34336       LABEL="TYPE OF HIGHEST DEGREE                15" FORMAT=F2.  
      ER34340       LABEL="YEAR GRADUATED BACHELOR DEGREE        15" FORMAT=F4.  
      ER34341       LABEL="HIGHEST DEGREE MAJOR MEN1             15" FORMAT=F3.  
      ER34342       LABEL="HIGHEST DEGREE MAJOR MEN2             15" FORMAT=F3.  
      ER34344       LABEL="YEAR GRADUATED HIGHEST DEGREE         15" FORMAT=F4.  
      ER34347       LABEL="WTR CURRENTLY ENROLLED IN SCHOOL      15" FORMAT=F1.  
      ER34348       LABEL="GRADE CURRENTLY ENROLLED              15" FORMAT=F2.  
      ER34349       LABEL="YEARS COMPLETED EDUCATION             15" FORMAT=F2.  
      ER34350       LABEL="UP: WTR ATTENDED SCHOOL SINCE LAST IW 15" FORMAT=F1.  
      ER34351       LABEL="UP: WHETHER EDUCATED IN US            15" FORMAT=F1.  
      ER34352       LABEL="UP: WTR REC HS DIPLOMA/GED/NEITHER    15" FORMAT=F1.  
      ER34354       LABEL="UP: YEAR GRADUATED HIGH SCHOOL        15" FORMAT=F4.  
      ER34357       LABEL="UP: YEAR LAST IN SCHOOL IF GED        15" FORMAT=F4.  
      ER34359       LABEL="UP: YEAR RECEIVED GED                 15" FORMAT=F4.  
      ER34360       LABEL="UP: GRADE SCHOOL FINISHED IF NEITHER  15" FORMAT=F2.  
      ER34362       LABEL="UP: YEAR LAST IN SCHOOL IF NEITHER    15" FORMAT=F4.  
      ER34363       LABEL="UP: WTR ATTENDED COLLEGE              15" FORMAT=F1.  
      ER34365       LABEL="UP: YEAR LAST ATTENDED COLLEGE        15" FORMAT=F4.  
      ER34367       LABEL="UP: WTR RECEIVED COLLEGE DEGREE       15" FORMAT=F1.  
      ER34368       LABEL="UP: TYPE OF HIGHEST DEGREE            15" FORMAT=F2.  
      ER34369       LABEL="UP: BACHELOR DEGREE MAJOR MEN1        15" FORMAT=F3.  
      ER34372       LABEL="UP: YEAR GRADUATED BACHELOR DEGREE    15" FORMAT=F4.  
      ER34373       LABEL="UP: HIGHEST DEGREE MAJOR MEN1         15" FORMAT=F3.  
      ER34376       LABEL="UP: YEAR GRADUATED HIGHEST DEGREE     15" FORMAT=F4.  
      ER34379       LABEL="UP: WTR CURRENTLY ENROLLED IN SCHOOL  15" FORMAT=F1.  
      ER34380       LABEL="UP: GRADE CURRENTLY ENROLLED          15" FORMAT=F2.  
      ER34381       LABEL="HEALTH GOOD?                          15" FORMAT=F1.  
      ER34382       LABEL="H61E2 WTR STATE INSURNCE PLN FOR KIDS 15" FORMAT=F1.  
      ER34383       LABEL="H61M MONTHS UNINSURED IN 13           15" FORMAT=F2.  
      ER34384       LABEL="H61N MONTHS UNINSURED IN 14           15" FORMAT=F2.  
      ER34385       LABEL="H61D3 WTR COVERED BY INSURANCE NOW    15" FORMAT=F1.  
      ER34386       LABEL="H61E TYPE CURRENT HEALTH INS MEN 1    15" FORMAT=F2.  
      ER34387       LABEL="H61E TYPE CURRENT HEALTH INS MEN 2    15" FORMAT=F2.  
      ER34388       LABEL="H61E TYPE CURRENT HEALTH INS MEN 3    15" FORMAT=F2.  
      ER34389       LABEL="H61F SN 1ST PERSON EMP PROVIDES INS   15" FORMAT=F2.  
      ER34390       LABEL="H61F SN 2ND PERSON EMP PROVIDES INS   15" FORMAT=F2.  
      ER34391       LABEL="H61G SN 1ST PERSON POLICY HOLDER      15" FORMAT=F2.  
      ER34392       LABEL="H61G SN 2ND PERSON POLICY HOLDER      15" FORMAT=F2.  
      ER34393       LABEL="WHETHER MEDICARE NUMBER GIVEN         15" FORMAT=F1.  
      ER34393A      LABEL="G76 NUMBER OF JOBS IN PY              15" FORMAT=F1.  
      ER34393B      LABEL="G84A_G94B IMPUTED INTEREST            15" FORMAT=F6.  
      ER34393D      LABEL="G84B IMPUTED TANF                     15" FORMAT=F6.  
      ER34393F      LABEL="G84C_G94C IMPUTED SSI                 15" FORMAT=F6.  
      ER34393H      LABEL="G84D_G94D IMPUTED WELFARE             15" FORMAT=F6.  
      ER34393J      LABEL="G84F IMPUTED VETERANS BEN             15" FORMAT=F6.  
      ER34393L      LABEL="G84G IMPUTED PENSION/ANN              15" FORMAT=F6.  
      ER34393N      LABEL="G84H IMPUTED UNEMP COMP               15" FORMAT=F6.  
      ER34393P      LABEL="G84J IMPUTED WORKERS COMP             15" FORMAT=F6.  
      ER34393R      LABEL="G84K IMPUTED CHILD SUPPORT            15" FORMAT=F6.  
      ER34393T      LABEL="G84L IMPUTED HELP FROM RELS           15" FORMAT=F6.  
      ER34393V      LABEL="G84M_G94F IMPUTED OTHER INCOME        15" FORMAT=F6.  
      ER34393X      LABEL="OFUM BUSINESS LABOR INCOME - IMPUTED  15" FORMAT=F7.  
      ER34393Y      LABEL="OFUM BUSINESS ASSET INCOME - IMPUTED  15" FORMAT=F7.  
      ER34400       LABEL="G34 AMT SOC SEC RCD                   15" FORMAT=F5.  
      ER34401A      LABEL="OFUM TOTAL LABOR INCOME- IMPUTED      15" FORMAT=F7.  
      ER34401C      LABEL="OFUM TOTAL ASSET INCOME - IMPUTED     15" FORMAT=F6.  
      ER34401D      LABEL="OFUM TOTAL TAXABLE INCOME - IMPUTED   15" FORMAT=F7.  
      ER34401E      LABEL="OFUM TOTAL TRANSFER INCOME -IMPUTED   15" FORMAT=F6.  
      ER34403       LABEL="YEAR S/O FAM FORMED                   15" FORMAT=F4.  
      ER34404       LABEL="MAIN FAM ID FOR S/O                   15" FORMAT=F5.  
      ER34405       LABEL="FOLLOW STATUS                         15" FORMAT=F1.  
      ER34407       LABEL="WTR ELIGIBLE FOR TA                   15" FORMAT=F1.  
      ER34408       LABEL="RESULT OF TA IW ATTEMPT               15" FORMAT=F2.  
      ER34409       LABEL="WTR ELIG FOR WELL-BEING 2016          15" FORMAT=F1.  
      ER34410       LABEL="RESULT OF WELL-BEING IW ATTEMPT 16    15" FORMAT=F2.  
      ER34411       LABEL="TYPE OF IND RECORD                    15" FORMAT=F2.  
      ER34412       LABEL="WHY NONRESPONSE                       15" FORMAT=F2.  
      ER34413       LABEL="CORE/IMM INDIVIDUAL LONGITUDINAL WT   15" FORMAT=F7.3 
      ER34414       LABEL="CORE/IMM INDIVIDUAL CROSS-SECTION WT  15" FORMAT=F5.  
      ER34501       LABEL="2017 INTERVIEW NUMBER"                    FORMAT=F5.  
      ER34502       LABEL="SEQUENCE NUMBER                       17" FORMAT=F2.  
      ER34503       LABEL="RELATION TO REFERENCE PERSON          17" FORMAT=F2.  
      ER34504       LABEL="AGE OF INDIVIDUAL                     17" FORMAT=F3.  
      ER34507       LABEL="MARITAL PAIRS INDICATOR               17" FORMAT=F1.  
      ER34508       LABEL="WHETHER MOVED IN/OUT                  17" FORMAT=F1.  
      ER34510       LABEL="YEAR MOVED IN/OUT                     17" FORMAT=F4.  
      ER34511       LABEL="RESPONDENT?                           17" FORMAT=F1.  
      ER34512       LABEL="SN 1ST PERSON WHO HELPED WITH IW      17" FORMAT=F2.  
      ER34513       LABEL="SN 2ND PERSON WHO HELPED WITH IW      17" FORMAT=F2.  
      ER34514       LABEL="SN 3RD PERSON WHO HELPED WITH IW      17" FORMAT=F2.  
      ER34515       LABEL="WTR COVERED BY TANF PAYMENTS IN 2016  17" FORMAT=F1.  
      ER34516       LABEL="EMPLOYMENT STATUS                     17" FORMAT=F1.  
      ER34517       LABEL="YEAR HIGHEST EDUCATION UPDATED        17" FORMAT=F4.  
      ER34518       LABEL="WHETHER EDUCATED IN US                17" FORMAT=F1.  
      ER34519       LABEL="WTR REC HS DIPLOMA/GED/NEITHER        17" FORMAT=F1.  
      ER34520       LABEL="MONTH GRADUATED HIGH SCHOOL           17" FORMAT=F2.  
      ER34521       LABEL="YEAR GRADUATED HIGH SCHOOL            17" FORMAT=F4.  
      ER34522       LABEL="GRADE LEVEL IF GED                    17" FORMAT=F2.  
      ER34524       LABEL="YEAR LAST IN SCHOOL IF GED            17" FORMAT=F4.  
      ER34526       LABEL="YEAR RECEIVED GED                     17" FORMAT=F4.  
      ER34527       LABEL="GRADE OF SCHOOL FINISHED IF NEITHER   17" FORMAT=F2.  
      ER34529       LABEL="YEAR LAST IN SCHOOL IF NEITHER        17" FORMAT=F4.  
      ER34530       LABEL="WTR ATTENDED COLLEGE                  17" FORMAT=F1.  
      ER34534       LABEL="WTR RECEIVED COLLEGE DEGREE           17" FORMAT=F1.  
      ER34535       LABEL="TYPE OF HIGHEST DEGREE                17" FORMAT=F2.  
      ER34539       LABEL="YEAR GRADUATED BACHELOR DEGREE        17" FORMAT=F4.  
      ER34540       LABEL="HIGHEST DEGREE MAJOR MEN1             17" FORMAT=F3.  
      ER34541       LABEL="HIGHEST DEGREE MAJOR MEN2             17" FORMAT=F3.  
      ER34543       LABEL="YEAR GRADUATED HIGHEST DEGREE         17" FORMAT=F4.  
      ER34546       LABEL="WTR CURRENTLY ENROLLED IN SCHOOL      17" FORMAT=F1.  
      ER34547       LABEL="GRADE CURRENTLY ENROLLED              17" FORMAT=F2.  
      ER34548       LABEL="YEARS COMPLETED EDUCATION             17" FORMAT=F2.  
      ER34549       LABEL="UP: WTR ATTENDED SCHOOL SINCE LAST IW 17" FORMAT=F1.  
      ER34550       LABEL="UP: WHETHER EDUCATED IN US            17" FORMAT=F1.  
      ER34551       LABEL="UP: WTR REC HS DIPLOMA/GED/NEITHER    17" FORMAT=F1.  
      ER34553       LABEL="UP: YEAR GRADUATED HIGH SCHOOL        17" FORMAT=F4.  
      ER34556       LABEL="UP: YEAR LAST IN SCHOOL IF GED        17" FORMAT=F4.  
      ER34558       LABEL="UP: YEAR RECEIVED GED                 17" FORMAT=F4.  
      ER34559       LABEL="UP: GRADE SCHOOL FINISHED IF NEITHER  17" FORMAT=F2.  
      ER34561       LABEL="UP: YEAR LAST IN SCHOOL IF NEITHER    17" FORMAT=F4.  
      ER34562       LABEL="UP: WTR ATTENDED COLLEGE              17" FORMAT=F1.  
      ER34564       LABEL="UP: YEAR LAST ATTENDED COLLEGE        17" FORMAT=F4.  
      ER34566       LABEL="UP: WTR RECEIVED COLLEGE DEGREE       17" FORMAT=F1.  
      ER34567       LABEL="UP: TYPE OF HIGHEST DEGREE            17" FORMAT=F2.  
      ER34568       LABEL="UP: BACHELOR DEGREE MAJOR MEN1        17" FORMAT=F3.  
      ER34571       LABEL="UP: YEAR GRADUATED BACHELOR DEGREE    17" FORMAT=F4.  
      ER34572       LABEL="UP: HIGHEST DEGREE MAJOR MEN1         17" FORMAT=F3.  
      ER34575       LABEL="UP: YEAR GRADUATED HIGHEST DEGREE     17" FORMAT=F4.  
      ER34578       LABEL="UP: WTR CURRENTLY ENROLLED IN SCHOOL  17" FORMAT=F1.  
      ER34579       LABEL="UP: GRADE CURRENTLY ENROLLED          17" FORMAT=F2.  
      ER34580       LABEL="HEALTH GOOD?                          17" FORMAT=F1.  
      ER34581       LABEL="H5N/H50A CKPT WTR INDIVIDUAL IS 65+   17" FORMAT=F1.  
      ER34582       LABEL="H5N2/H50B WTR CHNGE MAKING DECISIONS  17" FORMAT=F1.  
      ER34583       LABEL="H5N3/H50C WTR CHNGE INTEREST ACTVTIES 17" FORMAT=F1.  
      ER34584       LABEL="H5N4/H50D WTR CHNGE REPEATNG STORIES  17" FORMAT=F1.  
      ER34585       LABEL="H5N5/H50E WTR CHNGE LEARNING/USE TOOLS17" FORMAT=F1.  
      ER34586       LABEL="H5N6/H50F WTR CHNGE REMEMBERING DATES 17" FORMAT=F1.  
      ER34587       LABEL="H5N7/H50G WTR CHNGE HNDLNG MONEY ISSUE17" FORMAT=F1.  
      ER34588       LABEL="H5N8/H50H WTR CHNGE REMEMBERING APPTS 17" FORMAT=F1.  
      ER34589       LABEL="H5N9/H50I WTR CHNGE IN THINKING/MEMORY17" FORMAT=F1.  
      ER34590       LABEL="WTR ENDORSED 2+ MEMORY PROBLEMS       17" FORMAT=F1.  
      ER34591       LABEL="H61E2 WTR STATE INSURNCE PLN FOR KIDS 17" FORMAT=F1.  
      ER34592       LABEL="H61M MONTHS UNINSURED IN 15           17" FORMAT=F2.  
      ER34593       LABEL="H61N MONTHS UNINSURED IN 16           17" FORMAT=F2.  
      ER34594       LABEL="H61D3 WTR COVERED BY INSURANCE NOW    17" FORMAT=F1.  
      ER34595       LABEL="H61E TYPE CURRENT HEALTH INS MEN 1    17" FORMAT=F2.  
      ER34596       LABEL="H61E TYPE CURRENT HEALTH INS MEN 2    17" FORMAT=F2.  
      ER34597       LABEL="H61E TYPE CURRENT HEALTH INS MEN 3    17" FORMAT=F2.  
      ER34598       LABEL="H61F SN 1ST PERSON EMP PROVIDES INS   17" FORMAT=F2.  
      ER34599       LABEL="H61F SN 2ND PERSON EMP PROVIDES INS   17" FORMAT=F2.  
      ER34600       LABEL="H61G SN 1ST PERSON POLICY HOLDER      17" FORMAT=F2.  
      ER34601       LABEL="H61G SN 2ND PERSON POLICY HOLDER      17" FORMAT=F2.  
      ER34602       LABEL="WHETHER MEDICARE NUMBER GIVEN         17" FORMAT=F1.  
      ER34609       LABEL="G34 AMT SOC SEC RCD                   17" FORMAT=F5.  
      ER34611       LABEL="G76 NUMBER OF JOBS IN PY              17" FORMAT=F1.  
      ER34612       LABEL="G84A_G94B IMPUTED INTEREST            17" FORMAT=F6.  
      ER34614       LABEL="G84B IMPUTED TANF                     17" FORMAT=F6.  
      ER34616       LABEL="G84C_G94C IMPUTED SSI                 17" FORMAT=F6.  
      ER34618       LABEL="G84D_G94D IMPUTED WELFARE             17" FORMAT=F6.  
      ER34620       LABEL="G84F IMPUTED VETERANS BEN             17" FORMAT=F6.  
      ER34622       LABEL="G84G IMPUTED PENSION/ANN              17" FORMAT=F6.  
      ER34624       LABEL="G84H IMPUTED UNEMP COMP               17" FORMAT=F6.  
      ER34626       LABEL="G84J IMPUTED WORKERS COMP             17" FORMAT=F6.  
      ER34628       LABEL="G84K IMPUTED CHILD SUPPORT            17" FORMAT=F6.  
      ER34630       LABEL="G84L IMPUTED HELP FROM RELS           17" FORMAT=F6.  
      ER34632       LABEL="G84M_G94F IMPUTED OTHER INCOME        17" FORMAT=F6.  
      ER34634       LABEL="OFUM BUSINESS LABOR INCOME - IMPUTED  17" FORMAT=F7.  
      ER34635       LABEL="OFUM BUSINESS ASSET INCOME - IMPUTED  17" FORMAT=F7.  
      ER34636       LABEL="OFUM TOTAL LABOR INCOME- IMPUTED      17" FORMAT=F7.  
      ER34638       LABEL="OFUM TOTAL ASSET INCOME - IMPUTED     17" FORMAT=F6.  
      ER34639       LABEL="OFUM TOTAL TAXABLE INCOME - IMPUTED   17" FORMAT=F7.  
      ER34640       LABEL="OFUM TOTAL TRANSFER INCOME -IMPUTED   17" FORMAT=F6.  
      ER34642       LABEL="YEAR S/O FAM FORMED                   17" FORMAT=F4.  
      ER34643       LABEL="MAIN FAM ID FOR S/O                   17" FORMAT=F5.  
      ER34644       LABEL="FOLLOW STATUS                         17" FORMAT=F1.  
      ER34646       LABEL="WTR ELIGIBLE FOR TA                   17" FORMAT=F1.  
      ER34647       LABEL="RESULT OF TA IW ATTEMPT               17" FORMAT=F2.  
      ER34648       LABEL="TYPE OF IND RECORD                    17" FORMAT=F2.  
      ER34649       LABEL="WHY NONRESPONSE                       17" FORMAT=F2.  
      ER34650       LABEL="CORE/IMM INDIVIDUAL LONGITUDINAL WT   17" FORMAT=F7.3 
      ER34651       LABEL="CORE/IMM INDIVIDUAL CROSS-SECTION WT  17" FORMAT=F5.  
   ;
   INFILE J260682 LRECL = 4080 ; 
   INPUT 
      ER30000              1 - 1           ER30001              2 - 5           ER30002              6 - 8     
      ER32000              9 - 9           ER32001             10 - 10          ER32002             11 - 11    
      ER32014             12 - 14          ER32021             15 - 18          ER32022             19 - 20    
      ER32024             21 - 24          ER32026             25 - 28          ER32028             29 - 32    
      ER32030             33 - 36          ER32032             37 - 40          ER32033             41 - 44    
      ER32034             45 - 46          ER32036             47 - 50          ER32037             51 - 51    
      ER32039             52 - 55          ER32041             56 - 59          ER32043             60 - 63    
      ER32044             64 - 64          ER32046             65 - 68          ER32048             69 - 72    
      ER32049             73 - 73          ER32051             74 - 77          ER30003             78 - 78    
      ER30004             79 - 81          ER30005             82 - 82          ER30006             83 - 83    
      ER30008             84 - 87          ER30009             88 - 88          ER30010             89 - 90    
      ER30011             91 - 91          ER30012             92 - 95          ER30013             96 - 99    
      ER30014            100 - 100         ER30016            101 - 101         ER30017            102 - 103   
      ER30018            104 - 105         ER30019            106 - 109         ER30020            110 - 113   
      ER30021            114 - 115         ER30022            116 - 116         ER30023            117 - 119   
      ER30024            120 - 120         ER30025            121 - 121         ER30027            122 - 125   
      ER30028            126 - 126         ER30029            127 - 128         ER30030            129 - 129   
      ER30031            130 - 130         ER30032            131 - 131         ER30033            132 - 136   
      ER30034            137 - 140         ER30035            141 - 141         ER30038            142 - 145   
      ER30039            146 - 149         ER30040            150 - 151         ER30041            152 - 153   
      ER30042            154 - 157         ER30043            158 - 161         ER30044            162 - 163   
      ER30045            164 - 164         ER30046            165 - 167         ER30047            168 - 168   
      ER30048            169 - 169         ER30050            170 - 173         ER30051            174 - 174   
      ER30052            175 - 176         ER30053            177 - 178         ER30054            179 - 179   
      ER30055            180 - 180         ER30056            181 - 181         ER30057            182 - 186   
      ER30058            187 - 190         ER30059            191 - 191         ER30062            192 - 195   
      ER30063            196 - 199         ER30064            200 - 201         ER30065            202 - 203   
      ER30066            204 - 207         ER30067            208 - 211         ER30068            212 - 213   
      ER30069            214 - 214         ER30070            215 - 217         ER30071            218 - 218   
      ER30072            219 - 219         ER30074            220 - 223         ER30075            224 - 224   
      ER30076            225 - 226         ER30077            227 - 228         ER30078            229 - 229   
      ER30079            230 - 230         ER30080            231 - 231         ER30081            232 - 236   
      ER30082            237 - 240         ER30083            241 - 241         ER30086            242 - 245   
      ER30087            246 - 249         ER30088            250 - 251         ER30089            252 - 253   
      ER30090            254 - 257         ER30091            258 - 261         ER30092            262 - 263   
      ER30093            264 - 264         ER30094            265 - 267         ER30095            268 - 268   
      ER30096            269 - 269         ER30098            270 - 273         ER30099            274 - 274   
      ER30100            275 - 276         ER30101            277 - 277         ER30102            278 - 279   
      ER30103            280 - 280         ER30104            281 - 281         ER30105            282 - 282   
      ER30106            283 - 287         ER30107            288 - 291         ER30108            292 - 292   
      ER30110            293 - 294         ER30112            295 - 298         ER30113            299 - 302   
      ER30114            303 - 304         ER30115            305 - 306         ER30116            307 - 310   
      ER30117            311 - 314         ER30118            315 - 316         ER30119            317 - 317   
      ER30120            318 - 320         ER30121            321 - 321         ER30122            322 - 322   
      ER30124            323 - 326         ER30125            327 - 327         ER30126            328 - 329   
      ER30127            330 - 331         ER30128            332 - 332         ER30129            333 - 333   
      ER30130            334 - 338         ER30131            339 - 342         ER30133            343 - 346   
      ER30134            347 - 350         ER30135            351 - 352         ER30136            353 - 354   
      ER30137            355 - 358         ER30138            359 - 362         ER30139            363 - 364   
      ER30140            365 - 365         ER30141            366 - 368         ER30142            369 - 369   
      ER30143            370 - 370         ER30145            371 - 374         ER30146            375 - 375   
      ER30147            376 - 377         ER30148            378 - 379         ER30149            380 - 380   
      ER30150            381 - 381         ER30151            382 - 382         ER30152            383 - 387   
      ER30153            388 - 391         ER30155            392 - 395         ER30156            396 - 399   
      ER30157            400 - 401         ER30158            402 - 403         ER30159            404 - 407   
      ER30160            408 - 411         ER30161            412 - 413         ER30162            414 - 414   
      ER30163            415 - 417         ER30164            418 - 418         ER30165            419 - 419   
      ER30167            420 - 423         ER30168            424 - 424         ER30169            425 - 426   
      ER30170            427 - 427         ER30171            428 - 428         ER30172            429 - 429   
      ER30173            430 - 434         ER30175            435 - 439         ER30177            440 - 443   
      ER30179            444 - 447         ER30181            448 - 449         ER30183            450 - 453   
      ER30184            454 - 457         ER30185            458 - 459         ER30186            460 - 461   
      ER30187            462 - 465         ER30188            466 - 469         ER30189            470 - 471   
      ER30190            472 - 472         ER30191            473 - 475         ER30192            476 - 476   
      ER30193            477 - 477         ER30195            478 - 481         ER30196            482 - 482   
      ER30197            483 - 484         ER30198            485 - 486         ER30199            487 - 487   
      ER30200            488 - 488         ER30201            489 - 489         ER30202            490 - 494   
      ER30204            495 - 498         ER30206            499 - 502         ER30208            503 - 503   
      ER30209            504 - 508         ER30212            509 - 512         ER30213            513 - 516   
      ER30214            517 - 518         ER30215            519 - 520         ER30216            521 - 524   
      ER30217            525 - 528         ER30218            529 - 530         ER30219            531 - 531   
      ER30220            532 - 534         ER30221            535 - 535         ER30222            536 - 536   
      ER30224            537 - 540         ER30225            541 - 541         ER30226            542 - 543   
      ER30227            544 - 545         ER30228            546 - 546         ER30229            547 - 547   
      ER30230            548 - 548         ER30231            549 - 553         ER30233            554 - 557   
      ER30235            558 - 561         ER30237            562 - 563         ER30238            564 - 568   
      ER30241            569 - 572         ER30242            573 - 576         ER30243            577 - 578   
      ER30244            579 - 580         ER30245            581 - 584         ER30246            585 - 588   
      ER30247            589 - 590         ER30248            591 - 591         ER30249            592 - 594   
      ER30250            595 - 595         ER30251            596 - 596         ER30253            597 - 600   
      ER30254            601 - 601         ER30255            602 - 603         ER30256            604 - 605   
      ER30257            606 - 606         ER30259            607 - 607         ER30260            608 - 608   
      ER30261            609 - 610         ER30262            611 - 611         ER30263            612 - 612   
      ER30264            613 - 613         ER30265            614 - 614         ER30266            615 - 615   
      ER30267            616 - 616         ER30268            617 - 621         ER30270            622 - 625   
      ER30272            626 - 629         ER30274            630 - 631         ER30275            632 - 636   
      ER30278            637 - 640         ER30279            641 - 644         ER30280            645 - 646   
      ER30281            647 - 648         ER30282            649 - 652         ER30283            653 - 656   
      ER30284            657 - 658         ER30285            659 - 659         ER30286            660 - 662   
      ER30287            663 - 663         ER30288            664 - 664         ER30290            665 - 668   
      ER30291            669 - 670         ER30292            671 - 671         ER30293            672 - 672   
      ER30294            673 - 673         ER30295            674 - 675         ER30296            676 - 677   
      ER30297            678 - 678         ER30298            679 - 683         ER30300            684 - 687   
      ER30302            688 - 691         ER30304            692 - 693         ER30305            694 - 698   
      ER30308            699 - 702         ER30309            703 - 706         ER30310            707 - 708   
      ER30311            709 - 710         ER30312            711 - 714         ER30313            715 - 718   
      ER30314            719 - 720         ER30315            721 - 721         ER30316            722 - 724   
      ER30317            725 - 725         ER30318            726 - 726         ER30320            727 - 730   
      ER30321            731 - 732         ER30322            733 - 733         ER30323            734 - 734   
      ER30324            735 - 735         ER30325            736 - 737         ER30326            738 - 739   
      ER30327            740 - 740         ER30328            741 - 745         ER30330            746 - 749   
      ER30332            750 - 753         ER30334            754 - 755         ER30335            756 - 760   
      ER30338            761 - 764         ER30339            765 - 768         ER30340            769 - 770   
      ER30341            771 - 772         ER30342            773 - 776         ER30343            777 - 780   
      ER30344            781 - 782         ER30345            783 - 783         ER30346            784 - 786   
      ER30347            787 - 787         ER30348            788 - 788         ER30350            789 - 792   
      ER30351            793 - 794         ER30352            795 - 795         ER30353            796 - 796   
      ER30354            797 - 797         ER30355            798 - 799         ER30356            800 - 801   
      ER30357            802 - 802         ER30358            803 - 807         ER30360            808 - 811   
      ER30362            812 - 815         ER30364            816 - 817         ER30365            818 - 822   
      ER30368            823 - 826         ER30369            827 - 830         ER30370            831 - 832   
      ER30371            833 - 834         ER30372            835 - 838         ER30373            839 - 842   
      ER30374            843 - 844         ER30375            845 - 845         ER30376            846 - 848   
      ER30377            849 - 849         ER30378            850 - 850         ER30380            851 - 854   
      ER30381            855 - 855         ER30382            856 - 856         ER30383            857 - 857   
      ER30384            858 - 859         ER30385            860 - 860         ER30386            861 - 865   
      ER30388            866 - 869         ER30390            870 - 871         ER30391            872 - 876   
      ER30394            877 - 880         ER30395            881 - 884         ER30396            885 - 886   
      ER30397            887 - 888         ER30398            889 - 892         ER30399            893 - 896   
      ER30400            897 - 898         ER30401            899 - 900         ER30402            901 - 903   
      ER30405            904 - 904         ER30406            905 - 905         ER30408            906 - 909   
      ER30409            910 - 911         ER30410            912 - 912         ER30411            913 - 913   
      ER30412            914 - 914         ER30413            915 - 916         ER30414            917 - 917   
      ER30415            918 - 923         ER30417            924 - 927         ER30419            928 - 929   
      ER30420            930 - 934         ER30423            935 - 938         ER30424            939 - 942   
      ER30426            943 - 944         ER30427            945 - 946         ER30428            947 - 950   
      ER30429            951 - 954         ER30430            955 - 956         ER30431            957 - 958   
      ER30432            959 - 961         ER30435            962 - 962         ER30436            963 - 963   
      ER30438            964 - 967         ER30439            968 - 969         ER30440            970 - 970   
      ER30441            971 - 971         ER30442            972 - 972         ER30443            973 - 974   
      ER30444            975 - 975         ER30445            976 - 981         ER30447            982 - 985   
      ER30449            986 - 987         ER30450            988 - 988         ER30451            989 - 993   
      ER30453            994 - 998         ER30455            999 - 1003        ER30457           1004 - 1007  
      ER30458           1008 - 1011        ER30460           1012 - 1013        ER30461           1014 - 1015  
      ER30462           1016 - 1019        ER30463           1020 - 1023        ER30464           1024 - 1025  
      ER30465           1026 - 1027        ER30466           1028 - 1030        ER30469           1031 - 1031  
      ER30470           1032 - 1032        ER30472           1033 - 1036        ER30473           1037 - 1038  
      ER30474           1039 - 1039        ER30476           1040 - 1043        ER30477           1044 - 1044  
      ER30478           1045 - 1046        ER30479           1047 - 1047        ER30480           1048 - 1053  
      ER30482           1054 - 1057        ER30484           1058 - 1059        ER30485           1060 - 1060  
      ER30486           1061 - 1065        ER30488           1066 - 1070        ER30490           1071 - 1075  
      ER30492           1076 - 1079        ER30493           1080 - 1083        ER30495           1084 - 1085  
      ER30496           1086 - 1087        ER30497           1088 - 1091        ER30498           1092 - 1095  
      ER30499           1096 - 1097        ER30500           1098 - 1099        ER30501           1100 - 1102  
      ER30504           1103 - 1103        ER30505           1104 - 1104        ER30507           1105 - 1108  
      ER30508           1109 - 1110        ER30509           1111 - 1111        ER30511           1112 - 1115  
      ER30512           1116 - 1116        ER30513           1117 - 1118        ER30514           1119 - 1119  
      ER30515           1120 - 1125        ER30517           1126 - 1129        ER30519           1130 - 1131  
      ER30520           1132 - 1132        ER30521           1133 - 1137        ER30523           1138 - 1142  
      ER30525           1143 - 1147        ER30526           1148 - 1148        ER30527           1149 - 1149  
      ER30529           1150 - 1153        ER30530           1154 - 1157        ER30532           1158 - 1159  
      ER30533           1160 - 1161        ER30534           1162 - 1165        ER30535           1166 - 1169  
      ER30536           1170 - 1171        ER30537           1172 - 1173        ER30538           1174 - 1176  
      ER30541           1177 - 1177        ER30542           1178 - 1178        ER30544           1179 - 1182  
      ER30545           1183 - 1183        ER30547           1184 - 1187        ER30548           1188 - 1188  
      ER30549           1189 - 1190        ER30550           1191 - 1191        ER30551           1192 - 1197  
      ER30553           1198 - 1201        ER30555           1202 - 1203        ER30556           1204 - 1204  
      ER30557           1205 - 1209        ER30559           1210 - 1214        ER30561           1215 - 1219  
      ER30562           1220 - 1220        ER30564           1221 - 1224        ER30565           1225 - 1228  
      ER30567           1229 - 1230        ER30568           1231 - 1232        ER30569           1233 - 1236  
      ER30570           1237 - 1240        ER30571           1241 - 1242        ER30572           1243 - 1244  
      ER30573           1245 - 1247        ER30576           1248 - 1248        ER30577           1249 - 1249  
      ER30579           1250 - 1253        ER30580           1254 - 1254        ER30582           1255 - 1258  
      ER30583           1259 - 1259        ER30584           1260 - 1261        ER30585           1262 - 1262  
      ER30586           1263 - 1268        ER30588           1269 - 1272        ER30590           1273 - 1274  
      ER30591           1275 - 1275        ER30592           1276 - 1280        ER30594           1281 - 1285  
      ER30596           1286 - 1290        ER30597           1291 - 1291        ER30598           1292 - 1292  
      ER30600           1293 - 1296        ER30601           1297 - 1300        ER30603           1301 - 1302  
      ER30604           1303 - 1304        ER30605           1305 - 1308        ER30606           1309 - 1312  
      ER30607           1313 - 1314        ER30608           1315 - 1316        ER30609           1317 - 1319  
      ER30612           1320 - 1320        ER30613           1321 - 1321        ER30615           1322 - 1325  
      ER30616           1326 - 1326        ER30618           1327 - 1330        ER30619           1331 - 1331  
      ER30620           1332 - 1333        ER30621           1334 - 1334        ER30622           1335 - 1340  
      ER30624           1341 - 1344        ER30626           1345 - 1346        ER30627           1347 - 1347  
      ER30628           1348 - 1352        ER30630           1353 - 1357        ER30632           1358 - 1362  
      ER30633           1363 - 1363        ER30634           1364 - 1364        ER30636           1365 - 1368  
      ER30637           1369 - 1372        ER30639           1373 - 1374        ER30640           1375 - 1376  
      ER30641           1377 - 1380        ER30642           1381 - 1385        ER30643           1386 - 1387  
      ER30644           1388 - 1389        ER30645           1390 - 1392        ER30648           1393 - 1393  
      ER30649           1394 - 1394        ER30651           1395 - 1398        ER30653           1399 - 1399  
      ER30655           1400 - 1403        ER30656           1404 - 1404        ER30657           1405 - 1406  
      ER30658           1407 - 1407        ER30659           1408 - 1413        ER30661           1414 - 1417  
      ER30663           1418 - 1419        ER30664           1420 - 1420        ER30665           1421 - 1425  
      ER30667           1426 - 1430        ER30669           1431 - 1435        ER30670           1436 - 1436  
      ER30671           1437 - 1437        ER30678           1438 - 1441        ER30679           1442 - 1446  
      ER30681           1447 - 1447        ER30682           1448 - 1448        ER30683           1449 - 1449  
      ER30684           1450 - 1451        ER30685           1452 - 1453        ER30686           1454 - 1460  
      ER30687           1461 - 1465        ER30688           1466 - 1472        ER30689           1473 - 1476  
      ER30690           1477 - 1478        ER30691           1479 - 1480        ER30692           1481 - 1483  
      ER30695           1484 - 1484        ER30696           1485 - 1485        ER30698           1486 - 1489  
      ER30699           1490 - 1490        ER30701           1491 - 1494        ER30702           1495 - 1495  
      ER30703           1496 - 1497        ER30704           1498 - 1498        ER30705           1499 - 1504  
      ER30707           1505 - 1510        ER30708           1511 - 1511        ER30709           1512 - 1515  
      ER30711           1516 - 1517        ER30712           1518 - 1518        ER30713           1519 - 1523  
      ER30715           1524 - 1528        ER30717           1529 - 1533        ER30718           1534 - 1534  
      ER30719           1535 - 1535        ER30721           1536 - 1539        ER30722           1540 - 1544  
      ER30724           1545 - 1545        ER30725           1546 - 1546        ER30727           1547 - 1547  
      ER30728           1548 - 1549        ER30729           1550 - 1551        ER30730           1552 - 1558  
      ER30731           1559 - 1563        ER30732           1564 - 1570        ER30733           1571 - 1574  
      ER30734           1575 - 1576        ER30735           1577 - 1578        ER30736           1579 - 1581  
      ER30739           1582 - 1582        ER30740           1583 - 1583        ER30742           1584 - 1587  
      ER30744           1588 - 1588        ER30746           1589 - 1592        ER30747           1593 - 1593  
      ER30748           1594 - 1595        ER30749           1596 - 1596        ER30750           1597 - 1602  
      ER30752           1603 - 1608        ER30753           1609 - 1609        ER30754           1610 - 1613  
      ER30756           1614 - 1615        ER30757           1616 - 1616        ER30758           1617 - 1621  
      ER30760           1622 - 1626        ER30762           1627 - 1631        ER30763           1632 - 1632  
      ER30764           1633 - 1633        ER30770           1634 - 1634        ER30771           1635 - 1635  
      ER30772           1636 - 1636        ER30773           1637 - 1637        ER30774           1638 - 1638  
      ER30775           1639 - 1639        ER30776           1640 - 1640        ER30777           1641 - 1641  
      ER30778           1642 - 1642        ER30779           1643 - 1643        ER30781           1644 - 1644  
      ER30783           1645 - 1645        ER30785           1646 - 1646        ER30787           1647 - 1647  
      ER30789           1648 - 1648        ER30791           1649 - 1649        ER30793           1650 - 1651  
      ER30794           1652 - 1652        ER30796           1653 - 1656        ER30797           1657 - 1661  
      ER30799           1662 - 1662        ER30800           1663 - 1663        ER30801           1664 - 1665  
      ER30802           1666 - 1667        ER30803           1668 - 1674        ER30804           1675 - 1679  
      ER30805           1680 - 1686        ER30806           1687 - 1691        ER30807           1692 - 1693  
      ER30808           1694 - 1695        ER30809           1696 - 1698        ER30812           1699 - 1699  
      ER30813           1700 - 1700        ER30815           1701 - 1704        ER30816           1705 - 1705  
      ER30818           1706 - 1709        ER30819           1710 - 1710        ER30820           1711 - 1712  
      ER30821           1713 - 1718        ER30822           1719 - 1725        ER30823           1726 - 1729  
      ER30824           1730 - 1731        ER30825           1732 - 1737        ER30826           1738 - 1738  
      ER30827           1739 - 1739        ER30828           1740 - 1740        ER30829           1741 - 1741  
      ER30830           1742 - 1742        ER30831           1743 - 1743        ER30832           1744 - 1744  
      ER30833           1745 - 1745        ER30834           1746 - 1746        ER30835           1747 - 1747  
      ER30836           1748 - 1748        ER30837           1749 - 1749        ER30839           1750 - 1750  
      ER30841           1751 - 1751        ER30843           1752 - 1752        ER30845           1753 - 1753  
      ER30847           1754 - 1754        ER30849           1755 - 1755        ER30851           1756 - 1757  
      ER30852           1758 - 1758        ER30857           1759 - 1762        ER30858           1763 - 1767  
      ER30859           1768 - 1768        ER30861           1769 - 1769        ER30862           1770 - 1771  
      ER30863           1772 - 1773        ER33101           1774 - 1778        ER33102           1779 - 1780  
      ER33103           1781 - 1782        ER33104           1783 - 1785        ER33107           1786 - 1786  
      ER33108           1787 - 1787        ER33110           1788 - 1791        ER33111           1792 - 1792  
      ER33113           1793 - 1796        ER33114           1797 - 1797        ER33115           1798 - 1799  
      ER33116           1800 - 1800        ER33117           1801 - 1801        ER33118           1802 - 1802  
      ER33123           1803 - 1806        ER33124           1807 - 1811        ER33125           1812 - 1812  
      ER33126           1813 - 1814        ER33127           1815 - 1816        ER33128           1817 - 1817  
      ER33129           1818 - 1818        ER33130           1819 - 1819        ER33131           1820 - 1820  
      ER33132           1821 - 1821        ER33133           1822 - 1822        ER33134           1823 - 1823  
      ER33135           1824 - 1824        ER33136           1825 - 1825        ER33137           1826 - 1826  
      ER33138           1827 - 1827        ER33140           1828 - 1828        ER33142           1829 - 1829  
      ER33144           1830 - 1830        ER33146           1831 - 1831        ER33148           1832 - 1832  
      ER33201           1833 - 1837        ER33202           1838 - 1839        ER33203           1840 - 1841  
      ER33204           1842 - 1844        ER33207           1845 - 1845        ER33208           1846 - 1846  
      ER33210           1847 - 1850        ER33211           1851 - 1851        ER33213           1852 - 1855  
      ER33214           1856 - 1856        ER33215           1857 - 1858        ER33216           1859 - 1859  
      ER33217           1860 - 1860        ER33218           1861 - 1861        ER33220           1862 - 1862  
      ER33221           1863 - 1863        ER33225           1864 - 1867        ER33226           1868 - 1868  
      ER33230           1869 - 1869        ER33245           1870 - 1870        ER33246           1871 - 1871  
      ER33247           1872 - 1873        ER33259           1874 - 1874        ER33260           1875 - 1875  
      ER33261           1876 - 1876        ER33264           1877 - 1877        ER33265           1878 - 1878  
      ER33266           1879 - 1879        ER33267           1880 - 1880        ER33268           1881 - 1882  
      ER33269           1883 - 1884        ER33271           1885 - 1888        ER33272           1889 - 1889  
      ER33273           1890 - 1890        ER33274           1891 - 1891        ER33279           1892 - 1895  
      ER33280           1896 - 1900        ER33281           1901 - 1901        ER33282           1902 - 1903  
      ER33283           1904 - 1905        ER33284           1906 - 1906        ER33285           1907 - 1907  
      ER33286           1908 - 1908        ER33287           1909 - 1909        ER33288           1910 - 1910  
      ER33289           1911 - 1911        ER33290           1912 - 1912        ER33291           1913 - 1913  
      ER33292           1914 - 1914        ER33293           1915 - 1915        ER33294           1916 - 1916  
      ER33295           1917 - 1917        ER33296           1918 - 1918        ER33297           1919 - 1919  
      ER33298           1920 - 1920        ER33299           1921 - 1921        ER33301           1922 - 1925  
      ER33302           1926 - 1927        ER33303           1928 - 1929        ER33304           1930 - 1932  
      ER33307           1933 - 1933        ER33308           1934 - 1934        ER33310           1935 - 1938  
      ER33311           1939 - 1939        ER33313           1940 - 1943        ER33314           1944 - 1944  
      ER33315           1945 - 1946        ER33316           1947 - 1947        ER33317           1948 - 1948  
      ER33320           1949 - 1952        ER33321           1953 - 1957        ER33322           1958 - 1958  
      ER33324           1959 - 1960        ER33325           1961 - 1962        ER33326           1963 - 1963  
      ER33327           1964 - 1964        ER33328           1965 - 1965        ER33329           1966 - 1966  
      ER33330           1967 - 1967        ER33331           1968 - 1968        ER33332           1969 - 1969  
      ER33333           1970 - 1970        ER33334           1971 - 1971        ER33335           1972 - 1972  
      ER33336           1973 - 1973        ER33338           1974 - 1974        ER33340           1975 - 1975  
      ER33342           1976 - 1976        ER33344           1977 - 1977        ER33346           1978 - 1978  
      ER33401           1979 - 1983        ER33402           1984 - 1985        ER33403           1986 - 1987  
      ER33404           1988 - 1990        ER33407           1991 - 1991        ER33408           1992 - 1992  
      ER33410           1993 - 1996        ER33411           1997 - 1997        ER33413           1998 - 2001  
      ER33414           2002 - 2002        ER33415           2003 - 2004        ER33416           2005 - 2005  
      ER33417           2006 - 2006        ER33418           2007 - 2007        ER33419           2008 - 2008  
      ER33420           2009 - 2010        ER33430           2011 - 2017        ER33432           2018 - 2021  
      ER33433           2022 - 2026        ER33434           2027 - 2027        ER33436           2028 - 2029  
      ER33437           2030 - 2031        ER33438           2032 - 2037        ER33501           2038 - 2042  
      ER33502           2043 - 2044        ER33503           2045 - 2046        ER33504           2047 - 2049  
      ER33507           2050 - 2050        ER33508           2051 - 2051        ER33510           2052 - 2055  
      ER33511           2056 - 2056        ER33512           2057 - 2057        ER33514           2058 - 2061  
      ER33515           2062 - 2062        ER33516           2063 - 2064        ER33517           2065 - 2065  
      ER33518           2066 - 2067        ER33519           2068 - 2069        ER33520           2070 - 2071  
      ER33521           2072 - 2073        ER33522           2074 - 2075        ER33523           2076 - 2077  
      ER33532A          2078 - 2078        ER33532B          2079 - 2080        ER33532C          2081 - 2081  
      ER33532D          2082 - 2082        ER33532E          2083 - 2083        ER33532F          2084 - 2084  
      ER33532G          2085 - 2085        ER33532H          2086 - 2086        ER33532I          2087 - 2087  
      ER33532J          2088 - 2092        ER33532K          2093 - 2096        ER33532X          2097 - 2098  
      ER33532Y          2099 - 2103        ER33533           2104 - 2104        ER33534           2105 - 2105  
      ER33535           2106 - 2106        ER33536           2107 - 2107        ER33536A          2108 - 2117  
      ER33536B          2118 - 2118        ER33536C          2119 - 2120        ER33536P          2121 - 2122  
      ER33536Q          2123 - 2125        ER33537           2126 - 2126        ER33537M          2127 - 2128  
      ER33537N          2129 - 2135        ER33537O          2136 - 2141        ER33538           2142 - 2142  
      ER33540           2143 - 2146        ER33541           2147 - 2151        ER33542           2152 - 2152  
      ER33544           2153 - 2154        ER33545           2155 - 2156        ER33546           2157 - 2163  
      ER33547           2164 - 2168        ER33601           2169 - 2172        ER33602           2173 - 2174  
      ER33603           2175 - 2176        ER33604           2177 - 2179        ER33607           2180 - 2180  
      ER33608           2181 - 2181        ER33610           2182 - 2185        ER33611           2186 - 2186  
      ER33612           2187 - 2187        ER33614           2188 - 2191        ER33615           2192 - 2192  
      ER33616           2193 - 2194        ER33617           2195 - 2195        ER33618           2196 - 2197  
      ER33619           2198 - 2199        ER33620           2200 - 2201        ER33621           2202 - 2203  
      ER33622           2204 - 2205        ER33623           2206 - 2207        ER33623A          2208 - 2208  
      ER33623B          2209 - 2210        ER33623C          2211 - 2211        ER33623D          2212 - 2212  
      ER33623E          2213 - 2213        ER33623F          2214 - 2214        ER33623G          2215 - 2215  
      ER33623H          2216 - 2216        ER33623I          2217 - 2217        ER33623J          2218 - 2222  
      ER33623K          2223 - 2225        ER33623X          2226 - 2227        ER33623Y          2228 - 2232  
      ER33624           2233 - 2233        ER33625           2234 - 2234        ER33626           2235 - 2235  
      ER33627           2236 - 2236        ER33627A          2237 - 2246        ER33627B          2247 - 2247  
      ER33627C          2248 - 2249        ER33627P          2250 - 2251        ER33627Q          2252 - 2254  
      ER33628           2255 - 2255        ER33628M          2256 - 2257        ER33628N          2258 - 2264  
      ER33628O          2265 - 2270        ER33629           2271 - 2271        ER33631           2272 - 2275  
      ER33632           2276 - 2280        ER33633           2281 - 2281        ER33635           2282 - 2283  
      ER33636           2284 - 2285        ER33637           2286 - 2292        ER33638           2293 - 2294  
      ER33639           2295 - 2299        ER33701           2300 - 2304        ER33702           2305 - 2306  
      ER33703           2307 - 2308        ER33704           2309 - 2311        ER33707           2312 - 2312  
      ER33708           2313 - 2313        ER33710           2314 - 2317        ER33711           2318 - 2318  
      ER33712           2319 - 2319        ER33714           2320 - 2323        ER33715           2324 - 2324  
      ER33716           2325 - 2326        ER33717           2327 - 2327        ER33718           2328 - 2329  
      ER33719           2330 - 2331        ER33720           2332 - 2333        ER33721           2334 - 2335  
      ER33722           2336 - 2337        ER33723           2338 - 2339        ER33724           2340 - 2340  
      ER33724A          2341 - 2342        ER33724B          2343 - 2343        ER33724C          2344 - 2344  
      ER33724D          2345 - 2345        ER33724E          2346 - 2346        ER33724F          2347 - 2347  
      ER33724G          2348 - 2348        ER33724H          2349 - 2349        ER33724I          2350 - 2350  
      ER33725           2351 - 2351        ER33726           2352 - 2352        ER33727           2353 - 2353  
      ER33727A          2354 - 2361        ER33727B          2362 - 2362        ER33727C          2363 - 2364  
      ER33727P          2365 - 2366        ER33727Q          2367 - 2369        ER33728           2370 - 2370  
      ER33728M          2371 - 2372        ER33728N          2373 - 2379        ER33728O          2380 - 2385  
      ER33729           2386 - 2386        ER33730           2387 - 2387        ER33731           2388 - 2388  
      ER33732           2389 - 2389        ER33734           2390 - 2393        ER33735           2394 - 2398  
      ER33736           2399 - 2399        ER33738           2400 - 2401        ER33739           2402 - 2403  
      ER33740           2404 - 2410        ER33741           2411 - 2411        ER33742           2412 - 2416  
      ER33801           2417 - 2421        ER33802           2422 - 2423        ER33803           2424 - 2425  
      ER33804           2426 - 2428        ER33807           2429 - 2429        ER33808           2430 - 2430  
      ER33810           2431 - 2434        ER33811           2435 - 2435        ER33812           2436 - 2436  
      ER33813           2437 - 2437        ER33815           2438 - 2441        ER33816           2442 - 2442  
      ER33817           2443 - 2444        ER33818           2445 - 2445        ER33819           2446 - 2447  
      ER33820           2448 - 2449        ER33821           2450 - 2451        ER33822           2452 - 2453  
      ER33823           2454 - 2454        ER33824           2455 - 2456        ER33825           2457 - 2458  
      ER33826           2459 - 2459        ER33826A          2460 - 2467        ER33826B          2468 - 2468  
      ER33827           2469 - 2469        ER33827E          2470 - 2477        ER33827F          2478 - 2478  
      ER33827S          2479 - 2480        ER33827U          2481 - 2483        ER33828           2484 - 2484  
      ER33829           2485 - 2485        ER33830           2486 - 2486        ER33831           2487 - 2487  
      ER33832           2488 - 2488        ER33833           2489 - 2489        ER33833A          2490 - 2491  
      ER33833B          2492 - 2492        ER33833C          2493 - 2493        ER33833D          2494 - 2494  
      ER33833E          2495 - 2495        ER33833F          2496 - 2496        ER33833G          2497 - 2497  
      ER33833H          2498 - 2498        ER33834           2499 - 2499        ER33835           2500 - 2500  
      ER33836           2501 - 2501        ER33837           2502 - 2502        ER33837A          2503 - 2503  
      ER33837B          2504 - 2508        ER33837D          2509 - 2509        ER33837E          2510 - 2515  
      ER33837G          2516 - 2521        ER33837I          2522 - 2527        ER33837K          2528 - 2533  
      ER33837M          2534 - 2539        ER33837O          2540 - 2545        ER33837Q          2546 - 2551  
      ER33837S          2552 - 2557        ER33837U          2558 - 2563        ER33837W          2564 - 2569  
      ER33837Y          2570 - 2575        ER33838           2576 - 2576        ER33838A          2577 - 2583  
      ER33838B          2584 - 2590        ER33838C          2591 - 2597        ER33838E          2598 - 2603  
      ER33838F          2604 - 2610        ER33838G          2611 - 2616        ER33840           2617 - 2620  
      ER33841           2621 - 2625        ER33842           2626 - 2626        ER33844           2627 - 2627  
      ER33845           2628 - 2629        ER33846           2630 - 2631        ER33847           2632 - 2633  
      ER33848           2634 - 2640        ER33849           2641 - 2645        ER33901           2646 - 2650  
      ER33902           2651 - 2652        ER33903           2653 - 2654        ER33904           2655 - 2657  
      ER33907           2658 - 2658        ER33908           2659 - 2659        ER33910           2660 - 2663  
      ER33911           2664 - 2664        ER33912           2665 - 2665        ER33913           2666 - 2666  
      ER33915           2667 - 2670        ER33916           2671 - 2671        ER33917           2672 - 2673  
      ER33918           2674 - 2674        ER33919           2675 - 2676        ER33920           2677 - 2678  
      ER33921           2679 - 2680        ER33922           2681 - 2682        ER33923           2683 - 2683  
      ER33924           2684 - 2685        ER33925           2686 - 2687        ER33925A          2688 - 2688  
      ER33925B          2689 - 2693        ER33925D          2694 - 2694        ER33925E          2695 - 2700  
      ER33925G          2701 - 2706        ER33925I          2707 - 2712        ER33925K          2713 - 2718  
      ER33925M          2719 - 2724        ER33925O          2725 - 2730        ER33925Q          2731 - 2736  
      ER33925S          2737 - 2742        ER33925U          2743 - 2748        ER33925W          2749 - 2754  
      ER33925Y          2755 - 2760        ER33926           2761 - 2761        ER33926A          2762 - 2771  
      ER33926B          2772 - 2772        ER33927           2773 - 2773        ER33927A          2774 - 2775  
      ER33927C          2776 - 2778        ER33928           2779 - 2779        ER33929           2780 - 2780  
      ER33930           2781 - 2781        ER33931           2782 - 2782        ER33932           2783 - 2783  
      ER33933           2784 - 2784        ER33933A          2785 - 2786        ER33933B          2787 - 2787  
      ER33933C          2788 - 2788        ER33933D          2789 - 2789        ER33933E          2790 - 2790  
      ER33933F          2791 - 2791        ER33933G          2792 - 2792        ER33933H          2793 - 2793  
      ER33934           2794 - 2794        ER33935           2795 - 2795        ER33936           2796 - 2796  
      ER33937           2797 - 2797        ER33938           2798 - 2798        ER33938A          2799 - 2805  
      ER33938B          2806 - 2812        ER33938C          2813 - 2819        ER33938E          2820 - 2825  
      ER33938F          2826 - 2832        ER33938G          2833 - 2838        ER33940           2839 - 2842  
      ER33941           2843 - 2847        ER33942           2848 - 2848        ER33944           2849 - 2849  
      ER33945           2850 - 2851        ER33948           2852 - 2853        ER33949           2854 - 2855  
      ER33950           2856 - 2862        ER33951           2863 - 2867        ER34001           2868 - 2872  
      ER34002           2873 - 2874        ER34003           2875 - 2876        ER34004           2877 - 2879  
      ER34007           2880 - 2880        ER34008           2881 - 2881        ER34010           2882 - 2885  
      ER34011           2886 - 2886        ER34012           2887 - 2888        ER34013           2889 - 2890  
      ER34014           2891 - 2892        ER34015           2893 - 2893        ER34016           2894 - 2894  
      ER34018           2895 - 2898        ER34019           2899 - 2899        ER34020           2900 - 2901  
      ER34021           2902 - 2902        ER34022           2903 - 2904        ER34023           2905 - 2906  
      ER34024           2907 - 2908        ER34025           2909 - 2910        ER34026           2911 - 2911  
      ER34027           2912 - 2913        ER34028           2914 - 2915        ER34029           2916 - 2916  
      ER34029A          2917 - 2917        ER34029B          2918 - 2923        ER34029D          2924 - 2929  
      ER34029F          2930 - 2935        ER34029H          2936 - 2941        ER34029J          2942 - 2947  
      ER34029L          2948 - 2953        ER34029N          2954 - 2959        ER34029P          2960 - 2965  
      ER34029R          2966 - 2971        ER34029T          2972 - 2977        ER34029V          2978 - 2983  
      ER34029X          2984 - 2990        ER34029Y          2991 - 2997        ER34030           2998 - 2998  
      ER34031           2999 - 3003        ER34032A          3004 - 3010        ER34032C          3011 - 3016  
      ER34032D          3017 - 3023        ER34032E          3024 - 3029        ER34034           3030 - 3033  
      ER34035           3034 - 3038        ER34036           3039 - 3039        ER34038           3040 - 3040  
      ER34039           3041 - 3042        ER34040           3043 - 3043        ER34041           3044 - 3044  
      ER34042           3045 - 3046        ER34043           3047 - 3048        ER34044           3049 - 3050  
      ER34045           3051 - 3057        ER34046           3058 - 3062        ER34101           3063 - 3067  
      ER34102           3068 - 3069        ER34103           3070 - 3071        ER34104           3072 - 3074  
      ER34107           3075 - 3075        ER34108           3076 - 3076        ER34110           3077 - 3080  
      ER34111           3081 - 3081        ER34112           3082 - 3083        ER34113           3084 - 3085  
      ER34114           3086 - 3087        ER34115           3088 - 3088        ER34116           3089 - 3089  
      ER34118           3090 - 3093        ER34119           3094 - 3095        ER34120           3096 - 3096  
      ER34121           3097 - 3098        ER34122           3099 - 3100        ER34123           3101 - 3102  
      ER34124           3103 - 3104        ER34125           3105 - 3105        ER34126           3106 - 3107  
      ER34127           3108 - 3109        ER34128           3110 - 3110        ER34129           3111 - 3112  
      ER34130           3113 - 3114        ER34131           3115 - 3116        ER34132           3117 - 3118  
      ER34133           3119 - 3120        ER34134           3121 - 3122        ER34135           3123 - 3124  
      ER34136           3125 - 3125        ER34136A          3126 - 3126        ER34136B          3127 - 3132  
      ER34136D          3133 - 3138        ER34136F          3139 - 3144        ER34136H          3145 - 3150  
      ER34136J          3151 - 3156        ER34136L          3157 - 3162        ER34136N          3163 - 3168  
      ER34136P          3169 - 3174        ER34136R          3175 - 3180        ER34136T          3181 - 3186  
      ER34136V          3187 - 3192        ER34136X          3193 - 3199        ER34136Y          3200 - 3206  
      ER34143           3207 - 3211        ER34144A          3212 - 3218        ER34144C          3219 - 3224  
      ER34144D          3225 - 3231        ER34144E          3232 - 3237        ER34146           3238 - 3241  
      ER34147           3242 - 3246        ER34148           3247 - 3247        ER34150           3248 - 3248  
      ER34151           3249 - 3250        ER34152           3251 - 3252        ER34153           3253 - 3254  
      ER34154           3255 - 3261        ER34155           3262 - 3266        ER34201           3267 - 3271  
      ER34202           3272 - 3273        ER34203           3274 - 3275        ER34204           3276 - 3278  
      ER34207           3279 - 3279        ER34208           3280 - 3280        ER34210           3281 - 3284  
      ER34211           3285 - 3285        ER34212           3286 - 3287        ER34213           3288 - 3289  
      ER34214           3290 - 3291        ER34215           3292 - 3292        ER34216           3293 - 3293  
      ER34218           3294 - 3297        ER34219           3298 - 3299        ER34220           3300 - 3300  
      ER34221           3301 - 3302        ER34223           3303 - 3306        ER34226           3307 - 3310  
      ER34227           3311 - 3313        ER34228           3314 - 3314        ER34229           3315 - 3316  
      ER34230           3317 - 3318        ER34231           3319 - 3319        ER34232           3320 - 3320  
      ER34233           3321 - 3322        ER34234           3323 - 3324        ER34235           3325 - 3325  
      ER34236           3326 - 3327        ER34237           3328 - 3329        ER34238           3330 - 3331  
      ER34239           3332 - 3333        ER34240           3334 - 3335        ER34241           3336 - 3337  
      ER34242           3338 - 3339        ER34243           3340 - 3340        ER34243A          3341 - 3341  
      ER34243B          3342 - 3347        ER34243D          3348 - 3353        ER34243F          3354 - 3359  
      ER34243H          3360 - 3365        ER34243J          3366 - 3371        ER34243L          3372 - 3377  
      ER34243N          3378 - 3383        ER34243P          3384 - 3389        ER34243R          3390 - 3395  
      ER34243T          3396 - 3401        ER34243V          3402 - 3407        ER34243X          3408 - 3414  
      ER34243Y          3415 - 3421        ER34250           3422 - 3426        ER34251A          3427 - 3433  
      ER34251C          3434 - 3439        ER34251D          3440 - 3446        ER34251E          3447 - 3452  
      ER34253           3453 - 3456        ER34254           3457 - 3461        ER34255           3462 - 3462  
      ER34257           3463 - 3463        ER34258           3464 - 3465        ER34259           3466 - 3466  
      ER34260           3467 - 3467        ER34261           3468 - 3469        ER34261A          3470 - 3470  
      ER34262           3471 - 3471        ER34263           3472 - 3473        ER34264           3474 - 3474  
      ER34265           3475 - 3476        ER34266           3477 - 3478        ER34267           3479 - 3480  
      ER34268           3481 - 3487        ER34269           3488 - 3492        ER34301           3493 - 3497  
      ER34302           3498 - 3499        ER34303           3500 - 3501        ER34304           3502 - 3502  
      ER34305           3503 - 3505        ER34308           3506 - 3506        ER34309           3507 - 3507  
      ER34311           3508 - 3511        ER34312           3512 - 3512        ER34313           3513 - 3514  
      ER34314           3515 - 3516        ER34315           3517 - 3518        ER34316           3519 - 3519  
      ER34317           3520 - 3520        ER34318           3521 - 3524        ER34319           3525 - 3525  
      ER34320           3526 - 3526        ER34321           3527 - 3528        ER34322           3529 - 3532  
      ER34323           3533 - 3534        ER34325           3535 - 3538        ER34327           3539 - 3542  
      ER34328           3543 - 3544        ER34330           3545 - 3548        ER34331           3549 - 3549  
      ER34335           3550 - 3550        ER34336           3551 - 3552        ER34340           3553 - 3556  
      ER34341           3557 - 3559        ER34342           3560 - 3562        ER34344           3563 - 3566  
      ER34347           3567 - 3567        ER34348           3568 - 3569        ER34349           3570 - 3571  
      ER34350           3572 - 3572        ER34351           3573 - 3573        ER34352           3574 - 3574  
      ER34354           3575 - 3578        ER34357           3579 - 3582        ER34359           3583 - 3586  
      ER34360           3587 - 3588        ER34362           3589 - 3592        ER34363           3593 - 3593  
      ER34365           3594 - 3597        ER34367           3598 - 3598        ER34368           3599 - 3600  
      ER34369           3601 - 3603        ER34372           3604 - 3607        ER34373           3608 - 3610  
      ER34376           3611 - 3614        ER34379           3615 - 3615        ER34380           3616 - 3617  
      ER34381           3618 - 3618        ER34382           3619 - 3619        ER34383           3620 - 3621  
      ER34384           3622 - 3623        ER34385           3624 - 3624        ER34386           3625 - 3626  
      ER34387           3627 - 3628        ER34388           3629 - 3630        ER34389           3631 - 3632  
      ER34390           3633 - 3634        ER34391           3635 - 3636        ER34392           3637 - 3638  
      ER34393           3639 - 3639        ER34393A          3640 - 3640        ER34393B          3641 - 3646  
      ER34393D          3647 - 3652        ER34393F          3653 - 3658        ER34393H          3659 - 3664  
      ER34393J          3665 - 3670        ER34393L          3671 - 3676        ER34393N          3677 - 3682  
      ER34393P          3683 - 3688        ER34393R          3689 - 3694        ER34393T          3695 - 3700  
      ER34393V          3701 - 3706        ER34393X          3707 - 3713        ER34393Y          3714 - 3720  
      ER34400           3721 - 3725        ER34401A          3726 - 3732        ER34401C          3733 - 3738  
      ER34401D          3739 - 3745        ER34401E          3746 - 3751        ER34403           3752 - 3755  
      ER34404           3756 - 3760        ER34405           3761 - 3761        ER34407           3762 - 3762  
      ER34408           3763 - 3764        ER34409           3765 - 3765        ER34410           3766 - 3767  
      ER34411           3768 - 3769        ER34412           3770 - 3771        ER34413           3772 - 3778  
      ER34414           3779 - 3783        ER34501           3784 - 3788        ER34502           3789 - 3790  
      ER34503           3791 - 3792        ER34504           3793 - 3795        ER34507           3796 - 3796  
      ER34508           3797 - 3797        ER34510           3798 - 3801        ER34511           3802 - 3802  
      ER34512           3803 - 3804        ER34513           3805 - 3806        ER34514           3807 - 3808  
      ER34515           3809 - 3809        ER34516           3810 - 3810        ER34517           3811 - 3814  
      ER34518           3815 - 3815        ER34519           3816 - 3816        ER34520           3817 - 3818  
      ER34521           3819 - 3822        ER34522           3823 - 3824        ER34524           3825 - 3828  
      ER34526           3829 - 3832        ER34527           3833 - 3834        ER34529           3835 - 3838  
      ER34530           3839 - 3839        ER34534           3840 - 3840        ER34535           3841 - 3842  
      ER34539           3843 - 3846        ER34540           3847 - 3849        ER34541           3850 - 3852  
      ER34543           3853 - 3856        ER34546           3857 - 3857        ER34547           3858 - 3859  
      ER34548           3860 - 3861        ER34549           3862 - 3862        ER34550           3863 - 3863  
      ER34551           3864 - 3864        ER34553           3865 - 3868        ER34556           3869 - 3872  
      ER34558           3873 - 3876        ER34559           3877 - 3878        ER34561           3879 - 3882  
      ER34562           3883 - 3883        ER34564           3884 - 3887        ER34566           3888 - 3888  
      ER34567           3889 - 3890        ER34568           3891 - 3893        ER34571           3894 - 3897  
      ER34572           3898 - 3900        ER34575           3901 - 3904        ER34578           3905 - 3905  
      ER34579           3906 - 3907        ER34580           3908 - 3908        ER34581           3909 - 3909  
      ER34582           3910 - 3910        ER34583           3911 - 3911        ER34584           3912 - 3912  
      ER34585           3913 - 3913        ER34586           3914 - 3914        ER34587           3915 - 3915  
      ER34588           3916 - 3916        ER34589           3917 - 3917        ER34590           3918 - 3918  
      ER34591           3919 - 3919        ER34592           3920 - 3921        ER34593           3922 - 3923  
      ER34594           3924 - 3924        ER34595           3925 - 3926        ER34596           3927 - 3928  
      ER34597           3929 - 3930        ER34598           3931 - 3932        ER34599           3933 - 3934  
      ER34600           3935 - 3936        ER34601           3937 - 3938        ER34602           3939 - 3939  
      ER34609           3940 - 3944        ER34611           3945 - 3945        ER34612           3946 - 3951  
      ER34614           3952 - 3957        ER34616           3958 - 3963        ER34618           3964 - 3969  
      ER34620           3970 - 3975        ER34622           3976 - 3981        ER34624           3982 - 3987  
      ER34626           3988 - 3993        ER34628           3994 - 3999        ER34630           4000 - 4005  
      ER34632           4006 - 4011        ER34634           4012 - 4018        ER34635           4019 - 4025  
      ER34636           4026 - 4032        ER34638           4033 - 4038        ER34639           4039 - 4045  
      ER34640           4046 - 4051        ER34642           4052 - 4055        ER34643           4056 - 4060  
      ER34644           4061 - 4061        ER34646           4062 - 4062        ER34647           4063 - 4064  
      ER34648           4065 - 4066        ER34649           4067 - 4068        ER34650           4069 - 4075  
      ER34651           4076 - 4080  
   ;
run ;
