/* LAYOUT PARA LEITURA DOS MICRODADOS DO CENSO ESCOLAR */

DATA CENSOESC; 

     INFILE 'd:\DADOS\dados_censoesc.TXT' LRECL=8395 MISSOVER;
     INPUT

@1		MASCARA		    8.		/*	M�scara da Escola	*/
@9		ANO			    5.		/*	Ano do Censo Escolar	*/
@14		CODMUNIC   $CHAR12.	    /*	C�digo do Munic�pio	*/
@26		UF         $CHAR50.	    /*	Nome da Unidade da Federa��o	*/
@76		SIGLA      $CHAR2.		/*	Sigla da UF	*/
@78		MUNIC 	   $CHAR50.   	/*	Nome do Munic�pio	*/
@128	DEP		   $CHAR10.	    /*	Depend�ncia Administrativa	*/
@138	LOC		   $CHAR10.	    /*	Localiza��o/Zona da Escola	*/
@148	CODFUNC	   $CHAR11.	    /*	Condi��o de Funcionamento	*/
@159	NIVELCRE   $CHAR1.		/*	N�vel/Modalidade de Ensino oferecido - Educa��o Infantil - Creche	*/
@160	NIVELPRE   $CHAR1.		/*	N�vel/Modalidade de Ensino oferecido - Educa��o Infantil - Pr�-Escola	*/
@161	NIVELALF   $CHAR1.		/*	N�vel/Modalidade de Ensino oferecido - Classe de Alfabetiza��o	*/
@162	NIV_F1A4   $CHAR1.		/*	N�vel/Modalidade de Ensino oferecido - Ensino Fundamental - 1� a 4� s�rie	*/
@163	NIV_F5A8   $CHAR1.		/*	N�vel/Modalidade de Ensino oferecido - Ensino Fundamental - 5� a 8� s�rie	*/
@164	NIVELMED   $CHAR1.		/*	N�vel/Modalidade de Ensino oferecido - Ensino M�dio	*/
@165	NIVMEDPR   $CHAR1.		/*	N�vel/Modalidade de Ensino oferecido - Ensino M�dio Profissionalizante	*/
@166	NIVMEDMA   $CHAR1.		/*	N�vel/Modalidade de Ensino oferecido - Curso Normal em N�vel M�dio	*/
@167	SUPL_AVA   $CHAR1.		/*	N�vel/Modalidade de Ensino oferecido - Educa��o de Jovens e Adultos - Curso Presencial	*/
@168	SPREPEXC   $CHAR1.		/*	N�vel/Modalidade de Ensino oferecido - Educa��o de Jovens e Adultos - Curso Preparat�rio	*/
@169	SSEMIAVA   $CHAR1.		/*	N�vel/Modalidade de Ensino oferecido - Educa��o de Jovens e Adultos - Curso Semipresencial */
@170	EDPROFIS   $CHAR1.		/*	N�vel/Modalidade de Ensino oferecido - Educa��o Profissional N�vel T�cnico	*/
@171	ESP_EXCL   $CHAR1.		/*	N�vel/Modalidade de Ensino oferecido - Escola Exclusivamente de Educa��o Especial	*/
@172	ESP_T_ES   $CHAR1.		/*	N�vel/Modalidade de Ensino oferecido - Escola de Ensino Regular com Classe Especial	*/
@173	ESP_S_RE   $CHAR1.		/*	N�vel/Modalidade de Ensino oferecido - Escola Inclusiva com apoio de Sala de Recursos	*/
@174	ESP_A_IN   $CHAR1.		/*	N�vel/Modalidade de Ensino oferecido - Escola Inclusiva sem apoio de Sala de Recursos	*/
@175	EDAM14PR   $CHAR1.		/*	Trabalho da Escola na Educa��o Ambiental - 1a a 4a s�rie / projetos	*/
@176	EDAM14DE   $CHAR1.		/*	Trabalho da Escola na Educa��o Ambiental - 1a a 4a s�rie / disciplinas especiais	*/
@177	EDAM14ID   $CHAR1.		/*	Trabalho da Escola na Educa��o Ambiental - 1a a 4a s�rie / inser��o da tem�tica nas disciplinas	*/
@178	EDAM14NT   $CHAR1.		/*	Trabalho da Escola na Educa��o Ambiental - 1a a 4a s�rie / n�o trabalha	*/
@179	EDAM58PR   $CHAR1.		/*	Trabalho da Escola na Educa��o Ambiental - 5a a 8a s�rie / projetos	*/
@180	EDAM58DE   $CHAR1.		/*	Trabalho da Escola na Educa��o Ambiental - 5a a 8a s�rie / disciplinas especiais	*/
@181	EDAM58ID   $CHAR1.		/*	Trabalho da Escola na Educa��o Ambiental - 5a a 8a s�rie / inser��o da tem�tica nas disciplinas	*/
@182	EDAM58NT   $CHAR1.		/*	Trabalho da Escola na Educa��o Ambiental - 5a a 8a s�rie / n�o trabalha	*/
@183	ED_INDIG   $CHAR1.		/*	Escolas destinadas ao atendimento exclusivo de educandos da comunidade ind�gena - Educa��o ind�gena	*/
@184	ED_IN_LM   $CHAR1.		/*	Escolas destinadas ao atendimento exclusivo de educandos da comunidade ind�gena - Educa��o ind�gena / L�ngua Ind�gena	*/
@185	ED_IN_LP   $CHAR1.		/*	Escolas destinadas ao atendimento exclusivo de educandos da comunidade ind�gena - Educa��o ind�gena / L�ngua Portuguesa	*/
@186	MAT_ETNI   $CHAR1.		/*	Escolas destinadas ao atendimento exclusivo de educandos da comunidade ind�gena - Educa��o ind�gena / Materiais did�ticos espec�ficos	*/
@187	ESC_T_IN   $CHAR1.		/*	Escolas destinadas ao atendimento exclusivo de educandos da comunidade ind�gena - Educa��o ind�gena / Localiza��o em terra ind�gena	*/
@188	PRED_ESC   $CHAR1.		/*	Local de funcionamento da escola / Pr�dio escolar	*/
@189	TEMPLO     $CHAR1.		/*	Local de funcionamento da escola / Templo/igreja	*/
@190	EMPRESA    $CHAR1.		/*	Local de funcionamento da escola / Salas de empresa	*/
@191	CAS_PROF   $CHAR1.		/*	Local de funcionamento da escola / Casa do professor	*/
@192	OUTR_ESC   $CHAR1.		/*	Local de funcionamento da escola / Salas em outra escola	*/
@193	GALPAO     $CHAR1.		/*	Local de funcionamento da escola / Galp�o/rancho/paiol/barrac�o	*/
@194	OUTR_INS   $CHAR1.		/*	Local de funcionamento da escola / Outros	*/
@195	PROP_FED   $CHAR1.		/*	Entidade Propriet�ria do Im�vel / Federal	*/
@196	PROP_EST   $CHAR1.		/*	Entidade Propriet�ria do Im�vel / Estadual	*/
@197	PROP_MUN   $CHAR1.		/*	Entidade Propriet�ria do Im�vel / Municipal	*/
@198	PROP_PAR   $CHAR1.		/*	Entidade Propriet�ria do Im�vel / Particular	*/
@199	PROPRIO    $CHAR1.		/*	Forma de Ocupa��o do Pr�dio / Pr�prio	*/
@200	ALUGADO    $CHAR1.		/*	Forma de Ocupa��o do Pr�dio / Alugado	*/
@201	CEDIDO     $CHAR1.		/*	Forma de Ocupa��o do Pr�dio / Cedido	*/
@202	PRED_COM   $CHAR1.		/*	Pr�dio Compartilhado com Outra Escola	*/
@203	DIRETORI   $CHAR1.		/*	Depend�ncias Existentes / Diretoria	*/
@204	SECRETAR   $CHAR1.		/*	Depend�ncias Existentes / Secretaria	*/
@205	SAL_DE_P   $CHAR1.		/*	Depend�ncias Existentes / Sala de Professores	*/
@206	BIBLIOTE   $CHAR1.		/*	Depend�ncias Existentes / Biblioteca	*/
@207	VIDEOTEC   $CHAR1.		/*	Depend�ncias Existentes / Videoteca	*/
@208	SALTVVID   $CHAR1.		/*	Depend�ncias Existentes / Sala para TV/V�deo	*/
@209	SALA_LEI   $CHAR1.		/*	Depend�ncias Existentes / Sala de Leitura	*/
@210	COZINHA    $CHAR1.		/*	Depend�ncias Existentes / Cozinha	*/
@211	CANTINA    $CHAR1.		/*	Depend�ncias Existentes / Cantina	*/
@212	REFEITOR   $CHAR1.		/*	Depend�ncias Existentes / Refeit�rio	*/
@213	DEP_ALIM   $CHAR1.		/*	Depend�ncias Existentes / Dep�sito de Alimentos	*/
@214	ALMOXARI   $CHAR1.		/*	Depend�ncias Existentes / Almoxarifado	*/
@215	LAB_INFO   $CHAR1.		/*	Depend�ncias Existentes / Laborat�rio de Inform�tica	*/
@216	LAB_CIEN   $CHAR1.		/*	Depend�ncias Existentes / Laborat�rio de Ci�ncias	*/
@217	LAB_OUTR   $CHAR1.		/*	Depend�ncias Existentes / Outros Laborat�rios/Oficinas	*/
@218	PARQ_INF   $CHAR1.		/*	Depend�ncias Existentes / Parque Infantil	*/
@219	DORMITOR   $CHAR1.		/*	Depend�ncias Existentes / Dormit�rio	*/
@220	BERCARIO   $CHAR1.		/*	Depend�ncias Existentes / Ber��rio	*/
@221	QUAD_DES   $CHAR1.		/*	Depend�ncias Existentes / Quadra de Esporte Descoberta	*/
@222	QUAD_COB   $CHAR1.		/*	Depend�ncias Existentes / Quadra de Esporte Coberta	*/
@223	PISCINA    $CHAR1.		/*	Depend�ncias Existentes / Piscina	*/
@224	SANI_FOR   $CHAR1.		/*	Depend�ncias Existentes / Sanit�rio fora do Pr�dio	*/
@225	SANI_DEN   $CHAR1.		/*	Depend�ncias Existentes / Sanit�rio dentro do Pr�dio	*/
@226	SANI_PRE   $CHAR1.		/*	Depend�ncias Existentes / Sanit�rio adequado � Pr�-Escola	*/
@227	SANI_ESP   $CHAR1.		/*	Depend�ncias Existentes / Sanit�rio adequado a portadores de defici�ncia	*/
@228	DEP_ESP    $CHAR1.		/*	Depend�ncias Existentes / Depend�ncias e vias para deficientes	*/
@229	NDA        $CHAR1.		/*	Depend�ncias Existentes / Nenhuma das Depend�ncias Relacionadas	*/
@230	FOG_IND    $CHAR1.		/*	Utens�lios de copa/cozinha em uso na escola / Fog�o Industrial	*/
@231	FOG_DOM    $CHAR1.		/*	Utens�lios de copa/cozinha em uso na escola / Fog�o Dom�stico	*/
@232	FOG_LENH   $CHAR1.		/*	Utens�lios de copa/cozinha em uso na escola / Fog�o a Lenha	*/
@233	GELADEIR   $CHAR1.		/*	Utens�lios de copa/cozinha em uso na escola / Geladeira	*/
@234	FREEZER    $CHAR1.		/*	Utens�lios de copa/cozinha em uso na escola / Freezer	*/
@235	FILTRO     $CHAR1.		/*	Utens�lios de copa/cozinha em uso na escola / Filtro	*/
@236	LIQUIDIF   $CHAR1.		/*	Utens�lios de copa/cozinha em uso na escola / Liquidificador	*/
@237	VVIDEO          7.		/*	Equipamento em Uso na Escola / Videocassete	*/
@244	VTV             7.		/*	Equipamento em Uso na Escola / Aparelho de Televis�o	*/
@251	PARABOL         7.		/*	Equipamento em Uso na Escola / Antena Parab�lica	*/
@258	RETRO           7.		/*	Equipamento em Uso na Escola / Retropojetor	*/
@265	VFAX            7.		/*	Equipamento em Uso na Escola / Aparelho de Fax	*/
@272	MIMEOGRA        7.		/*	Equipamento em Uso na Escola / Mime�grafo El�trico	*/
@279	VCOPIAD         7.		/*	Equipamento em Uso na Escola / M�quina Copiadora	*/
@286	ARSALAS         7.		/*	Equipamento em Uso na Escola / Ar-Condicionado em Salas de Aula	*/
@293	VENTILAD        7.		/*	Equipamento em Uso na Escola / Ventilador em Salas de Aula	*/
@300	APSOM           7.		/*	Equipamento em Uso na Escola / Aparelho de Som	*/
@307	APDEFAUD        7.		/*	Equipamento em Uso na Escola / Aparelho p/ Defici�ncia Auditiva	*/
@314	APDEFVIS        7.		/*	Equipamento em Uso na Escola / p/ Defici�ncia Visual	*/
@321	APDEFFIS        7.		/*	Equipamento em Uso na Escola / Defici�ncia F�sica	*/
@328	COMPPENT        7.		/*	Equipamento de Inform�tica em Uso na Escola / Microcomputador Pentium ou superior*/
@335	PC486386        7.		/*	Equipamento de Inform�tica em Uso na Escola / Microcomputador 486/386	*/
@342	COMPOUTR        7.		/*	Equipamento de Inform�tica em Uso na Escola / Microcomputador - outros	*/
@349	VIMPRESS        7.		/*	Equipamento de Inform�tica em Uso na Escola / Impressora	*/
@356	REDE_LOC   $CHAR1.		/*	Os Equipamentos de Inform�tica est�o interligados em rede local	*/
@357	INTERNET   $CHAR1.		/*	A Escola est� ligada na Rede Mundial de Inform�tica (INTERNET)	*/
@358	LT_EXINT   $CHAR1.		/*	A Linha Telef�nica � exclusiva para a INTERNET	*/
@359	INFOPEDA   $CHAR1.		/*	Aplica��o da Inform�tica - Pedag�gico	*/
@360	INFOADM    $CHAR1.		/*	Aplica��o da Inform�tica - Administrativo	*/
@361	INFOLAB    $CHAR1.		/*	Uso dos microcomputadores - Em Laborat�rios	*/
@362	INFOAULA   $CHAR1.		/*	Uso dos microcomputadores - Em Salas de Aula	*/
@363	INFOOUTR   $CHAR1.		/*	Uso dos microcomputadores - Em Outros Usos	*/
@364	ENER_PUB   $CHAR1.		/*	Abastecimento de Energia El�trica / Rede P�blica	*/
@365	ENER_GER   $CHAR1.		/*	Abastecimento de Energia El�trica / Gerador Pr�prio	*/
@366	ENER_SOL   $CHAR1.		/*	Abastecimento de Energia El�trica / Energia Solar	*/
@367	ENER_INE   $CHAR1.		/*	Abastecimento de Energia El�trica / Inexistente	*/
@368	VOLTAGEM   $CHAR10.		/*	Abastecimento de Energia El�trica / Voltagem	*/
@378	AGUA_PUB   $CHAR1.		/*	Abastecimento de �gua / Rede P�blica	*/
@379	AGUA_ART   $CHAR1.		/*	Abastecimento de �gua / Po�o Artesiano	*/
@380	AGUA_CAC   $CHAR1.		/*	Abastecimento de �gua / Cacimba/ Cisterna/ Po�o	*/
@381	AGUA_FON   $CHAR1.		/*	Abastecimento de �gua / Fonte/ Rio/ Igarap�/ Riacho/ C�rrego	*/
@382	AGUA_INE   $CHAR1.		/*	Abastecimento de �gua / Inexistente	*/
@383	ESG_PUB    $CHAR1.		/*	Esgoto Sanit�rio / Rede P�blica	*/
@384	ESG_FOSS   $CHAR1.		/*	Esgoto Sanit�rio / Fossa	*/
@385	ESG_INEX   $CHAR1.		/*	Esgoto Sanit�rio / Inexistente	*/
@386	LIXO_COL   $CHAR1.		/*	Destina��o do Lixo / Coleta Peri�dica	*/
@387	LIXO_REU   $CHAR1.		/*	Destina��o do Lixo / Reutiliza	*/
@388	LIXO_QUE   $CHAR1.		/*	Destina��o do Lixo / Queima	*/
@389	LIXO_REC   $CHAR1.		/*	Destina��o do Lixo / Recicla	*/
@390	LIXO_JOG   $CHAR1.		/*	Destina��o do Lixo / Joga em outra �rea	*/
@391	PAR_ACAO   $CHAR1.		/*	A Escola participa - Programa Par�metros em a��o	*/
@392	COM_SOLI   $CHAR1.		/*	A Escola participa - Alfabetiza��o Solid�ria	*/
@393	REND_MIN   $CHAR1.		/*	A Escola participa - Programa Renda M�nima/Bolsa Escola	*/
@394	FNDE       $CHAR1.		/*	A Escola participa - Programa do FNDE	*/
@395	OUVE_BEM   $CHAR1.		/*	A Escola participa - Programa Quem ouve bem aprende melhor	*/
@396	REAB_VIS   $CHAR1.		/*	A Escola participa - Programa Campanha de Reabilita��o Visual	*/
@397	TRAN_ESC   $CHAR1.		/*	A Escola participa - Programa Nacional de Transporte Escolar	*/
@398	PROGBIBL   $CHAR1.		/*	A Escola participa - Programa Nacional de Biblioteca na Escola	*/
@399	TV_ESC 	   $CHAR1.		/*	A Escola participa - Programa TV-Escola do MEC	*/
@400	PROG_TVE   $CHAR1.		/*	A Escola participa - Outros Programas de TV Educativa	*/
@401	PROINFO    $CHAR1.		/*	A Escola participa - Programa PROINFO/MEC	*/
@402	INFESEST   $CHAR1.		/*	A Escola participa - Programa Estadual de Inform�tica	*/
@403	INFESMUN   $CHAR1.		/*	A Escola participa - Programa Municipal de Inform�tica	*/
@404	OUTR_EST   $CHAR1.		/*	A Escola participa - Outros Programas Estaduais	*/
@405	OUTR_MUN   $CHAR1.		/*	A Escola participa - Outros Programas Municipais	*/
@406	LIV_SER1   $CHAR1.		/*	S�ries que receberam Livro Did�tico para o ano do Censo Escolar - 1� S�rie	*/
@407	LIV_SER2   $CHAR1.		/*	S�ries que receberam Livro Did�tico para o ano do Censo Escolar - 2� S�rie	*/
@408	LIV_SER3   $CHAR1.		/*	S�ries que receberam Livro Did�tico para o ano do Censo Escolar - 3� S�rie	*/
@409	LIV_SER4   $CHAR1.		/*	S�ries que receberam Livro Did�tico para o ano do Censo Escolar - 4� S�rie	*/
@410	LIV_SER5   $CHAR1.		/*	S�ries que receberam Livro Did�tico para o ano do Censo Escolar - 5� S�rie	*/
@411	LIV_SER6   $CHAR1.		/*	S�ries que receberam Livro Did�tico para o ano do Censo Escolar - 6� S�rie	*/
@412	LIV_SER7   $CHAR1.		/*	S�ries que receberam Livro Did�tico para o ano do Censo Escolar - 7� S�rie	*/
@413	LIV_SER8   $CHAR1.		/*	S�ries que receberam Livro Did�tico para o ano do Censo Escolar - 8� S�rie	*/
@414	LIV_REUT   $CHAR1.		/*	Os Livros Did�ticos est�o sendo reutilizados na Escola (no ano do Censo Escolar) ?	*/
@415	MERE_ESC   $CHAR1.		/*	A Escola Oferece Alimenta��o Escolar aos Alunos	*/
@416	CONS_ALI   $CHAR1.		/*	O Conselho de Alimenta��o Escolar visita a Escola	*/
@417	PERMANEN        7.		/*	N�mero de Salas de Aula Existentes - Permanentes	*/
@424	PROVISOR        7.		/*	N�mero de Salas de Aula Existentes - Provis�rias	*/
@431	NOESTAB         7.		/*	N�mero de Salas de Aula Utilizadas - No Estabelecimento	*/
@438	FORAESTA        7.		/*	N�mero de Salas de Aula Utilizadas - Fora do Estabelecimento	*/
@445	FUNCION         7.		/*	Total de Funcion�rios da Escola	*/
@452	PROFESS         7.		/*	Total de Professores em Exerc�cio (em sala de aula)	*/
@459	VDG1CA          7.		/*	N� de Professores na Creche	*/
@466	VDG1C1          7.		/*	N� de Professores na Pr�-Escola	*/
@473	VDG1C2          7.		/*	N� de Professores na Classe de Alfabetiza��o	*/
@480	VDG1C3          7.		/*	N� de Professores no Ensino Fundamental	*/
@487	VDG1C4          7.		/*	N� de Professores no Ensino M�dio e M�dio Profissionalizante	*/
@494	VDG1CB          7.		/*	N� de Professores no Curso Normal em N�vel M�dio	*/
@501	VDG1C5          7.		/*	N� de Professores na Educa��o Especial	*/
@508	VDG1C6          7.		/*	N� de Professores na Educa��o de Jovens e Adultos/Supletivo	*/
@515	VDG1C9          7.		/*	N� de Professores na Educa��o Profissional N�vel T�cnico	*/
@522	VDG1E1          7.		/*	Com Fundamental (1� Grau) Incompleto	*/
@529	VDG1E2          7.		/*	Com Fundamental (1� Grau) Completo	*/
@536	VDG1E3          7.		/*	Com M�dio (2� Grau) Magist�rio Completo	*/
@543	VDG1E4          7.		/*	Com M�dio (2� Grau) Outra Forma��o Completa	*/
@550	VDG1E5          7.		/*	Superior (3� Grau) Licenciatura Completa	*/
@557	VDG1E6          7.		/*	Superior (3� Grau) Completo sem Licenciatura Com Magist�rio	*/
@564	VDG1E7          7.		/*	Superior (3� Grau) Completo sem Licenciatura Sem Magist�rio	*/
@571	VDG1F1          7.		/*	Com Fundamental (1� Grau) Incompleto	*/
@578	VDG1F2          7.		/*	Com Fundamental (1� Grau) Completo	*/
@585	VDG1F3          7.		/*	Com M�dio (2� Grau) Magist�rio Completo	*/
@592	VDG1F4          7.		/*	Com M�dio (2� Grau) Outra Forma��o Completa	*/
@599	VDG1F5          7.		/*	Superior (3� Grau) Licenciatura Completa	*/
@606	VDG1F6          7.		/*	Superior (3� Grau) Completo sem Licenciatura Com Magist�rio	*/
@613	VDG1F7          7.		/*	Superior (3� Grau) Completo sem Licenciatura Sem Magist�rio	*/
@620	VDG121          7.		/*	Com Fundamental (1� Grau) Incompleto	*/
@627	VDG122          7.		/*	Com Fundamental (1� Grau) Completo	*/
@634	VDG123          7.		/*	Com M�dio (2� Grau) Magist�rio Completo	*/
@641	VDG124          7.		/*	Com M�dio (2� Grau) Outra Forma��o Completa	*/
@648	VDG125          7.		/*	Superior (3� Grau) Licenciatura Completa	*/
@655	VDG126          7.		/*	Superior (3� Grau) Completo sem Licenciatura Com Magist�rio	*/
@662	VDG127          7.		/*	Superior (3� Grau) Completo sem Licenciatura Sem Magist�rio	*/
@669	VDG131          7.		/*	Com Fundamental (1� Grau) Incompleto	*/
@676	VDG132          7.		/*	Com Fundamental (1� Grau) Completo	*/
@683	VDG133          7.		/*	Com M�dio (2� Grau) Magist�rio Completo	*/
@690	VDG134          7.		/*	Com M�dio (2� Grau) Outra Forma��o Completa	*/
@697	VDG135          7.		/*	Superior (3� Grau) Licenciatura Completa	*/
@704	VDG136          7.		/*	Superior (3� Grau) Completo sem Licenciatura Com Magist�rio	*/
@711	VDG137          7.		/*	Superior (3� Grau) Completo sem Licenciatura Sem Magist�rio	*/
@718	VDG141          7.		/*	Com Fundamental (1� Grau) Incompleto	*/
@725	VDG142          7.		/*	Com Fundamental (1� Grau) Completo	*/
@732	VDG143          7.		/*	Com M�dio (2� Grau) Magist�rio Completo	*/
@739	VDG144          7.		/*	Com M�dio (2� Grau) Outra Forma��o Completa	*/
@746	VDG145          7.		/*	Superior (3� Grau) Licenciatura Completa	*/
@753	VDG146          7.		/*	Superior (3� Grau) Completo sem Licenciatura Com Magist�rio	*/
@760	VDG147          7.		/*	Superior (3� Grau) Completo sem Licenciatura Sem Magist�rio	*/
@767	VDG151          7.		/*	Com Fundamental (1� Grau) Incompleto	*/
@774	VDG152          7.		/*	Com Fundamental (1� Grau) Completo	*/
@781	VDG153          7.		/*	Com M�dio (2� Grau) Magist�rio Completo	*/
@788	VDG154          7.		/*	Com M�dio (2� Grau) Outra Forma��o Completa	*/
@795	VDG155          7.		/*	Superior (3� Grau) Licenciatura Completa	*/
@802	VDG156          7.		/*	Superior (3� Grau) Completo sem Licenciatura Com Magist�rio	*/
@809	VDG157          7.		/*	Superior (3� Grau) Completo sem Licenciatura Sem Magist�rio	*/
@816	VDG161          7.		/*	Com Fundamental (1� Grau) Incompleto	*/
@823	VDG162          7.		/*	Com Fundamental (1� Grau) Completo	*/
@830	VDG163          7.		/*	Com M�dio (2� Grau) Magist�rio Completo	*/
@837	VDG164          7.		/*	Com M�dio (2� Grau) Outra Forma��o Completa	*/
@844	VDG165          7.		/*	Superior (3� Grau) Licenciatura Completa	*/
@851	VDG166          7.		/*	Superior (3� Grau) Completo sem Licenciatura Com Magist�rio	*/
@858	VDG167          7.		/*	Superior (3� Grau) Completo sem Licenciatura Sem Magist�rio	*/
@865	VDG171          7.		/*	Com Fundamental (1� Grau) Incompleto	*/
@872	VDG172          7.		/*	Com Fundamental (1� Grau) Completo	*/
@879	VDG173          7.		/*	Com M�dio (2� Grau) Magist�rio Completo	*/
@886	VDG174          7.		/*	Com M�dio (2� Grau) Outra Forma��o Completa	*/
@893	VDG175          7.		/*	Superior (3� Grau) Licenciatura Completa	*/
@900	VDG176          7.		/*	Superior (3� Grau) Completo sem Licenciatura Com Magist�rio	*/
@907	VDG177          7.		/*	Superior (3� Grau) Completo sem Licenciatura Sem Magist�rio	*/
@914	VDG1G1          7.		/*	Com Fundamental (1� Grau) Incompleto	*/
@921	VDG1G2          7.		/*	Com Fundamental (1� Grau) Completo	*/
@928	VDG1G3          7.		/*	Com M�dio (2� Grau) Magist�rio Completo	*/
@935	VDG1G4          7.		/*	Com M�dio (2� Grau) Outra Forma��o Completa	*/
@942	VDG1G5          7.		/*	Superior (3� Grau) Licenciatura Completa	*/
@949	VDG1G6          7.		/*	Superior (3� Grau) Completo sem Licenciatura Com Magist�rio	*/
@956	VDG1G7          7.		/*	Superior (3� Grau) Completo sem Licenciatura Sem Magist�rio	*/
@963	VDG181          7.		/*	Com Fundamental (1� Grau) Incompleto	*/
@970	VDG182          7.		/*	Com Fundamental (1� Grau) Completo	*/
@977	VDG183          7.		/*	Com M�dio (2� Grau) Magist�rio Completo	*/
@984	VDG184          7.		/*	Com M�dio (2� Grau) Outra Forma��o Completa	*/
@991	VDG185          7.		/*	Superior (3� Grau) Licenciatura Completa	*/
@998	VDG186          7.		/*	Superior (3� Grau) Completo sem Licenciatura Com Magist�rio	*/
@1005	VDG187          7.		/*	Superior (3� Grau) Completo sem Licenciatura Sem Magist�rio	*/
@1012	VDG191          7.		/*	Com Fundamental (1� Grau) Incompleto	*/
@1019	VDG192          7.		/*	Com Fundamental (1� Grau) Completo	*/
@1026	VDG193          7.		/*	Com M�dio (2� Grau) Magist�rio Completo	*/
@1033	VDG194          7.		/*	Com M�dio (2� Grau) Outra Forma��o Completa	*/
@1040	VDG195          7.		/*	Superior (3� Grau) Licenciatura Completa	*/
@1047	VDG196          7.		/*	Superior (3� Grau) Completo sem Licenciatura Com Magist�rio	*/
@1054	VDG197          7.		/*	Superior (3� Grau) Completo sem Licenciatura Sem Magist�rio	*/
@1061	VDG1H1          7.		/*	Com Fundamental (1� Grau) Incompleto	*/
@1068	VDG1H2          7.		/*	Com Fundamental (1� Grau) Completo	*/
@1075	VDG1H3          7.		/*	Com M�dio (2� Grau) Magist�rio Completo	*/
@1082	VDG1H4          7.		/*	Com M�dio (2� Grau) Outra Forma��o Completa	*/
@1089	VDG1H5          7.		/*	Superior (3� Grau) Licenciatura Completa	*/
@1096	VDG1H6          7.		/*	Superior (3� Grau) Completo sem Licenciatura Com Magist�rio	*/
@1103	VDG1H7          7.		/*	Superior (3� Grau) Completo sem Licenciatura Sem Magist�rio	*/
@1110	VDG1I1          7.		/*	Com Fundamental (1� Grau) Incompleto	*/
@1117	VDG1I2          7.		/*	Com Fundamental (1� Grau) Completo	*/
@1124	VDG1I3          7.		/*	Com M�dio (2� Grau) Magist�rio Completo	*/
@1131	VDG1I4          7.		/*	Com M�dio (2� Grau) Outra Forma��o Completa	*/
@1138	VDG1I5          7.		/*	Superior (3� Grau) Licenciatura Completa	*/
@1145	VDG1I6          7.		/*	Superior (3� Grau) Completo sem Licenciatura Com Magist�rio	*/
@1152	VDG1I7          7.		/*	Superior (3� Grau) Completo sem Licenciatura Sem Magist�rio	*/
@1159	VDG1J1          7.		/*	Com Fundamental (1� Grau) Incompleto	*/
@1166	VDG1J2          7.		/*	Com Fundamental (1� Grau) Completo	*/
@1173	VDG1J3          7.		/*	Com M�dio (2� Grau) Magist�rio Completo	*/
@1180	VDG1J4          7.		/*	Com M�dio (2� Grau) Outra Forma��o Completa	*/
@1187	VDG1J5          7.		/*	Superior (3� Grau) Licenciatura Completa	*/
@1194	VDG1J6          7.		/*	Superior (3� Grau) Completo sem Licenciatura Com Magist�rio	*/
@1201	VDG1J7          7.		/*	Superior (3� Grau) Completo sem Licenciatura Sem Magist�rio	*/
@1208	VDG1K1          7.		/*	Com Fundamental (1� Grau) Incompleto	*/
@1215	VDG1K2          7.		/*	Com Fundamental (1� Grau) Completo	*/
@1222	VDG1K3          7.		/*	Com M�dio (2� Grau) Magist�rio Completo	*/
@1229	VDG1K4          7.		/*	Com M�dio (2� Grau) Outra Forma��o Completa	*/
@1236	VDG1K5          7.		/*	Superior (3� Grau) Licenciatura Completa	*/
@1243	VDG1K6          7.		/*	Superior (3� Grau) Completo sem Licenciatura Com Magist�rio	*/
@1250	VDG1K7          7.		/*	Superior (3� Grau) Completo sem Licenciatura Sem Magist�rio	*/
@1257	VDG1D1          7.		/*	Com Fundamental (1� Grau) Incompleto	*/
@1264	VDG1D2          7.		/*	Com Fundamental (1� Grau) Completo	*/
@1271	VDG1D3          7.		/*	Com M�dio (2� Grau) Magist�rio Completo	*/
@1278	VDG1D4          7.		/*	Com M�dio (2� Grau) Outra Forma��o Completa	*/
@1285	VDG1D5          7.		/*	Superior (3� Grau) Licenciatura Completa	*/
@1292	VDG1D6          7.		/*	Superior (3� Grau) Completo sem Licenciatura Com Magist�rio	*/
@1299	VDG1D7          7.		/*	Superior (3� Grau) Completo sem Licenciatura Sem Magist�rio	*/
@1306	DPE113          7.		/*	Turmas na Creche - Turno Diurno	*/
@1313	DPE119          7.		/*	Matr�culas na Creche - Turno Diurno	*/
@1320	DPE117          7.		/*	Turmas na Pr�-Escola - Turno Diurno	*/
@1327	DPE11D          7.		/*	Matr�culas na Pr�-Escola - Turno Diurno	*/
@1334	NPE113          7.		/*	Turmas na Creche - Turno Noturno	*/
@1341	NPE119          7.		/*	Matr�culas na Creche - Turno Noturno	*/
@1348	NPE117          7.		/*	Turmas na Pr�-Escola - Turno Noturno	*/
@1355	NPE11D          7.		/*	Matr�culas na Pr�-Escola - Turno Noturno	*/
@1362	VPE396          7.		/*	Matr�culas na Creche - Nascidos ap�s 1999	*/
@1369	VPE3A6          7.		/*	Matr�culas na Creche - Nascidos em 1999	*/
@1376	VPE326          7.		/*	Matr�culas na Creche - Nascidos em 1998	*/
@1383	VPE336          7.		/*	Matr�culas na Creche - Nascidos em 1997	*/
@1390	VPE346          7.		/*	Matr�culas na Creche - Nascidos em 1996	*/
@1397	VPE356          7.		/*	Matr�culas na Creche - Nascidos em 1995	*/
@1404	VPE366          7.		/*	Matr�culas na Creche - Nascidos em 1994	*/
@1411	VPE376          7.		/*	Matr�culas na Creche - Nascidos em 1993	*/
@1418	VPE386          7.		/*	Matr�culas na Creche - Nascidos antes de 1993	*/
@1425	VPE397          7.		/*	Matr�culas na Pr�-Escola - Nascidos ap�s 1999	*/
@1432	VPE3A7          7.		/*	Matr�culas na Pr�-Escola - Nascidos em 1999	*/
@1439	VPE327          7.		/*	Matr�culas na Pr�-Escola - Nascidos em 1998	*/
@1446	VPE337          7.		/*	Matr�culas na Pr�-Escola - Nascidos em 1997	*/
@1453	VPE347          7.		/*	Matr�culas na Pr�-Escola - Nascidos em 1996	*/
@1460	VPE357          7.		/*	Matr�culas na Pr�-Escola - Nascidos em 1995	*/
@1467	VPE367          7.		/*	Matr�culas na Pr�-Escola - Nascidos em 1994	*/
@1474	VPE377          7.		/*	Matr�culas na Pr�-Escola - Nascidos em 1993	*/
@1481	VPE387          7.		/*	Matr�culas na Pr�-Escola - Nascidos antes de 1993	*/
@1488	VPE416          7.		/*	Matr�culas na Creche - Masculino	*/
@1495	VPE426          7.		/*	Matr�culas na Creche - Feminino	*/
@1502	VPE417          7.		/*	Matr�culas na Pr�-Escola - Masculino	*/
@1509	VPE427          7.		/*	Matr�culas na Pr�-Escola - Feminino	*/
@1516	DCA113          7.		/*	Turmas na Classe de Alfabetiza��o - Turno Diurno	*/
@1523	DCA114          7.		/*	Matr�culas na Classe de Alfabetiza��o - Turno Diurno	*/
@1530	NCA113          7.		/*	Turmas na Classe de Alfabetiza��o - Turno Noturno	*/
@1537	NCA114          7.		/*	Matr�culas na Classe de Alfabetiza��o - Turno Noturno	*/
@1544	VCA311          7.		/*	Matr�culas na Classe de Alfabetiza��o - Nascidos ap�s 1997	*/
@1551	VCA321          7.		/*	Matr�culas na Classe de Alfabetiza��o - Nascidos em 1997	*/
@1558	VCA331          7.		/*	Matr�culas na Classe de Alfabetiza��o - Nascidos em 1996	*/
@1565	VCA341          7.		/*	Matr�culas na Classe de Alfabetiza��o - Nascidos em 1995	*/
@1572	VCA351          7.		/*	Matr�culas na Classe de Alfabetiza��o - Nascidos em 1994	*/
@1579	VCA361          7.		/*	Matr�culas na Classe de Alfabetiza��o - Nascidos em 1993	*/
@1586	VCA371          7.		/*	Matr�culas na Classe de Alfabetiza��o - Nascidos antes de 1993	*/
@1593	VCA411          7.		/*	Matr�culas na Classe de Alfabetiza��o - Masculino	*/
@1600	VCA421          7.		/*	Matr�culas na Classe de Alfabetiza��o - Feminino	*/
@1607	DEF113          7.		/*	Turmas na 1� S�rie - Turno Diurno	*/
@1614	DEF114          7.		/*	Turmas na 2� S�rie - Turno Diurno	*/
@1621	DEF115          7.		/*	Turmas na 3� S�rie -Turno Diurno	*/
@1628	DEF116          7.		/*	Turmas na 4� S�rie -Turno Diurno	*/
@1635	DEF117          7.		/*	Turmas na 5� S�rie -Turno Diurno	*/
@1642	DEF118          7.		/*	Turmas na 6� S�rie -Turno Diurno	*/
@1649	DEF119          7.		/*	Turmas na 7� S�rie -Turno Diurno	*/
@1656	DEF11A          7.		/*	Turmas na 8� S�rie -Turno Diurno	*/
@1663	DEF11B          7.		/*	Turmas Multisseriadas -Turno Diurno	*/
@1670	DEF11K          7.		/*	Turmas Acelera��o -Turno Diurno	*/
@1677	DEF11C          7.		/*	Matr�culas na 1� S�rie -Turno Diurno	*/
@1684	DEF11D          7.		/*	Matr�culas na 2� S�rie -Turno Diurno	*/
@1691	DEF11E          7.		/*	Matr�culas na 3� S�rie -Turno Diurno	*/
@1698	DEF11F          7.		/*	Matr�culas na 4� S�rie -Turno Diurno	*/
@1705	DEF11G          7.		/*	Matr�culas na 5� S�rie -Turno Diurno	*/
@1712	DEF11H          7.		/*	Matr�culas na 6� S�rie -Turno Diurno	*/
@1719	DEF11I          7.		/*	Matr�culas na 7� S�rie -Turno Diurno	*/
@1726	DEF11J          7.		/*	Matr�culas na 8� S�rie -Turno Diurno	*/
@1733	NEF113          7.		/*	Turmas na 1� S�rie - Turno Noturno	*/
@1740	NEF114          7.		/*	Turmas na 2� S�rie - Turno Noturno	*/
@1747	NEF115          7.		/*	Turmas na 3� S�rie - Turno Noturno	*/
@1754	NEF116          7.		/*	Turmas na 4� S�rie - Turno Noturno	*/
@1761	NEF117          7.		/*	Turmas na 5� S�rie - Turno Noturno	*/
@1768	NEF118          7.		/*	Turmas na 6� S�rie - Turno Noturno	*/
@1775	NEF119          7.		/*	Turmas na 7� S�rie - Turno Noturno	*/
@1782	NEF11A          7.		/*	Turmas na 8� S�rie - Turno Noturno	*/
@1789	NEF11B          7.		/*	Turmas Multisseriadas - Turno Noturno	*/
@1796	NEF11K          7.		/*	Turmas Acelera��o - Turno Noturno	*/
@1803	NEF11C          7.		/*	Matr�culas na 1� S�rie - Turno Noturno	*/
@1810	NEF11D          7.		/*	Matr�culas na 2� S�rie - Turno Noturno	*/
@1817	NEF11E          7.		/*	Matr�culas na 3� S�rie - Turno Noturno	*/
@1824	NEF11F          7.		/*	Matr�culas na 4� S�rie - Turno Noturno	*/
@1831	NEF11G          7.		/*	Matr�culas na 5� S�rie - Turno Noturno	*/
@1838	NEF11H          7.		/*	Matr�culas na 6� S�rie - Turno Noturno	*/
@1845	NEF11I          7.		/*	Matr�culas na 7� S�rie - Turno Noturno	*/
@1852	NEF11J          7.		/*	Matr�culas na 8� S�rie - Turno Noturno	*/
@1859	VEF3L1          7.		/*	Matr�culas na 1� S�rie - Nascidos ap�s 1996	*/
@1866	VEF3M1          7.		/*	Matr�culas na 1� S�rie - Nascidos em 1996	*/
@1873	VEF3M2          7.		/*	Matr�culas na 2� S�rie - Nascidos em 1996	*/
@1880	VEF321          7.		/*	Matr�culas na 1� S�rie - Nascidos em 1995	*/
@1887	VEF322          7.		/*	Matr�culas na 2� S�rie - Nascidos em 1995	*/
@1894	VEF323          7.		/*	Matr�culas na 3� S�rie - Nascidos em 1995	*/
@1901	VEF331          7.		/*	Matr�culas na 1� S�rie - Nascidos em 1994	*/
@1908	VEF332          7.		/*	Matr�culas na 2� S�rie - Nascidos em 1994	*/
@1915	VEF333          7.		/*	Matr�culas na 3� S�rie - Nascidos em 1994	*/
@1922	VEF334          7.		/*	Matr�culas na 4� S�rie - Nascidos em 1994	*/
@1929	VEF341          7.		/*	Matr�culas na 1� S�rie - Nascidos em 1993	*/
@1936	VEF342          7.		/*	Matr�culas na 2� S�rie - Nascidos em 1993	*/
@1943	VEF343          7.		/*	Matr�culas na 3� S�rie - Nascidos em 1993	*/
@1950	VEF344          7.		/*	Matr�culas na 4� S�rie - Nascidos em 1993	*/
@1957	VEF345          7.		/*	Matr�culas na 5� S�rie - Nascidos em 1993	*/
@1964	VEF351          7.		/*	Matr�culas na 1� S�rie - Nascidos em 1992	*/
@1971	VEF352          7.		/*	Matr�culas na 2� S�rie - Nascidos em 1992	*/
@1978	VEF353          7.		/*	Matr�culas na 3� S�rie - Nascidos em 1992	*/
@1985	VEF354          7.		/*	Matr�culas na 4� S�rie - Nascidos em 1992	*/
@1992	VEF355          7.		/*	Matr�culas na 5� S�rie - Nascidos em 1992	*/
@1999	VEF356          7.		/*	Matr�culas na 6� S�rie - Nascidos em 1992	*/
@2006	VEF361          7.		/*	Matr�culas na 1� S�rie - Nascidos em 1991	*/
@2013	VEF362          7.		/*	Matr�culas na 2� S�rie - Nascidos em 1991	*/
@2020	VEF363          7.		/*	Matr�culas na 3� S�rie - Nascidos em 1991	*/
@2027	VEF364          7.		/*	Matr�culas na 4� S�rie - Nascidos em 1991	*/
@2034	VEF365          7.		/*	Matr�culas na 5� S�rie - Nascidos em 1991	*/
@2041	VEF366          7.		/*	Matr�culas na 6� S�rie - Nascidos em 1991	*/
@2048	VEF367          7.		/*	Matr�culas na 7� S�rie - Nascidos em 1991	*/
@2055	VEF371          7.		/*	Matr�culas na 1� S�rie - Nascidos em 1990	*/
@2062	VEF372          7.		/*	Matr�culas na 2� S�rie - Nascidos em 1990	*/
@2069	VEF373          7.		/*	Matr�culas na 3� S�rie - Nascidos em 1990	*/
@2076	VEF374          7.		/*	Matr�culas na 4� S�rie - Nascidos em 1990	*/
@2083	VEF375          7.		/*	Matr�culas na 5� S�rie - Nascidos em 1990	*/
@2090	VEF376          7.		/*	Matr�culas na 6� S�rie - Nascidos em 1990	*/
@2097	VEF377          7.		/*	Matr�culas na 7� S�rie - Nascidos em 1990	*/
@2104	VEF378          7.		/*	Matr�culas na 8� S�rie - Nascidos em 1990	*/
@2111	VEF381          7.		/*	Matr�culas na 1� S�rie - Nascidos em 1989	*/
@2118	VEF382          7.		/*	Matr�culas na 2� S�rie - Nascidos em 1989	*/
@2125	VEF383          7.		/*	Matr�culas na 3� S�rie - Nascidos em 1989	*/
@2132	VEF384          7.		/*	Matr�culas na 4� S�rie - Nascidos em 1989	*/
@2139	VEF385          7.		/*	Matr�culas na 5� S�rie - Nascidos em 1989	*/
@2146	VEF386          7.		/*	Matr�culas na 6� S�rie - Nascidos em 1989	*/
@2153	VEF387          7.		/*	Matr�culas na 7� S�rie - Nascidos em 1989	*/
@2160	VEF388          7.		/*	Matr�culas na 8� S�rie - Nascidos em 1989	*/
@2167	VEF391          7.		/*	Matr�culas na 1� S�rie - Nascidos em 1988	*/
@2174	VEF392          7.		/*	Matr�culas na 2� S�rie - Nascidos em 1988	*/
@2181	VEF393          7.		/*	Matr�culas na 3� S�rie - Nascidos em 1988	*/
@2188	VEF394          7.		/*	Matr�culas na 4� S�rie - Nascidos em 1988	*/
@2195	VEF395          7.		/*	Matr�culas na 5� S�rie - Nascidos em 1988	*/
@2202	VEF396          7.		/*	Matr�culas na 6� S�rie - Nascidos em 1988	*/
@2209	VEF397          7.		/*	Matr�culas na 7� S�rie - Nascidos em 1988	*/
@2216	VEF398          7.		/*	Matr�culas na 8� S�rie - Nascidos em 1988	*/
@2223	VEF3A1          7.		/*	Matr�culas na 1� S�rie - Nascidos em 1987	*/
@2230	VEF3A2          7.		/*	Matr�culas na 2� S�rie - Nascidos em 1987	*/
@2237	VEF3A3          7.		/*	Matr�culas na 3� S�rie - Nascidos em 1987	*/
@2244	VEF3A4          7.		/*	Matr�culas na 4� S�rie - Nascidos em 1987	*/
@2251	VEF3A5          7.		/*	Matr�culas na 5� S�rie - Nascidos em 1987	*/
@2258	VEF3A6          7.		/*	Matr�culas na 6� S�rie - Nascidos em 1987	*/
@2265	VEF3A7          7.		/*	Matr�culas na 7� S�rie - Nascidos em 1987	*/
@2272	VEF3A8          7.		/*	Matr�culas na 8� S�rie - Nascidos em 1987	*/
@2279	VEF3B1          7.		/*	Matr�culas na 1� S�rie - Nascidos em 1986	*/
@2286	VEF3B2          7.		/*	Matr�culas na 2� S�rie - Nascidos em 1986	*/
@2293	VEF3B3          7.		/*	Matr�culas na 3� S�rie - Nascidos em 1986	*/
@2300	VEF3B4          7.		/*	Matr�culas na 4� S�rie - Nascidos em 1986	*/
@2307	VEF3B5          7.		/*	Matr�culas na 5� S�rie - Nascidos em 1986	*/
@2314	VEF3B6          7.		/*	Matr�culas na 6� S�rie - Nascidos em 1986	*/
@2321	VEF3B7          7.		/*	Matr�culas na 7� S�rie - Nascidos em 1986	*/
@2328	VEF3B8          7.		/*	Matr�culas na 8� S�rie - Nascidos em 1986	*/
@2335	VEF3C1          7.		/*	Matr�culas na 1� S�rie - Nascidos em 1985	*/
@2342	VEF3C2          7.		/*	Matr�culas na 2� S�rie - Nascidos em 1985	*/
@2349	VEF3C3          7.		/*	Matr�culas na 3� S�rie - Nascidos em 1985	*/
@2356	VEF3C4          7.		/*	Matr�culas na 4� S�rie - Nascidos em 1985	*/
@2363	VEF3C5          7.		/*	Matr�culas na 5� S�rie - Nascidos em 1985	*/
@2370	VEF3C6          7.		/*	Matr�culas na 6� S�rie - Nascidos em 1985	*/
@2377	VEF3C7          7.		/*	Matr�culas na 7� S�rie - Nascidos em 1985	*/
@2384	VEF3C8          7.		/*	Matr�culas na 8� S�rie - Nascidos em 1985	*/
@2391	VEF3D1          7.		/*	Matr�culas na 1� S�rie - Nascidos em 1984	*/
@2398	VEF3D2          7.		/*	Matr�culas na 2� S�rie - Nascidos em 1984	*/
@2405	VEF3D3          7.		/*	Matr�culas na 3� S�rie - Nascidos em 1984	*/
@2412	VEF3D4          7.		/*	Matr�culas na 4� S�rie - Nascidos em 1984	*/
@2419	VEF3D5          7.		/*	Matr�culas na 5� S�rie - Nascidos em 1984	*/
@2426	VEF3D6          7.		/*	Matr�culas na 6� S�rie - Nascidos em 1984	*/
@2433	VEF3D7          7.		/*	Matr�culas na 7� S�rie - Nascidos em 1984	*/
@2440	VEF3D8          7.		/*	Matr�culas na 8� S�rie - Nascidos em 1984	*/
@2447	VEF3E1          7.		/*	Matr�culas na 1� S�rie - Nascidos em 1983	*/
@2454	VEF3E2          7.		/*	Matr�culas na 2� S�rie - Nascidos em 1983	*/
@2461	VEF3E3          7.		/*	Matr�culas na 3� S�rie - Nascidos em 1983	*/
@2468	VEF3E4          7.		/*	Matr�culas na 4� S�rie - Nascidos em 1983	*/
@2475	VEF3E5          7.		/*	Matr�culas na 5� S�rie - Nascidos em 1983	*/
@2482	VEF3E6          7.		/*	Matr�culas na 6� S�rie - Nascidos em 1983	*/
@2489	VEF3E7          7.		/*	Matr�culas na 7� S�rie - Nascidos em 1983	*/
@2496	VEF3E8          7.		/*	Matr�culas na 8� S�rie - Nascidos em 1983	*/
@2503	VEF3G1          7.		/*	Matr�culas na 1� S�rie - Nascidos de 1982 a 1978	*/
@2510	VEF3G2          7.		/*	Matr�culas na 2� S�rie - Nascidos de 1982 a 1978	*/
@2517	VEF3G3          7.		/*	Matr�culas na 3� S�rie - Nascidos de 1982 a 1978	*/
@2524	VEF3G4          7.		/*	Matr�culas na 4� S�rie - Nascidos de 1982 a 1978	*/
@2531	VEF3G5          7.		/*	Matr�culas na 5� S�rie - Nascidos de 1982 a 1978	*/
@2538	VEF3G6          7.		/*	Matr�culas na 6� S�rie - Nascidos de 1982 a 1978	*/
@2545	VEF3G7          7.		/*	Matr�culas na 7� S�rie - Nascidos de 1982 a 1978	*/
@2552	VEF3G8          7.		/*	Matr�culas na 8� S�rie - Nascidos de 1982 a 1978	*/
@2559	VEF3H1          7.		/*	Matr�culas na 1� S�rie - Nascidos de 1977 a 1973	*/
@2566	VEF3H2          7.		/*	Matr�culas na 2� S�rie - Nascidos de 1977 a 1973	*/
@2573	VEF3H3          7.		/*	Matr�culas na 3� S�rie - Nascidos de 1977 a 1973	*/
@2580	VEF3H4          7.		/*	Matr�culas na 4� S�rie - Nascidos de 1977 a 1973	*/
@2587	VEF3H5          7.		/*	Matr�culas na 5� S�rie - Nascidos de 1977 a 1973	*/
@2594	VEF3H6          7.		/*	Matr�culas na 6� S�rie - Nascidos de 1977 a 1973	*/
@2601	VEF3H7          7.		/*	Matr�culas na 7� S�rie - Nascidos de 1977 a 1973	*/
@2608	VEF3H8          7.		/*	Matr�culas na 8� S�rie - Nascidos de 1977 a 1973	*/
@2615	VEF3I1          7.		/*	Matr�culas na 1� S�rie - Nascidos de 1972 a 1968	*/
@2622	VEF3I2          7.		/*	Matr�culas na 2� S�rie - Nascidos de 1972 a 1968	*/
@2629	VEF3I3          7.		/*	Matr�culas na 3� S�rie - Nascidos de 1972 a 1968	*/
@2636	VEF3I4          7.		/*	Matr�culas na 4� S�rie - Nascidos de 1972 a 1968	*/
@2643	VEF3I5          7.		/*	Matr�culas na 5� S�rie - Nascidos de 1972 a 1968	*/
@2650	VEF3I6          7.		/*	Matr�culas na 6� S�rie - Nascidos de 1972 a 1968	*/
@2657	VEF3I7          7.		/*	Matr�culas na 7� S�rie - Nascidos de 1972 a 1968	*/
@2664	VEF3I8          7.		/*	Matr�culas na 8� S�rie - Nascidos de 1972 a 1968	*/
@2671	VEF3J1          7.		/*	Matr�culas na 1� S�rie - Nascidos de 1967 a 1963	*/
@2678	VEF3J2          7.		/*	Matr�culas na 2� S�rie - Nascidos de 1967 a 1963	*/
@2685	VEF3J3          7.		/*	Matr�culas na 3� S�rie - Nascidos de 1967 a 1963	*/
@2692	VEF3J4          7.		/*	Matr�culas na 4� S�rie - Nascidos de 1967 a 1963	*/
@2699	VEF3J5          7.		/*	Matr�culas na 5� S�rie - Nascidos de 1967 a 1963	*/
@2706	VEF3J6          7.		/*	Matr�culas na 6� S�rie - Nascidos de 1967 a 1963	*/
@2713	VEF3J7          7.		/*	Matr�culas na 7� S�rie - Nascidos de 1967 a 1963	*/
@2720	VEF3J8          7.		/*	Matr�culas na 8� S�rie - Nascidos de 1967 a 1963	*/
@2727	VEF3K1          7.		/*	Matr�culas na 1� S�rie - Nascidos antes de 1963	*/
@2734	VEF3K2          7.		/*	Matr�culas na 2� S�rie - Nascidos antes de 1963	*/
@2741	VEF3K3          7.		/*	Matr�culas na 3� S�rie - Nascidos antes de 1963	*/
@2748	VEF3K4          7.		/*	Matr�culas na 4� S�rie - Nascidos antes de 1963	*/
@2755	VEF3K5          7.		/*	Matr�culas na 5� S�rie - Nascidos antes de 1963	*/
@2762	VEF3K6          7.		/*	Matr�culas na 6� S�rie - Nascidos antes de 1963	*/
@2769	VEF3K7          7.		/*	Matr�culas na 7� S�rie - Nascidos antes de 1963	*/
@2776	VEF3K8          7.		/*	Matr�culas na 8� S�rie - Nascidos antes de 1963	*/
@2783	VEF411          7.		/*	Matr�culas na 1� S�rie - Masculino	*/
@2790	VEF412          7.		/*	Matr�culas na 2� S�rie - Masculino	*/
@2797	VEF413          7.		/*	Matr�culas na 3� S�rie - Masculino	*/
@2804	VEF414          7.		/*	Matr�culas na 4� S�rie - Masculino	*/
@2811	VEF415          7.		/*	Matr�culas na 5� S�rie - Masculino	*/
@2818	VEF416          7.		/*	Matr�culas na 6� S�rie - Masculino	*/
@2825	VEF417          7.		/*	Matr�culas na 7� S�rie - Masculino	*/
@2832	VEF418          7.		/*	Matr�culas na 8� S�rie - Masculino	*/
@2839	VEF421          7.		/*	Matr�culas na 1� S�rie - Feminino	*/
@2846	VEF422          7.		/*	Matr�culas na 2� S�rie - Feminino	*/
@2853	VEF423          7.		/*	Matr�culas na 3� S�rie - Feminino	*/
@2860	VEF424          7.		/*	Matr�culas na 4� S�rie - Feminino	*/
@2867	VEF425          7.		/*	Matr�culas na 5� S�rie - Feminino	*/
@2874	VEF426          7.		/*	Matr�culas na 6� S�rie - Feminino	*/
@2881	VEF427          7.		/*	Matr�culas na 7� S�rie - Feminino	*/
@2888	VEF428          7.		/*	Matr�culas na 8� S�rie - Feminino	*/
@2895	VEF1111         7.		/*	Matr�culas na 1� S�rie - Nas Classes de Acelera��o	*/
@2902	VEF1112         7.		/*	Matr�culas na 2� S�rie - Nas Classes de Acelera��o	*/
@2909	VEF1113         7.		/*	Matr�culas na 3� S�rie - Nas Classes de Acelera��o	*/
@2916	VEF1114         7.		/*	Matr�culas na 4� S�rie - Nas Classes de Acelera��o	*/
@2923	VEF1115         7.		/*	Matr�culas na 5� S�rie - Nas Classes de Acelera��o	*/
@2930	VEF1116         7.		/*	Matr�culas na 6� S�rie - Nas Classes de Acelera��o	*/
@2937	VEF1117         7.		/*	Matr�culas na 7� S�rie - Nas Classes de Acelera��o	*/
@2944	VEF1118         7.		/*	Matr�culas na 8� S�rie - Nas Classes de Acelera��o	*/
@2951	DEF13D1			7.		/*	Concluintes em 2001 - Nascidos ap�s 1988 - Turno Diurno - Masculino	*/
@2958	DEF13E1			7.		/*	Concluintes em 2001 - Nascidos em 1988 - Turno Diurno - Masculino	*/
@2965	DEF13F1			7.		/*	Concluintes em 2001 - Nascidos em 1987 - Turno Diurno - Masculino	*/
@2972	DEF13G1			7.		/*	Concluintes em 2001 - Nascidos em 1986 - Turno Diurno - Masculino	*/
@2979	DEF13H1			7.		/*	Concluintes em 2001 - Nascidos em 1985 - Turno Diurno - Masculino	*/
@2986	DEF13I1			7.		/*	Concluintes em 2001 - Nascidos em 1984 - Turno Diurno - Masculino	*/
@2993	DEF13J1			7.		/*	Concluintes em 2001 - Nascidos em 1983 - Turno Diurno - Masculino	*/
@3000	DEF13K1			7.		/*	Concluintes em 2001 - Nascidos de 1982 a 1978 - Turno Diurno - Masculino	*/
@3007	DEF13L1			7.		/*	Concluintes em 2001 - Nascidos de 1977 a 1973 - Turno Diurno - Masculino	*/
@3014	DEF13M1			7.		/*	Concluintes em 2001 - Nascidos de 1972 a 1968 - Turno Diurno - Masculino	*/
@3021	DEF13N1			7.		/*	Concluintes em 2001 - Nascidos de 1967 a 1963 - Turno Diurno - Masculino	*/
@3028	DEF13O1			7.		/*	Concluintes em 2001 - Nascidos antes de 1963 - Turno Diurno - Masculino	*/
@3035	DEF13D2			7.		/*	Concluintes em 2001 - Nascidos ap�s 1988 - Turno Diurno - Feminino	*/
@3042	DEF13E2			7.		/*	Concluintes em 2001 - Nascidos em 1988 - Turno Diurno - Feminino	*/
@3049	DEF13F2			7.		/*	Concluintes em 2001 - Nascidos em 1987 - Turno Diurno - Feminino	*/
@3056	DEF13G2			7.		/*	Concluintes em 2001 - Nascidos em 1986 - Turno Diurno - Feminino	*/
@3063	DEF13H2			7.		/*	Concluintes em 2001 - Nascidos em 1985 - Turno Diurno - Feminino	*/
@3070	DEF13I2			7.		/*	Concluintes em 2001 - Nascidos em 1984 - Turno Diurno - Feminino	*/
@3077	DEF13J2			7.		/*	Concluintes em 2001 - Nascidos em 1983 - Turno Diurno - Feminino	*/
@3084	DEF13K2			7.		/*	Concluintes em 2001 - Nascidos de 1982 a 1978 - Turno Diurno - Feminino	*/
@3091	DEF13L2			7.		/*	Concluintes em 2001 - Nascidos de 1977 a 1973 - Turno Diurno - Feminino	*/
@3098	DEF13M2			7.		/*	Concluintes em 2001 - Nascidos de 1972 a 1968 - Turno Diurno - Feminino	*/
@3105	DEF13N2			7.		/*	Concluintes em 2001 - Nascidos de 1967 a 1963 - Turno Diurno - Feminino	*/
@3112	DEF13O2			7.		/*	Concluintes em 2001 - Nascidos antes de 1963 - Turno Diurno - Feminino	*/
@3119	NEF13D3			7.		/*	Concluintes em 2001 - Nascidos ap�s 1988 - Turno Noturno - Masculino	*/
@3126	NEF13E3			7.		/*	Concluintes em 2001 - Nascidos em 1988 - Turno Noturno - Masculino	*/
@3133	NEF13F3			7.		/*	Concluintes em 2001 - Nascidos em 1987 - Turno Noturno - Masculino	*/
@3140	NEF13G3			7.		/*	Concluintes em 2001 - Nascidos em 1986 - Turno Noturno - Masculino	*/
@3147	NEF13H3			7.		/*	Concluintes em 2001 - Nascidos em 1985 - Turno Noturno - Masculino	*/
@3154	NEF13I3			7.		/*	Concluintes em 2001 - Nascidos em 1984 - Turno Noturno - Masculino	*/
@3161	NEF13J3			7.		/*	Concluintes em 2001 - Nascidos em 1983 - Turno Noturno - Masculino	*/
@3168	NEF13K3			7.		/*	Concluintes em 2001 - Nascidos de 1982 a 1978 - Turno Noturno - Masculino	*/
@3175	NEF13L3			7.		/*	Concluintes em 2001 - Nascidos de 1977 a 1973 - Turno Noturno - Masculino	*/
@3182	NEF13M3			7.		/*	Concluintes em 2001 - Nascidos de 1972 a 1968 - Turno Noturno - Masculino	*/
@3189	NEF13N3			7.		/*	Concluintes em 2001 - Nascidos de 1967 a 1963 - Turno Noturno - Masculino	*/
@3196	NEF13O3			7.		/*	Concluintes em 2001 - Nascidos antes de 1963 - Turno Noturno - Masculino	*/
@3203	NEF13D4			7.		/*	Concluintes em 2001 - Nascidos ap�s 1988 - Turno Noturno - Feminino	*/
@3210	NEF13E4			7.		/*	Concluintes em 2001 - Nascidos em 1988 - Turno Noturno - Feminino	*/
@3217	NEF13F4			7.		/*	Concluintes em 2001 - Nascidos em 1987 - Turno Noturno - Feminino	*/
@3224	NEF13G4			7.		/*	Concluintes em 2001 - Nascidos em 1986 - Turno Noturno - Feminino	*/
@3231	NEF13H4			7.		/*	Concluintes em 2001 - Nascidos em 1985 - Turno Noturno - Feminino	*/
@3238	NEF13I4			7.		/*	Concluintes em 2001 - Nascidos em 1984 - Turno Noturno - Feminino	*/
@3245	NEF13J4			7.		/*	Concluintes em 2001 - Nascidos em 1983 - Turno Noturno - Feminino	*/
@3252	NEF13K4			7.		/*	Concluintes em 2001 - Nascidos de 1982 a 1978 - Turno Noturno - Feminino	*/
@3259	NEF13L4			7.		/*	Concluintes em 2001 - Nascidos de 1977 a 1973 - Turno Noturno - Feminino	*/
@3266	NEF13M4			7.		/*	Concluintes em 2001 - Nascidos de 1972 a 1968 - Turno Noturno - Feminino	*/
@3273	NEF13N4			7.		/*	Concluintes em 2001 - Nascidos de 1967 a 1963 - Turno Noturno - Feminino	*/
@3280	NEF13O4			7.		/*	Concluintes em 2001 - Nascidos antes de 1963 - Turno Noturno - Feminino	*/
@3287	DEF1611	   $CHAR1.		/*	Dura��o m�nima de 8 anos do Ensino Fundamental	*/
@3288	DEF1612	   $CHAR1.		/*	Dura��o m�nima de 9 anos do Ensino Fundamental	*/
@3289	DEM113          7.		/*	Turmas na 1� S�rie - Turno Diurno	*/
@3296	DEM114          7.		/*	Turmas na 2� S�rie - Turno Diurno	*/
@3303	DEM115          7.		/*	Turmas na 3� S�rie - Turno Diurno	*/
@3310	DEM116          7.		/*	Turmas na 4� S�rie - Turno Diurno	*/
@3317	DEM117          7.		/*	Turmas - N�o Seriada - Turno Diurno	*/
@3324	DEM118          7.		/*	Matr�culas na 1� S�rie - Turno Diurno	*/
@3331	DEM119          7.		/*	Matr�culas na 2� S�rie - Turno Diurno	*/
@3338	DEM11A          7.		/*	Matr�culas na 3� S�rie - Turno Diurno	*/
@3345	DEM11B          7.		/*	Matr�culas na 4� S�rie - Turno Diurno	*/
@3352	DEM11C          7.		/*	Matr�culas - N�o Seriada - Turno Diurno	*/
@3359	NEM113          7.		/*	Turmas na 1� S�rie - Turno Noturno	*/
@3366	NEM114          7.		/*	Turmas na 2� S�rie - Turno Noturno	*/
@3373	NEM115          7.		/*	Turmas na 3� S�rie - Turno Noturno	*/
@3380	NEM116          7.		/*	Turmas na 4� S�rie - Turno Noturno	*/
@3387	NEM117          7.		/*	Turmas - N�o Seriada - Turno Noturno	*/
@3394	NEM118          7.		/*	Matr�culas na 1� S�rie - Turno Noturno	*/
@3401	NEM119          7.		/*	Matr�culas na 2� S�rie - Turno Noturno	*/
@3408	NEM11A          7.		/*	Matr�culas na 3� S�rie - Turno Noturno	*/
@3415	NEM11B          7.		/*	Matr�culas na 4� S�rie - Turno Noturno	*/
@3422	NEM11C          7.		/*	Matr�culas - N�o Seriada - Turno Noturno	*/
@3429	VEM3H1			7.		/*	Matr�culas na 1� S�rie - Nascidos ap�s 1988	*/
@3436	VEM3H2			7.		/*	Matr�culas na 2� S�rie - Nascidos ap�s 1988	*/
@3443	VEM3H3			7.		/*	Matr�culas na 3� S�rie - Nascidos ap�s 1988	*/
@3450	VEM3H4			7.		/*	Matr�culas na 4� S�rie - Nascidos ap�s 1988	*/
@3457	VEM3H5			7.		/*	Matr�culas - N�o Seriada - Nascidos ap�s 1988	*/
@3464	VEM3I1			7.		/*	Matr�culas na 1� S�rie - Nascidos em 1988	*/
@3471	VEM3I2			7.		/*	Matr�culas na 2� S�rie - Nascidos em 1988	*/
@3478	VEM3I3			7.		/*	Matr�culas na 3� S�rie - Nascidos em 1988	*/
@3485	VEM3I4			7.		/*	Matr�culas na 4� S�rie - Nascidos em 1988	*/
@3492	VEM3I5			7.		/*	Matr�culas - N�o Seriada - Nascidos em 1988	*/
@3499	VEM321			7.		/*	Matr�culas na 1� S�rie - Nascidos em 1987	*/
@3506	VEM322			7.		/*	Matr�culas na 2� S�rie - Nascidos em 1987	*/
@3513	VEM323			7.		/*	Matr�culas na 3� S�rie - Nascidos em 1987	*/
@3520	VEM324			7.		/*	Matr�culas na 4� S�rie - Nascidos em 1987	*/
@3527	VEM325			7.		/*	Matr�culas - N�o Seriada - Nascidos em 1987	*/
@3534	VEM331			7.		/*	Matr�culas na 1� S�rie - Nascidos em 1986	*/
@3541	VEM332			7.		/*	Matr�culas na 2� S�rie - Nascidos em 1986	*/
@3548	VEM333			7.		/*	Matr�culas na 3� S�rie - Nascidos em 1986	*/
@3555	VEM334			7.		/*	Matr�culas na 4� S�rie - Nascidos em 1986	*/
@3562	VEM335			7.		/*	Matr�culas - N�o Seriada - Nascidos em 1986	*/
@3569	VEM341			7.		/*	Matr�culas na 1� S�rie - Nascidos em 1985	*/
@3576	VEM342			7.		/*	Matr�culas na 2� S�rie - Nascidos em 1985	*/
@3583	VEM343			7.		/*	Matr�culas na 3� S�rie - Nascidos em 1985	*/
@3590	VEM344			7.		/*	Matr�culas na 4� S�rie - Nascidos em 1985	*/
@3597	VEM345			7.		/*	Matr�culas - N�o Seriada - Nascidos em 1985	*/
@3604	VEM351			7.		/*	Matr�culas na 1� S�rie - Nascidos em 1984	*/
@3611	VEM352			7.		/*	Matr�culas na 2� S�rie - Nascidos em 1984	*/
@3618	VEM353			7.		/*	Matr�culas na 3� S�rie - Nascidos em 1984	*/
@3625	VEM354			7.		/*	Matr�culas na 4� S�rie - Nascidos em 1984	*/
@3632	VEM355			7.		/*	Matr�culas - N�o Seriada - Nascidos em 1984	*/
@3639	VEM361			7.		/*	Matr�culas na 1� S�rie - Nascidos em 1983	*/
@3646	VEM362			7.		/*	Matr�culas na 2� S�rie - Nascidos em 1983	*/
@3653	VEM363			7.		/*	Matr�culas na 3� S�rie - Nascidos em 1983	*/
@3660	VEM364			7.		/*	Matr�culas na 4� S�rie - Nascidos em 1983	*/
@3667	VEM365			7.		/*	Matr�culas - N�o Seriada - Nascidos em 1983	*/
@3674	VEM371			7.		/*	Matr�culas na 1� S�rie - Nascidos em 1982	*/
@3681	VEM372			7.		/*	Matr�culas na 2� S�rie - Nascidos em 1982	*/
@3688	VEM373			7.		/*	Matr�culas na 3� S�rie - Nascidos em 1982	*/
@3695	VEM374			7.		/*	Matr�culas na 4� S�rie - Nascidos em 1982	*/
@3702	VEM375			7.		/*	Matr�culas - N�o Seriada - Nascidos em 1982	*/
@3709	VEM391			7.		/*	Matr�culas na 1� S�rie - Nascidos em 1981	*/
@3716	VEM392			7.		/*	Matr�culas na 2� S�rie - Nascidos em 1981	*/
@3723	VEM393			7.		/*	Matr�culas na 3� S�rie - Nascidos em 1981	*/
@3730	VEM394			7.		/*	Matr�culas na 4� S�rie - Nascidos em 1981	*/
@3737	VEM395			7.		/*	Matr�culas - N�o Seriada - Nascidos em 1981	*/
@3744	VEM3A1			7.		/*	Matr�culas na 1� S�rie - Nascidos em 1980	*/
@3751	VEM3A2			7.		/*	Matr�culas na 2� S�rie - Nascidos em 1980	*/
@3758	VEM3A3			7.		/*	Matr�culas na 3� S�rie - Nascidos em 1980	*/
@3765	VEM3A4			7.		/*	Matr�culas na 4� S�rie - Nascidos em 1980	*/
@3772	VEM3A5			7.		/*	Matr�culas - N�o Seriada - Nascidos em 1980	*/
@3779	VEM3B1			7.		/*	Matr�culas na 1� S�rie - Nascidos em 1979	*/
@3786	VEM3B2			7.		/*	Matr�culas na 2� S�rie - Nascidos em 1979	*/
@3793	VEM3B3			7.		/*	Matr�culas na 3� S�rie - Nascidos em 1979	*/
@3800	VEM3B4			7.		/*	Matr�culas na 4� S�rie - Nascidos em 1979	*/
@3807	VEM3B5			7.		/*	Matr�culas - N�o Seriada - Nascidos em 1979	*/
@3814	VEM3C1			7.		/*	Matr�culas na 1� S�rie - Nascidos em 1978	*/
@3821	VEM3C2			7.		/*	Matr�culas na 2� S�rie - Nascidos em 1978	*/
@3828	VEM3C3			7.		/*	Matr�culas na 3� S�rie - Nascidos em 1978	*/
@3835	VEM3C4			7.		/*	Matr�culas na 4� S�rie - Nascidos em 1978	*/
@3842	VEM3C5			7.		/*	Matr�culas - N�o Seriada - Nascidos em 1978	*/
@3849	VEM3D1			7.		/*	Matr�culas na 1� S�rie - Nascidos de 1977 a 1973	*/
@3856	VEM3D2			7.		/*	Matr�culas na 2� S�rie - Nascidos de 1977 a 1973	*/
@3863	VEM3D3			7.		/*	Matr�culas na 3� S�rie - Nascidos de 1977 a 1973	*/
@3870	VEM3D4			7.		/*	Matr�culas na 4� S�rie - Nascidos de 1977 a 1973	*/
@3877	VEM3D5			7.		/*	Matr�culas - N�o Seriada - Nascidos de 1977 a 1973	*/
@3884	VEM3E1			7.		/*	Matr�culas na 1� S�rie - Nascidos de 1972 a 1968	*/
@3891	VEM3E2			7.		/*	Matr�culas na 2� S�rie - Nascidos de 1972 a 1968	*/
@3898	VEM3E3			7.		/*	Matr�culas na 3� S�rie - Nascidos de 1972 a 1968	*/
@3905	VEM3E4			7.		/*	Matr�culas na 4� S�rie - Nascidos de 1972 a 1968	*/
@3912	VEM3E5			7.		/*	Matr�culas - N�o Seriada - Nascidos de 1972 a 1968	*/
@3919	VEM3F1			7.		/*	Matr�culas na 1� S�rie - Nascidos de 1967 a 1963	*/
@3926	VEM3F2			7.		/*	Matr�culas na 2� S�rie - Nascidos de 1967 a 1963	*/
@3933	VEM3F3			7.		/*	Matr�culas na 3� S�rie - Nascidos de 1967 a 1963	*/
@3940	VEM3F4			7.		/*	Matr�culas na 4� S�rie - Nascidos de 1967 a 1963	*/
@3947	VEM3F5			7.		/*	Matr�culas - N�o Seriada - Nascidos de 1967 a 1963	*/
@3954	VEM3G1			7.		/*	Matr�culas na 1� S�rie - Nascidos antes de 1963	*/
@3961	VEM3G2			7.		/*	Matr�culas na 2� S�rie - Nascidos antes de 1963	*/
@3968	VEM3G3			7.		/*	Matr�culas na 3� S�rie - Nascidos antes de 1963	*/
@3975	VEM3G4			7.		/*	Matr�culas na 4� S�rie - Nascidos antes de 1963	*/
@3982	VEM3G5			7.		/*	Matr�culas - N�o Seriada - Nascidos antes de 1963	*/
@3989	VEM411			7.		/*	Matr�culas na 1� S�rie - Masculino	*/
@3996	VEM412			7.		/*	Matr�culas na 2� S�rie - Masculino	*/
@4003	VEM413			7.		/*	Matr�culas na 3� S�rie - Masculino	*/
@4010	VEM414			7.		/*	Matr�culas na 4� S�rie - Masculino	*/
@4017	VEM415			7.		/*	Matr�culas - N�o Seriada - Masculino	*/
@4024	VEM421			7.		/*	Matr�culas na 1� S�rie - Feminino	*/
@4031	VEM422			7.		/*	Matr�culas na 2� S�rie - Feminino	*/
@4038	VEM423			7.		/*	Matr�culas na 3� S�rie - Feminino	*/
@4045	VEM424			7.		/*	Matr�culas na 4� S�rie - Feminino	*/
@4052	VEM425			7.		/*	Matr�culas - N�o Seriada - Feminino	*/
@4059	VEM1811			7.		/*	Matr�culas na 1� S�rie - Nas Classes de Acelera��o	*/
@4066	VEM1812			7.		/*	Matr�culas na 2� S�rie - Nas Classes de Acelera��o	*/
@4073	DEM17E1			7.		/*	Concluintes em 2001 - Nascidos Ap�s 1985 - Turno Diurno - Masculino	*/
@4080	DEM17F1			7.		/*	Concluintes em 2001 - Nascidos em 1985 - Turno Diurno - Masculino	*/
@4087	DEM17G1			7.		/*	Concluintes em 2001 - Nascidos em 1984 - Turno Diurno - Masculino	*/
@4094	DEM17H1			7.		/*	Concluintes em 2001 - Nascidos em 1983 - Turno Diurno - Masculino	*/
@4101	DEM17I1			7.		/*	Concluintes em 2001 - Nascidos em 1982 - Turno Diurno - Masculino	*/
@4108	DEM17J1			7.		/*	Concluintes em 2001 - Nascidos em 1981 - Turno Diurno - Masculino	*/
@4115	DEM17K1			7.		/*	Concluintes em 2001 - Nascidos em 1980 - Turno Diurno - Masculino	*/
@4122	DEM17L1			7.		/*	Concluintes em 2001 - Nascidos em 1979 - Turno Diurno - Masculino	*/
@4129	DEM17M1			7.		/*	Concluintes em 2001 - Nascidos em 1978 - Turno Diurno - Masculino	*/
@4136	DEM17N1			7.		/*	Concluintes em 2001 - Nascidos de 1977 a 1973 - Turno Diurno - Masculino	*/
@4143	DEM17O1			7.		/*	Concluintes em 2001 - Nascidos de 1972 a 1968 - Turno Diurno - Masculino	*/
@4150	DEM17P1			7.		/*	Concluintes em 2001 - Nascidos de 1967 a 1963 - Turno Diurno - Masculino	*/
@4157	DEM17Q1			7.		/*	Concluintes em 2001 - Nascidos antes de 1963 - Turno Diurno - Masculino	*/
@4164	DEM17E2			7.		/*	Concluintes em 2001 - Nascidos Ap�s 1985 - Turno Diurno - Feminino	*/
@4171	DEM17F2			7.		/*	Concluintes em 2001 - Nascidos em 1985 - Turno Diurno - Feminino	*/
@4178	DEM17G2			7.		/*	Concluintes em 2001 - Nascidos em 1984 - Turno Diurno - Feminino	*/
@4185	DEM17H2			7.		/*	Concluintes em 2001 - Nascidos em 1983 - Turno Diurno - Feminino	*/
@4192	DEM17I2			7.		/*	Concluintes em 2001 - Nascidos em 1982 - Turno Diurno - Feminino	*/
@4199	DEM17J2			7.		/*	Concluintes em 2001 - Nascidos em 1981 - Turno Diurno - Feminino	*/
@4206	DEM17K2			7.		/*	Concluintes em 2001 - Nascidos em 1980 - Turno Diurno - Feminino	*/
@4213	DEM17L2			7.		/*	Concluintes em 2001 - Nascidos em 1979 - Turno Diurno - Feminino	*/
@4220	DEM17M2			7.		/*	Concluintes em 2001 - Nascidos em 1978 - Turno Diurno - Feminino	*/
@4227	DEM17N2			7.		/*	Concluintes em 2001 - Nascidos de 1977 a 1973 - Turno Diurno - Feminino	*/
@4234	DEM17O2			7.		/*	Concluintes em 2001 - Nascidos de 1972 a 1968 - Turno Diurno - Feminino	*/
@4241	DEM17P2			7.		/*	Concluintes em 2001 - Nascidos de 1967 a 1963 - Turno Diurno - Feminino	*/
@4248	DEM17Q2			7.		/*	Concluintes em 2001 - Nascidos antes de 1963 - Turno Diurno - Feminino	*/
@4255	NEM17E3			7.		/*	Concluintes em 2001 - Nascidos Ap�s 1985 - Turno Noturno - Masculino	*/
@4262	NEM17F3			7.		/*	Concluintes em 2001 - Nascidos em 1985 - Turno Noturno - Masculino	*/
@4269	NEM17G3			7.		/*	Concluintes em 2001 - Nascidos em 1984 - Turno Noturno - Masculino	*/
@4276	NEM17H3			7.		/*	Concluintes em 2001 - Nascidos em 1983 - Turno Noturno - Masculino	*/
@4283	NEM17I3			7.		/*	Concluintes em 2001 - Nascidos em 1982 - Turno Noturno - Masculino	*/
@4290	NEM17J3			7.		/*	Concluintes em 2001 - Nascidos em 1981 - Turno Noturno - Masculino	*/
@4297	NEM17K3			7.		/*	Concluintes em 2001 - Nascidos em 1980 - Turno Noturno - Masculino	*/
@4304	NEM17L3			7.		/*	Concluintes em 2001 - Nascidos em 1979 - Turno Noturno - Masculino	*/
@4311	NEM17M3			7.		/*	Concluintes em 2001 - Nascidos em 1978 - Turno Noturno - Masculino	*/
@4318	NEM17N3			7.		/*	Concluintes em 2001 - Nascidos de 1977 a 1973 - Turno Noturno - Masculino	*/
@4325	NEM17O3			7.		/*	Concluintes em 2001 - Nascidos de 1972 a 1968 - Turno Noturno - Masculino	*/
@4332	NEM17P3			7.		/*	Concluintes em 2001 - Nascidos de 1967 a 1963 - Turno Noturno - Masculino	*/
@4339	NEM17Q3			7.		/*	Concluintes em 2001 - Nascidos antes de 1963 - Turno Noturno - Masculino	*/
@4346	NEM17E4			7.		/*	Concluintes em 2001 - Nascidos Ap�s 1985 - Turno Noturno - Feminino	*/
@4353	NEM17F4			7.		/*	Concluintes em 2001 - Nascidos em 1985 - Turno Noturno - Feminino	*/
@4360	NEM17G4			7.		/*	Concluintes em 2001 - Nascidos em 1984 - Turno Noturno - Feminino	*/
@4367	NEM17H4			7.		/*	Concluintes em 2001 - Nascidos em 1983 - Turno Noturno - Feminino	*/
@4374	NEM17I4			7.		/*	Concluintes em 2001 - Nascidos em 1982 - Turno Noturno - Feminino	*/
@4381	NEM17J4			7.		/*	Concluintes em 2001 - Nascidos em 1981 - Turno Noturno - Feminino	*/
@4388	NEM17K4			7.		/*	Concluintes em 2001 - Nascidos em 1980 - Turno Noturno - Feminino	*/
@4395	NEM17L4			7.		/*	Concluintes em 2001 - Nascidos em 1979 - Turno Noturno - Feminino	*/
@4402	NEM17M4			7.		/*	Concluintes em 2001 - Nascidos em 1978 - Turno Noturno - Feminino	*/
@4409	NEM17N4			7.		/*	Concluintes em 2001 - Nascidos de 1977 a 1973 - Turno Noturno - Feminino	*/
@4416	NEM17O4			7.		/*	Concluintes em 2001 - Nascidos de 1972 a 1968 - Turno Noturno - Feminino	*/
@4423	NEM17P4			7.		/*	Concluintes em 2001 - Nascidos de 1967 a 1963 - Turno Noturno - Feminino	*/
@4430	NEM17Q4			7.		/*	Concluintes em 2001 - Nascidos antes de 1963 - Turno Noturno - Feminino	*/
@4437	DCN113          7.		/*	Turmas na 1� S�rie - Turno Diurno	*/
@4444	DCN114          7.		/*	Turmas na 2� S�rie - Turno Diurno	*/
@4451	DCN115          7.		/*	Turmas na 3� S�rie - Turno Diurno	*/
@4458	DCN116          7.		/*	Turmas na 4� S�rie - Turno Diurno	*/
@4465	DCN117          7.		/*	Turmas - N�o Seriada - Turno Diurno	*/
@4472	DCN118          7.		/*	Matr�culas na 1� S�rie - Turno Diurno	*/
@4479	DCN119          7.		/*	Matr�culas na 2� S�rie - Turno Diurno	*/
@4486	DCN11A          7.		/*	Matr�culas na 3� S�rie - Turno Diurno	*/
@4493	DCN11B          7.		/*	Matr�culas na 4� S�rie - Turno Diurno	*/
@4500	DCN11C          7.		/*	Matr�culas - N�o Seriada - Turno Diurno	*/
@4507	NCN113          7.		/*	Turmas na 1� S�rie - Turno Noturno	*/
@4514	NCN114          7.		/*	Turmas na 2� S�rie - Turno Noturno	*/
@4521	NCN115          7.		/*	Turmas na 3� S�rie - Turno Noturno	*/
@4528	NCN116          7.		/*	Turmas na 4� S�rie - Turno Noturno	*/
@4535	NCN117          7.		/*	Turmas - N�o Seriada - Turno Noturno	*/
@4542	NCN118          7.		/*	Matr�culas na 1� S�rie - Turno Noturno	*/
@4549	NCN119          7.		/*	Matr�culas na 2� S�rie - Turno Noturno	*/
@4556	NCN11A          7.		/*	Matr�culas na 3� S�rie - Turno Noturno	*/
@4563	NCN11B          7.		/*	Matr�culas na 4� S�rie - Turno Noturno	*/
@4570	NCN11C          7.		/*	Matr�culas - N�o Seriada - Turno Noturno	*/
@4577	VCN211			7.		/*	Matr�culas na 1� S�rie - Nascidos ap�s 1988	*/
@4584	VCN212			7.		/*	Matr�culas na 2� S�rie - Nascidos ap�s 1988	*/
@4591	VCN213			7.		/*	Matr�culas na 3� S�rie - Nascidos ap�s 1988	*/
@4598	VCN214			7.		/*	Matr�culas na 4� S�rie - Nascidos ap�s 1988	*/
@4605	VCN215			7.		/*	Matr�culas - N�o Seriada - Nascidos ap�s 1988	*/
@4612	VCN221			7.		/*	Matr�culas na 1� S�rie - Nascidos em 1988	*/
@4619	VCN222			7.		/*	Matr�culas na 2� S�rie - Nascidos em 1988	*/
@4626	VCN223			7.		/*	Matr�culas na 3� S�rie - Nascidos em 1988	*/
@4633	VCN224			7.		/*	Matr�culas na 4� S�rie - Nascidos em 1988	*/
@4640	VCN225			7.		/*	Matr�culas - N�o Seriada - Nascidos em 1988	*/
@4647	VCN231			7.		/*	Matr�culas na 1� S�rie - Nascidos em 1987	*/
@4654	VCN232			7.		/*	Matr�culas na 2� S�rie - Nascidos em 1987	*/
@4661	VCN233			7.		/*	Matr�culas na 3� S�rie - Nascidos em 1987	*/
@4668	VCN234			7.		/*	Matr�culas na 4� S�rie - Nascidos em 1987	*/
@4675	VCN235			7.		/*	Matr�culas - N�o Seriada - Nascidos em 1987	*/
@4682	VCN241			7.		/*	Matr�culas na 1� S�rie - Nascidos em 1986	*/
@4689	VCN242			7.		/*	Matr�culas na 2� S�rie - Nascidos em 1986	*/
@4696	VCN243			7.		/*	Matr�culas na 3� S�rie - Nascidos em 1986	*/
@4703	VCN244			7.		/*	Matr�culas na 4� S�rie - Nascidos em 1986	*/
@4710	VCN245			7.		/*	Matr�culas - N�o Seriada - Nascidos em 1986	*/
@4717	VCN251			7.		/*	Matr�culas na 1� S�rie - Nascidos em 1985	*/
@4724	VCN252			7.		/*	Matr�culas na 2� S�rie - Nascidos em 1985	*/
@4731	VCN253			7.		/*	Matr�culas na 3� S�rie - Nascidos em 1985	*/
@4738	VCN254			7.		/*	Matr�culas na 4� S�rie - Nascidos em 1985	*/
@4745	VCN255			7.		/*	Matr�culas - N�o Seriada - Nascidos em 1985	*/
@4752	VCN261			7.		/*	Matr�culas na 1� S�rie - Nascidos em 1984	*/
@4759	VCN262			7.		/*	Matr�culas na 2� S�rie - Nascidos em 1984	*/
@4766	VCN263			7.		/*	Matr�culas na 3� S�rie - Nascidos em 1984	*/
@4773	VCN264			7.		/*	Matr�culas na 4� S�rie - Nascidos em 1984	*/
@4780	VCN265			7.		/*	Matr�culas - N�o Seriada - Nascidos em 1984	*/
@4787	VCN271			7.		/*	Matr�culas na 1� S�rie - Nascidos em 1983	*/
@4794	VCN272			7.		/*	Matr�culas na 2� S�rie - Nascidos em 1983	*/
@4801	VCN273			7.		/*	Matr�culas na 3� S�rie - Nascidos em 1983	*/
@4808	VCN274			7.		/*	Matr�culas na 4� S�rie - Nascidos em 1983	*/
@4815	VCN275			7.		/*	Matr�culas - N�o Seriada - Nascidos em 1983	*/
@4822	VCN281			7.		/*	Matr�culas na 1� S�rie - Nascidos em 1982	*/
@4829	VCN282			7.		/*	Matr�culas na 2� S�rie - Nascidos em 1982	*/
@4836	VCN283			7.		/*	Matr�culas na 3� S�rie - Nascidos em 1982	*/
@4843	VCN284			7.		/*	Matr�culas na 4� S�rie - Nascidos em 1982	*/
@4850	VCN285			7.		/*	Matr�culas - N�o Seriada - Nascidos em 1982	*/
@4857	VCN291			7.		/*	Matr�culas na 1� S�rie - Nascidos em 1981	*/
@4864	VCN292			7.		/*	Matr�culas na 2� S�rie - Nascidos em 1981	*/
@4871	VCN293			7.		/*	Matr�culas na 3� S�rie - Nascidos em 1981	*/
@4878	VCN294			7.		/*	Matr�culas na 4� S�rie - Nascidos em 1981	*/
@4885	VCN295			7.		/*	Matr�culas - N�o Seriada - Nascidos em 1981	*/
@4892	VCN2A1			7.		/*	Matr�culas na 1� S�rie - Nascidos em 1980	*/
@4899	VCN2A2			7.		/*	Matr�culas na 2� S�rie - Nascidos em 1980	*/
@4906	VCN2A3			7.		/*	Matr�culas na 3� S�rie - Nascidos em 1980	*/
@4913	VCN2A4			7.		/*	Matr�culas na 4� S�rie - Nascidos em 1980	*/
@4920	VCN2A5			7.		/*	Matr�culas - N�o Seriada - Nascidos em 1980	*/
@4927	VCN2B1			7.		/*	Matr�culas na 1� S�rie - Nascidos em 1979	*/
@4934	VCN2B2			7.		/*	Matr�culas na 2� S�rie - Nascidos em 1979	*/
@4941	VCN2B3			7.		/*	Matr�culas na 3� S�rie - Nascidos em 1979	*/
@4948	VCN2B4			7.		/*	Matr�culas na 4� S�rie - Nascidos em 1979	*/
@4955	VCN2B5			7.		/*	Matr�culas - N�o Seriada - Nascidos em 1979	*/
@4962	VCN2C1			7.		/*	Matr�culas na 1� S�rie - Nascidos em 1978	*/
@4969	VCN2C2			7.		/*	Matr�culas na 2� S�rie - Nascidos em 1978	*/
@4976	VCN2C3			7.		/*	Matr�culas na 3� S�rie - Nascidos em 1978	*/
@4983	VCN2C4			7.		/*	Matr�culas na 4� S�rie - Nascidos em 1978	*/
@4990	VCN2C5			7.		/*	Matr�culas - N�o Seriada - Nascidos em 1978	*/
@4997	VCN2D1			7.		/*	Matr�culas na 1� S�rie - Nascidos de 1977 a 1973	*/
@5004	VCN2D2			7.		/*	Matr�culas na 2� S�rie - Nascidos de 1977 a 1973	*/
@5011	VCN2D3			7.		/*	Matr�culas na 3� S�rie - Nascidos de 1977 a 1973	*/
@5018	VCN2D4			7.		/*	Matr�culas na 4� S�rie - Nascidos de 1977 a 1973	*/
@5025	VCN2D5			7.		/*	Matr�culas - N�o Seriada - Nascidos de 1977 a 1973	*/
@5032	VCN2E1			7.		/*	Matr�culas na 1� S�rie - Nascidos de 1972 a 1968	*/
@5039	VCN2E2			7.		/*	Matr�culas na 2� S�rie - Nascidos de 1972 a 1968	*/
@5046	VCN2E3			7.		/*	Matr�culas na 3� S�rie - Nascidos de 1972 a 1968	*/
@5053	VCN2E4			7.		/*	Matr�culas na 4� S�rie - Nascidos de 1972 a 1968	*/
@5060	VCN2E5			7.		/*	Matr�culas - N�o Seriada - Nascidos de 1972 a 1968	*/
@5067	VCN2F1			7.		/*	Matr�culas na 1� S�rie - Nascidos de 1967 a 1963	*/
@5074	VCN2F2			7.		/*	Matr�culas na 2� S�rie - Nascidos de 1967 a 1963	*/
@5081	VCN2F3			7.		/*	Matr�culas na 3� S�rie - Nascidos de 1967 a 1963	*/
@5088	VCN2F4			7.		/*	Matr�culas na 4� S�rie - Nascidos de 1967 a 1963	*/
@5095	VCN2F5			7.		/*	Matr�culas - N�o Seriada - Nascidos de 1967 a 1963	*/
@5102	VCN2G1			7.		/*	Matr�culas na 1� S�rie - Nascidos antes de 1963	*/
@5109	VCN2G2			7.		/*	Matr�culas na 2� S�rie - Nascidos antes de 1963	*/
@5116	VCN2G3			7.		/*	Matr�culas na 3� S�rie - Nascidos antes de 1963	*/
@5123	VCN2G4			7.		/*	Matr�culas na 4� S�rie - Nascidos antes de 1963	*/
@5130	VCN2G5			7.		/*	Matr�culas - N�o Seriada - Nascidos antes de 1963	*/
@5137	VCN311			7.		/*	Matr�culas na 1� S�rie - Masculino	*/
@5144	VCN312			7.		/*	Matr�culas na 2� S�rie - Masculino	*/
@5151	VCN313			7.		/*	Matr�culas na 3� S�rie - Masculino	*/
@5158	VCN314			7.		/*	Matr�culas na 4� S�rie - Masculino	*/
@5165	VCN315			7.		/*	Matr�culas - N�o Seriada - Masculino	*/
@5172	VCN321			7.		/*	Matr�culas na 1� S�rie - Feminino	*/
@5179	VCN322			7.		/*	Matr�culas na 2� S�rie - Feminino	*/
@5186	VCN323			7.		/*	Matr�culas na 3� S�rie - Feminino	*/
@5193	VCN324			7.		/*	Matr�culas na 4� S�rie - Feminino	*/
@5200	VCN325			7.		/*	Matr�culas - N�o Seriada - Feminino	*/
@5207	VCN411			7.		/*	Matr�culas na 1� S�rie - Nas Classes de Acelera��o	*/
@5214	VCN412			7.		/*	Matr�culas na 2� S�rie - Nas Classes de Acelera��o	*/
@5221	DCN1011			7.		/*	Concluintes em 2001 - Nascidos Ap�s 1985 - Turno Diurno - Masculino	*/
@5228	DCN1021			7.		/*	Concluintes em 2001 - Nascidos em 1985 - Turno Diurno - Masculino	*/
@5235	DCN1031			7.		/*	Concluintes em 2001 - Nascidos em 1984 - Turno Diurno - Masculino	*/
@5242	DCN1041			7.		/*	Concluintes em 2001 - Nascidos em 1983 - Turno Diurno - Masculino	*/
@5249	DCN1051			7.		/*	Concluintes em 2001 - Nascidos em 1982 - Turno Diurno - Masculino	*/
@5256	DCN1061			7.		/*	Concluintes em 2001 - Nascidos em 1981 - Turno Diurno - Masculino	*/
@5263	DCN1071			7.		/*	Concluintes em 2001 - Nascidos em 1980 - Turno Diurno - Masculino	*/
@5270	DCN1081			7.		/*	Concluintes em 2001 - Nascidos em 1979 - Turno Diurno - Masculino	*/
@5277	DCN1091			7.		/*	Concluintes em 2001 - Nascidos em 1978 - Turno Diurno - Masculino	*/
@5284	DCN10A1			7.		/*	Concluintes em 2001 - Nascidos de 1977 a 1973 - Turno Diurno - Masculino	*/
@5291	DCN10B1			7.		/*	Concluintes em 2001 - Nascidos de 1972 a 1968 - Turno Diurno - Masculino	*/
@5298	DCN10C1			7.		/*	Concluintes em 2001 - Nascidos de 1967 a 1963 - Turno Diurno - Masculino	*/
@5305	DCN10D1			7.		/*	Concluintes em 2001 - Nascidos antes de 1963 - Turno Diurno - Masculino	*/
@5312	DCN1012			7.		/*	Concluintes em 2001 - Nascidos Ap�s 1985 - Turno Diurno - Feminino	*/
@5319	DCN1022			7.		/*	Concluintes em 2001 - Nascidos em 1985 - Turno Diurno - Feminino	*/
@5326	DCN1032			7.		/*	Concluintes em 2001 - Nascidos em 1984 - Turno Diurno - Feminino	*/
@5333	DCN1042			7.		/*	Concluintes em 2001 - Nascidos em 1983 - Turno Diurno - Feminino	*/
@5340	DCN1052			7.		/*	Concluintes em 2001 - Nascidos em 1982 - Turno Diurno - Feminino	*/
@5347	DCN1062			7.		/*	Concluintes em 2001 - Nascidos em 1981 - Turno Diurno - Feminino	*/
@5354	DCN1072			7.		/*	Concluintes em 2001 - Nascidos em 1980 - Turno Diurno - Feminino	*/
@5361	DCN1082			7.		/*	Concluintes em 2001 - Nascidos em 1979 - Turno Diurno - Feminino	*/
@5368	DCN1092			7.		/*	Concluintes em 2001 - Nascidos em 1978 - Turno Diurno - Feminino	*/
@5375	DCN10A2			7.		/*	Concluintes em 2001 - Nascidos de 1977 a 1973 - Turno Diurno - Feminino	*/
@5382	DCN10B2			7.		/*	Concluintes em 2001 - Nascidos de 1972 a 1968 - Turno Diurno - Feminino	*/
@5389	DCN10C2			7.		/*	Concluintes em 2001 - Nascidos de 1967 a 1963 - Turno Diurno - Feminino	*/
@5396	DCN10D2			7.		/*	Concluintes em 2001 - Nascidos antes de 1963 - Turno Diurno - Feminino	*/
@5403	DCN1013			7.		/*	Concluintes em 2001 - Nascidos Ap�s 1985 - Turno Noturno - Masculino	*/
@5410	DCN1023			7.		/*	Concluintes em 2001 - Nascidos em 1985 - Turno Noturno - Masculino	*/
@5417	DCN1033			7.		/*	Concluintes em 2001 - Nascidos em 1984 - Turno Noturno - Masculino	*/
@5424	DCN1043			7.		/*	Concluintes em 2001 - Nascidos em 1983 - Turno Noturno - Masculino	*/
@5431	DCN1053			7.		/*	Concluintes em 2001 - Nascidos em 1982 - Turno Noturno - Masculino	*/
@5438	DCN1063			7.		/*	Concluintes em 2001 - Nascidos em 1981 - Turno Noturno - Masculino	*/
@5445	DCN1073			7.		/*	Concluintes em 2001 - Nascidos em 1980 - Turno Noturno - Masculino	*/
@5452	DCN1083			7.		/*	Concluintes em 2001 - Nascidos em 1979 - Turno Noturno - Masculino	*/
@5459	DCN1093			7.		/*	Concluintes em 2001 - Nascidos em 1978 - Turno Noturno - Masculino	*/
@5466	DCN10A3			7.		/*	Concluintes em 2001 - Nascidos de 1977 a 1973 - Turno Noturno - Masculino	*/
@5473	DCN10B3			7.		/*	Concluintes em 2001 - Nascidos de 1972 a 1968 - Turno Noturno - Masculino	*/
@5480	DCN10C3			7.		/*	Concluintes em 2001 - Nascidos de 1967 a 1963 - Turno Noturno - Masculino	*/
@5487	DCN10D3			7.		/*	Concluintes em 2001 - Nascidos antes de 1963 - Turno Noturno - Masculino	*/
@5494	DCN1014			7.		/*	Concluintes em 2001 - Nascidos Ap�s 1985 - Turno Noturno - Feminino	*/
@5501	DCN1024			7.		/*	Concluintes em 2001 - Nascidos em 1985 - Turno Noturno - Feminino	*/
@5508	DCN1034			7.		/*	Concluintes em 2001 - Nascidos em 1984 - Turno Noturno - Feminino	*/
@5515	DCN1044			7.		/*	Concluintes em 2001 - Nascidos em 1983 - Turno Noturno - Feminino	*/
@5522	DCN1054			7.		/*	Concluintes em 2001 - Nascidos em 1982 - Turno Noturno - Feminino	*/
@5529	DCN1064			7.		/*	Concluintes em 2001 - Nascidos em 1981 - Turno Noturno - Feminino	*/
@5536	DCN1074			7.		/*	Concluintes em 2001 - Nascidos em 1980 - Turno Noturno - Feminino	*/
@5543	DCN1084			7.		/*	Concluintes em 2001 - Nascidos em 1979 - Turno Noturno - Feminino	*/
@5550	DCN1094			7.		/*	Concluintes em 2001 - Nascidos em 1978 - Turno Noturno - Feminino	*/
@5557	DCN10A4			7.		/*	Concluintes em 2001 - Nascidos de 1977 a 1973 - Turno Noturno - Feminino	*/
@5564	DCN10B4			7.		/*	Concluintes em 2001 - Nascidos de 1972 a 1968 - Turno Noturno - Feminino	*/
@5571	DCN10C4			7.		/*	Concluintes em 2001 - Nascidos de 1967 a 1963 - Turno Noturno - Feminino	*/
@5578	DCN10D4			7.		/*	Concluintes em 2001 - Nascidos antes de 1963 - Turno Noturno - Feminino	*/
@5585	VEE1411			7.		/*	N�mero de Alunos da Creche/ Estimula��o Precoce - Nascidos ap�s 1998	*/
@5592	VEE1412			7.		/*	N�mero de Alunos da Creche/ Estimula��o Precoce - Nascidos de 1998 a 1996	*/
@5599	VEE1413			7.		/*	N�mero de Alunos da Creche/ Estimula��o Precoce - Nascidos de 1995 a 1988	*/
@5606	VEE1416			7.		/*	N�mero de Alunos da Creche/ Estimula��o Precoce - Nascidos de 1987 a 1985	*/
@5613	VEE1417			7.		/*	N�mero de Alunos da Creche/ Estimula��o Precoce - Nascidos antes de 1985	*/
@5620	VEE1421			7.		/*	N�mero de Alunos da Pr�-Escola - Nascidos ap�s 1998	*/
@5627	VEE1422			7.		/*	N�mero de Alunos da Pr�-Escola - Nascidos de 1998 a 1996	*/
@5634	VEE1423			7.		/*	N�mero de Alunos da Pr�-Escola - Nascidos de 1995 a 1988	*/
@5641	VEE1426			7.		/*	N�mero de Alunos da Pr�-Escola - Nascidos de 1987 a 1985	*/
@5648	VEE1427			7.		/*	N�mero de Alunos da Pr�-Escola - Nascidos antes de 1985	*/
@5655	VEE1471			7.		/*	N�mero de Alunos da Classe de Alfabetiza��o - Nascidos ap�s 1998	*/
@5662	VEE1472			7.		/*	N�mero de Alunos da Classe de Alfabetiza��o - Nascidos de 1998 a 1996	*/
@5669	VEE1473			7.		/*	N�mero de Alunos da Classe de Alfabetiza��o - Nascidos de 1995 a 1988	*/
@5676	VEE1476			7.		/*	N�mero de Alunos da Classe de Alfabetiza��o - Nascidos de 1987 a 1985	*/
@5683	VEE1477			7.		/*	N�mero de Alunos da Classe de Alfabetiza��o - Nascidos antes de 1985	*/
@5690	VEE1431			7.		/*	N�mero de Alunos do Ensino Fundamental - Nascidos ap�s 1998	*/
@5697	VEE1432			7.		/*	N�mero de Alunos do Ensino Fundamental - Nascidos de 1998 a 1996	*/
@5704	VEE1433			7.		/*	N�mero de Alunos do Ensino Fundamental - Nascidos de 1995 a 1988	*/
@5711	VEE1436			7.		/*	N�mero de Alunos do Ensino Fundamental - Nascidos de 1987 a 1985	*/
@5718	VEE1437			7.		/*	N�mero de Alunos do Ensino Fundamental - Nascidos antes de 1985	*/
@5725	VEE1441			7.		/*	N�mero de Alunos do Ensino M�dio - Nascidos ap�s 1998	*/
@5732	VEE1442			7.		/*	N�mero de Alunos do Ensino M�dio - Nascidos de 1998 a 1996	*/
@5739	VEE1443			7.		/*	N�mero de Alunos do Ensino M�dio - Nascidos de 1995 a 1988	*/
@5746	VEE1446			7.		/*	N�mero de Alunos do Ensino M�dio - Nascidos de 1987 a 1985	*/
@5753	VEE1447			7.		/*	N�mero de Alunos do Ensino M�dio - Nascidos antes de 1985	*/
@5760	VEE1451			7.		/*	N�mero de Alunos da Educa��o de Jovens e Adultos - Nascidos ap�s 1998	*/
@5767	VEE1452			7.		/*	N�mero de Alunos da Educa��o de Jovens e Adultos - Nascidos de 1998 a 1996	*/
@5774	VEE1453			7.		/*	N�mero de Alunos da Educa��o de Jovens e Adultos - Nascidos de 1995 a 1988	*/
@5781	VEE1456			7.		/*	N�mero de Alunos da Educa��o de Jovens e Adultos - Nascidos de 1987 a 1985	*/
@5788	VEE1457			7.		/*	N�mero de Alunos da Educa��o de Jovens e Adultos - Nascidos antes de 1985	*/
@5795	VEE1481			7.		/*	N�mero de Alunos da Educa��o Profissional - Nascidos ap�s 1998	*/
@5802	VEE1482			7.		/*	N�mero de Alunos da Educa��o Profissional - Nascidos de 1998 a 1996	*/
@5809	VEE1483			7.		/*	N�mero de Alunos da Educa��o Profissional - Nascidos de 1995 a 1988	*/
@5816	VEE1486			7.		/*	N�mero de Alunos da Educa��o Profissional - Nascidos de 1987 a 1985	*/
@5823	VEE1487			7.		/*	N�mero de Alunos da Educa��o Profissional - Nascidos antes de 1985	*/
@5830	VEE1011			7.		/*	N�mero de Alunos da Creche/ Estimula��o Precoce - Defici�ncia Visual	*/
@5837	VEE1012			7.		/*	N�mero de Alunos da Creche/ Estimula��o Precoce - Defici�ncia Auditiva	*/
@5844	VEE1013			7.		/*	N�mero de Alunos da Creche/ Estimula��o Precoce - Defici�ncia F�sica	*/
@5851	VEE1014			7.		/*	N�mero de Alunos da Creche/ Estimula��o Precoce - Defici�ncia Mental	*/
@5858	VEE1015			7.		/*	N�mero de Alunos da Creche/ Estimula��o Precoce - Defici�ncia M�ltipla	*/
@5865	VEE1016			7.		/*	N�mero de Alunos da Creche/ Estimula��o Precoce - Altas Habilidades/ Superdotado	*/
@5872	VEE1017			7.		/*	N�mero de Alunos da Creche/ Estimula��o Precoce - Condutas T�picas	*/
@5879	VEE1018			7.		/*	N�mero de Alunos da Creche/ Estimula��o Precoce - Outras Necessidades Educativas Especiais	*/
@5886	VEE1021			7.		/*	N�mero de Alunos da Pr�-Escola - Defici�ncia Visual	*/
@5893	VEE1022			7.		/*	N�mero de Alunos da Pr�-Escola - Defici�ncia Auditiva	*/
@5900	VEE1023			7.		/*	N�mero de Alunos da Pr�-Escola - Defici�ncia F�sica	*/
@5907	VEE1024			7.		/*	N�mero de Alunos da Pr�-Escola - Defici�ncia Mental	*/
@5914	VEE1025			7.		/*	N�mero de Alunos da Pr�-Escola - Defici�ncia M�ltipla	*/
@5921	VEE1026			7.		/*	N�mero de Alunos da Pr�-Escola - Altas Habilidades/ Superdotado	*/
@5928	VEE1027			7.		/*	N�mero de Alunos da Pr�-Escola - Condutas T�picas	*/
@5935	VEE1028			7.		/*	N�mero de Alunos da Pr�-Escola - Outras Necessidades Educativas Especiais	*/
@5942	VEE1071			7.		/*	N�mero de Alunos da Classe de Alfabetiza��o - Defici�ncia Visual	*/
@5949	VEE1072			7.		/*	N�mero de Alunos da Classe de Alfabetiza��o - Defici�ncia Auditiva	*/
@5956	VEE1073			7.		/*	N�mero de Alunos da Classe de Alfabetiza��o - Defici�ncia F�sica	*/
@5963	VEE1074			7.		/*	N�mero de Alunos da Classe de Alfabetiza��o - Defici�ncia Mental	*/
@5970	VEE1075			7.		/*	N�mero de Alunos da Classe de Alfabetiza��o - Defici�ncia M�ltipla	*/
@5977	VEE1076			7.		/*	N�mero de Alunos da Classe de Alfabetiza��o - Altas Habilidades/ Superdotado	*/
@5984	VEE1077			7.		/*	N�mero de Alunos da Classe de Alfabetiza��o - Condutas T�picas	*/
@5991	VEE1078			7.		/*	N�mero de Alunos da Classe de Alfabetiza��o - Outras Necessidades Educativas Especiais	*/
@5998	VEE1031			7.		/*	N�mero de Alunos do Ensino Fundamental - Defici�ncia Visual	*/
@6005	VEE1032			7.		/*	N�mero de Alunos do Ensino Fundamental - Defici�ncia Auditiva	*/
@6012	VEE1033			7.		/*	N�mero de Alunos do Ensino Fundamental - Defici�ncia F�sica	*/
@6019	VEE1034			7.		/*	N�mero de Alunos do Ensino Fundamental - Defici�ncia Mental	*/
@6026	VEE1035			7.		/*	N�mero de Alunos do Ensino Fundamental - Defici�ncia M�ltipla	*/
@6033	VEE1036			7.		/*	N�mero de Alunos do Ensino Fundamental - Altas Habilidades/ Superdotado	*/
@6040	VEE1037			7.		/*	N�mero de Alunos do Ensino Fundamental - Condutas T�picas	*/
@6047	VEE1038			7.		/*	N�mero de Alunos do Ensino Fundamental - Outras Necessidades Educativas Especiais	*/
@6054	VEE1041			7.		/*	N�mero de Alunos do Ensino M�dio - Defici�ncia Visual	*/
@6061	VEE1042			7.		/*	N�mero de Alunos do Ensino M�dio - Defici�ncia Auditiva	*/
@6068	VEE1043			7.		/*	N�mero de Alunos do Ensino M�dio - Defici�ncia F�sica	*/
@6075	VEE1044			7.		/*	N�mero de Alunos do Ensino M�dio - Defici�ncia Mental	*/
@6082	VEE1045			7.		/*	N�mero de Alunos do Ensino M�dio - Defici�ncia M�ltipla	*/
@6089	VEE1046			7.		/*	N�mero de Alunos do Ensino M�dio - Altas Habilidades/ Superdotado	*/
@6096	VEE1047			7.		/*	N�mero de Alunos do Ensino M�dio - Condutas T�picas	*/
@6103	VEE1048			7.		/*	N�mero de Alunos do Ensino M�dio - Outras Necessidades Educativas Especiais	*/
@6110	VEE1051			7.		/*	N�mero de Alunos da Educa��o de Jovens e Adultos - Defici�ncia Visual	*/
@6117	VEE1052			7.		/*	N�mero de Alunos da Educa��o de Jovens e Adultos - Defici�ncia Auditiva	*/
@6124	VEE1053			7.		/*	N�mero de Alunos da Educa��o de Jovens e Adultos - Defici�ncia F�sica	*/
@6131	VEE1054			7.		/*	N�mero de Alunos da Educa��o de Jovens e Adultos - Defici�ncia Mental	*/
@6138	VEE1055			7.		/*	N�mero de Alunos da Educa��o de Jovens e Adultos - Defici�ncia M�ltipla	*/
@6145	VEE1056			7.		/*	N�mero de Alunos da Educa��o de Jovens e Adultos - Altas Habilidades/ Superdotado	*/
@6152	VEE1057			7.		/*	N�mero de Alunos da Educa��o de Jovens e Adultos - Condutas T�picas	*/
@6159	VEE1058			7.		/*	N�mero de Alunos da Educa��o de Jovens e Adultos - Outras Necessidades Educativas Especiais	*/
@6166	VEE1081			7.		/*	N�mero de Alunos da Educa��o Profissional - Defici�ncia Visual	*/
@6173	VEE1082			7.		/*	N�mero de Alunos da Educa��o Profissional - Defici�ncia Auditiva	*/
@6180	VEE1083			7.		/*	N�mero de Alunos da Educa��o Profissional - Defici�ncia F�sica	*/
@6187	VEE1084			7.		/*	N�mero de Alunos da Educa��o Profissional - Defici�ncia Mental	*/
@6194	VEE1085			7.		/*	N�mero de Alunos da Educa��o Profissional - Defici�ncia M�ltipla	*/
@6201	VEE1086			7.		/*	N�mero de Alunos da Educa��o Profissional - Altas Habilidades/ Superdotado	*/
@6208	VEE1087			7.		/*	N�mero de Alunos da Educa��o Profissional - Condutas T�picas	*/
@6215	VEE1088			7.		/*	N�mero de Alunos da Educa��o Profissional - Outras Necessidades Educativas Especiais	*/
@6222	VEE1111			7.		/*	N�mero de Alunos da Creche/ Estimula��o Precoce - Defici�ncia Visual	*/
@6229	VEE1112			7.		/*	N�mero de Alunos da Creche/ Estimula��o Precoce - Defici�ncia Auditiva	*/
@6236	VEE1113			7.		/*	N�mero de Alunos da Creche/ Estimula��o Precoce - Defici�ncia F�sica	*/
@6243	VEE1114			7.		/*	N�mero de Alunos da Creche/ Estimula��o Precoce - Defici�ncia Mental	*/
@6250	VEE1115			7.		/*	N�mero de Alunos da Creche/ Estimula��o Precoce - Defici�ncia M�ltipla	*/
@6257	VEE1116			7.		/*	N�mero de Alunos da Creche/ Estimula��o Precoce - Altas Habilidades/ Superdotado	*/
@6264	VEE1117			7.		/*	N�mero de Alunos da Creche/ Estimula��o Precoce - Condutas T�picas	*/
@6271	VEE1118			7.		/*	N�mero de Alunos da Creche/ Estimula��o Precoce - Outras Necessidades Educativas Especiais	*/
@6278	VEE1121			7.		/*	N�mero de Alunos da Pr�-Escola - Defici�ncia Visual	*/
@6285	VEE1122			7.		/*	N�mero de Alunos da Pr�-Escola - Defici�ncia Auditiva	*/
@6292	VEE1123			7.		/*	N�mero de Alunos da Pr�-Escola - Defici�ncia F�sica	*/
@6299	VEE1124			7.		/*	N�mero de Alunos da Pr�-Escola - Defici�ncia Mental	*/
@6306	VEE1125			7.		/*	N�mero de Alunos da Pr�-Escola - Defici�ncia M�ltipla	*/
@6313	VEE1126			7.		/*	N�mero de Alunos da Pr�-Escola - Altas Habilidades/ Superdotado	*/
@6320	VEE1127			7.		/*	N�mero de Alunos da Pr�-Escola - Condutas T�picas	*/
@6327	VEE1128			7.		/*	N�mero de Alunos da Pr�-Escola - Outras Necessidades Educativas Especiais	*/
@6334	VEE1171			7.		/*	N�mero de Alunos da Classe de Alfabetiza��o - Defici�ncia Visual	*/
@6341	VEE1172			7.		/*	N�mero de Alunos da Classe de Alfabetiza��o - Defici�ncia Auditiva	*/
@6348	VEE1173			7.		/*	N�mero de Alunos da Classe de Alfabetiza��o - Defici�ncia F�sica	*/
@6355	VEE1174			7.		/*	N�mero de Alunos da Classe de Alfabetiza��o - Defici�ncia Mental	*/
@6362	VEE1175			7.		/*	N�mero de Alunos da Classe de Alfabetiza��o - Defici�ncia M�ltipla	*/
@6369	VEE1176			7.		/*	N�mero de Alunos da Classe de Alfabetiza��o - Altas Habilidades/ Superdotado	*/
@6376	VEE1177			7.		/*	N�mero de Alunos da Classe de Alfabetiza��o - Condutas T�picas	*/
@6383	VEE1178			7.		/*	N�mero de Alunos da Classe de Alfabetiza��o - Outras Necessidades Educativas Especiais	*/
@6390	VEE1131			7.		/*	N�mero de Alunos do Ensino Fundamental - Defici�ncia Visual	*/
@6397	VEE1132			7.		/*	N�mero de Alunos do Ensino Fundamental - Defici�ncia Auditiva	*/
@6404	VEE1133			7.		/*	N�mero de Alunos do Ensino Fundamental - Defici�ncia F�sica	*/
@6411	VEE1134			7.		/*	N�mero de Alunos do Ensino Fundamental - Defici�ncia Mental	*/
@6418	VEE1135			7.		/*	N�mero de Alunos do Ensino Fundamental - Defici�ncia M�ltipla	*/
@6425	VEE1136			7.		/*	N�mero de Alunos do Ensino Fundamental - Altas Habilidades/ Superdotado	*/
@6432	VEE1137			7.		/*	N�mero de Alunos do Ensino Fundamental - Condutas T�picas	*/
@6439	VEE1138			7.		/*	N�mero de Alunos do Ensino Fundamental - Outras Necessidades Educativas Especiais	*/
@6446	VEE1141			7.		/*	N�mero de Alunos do Ensino M�dio - Defici�ncia Visual	*/
@6453	VEE1142			7.		/*	N�mero de Alunos do Ensino M�dio - Defici�ncia Auditiva	*/
@6460	VEE1143			7.		/*	N�mero de Alunos do Ensino M�dio - Defici�ncia F�sica	*/
@6467	VEE1144			7.		/*	N�mero de Alunos do Ensino M�dio - Defici�ncia Mental	*/
@6474	VEE1145			7.		/*	N�mero de Alunos do Ensino M�dio - Defici�ncia M�ltipla	*/
@6481	VEE1146			7.		/*	N�mero de Alunos do Ensino M�dio - Altas Habilidades/ Superdotado	*/
@6488	VEE1147			7.		/*	N�mero de Alunos do Ensino M�dio - Condutas T�picas	*/
@6495	VEE1148			7.		/*	N�mero de Alunos do Ensino M�dio - Outras Necessidades Educativas Especiais	*/
@6502	VEE1151			7.		/*	N�mero de Alunos da Educa��o  de Jovens e Adultos - Defici�ncia Visual	*/
@6509	VEE1152			7.		/*	N�mero de Alunos da Educa��o  de Jovens e Adultos - Defici�ncia Auditiva	*/
@6516	VEE1153			7.		/*	N�mero de Alunos da Educa��o  de Jovens e Adultos - Defici�ncia F�sica	*/
@6523	VEE1154			7.		/*	N�mero de Alunos da Educa��o  de Jovens e Adultos - Defici�ncia Mental	*/
@6530	VEE1155			7.		/*	N�mero de Alunos da Educa��o  de Jovens e Adultos - Defici�ncia M�ltipla	*/
@6537	VEE1156			7.		/*	N�mero de Alunos da Educa��o  de Jovens e Adultos - Altas Habilidades/ Superdotado	*/
@6544	VEE1157			7.		/*	N�mero de Alunos da Educa��o  de Jovens e Adultos - Condutas T�picas	*/
@6551	VEE1158			7.		/*	N�mero de Alunos da Educa��o  de Jovens e Adultos - Outras Necessidades Educativas Especiais	*/
@6558	VEE1181			7.		/*	N�mero de Alunos da Educa��o  Profissional - Defici�ncia Visual	*/
@6565	VEE1182			7.		/*	N�mero de Alunos da Educa��o  Profissional - Defici�ncia Auditiva	*/
@6572	VEE1183			7.		/*	N�mero de Alunos da Educa��o  Profissional - Defici�ncia F�sica	*/
@6579	VEE1184			7.		/*	N�mero de Alunos da Educa��o  Profissional - Defici�ncia Mental	*/
@6586	VEE1185			7.		/*	N�mero de Alunos da Educa��o  Profissional - Defici�ncia M�ltipla	*/
@6593	VEE1186			7.		/*	N�mero de Alunos da Educa��o  Profissional - Altas Habilidades/ Superdotado	*/
@6600	VEE1187			7.		/*	N�mero de Alunos da Educa��o  Profissional - Condutas T�picas	*/
@6607	VEE1188			7.		/*	N�mero de Alunos da Educa��o  Profissional - Outras Necessidades Educativas Especiais	*/
@6614	VEE1211			7.		/*	N�mero de Alunos da Creche/ Estimula��o Precoce - Defici�ncia Visual	*/
@6621	VEE1212			7.		/*	N�mero de Alunos da Creche/ Estimula��o Precoce - Defici�ncia Auditiva	*/
@6628	VEE1213			7.		/*	N�mero de Alunos da Creche/ Estimula��o Precoce - Defici�ncia F�sica	*/
@6635	VEE1214			7.		/*	N�mero de Alunos da Creche/ Estimula��o Precoce - Defici�ncia Mental	*/
@6642	VEE1215			7.		/*	N�mero de Alunos da Creche/ Estimula��o Precoce - Defici�ncia M�ltipla	*/
@6649	VEE1216			7.		/*	N�mero de Alunos da Creche/ Estimula��o Precoce - Altas Habilidades/ Superdotado	*/
@6656	VEE1217			7.		/*	N�mero de Alunos da Creche/ Estimula��o Precoce - Condutas T�picas	*/
@6663	VEE1218			7.		/*	N�mero de Alunos da Creche/ Estimula��o Precoce - Outras Necessidades Educativas Especiais	*/
@6670	VEE1221			7.		/*	N�mero de Alunos da Pr�-Escola - Defici�ncia Visual	*/
@6677	VEE1222			7.		/*	N�mero de Alunos da Pr�-Escola - Defici�ncia Auditiva	*/
@6684	VEE1223			7.		/*	N�mero de Alunos da Pr�-Escola - Defici�ncia F�sica	*/
@6691	VEE1224			7.		/*	N�mero de Alunos da Pr�-Escola - Defici�ncia Mental	*/
@6698	VEE1225			7.		/*	N�mero de Alunos da Pr�-Escola - Defici�ncia M�ltipla	*/
@6705	VEE1226			7.		/*	N�mero de Alunos da Pr�-Escola - Altas Habilidades/ Superdotado	*/
@6712	VEE1227			7.		/*	N�mero de Alunos da Pr�-Escola - Condutas T�picas	*/
@6719	VEE1228			7.		/*	N�mero de Alunos da Pr�-Escola - Outras Necessidades Educativas Especiais	*/
@6726	VEE1271			7.		/*	N�mero de Alunos da Classe de Alfabetiza��o - Defici�ncia Visual	*/
@6733	VEE1272			7.		/*	N�mero de Alunos da Classe de Alfabetiza��o - Defici�ncia Auditiva	*/
@6740	VEE1273			7.		/*	N�mero de Alunos da Classe de Alfabetiza��o - Defici�ncia F�sica	*/
@6747	VEE1274			7.		/*	N�mero de Alunos da Classe de Alfabetiza��o - Defici�ncia Mental	*/
@6754	VEE1275			7.		/*	N�mero de Alunos da Classe de Alfabetiza��o - Defici�ncia M�ltipla	*/
@6761	VEE1276			7.		/*	N�mero de Alunos da Classe de Alfabetiza��o - Altas Habilidades/ Superdotado	*/
@6768	VEE1277			7.		/*	N�mero de Alunos da Classe de Alfabetiza��o - Condutas T�picas	*/
@6775	VEE1278			7.		/*	N�mero de Alunos da Classe de Alfabetiza��o - Outras Necessidades Educativas Especiais	*/
@6782	VEE1231			7.		/*	N�mero de Alunos do Ensino Fundamental - Defici�ncia Visual	*/
@6789	VEE1232			7.		/*	N�mero de Alunos do Ensino Fundamental - Defici�ncia Auditiva	*/
@6796	VEE1233			7.		/*	N�mero de Alunos do Ensino Fundamental - Defici�ncia F�sica	*/
@6803	VEE1234			7.		/*	N�mero de Alunos do Ensino Fundamental - Defici�ncia Mental	*/
@6810	VEE1235			7.		/*	N�mero de Alunos do Ensino Fundamental - Defici�ncia M�ltipla	*/
@6817	VEE1236			7.		/*	N�mero de Alunos do Ensino Fundamental - Altas Habilidades/ Superdotado	*/
@6824	VEE1237			7.		/*	N�mero de Alunos do Ensino Fundamental - Condutas T�picas	*/
@6831	VEE1238			7.		/*	N�mero de Alunos do Ensino Fundamental - Outras Necessidades Educativas Especiais	*/
@6838	VEE1241			7.		/*	N�mero de Alunos do Ensino M�dio - Defici�ncia Visual	*/
@6845	VEE1242			7.		/*	N�mero de Alunos do Ensino M�dio - Defici�ncia Auditiva	*/
@6852	VEE1243			7.		/*	N�mero de Alunos do Ensino M�dio - Defici�ncia F�sica	*/
@6859	VEE1244			7.		/*	N�mero de Alunos do Ensino M�dio - Defici�ncia Mental	*/
@6866	VEE1245			7.		/*	N�mero de Alunos do Ensino M�dio - Defici�ncia M�ltipla	*/
@6873	VEE1246			7.		/*	N�mero de Alunos do Ensino M�dio - Altas Habilidades/ Superdotado	*/
@6880	VEE1247			7.		/*	N�mero de Alunos do Ensino M�dio - Condutas T�picas	*/
@6887	VEE1248			7.		/*	N�mero de Alunos do Ensino M�dio - Outras Necessidades Educativas Especiais	*/
@6894	VEE1251			7.		/*	N�mero de Alunos da Educa��o  de Jovens e Adultos - Defici�ncia Visual	*/
@6901	VEE1252			7.		/*	N�mero de Alunos da Educa��o  de Jovens e Adultos - Defici�ncia Auditiva	*/
@6908	VEE1253			7.		/*	N�mero de Alunos da Educa��o  de Jovens e Adultos - Defici�ncia F�sica	*/
@6915	VEE1254			7.		/*	N�mero de Alunos da Educa��o  de Jovens e Adultos - Defici�ncia Mental	*/
@6922	VEE1255			7.		/*	N�mero de Alunos da Educa��o  de Jovens e Adultos - Defici�ncia M�ltipla	*/
@6929	VEE1256			7.		/*	N�mero de Alunos da Educa��o  de Jovens e Adultos - Altas Habilidades/ Superdotado	*/
@6936	VEE1257			7.		/*	N�mero de Alunos da Educa��o  de Jovens e Adultos - Condutas T�picas	*/
@6943	VEE1258			7.		/*	N�mero de Alunos da Educa��o  de Jovens e Adultos - Outras Necessidades Educativas Especiais	*/
@6950	VEE1281			7.		/*	N�mero de Alunos da Educa��o  Profissional - Defici�ncia Visual	*/
@6957	VEE1282			7.		/*	N�mero de Alunos da Educa��o  Profissional - Defici�ncia Auditiva	*/
@6964	VEE1283			7.		/*	N�mero de Alunos da Educa��o  Profissional - Defici�ncia F�sica	*/
@6971	VEE1284			7.		/*	N�mero de Alunos da Educa��o  Profissional - Defici�ncia Mental	*/
@6978	VEE1285			7.		/*	N�mero de Alunos da Educa��o  Profissional - Defici�ncia M�ltipla	*/
@6985	VEE1286			7.		/*	N�mero de Alunos da Educa��o  Profissional - Altas Habilidades/ Superdotado	*/
@6992	VEE1287			7.		/*	N�mero de Alunos da Educa��o  Profissional - Condutas T�picas	*/
@6999	VEE1288			7.		/*	N�mero de Alunos da Educa��o  Profissional - Outras Necessidades Educativas Especiais	*/
@7006	VEE1311			7.		/*	Portadores de Necessidades Especiais da Creche/ Estimula��o Precoce - Defici�ncia Visual	*/
@7013	VEE1312			7.		/*	Portadores de Necessidades Especiais da Creche/ Estimula��o Precoce - Defici�ncia Auditiva	*/
@7020	VEE1313			7.		/*	Portadores de Necessidades Especiais da Creche/ Estimula��o Precoce - Defici�ncia F�sica	*/
@7027	VEE1314			7.		/*	Portadores de Necessidades Especiais da Creche/ Estimula��o Precoce - Defici�ncia Mental	*/
@7034	VEE1315			7.		/*	Portadores de Necessidades Especiais da Creche/ Estimula��o Precoce - Defici�ncia M�ltipla	*/
@7041	VEE1316			7.		/*	Portadores de Necessidades Especiais da Creche/ Estimula��o Precoce - Altas Habilidades/ Superdotado	*/
@7048	VEE1317			7.		/*	Portadores de Necessidades Especiais da Creche/ Estimula��o Precoce - Condutas T�picas	*/
@7055	VEE1318			7.		/*	Portadores de Necessidades Especiais da Creche/ Estimula��o Precoce - Outras Necessidades Educativas Especiais	*/
@7062	VEE1321			7.		/*	Portadores de Necessidades Especiais da Pr�-Escola - Defici�ncia Visual	*/
@7069	VEE1322			7.		/*	Portadores de Necessidades Especiais da Pr�-Escola - Defici�ncia Auditiva	*/
@7076	VEE1323			7.		/*	Portadores de Necessidades Especiais da Pr�-Escola - Defici�ncia F�sica	*/
@7083	VEE1324			7.		/*	Portadores de Necessidades Especiais da Pr�-Escola - Defici�ncia Mental	*/
@7090	VEE1325			7.		/*	Portadores de Necessidades Especiais da Pr�-Escola - Defici�ncia M�ltipla	*/
@7097	VEE1326			7.		/*	Portadores de Necessidades Especiais da Pr�-Escola - Altas Habilidades/ Superdotado	*/
@7104	VEE1327			7.		/*	Portadores de Necessidades Especiais da Pr�-Escola - Condutas T�picas	*/
@7111	VEE1328			7.		/*	Portadores de Necessidades Especiais da Pr�-Escola - Outras Necessidades Educativas Especiais	*/
@7118	VEE1371			7.		/*	Portadores de Necessidades Especiais da Classe de Alfabetiza��o - Defici�ncia Visual	*/
@7125	VEE1372			7.		/*	Portadores de Necessidades Especiais da Classe de Alfabetiza��o - Defici�ncia Auditiva	*/
@7132	VEE1373			7.		/*	Portadores de Necessidades Especiais da Classe de Alfabetiza��o - Defici�ncia F�sica	*/
@7139	VEE1374			7.		/*	Portadores de Necessidades Especiais da Classe de Alfabetiza��o - Defici�ncia Mental	*/
@7146	VEE1375			7.		/*	Portadores de Necessidades Especiais da Classe de Alfabetiza��o - Defici�ncia M�ltipla	*/
@7153	VEE1376			7.		/*	Portadores de Necessidades Especiais da Classe de Alfabetiza��o - Altas Habilidades/ Superdotado	*/
@7160	VEE1377			7.		/*	Portadores de Necessidades Especiais da Classe de Alfabetiza��o - Condutas T�picas	*/
@7167	VEE1378			7.		/*	Portadores de Necessidades Especiais da Classe de Alfabetiza��o - Outras Necessidades Educativas Especiais	*/
@7174	VEE1331			7.		/*	Portadores de Necessidades Especiais do Ensino Fundamental - Defici�ncia Visual	*/
@7181	VEE1332			7.		/*	Portadores de Necessidades Especiais do Ensino Fundamental - Defici�ncia Auditiva	*/
@7188	VEE1333			7.		/*	Portadores de Necessidades Especiais do Ensino Fundamental - Defici�ncia F�sica	*/
@7195	VEE1334			7.		/*	Portadores de Necessidades Especiais do Ensino Fundamental - Defici�ncia Mental	*/
@7202	VEE1335			7.		/*	Portadores de Necessidades Especiais do Ensino Fundamental - Defici�ncia M�ltipla	*/
@7209	VEE1336			7.		/*	Portadores de Necessidades Especiais do Ensino Fundamental - Altas Habilidades/ Superdotado	*/
@7216	VEE1337			7.		/*	Portadores de Necessidades Especiais do Ensino Fundamental - Condutas T�picas	*/
@7223	VEE1338			7.		/*	Portadores de Necessidades Especiais do Ensino Fundamental - Outras Necessidades Educativas Especiais	*/
@7230	VEE1341			7.		/*	Portadores de Necessidades Especiais do Ensino M�dio - Defici�ncia Visual	*/
@7237	VEE1342			7.		/*	Portadores de Necessidades Especiais do Ensino M�dio - Defici�ncia Auditiva	*/
@7244	VEE1343			7.		/*	Portadores de Necessidades Especiais do Ensino M�dio - Defici�ncia F�sica	*/
@7251	VEE1344			7.		/*	Portadores de Necessidades Especiais do Ensino M�dio - Defici�ncia Mental	*/
@7258	VEE1345			7.		/*	Portadores de Necessidades Especiais do Ensino M�dio - Defici�ncia M�ltipla	*/
@7265	VEE1346			7.		/*	Portadores de Necessidades Especiais do Ensino M�dio - Altas Habilidades/ Superdotado	*/
@7272	VEE1347			7.		/*	Portadores de Necessidades Especiais do Ensino M�dio - Condutas T�picas	*/
@7279	VEE1348			7.		/*	Portadores de Necessidades Especiais do Ensino M�dio - Outras Necessidades Educativas Especiais	*/
@7286	VEE1351			7.		/*	Portadores de Necessidades Especiais da Educa��o  de Jovens e Adultos - Defici�ncia Visual	*/
@7293	VEE1352			7.		/*	Portadores de Necessidades Especiais da Educa��o  de Jovens e Adultos - Defici�ncia Auditiva	*/
@7300	VEE1353			7.		/*	Portadores de Necessidades Especiais da Educa��o  de Jovens e Adultos - Defici�ncia F�sica	*/
@7307	VEE1354			7.		/*	Portadores de Necessidades Especiais da Educa��o  de Jovens e Adultos - Defici�ncia Mental	*/
@7314	VEE1355			7.		/*	Portadores de Necessidades Especiais da Educa��o  de Jovens e Adultos - Defici�ncia M�ltipla	*/
@7321	VEE1356			7.		/*	Portadores de Necessidades Especiais da Educa��o  de Jovens e Adultos - Altas Habilidades/ Superdotado	*/
@7328	VEE1357			7.		/*	Portadores de Necessidades Especiais da Educa��o  de Jovens e Adultos - Condutas T�picas	*/
@7335	VEE1358			7.		/*	Portadores de Necessidades Especiais da Educa��o  de Jovens e Adultos - Outras Necessidades Educativas Especiais	*/
@7342	VEE1381			7.		/*	Portadores de Necessidades Especiais da Educa��o  Profissional - Defici�ncia Visual	*/
@7349	VEE1382			7.		/*	Portadores de Necessidades Especiais da Educa��o  Profissional - Defici�ncia Auditiva	*/
@7356	VEE1383			7.		/*	Portadores de Necessidades Especiais da Educa��o  Profissional - Defici�ncia F�sica	*/
@7363	VEE1384			7.		/*	Portadores de Necessidades Especiais da Educa��o  Profissional - Defici�ncia Mental	*/
@7370	VEE1385			7.		/*	Portadores de Necessidades Especiais da Educa��o  Profissional - Defici�ncia M�ltipla	*/
@7377	VEE1386			7.		/*	Portadores de Necessidades Especiais da Educa��o  Profissional - Altas Habilidades/ Superdotado	*/
@7384	VEE1387			7.		/*	Portadores de Necessidades Especiais da Educa��o  Profissional - Condutas T�picas	*/
@7391	VEE1388			7.		/*	Portadores de Necessidades Especiais da Educa��o  Profissional - Outras Necessidades Educativas Especiais	*/
@7398	VEE1511			7.		/*	N�mero de Alunos com Necessidades Especiais do Ensino Fundamental, Inclusiva com Sala de Recurso - Defici�ncia Visual	*/
@7405	VEE1512			7.		/*	N�mero de Alunos com Necessidades Especiais do Ensino Fundamental, Inclusiva com Sala de Recurso - Defici�ncia Auditiva	*/
@7412	VEE1513			7.		/*	N�mero de Alunos com Necessidades Especiais do Ensino Fundamental, Inclusiva com Sala de Recurso - Defici�ncia F�sica	*/
@7419	VEE1514			7.		/*	N�mero de Alunos com Necessidades Especiais do Ensino Fundamental, Inclusiva com Sala de Recurso - Defici�ncia Mental	*/
@7426	VEE1515			7.		/*	N�mero de Alunos com Necessidades Especiais do Ensino Fundamental, Inclusiva com Sala de Recurso - Defici�ncia M�ltipla	*/
@7433	VEE1516			7.		/*	N�mero de Alunos com Necessidades Especiais do Ensino Fundamental, Inclusiva com Sala de Recurso - Altas Habilidades/ Superdotado	*/
@7440	VEE1517			7.		/*	N�mero de Alunos com Necessidades Especiais do Ensino Fundamental, Inclusiva com Sala de Recurso - Condutas T�picas	*/
@7447	VEE1518			7.		/*	N�mero de Alunos com Necessidades Especiais do Ensino Fundamental, Inclusiva com Sala de Recurso - Outras Necessidades Educativas Especiais	*/
@7454	VEE1521			7.		/*	N�mero de Alunos com Necessidades Especiais do Ensino Fundamental, sem Sala de Recurso - Defici�ncia Visual	*/
@7461	VEE1522			7.		/*	N�mero de Alunos com Necessidades Especiais do Ensino Fundamental, sem Sala de Recurso - Defici�ncia Auditiva	*/
@7468	VEE1523			7.		/*	N�mero de Alunos com Necessidades Especiais do Ensino Fundamental, sem Sala de Recurso - Defici�ncia F�sica	*/
@7475	VEE1524			7.		/*	N�mero de Alunos com Necessidades Especiais do Ensino Fundamental, sem Sala de Recurso - Defici�ncia Mental	*/
@7482	VEE1525			7.		/*	N�mero de Alunos com Necessidades Especiais do Ensino Fundamental, sem Sala de Recurso - Defici�ncia M�ltipla	*/
@7489	VEE1526			7.		/*	N�mero de Alunos com Necessidades Especiais do Ensino Fundamental, sem Sala de Recurso - Altas Habilidades/ Superdotado	*/
@7496	VEE1527			7.		/*	N�mero de Alunos com Necessidades Especiais do Ensino Fundamental, sem Sala de Recurso - Condutas T�picas	*/
@7503	VEE1528			7.		/*	N�mero de Alunos com Necessidades Especiais do Ensino Fundamental, sem Sala de Recurso - Outras Necessidades Educativas Especiais	*/
@7510	VEE1531			7.		/*	N�mero de Alunos com Necessidades Especiais do Ensino M�dio, com Sala de Recurso - Defici�ncia Visual	*/
@7517	VEE1532			7.		/*	N�mero de Alunos com Necessidades Especiais do Ensino M�dio, com Sala de Recurso - Defici�ncia Auditiva	*/
@7524	VEE1533			7.		/*	N�mero de Alunos com Necessidades Especiais do Ensino M�dio, com Sala de Recurso - Defici�ncia F�sica	*/
@7531	VEE1534			7.		/*	N�mero de Alunos com Necessidades Especiais do Ensino M�dio, com Sala de Recurso - Defici�ncia Mental	*/
@7538	VEE1535			7.		/*	N�mero de Alunos com Necessidades Especiais do Ensino M�dio, com Sala de Recurso - Defici�ncia M�ltipla	*/
@7545	VEE1536			7.		/*	N�mero de Alunos com Necessidades Especiais do Ensino M�dio, com Sala de Recurso - Altas Habilidades/ Superdotado	*/
@7552	VEE1537			7.		/*	N�mero de Alunos com Necessidades Especiais do Ensino M�dio, com Sala de Recurso - Condutas T�picas	*/
@7559	VEE1538			7.		/*	N�mero de Alunos com Necessidades Especiais do Ensino M�dio, com Sala de Recurso - Outras Necessidades Educativas Especiais	*/
@7566	VEE1541			7.		/*	N�mero de Alunos com Necessidades Especiais do Ensino M�dio, sem Sala de Recurso - Defici�ncia Visual	*/
@7573	VEE1542			7.		/*	N�mero de Alunos com Necessidades Especiais do Ensino M�dio, sem Sala de Recurso - Defici�ncia Auditiva	*/
@7580	VEE1543			7.		/*	N�mero de Alunos com Necessidades Especiais do Ensino M�dio, sem Sala de Recurso - Defici�ncia F�sica	*/
@7587	VEE1544			7.		/*	N�mero de Alunos com Necessidades Especiais do Ensino M�dio, sem Sala de Recurso - Defici�ncia Mental	*/
@7594	VEE1545			7.		/*	N�mero de Alunos com Necessidades Especiais do Ensino M�dio, sem Sala de Recurso - Defici�ncia M�ltipla	*/
@7601	VEE1546			7.		/*	N�mero de Alunos com Necessidades Especiais do Ensino M�dio, sem Sala de Recurso - Altas Habilidades/ Superdotado	*/
@7608	VEE1547			7.		/*	N�mero de Alunos com Necessidades Especiais do Ensino M�dio, sem Sala de Recurso - Condutas T�picas	*/
@7615	VEE1548			7.		/*	N�mero de Alunos com Necessidades Especiais do Ensino M�dio, sem Sala de Recurso - Outras Necessidades Educativas Especiais	*/
@7622	DES1013			7.		/*	Turmas na Alfabetiza��o - Turno Diurno	*/
@7629	DES1014			7.		/*	Turmas da 1� a 4� S�ries - Turno Diurno	*/
@7636	DES1015			7.		/*	Turmas da 5� a 8� S�ries - Turno Diurno	*/
@7643	DES1016			7.		/*	Turmas no Ensino M�dio - Turno Diurno	*/
@7650	NES1013			7.		/*	Turmas na Alfabetiza��o - Turno Noturno	*/
@7657	NES1014			7.		/*	Turmas da 1� a 4� S�ries - Turno Noturno	*/
@7664	NES1015			7.		/*	Turmas da 5� a 8� S�ries - Turno Noturno	*/
@7671	NES1016			7.		/*	Turmas no Ensino M�dio - Turno Noturno	*/
@7678	DES1017			7.		/*	Matr�culas na Alfabetiza��o - Turno Diurno	*/
@7685	DES1018			7.		/*	Matr�culas da 1� a 4� S�ries - Turno Diurno	*/
@7692	DES1019			7.		/*	Matr�culas da 5� a 8� S�ries - Turno Diurno	*/
@7699	DES101A			7.		/*	Matr�culas no Ensino M�dio - Turno Diurno	*/
@7706	NES1017			7.		/*	Matr�culas na Alfabetiza��o - Turno Noturno	*/
@7713	NES1018			7.		/*	Matr�culas da 1� a 4� S�ries - Turno Noturno	*/
@7720	NES1019			7.		/*	Matr�culas da 5� a 8� S�ries - Turno Noturno	*/
@7727	NES101A			7.		/*	Matr�culas no Ensino M�dio - Turno Noturno	*/
@7734	VES761			7.		/*	Matr�culas na Alfabetiza��o - Nascidos ap�s 1987	*/
@7741	VES762			7.		/*	Matr�culas da 1� a 4� S�ries - Nascidos ap�s 1987	*/
@7748	VES763			7.		/*	Matr�culas da 5� a 8� S�ries - Nascidos ap�s 1987	*/
@7755	VES764			7.		/*	Matr�culas no Ensino M�dio - Nascidos ap�s 1987	*/
@7762	VES7D1			7.		/*	Matr�culas na Alfabetiza��o - Nascidos de 1987 a 1985	*/
@7769	VES7D2			7.		/*	Matr�culas da 1� a 4� S�ries - Nascidos de 1987 a 1985	*/
@7776	VES7D3			7.		/*	Matr�culas da 5� a 8� S�ries - Nascidos de 1987 a 1985	*/
@7783	VES7D4			7.		/*	Matr�culas no Ensino M�dio - Nascidos de 1987 a 1985	*/
@7790	VES7E1			7.		/*	Matr�culas na Alfabetiza��o - Nascidos de 1984 a 1978	*/
@7797	VES7E2			7.		/*	Matr�culas da 1� a 4� S�ries - Nascidos de 1984 a 1978	*/
@7804	VES7E3			7.		/*	Matr�culas da 5� a 8� S�ries - Nascidos de 1984 a 1978	*/
@7811	VES7E4			7.		/*	Matr�culas no Ensino M�dio - Nascidos de 1984 a 1978	*/
@7818	VES791			7.		/*	Matr�culas na Alfabetiza��o - Nascidos de 1977 a 1973	*/
@7825	VES792			7.		/*	Matr�culas da 1� a 4� S�ries - Nascidos de 1977 a 1973	*/
@7832	VES793			7.		/*	Matr�culas da 5� a 8� S�ries - Nascidos de 1977 a 1973	*/
@7839	VES794			7.		/*	Matr�culas no Ensino M�dio - Nascidos de 1977 a 1973	*/
@7846	VES7A1			7.		/*	Matr�culas na Alfabetiza��o - Nascidos de 1972 a 1968	*/
@7853	VES7A2			7.		/*	Matr�culas da 1� a 4� S�ries - Nascidos de 1972 a 1968	*/
@7860	VES7A3			7.		/*	Matr�culas da 5� a 8� S�ries - Nascidos de 1972 a 1968	*/
@7867	VES7A4			7.		/*	Matr�culas no Ensino M�dio - Nascidos de 1972 a 1968	*/
@7874	VES7B1			7.		/*	Matr�culas na Alfabetiza��o - Nascidos de 1967 a 1963	*/
@7881	VES7B2			7.		/*	Matr�culas da 1� a 4� S�ries - Nascidos de 1967 a 1963	*/
@7888	VES7B3			7.		/*	Matr�culas da 5� a 8� S�ries - Nascidos de 1967 a 1963	*/
@7895	VES7B4			7.		/*	Matr�culas no Ensino M�dio - Nascidos de 1967 a 1963	*/
@7902	VES7C1			7.		/*	Matr�culas na Alfabetiza��o - Nascidos antes de 1963	*/
@7909	VES7C2			7.		/*	Matr�culas da 1� a 4� S�ries - Nascidos antes de 1963	*/
@7916	VES7C3			7.		/*	Matr�culas da 5� a 8� S�ries - Nascidos antes de 1963	*/
@7923	VES7C4			7.		/*	Matr�culas no Ensino M�dio - Nascidos antes de 1963	*/
@7930	VES1111			7.		/*	Matr�culas na Alfabetiza��o - Masculino	*/
@7937	VES1112			7.		/*	Matr�culas da 1� a 4� S�ries - Masculino	*/
@7944	VES1113			7.		/*	Matr�culas da 5� a 8� S�ries - Masculino	*/
@7951	VES1114			7.		/*	Matr�culas no Ensino M�dio - Masculino	*/
@7958	VES1121			7.		/*	Matr�culas na Alfabetiza��o - Feminino	*/
@7965	VES1122			7.		/*	Matr�culas da 1� a 4� S�ries - Feminino	*/
@7972	VES1123			7.		/*	Matr�culas da 5� a 8� S�ries - Feminino	*/
@7979	VES1124			7.		/*	Matr�culas no Ensino M�dio - Feminino	*/
@7986	VES811			7.		/*	Concluintes da 4� S�rie - Em 2001	*/
@7993	VES812			7.		/*	Concluintes da 8� S�rie - Em 2001	*/
@8000	VES813			7.		/*	Concluintes do Ensino M�dio - Em 2001	*/
@8007	VES911          7.		/*	Matr�culas no Ensino Fundamental	*/
@8014	VES912          7.		/*	Matr�culas no Ensino M�dio	*/
@8021   VES1211			7.      /*	Matr�culas no Ensino Fundamental (1o grau) - Curso Semipresenciais	*/
@8028   VES1212			7.      /*	Matr�culas no Ensino M�dio (2o grau) - Curso Semipresenciais	*/

/*	INFORMA��ES SOBRE ALUNOS RESIDENTES EM �REA RURAL QUE UTILIZAM O TRANSPORTE ESCOLAR P�BLICO	*/ 
/*	OFERECIDO PELO PODER P�BLICO ESTADUAL OU MUNICIPAL											*/
@8035	USA_TEP			$CHAR1.	/*	Tem no corpo discente alunos residentes em �rea rural que utilizam transporte escolar oferecido pelo poder p�blico? */
@8036	VTE111			6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Estadual - Creche - Matutino */
@8042	VTE112			6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Estadual - Pr�-Escola - Matutino */
@8048	VTE113			6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Estadual - 1a a 4a s�rie - Matutino */
@8054	VTE114          6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Estadual - 5a a 8a s�rie - Matutino */
@8060	VTE115          6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Estadual - Ensino M�dio - Matutino */
@8066	VTE116			6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Estadual - EJA/Alfabetiza��o - Matutino */
@8072	VTE117			6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Estadual - EJA/1a a 4a s�rie - Matutino */
@8078	VTE118			6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Estadual - EJA/5a a 8a s�rie - Matutino */
@8084	VTE119          6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Estadual - Ensino M�dio - Matutino */
@8090	VTE11A          6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Estadual - Educa��o Especial em Classes Especiais e Escolas Exclusivas - Matutino */
@8096	VTE121			6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Estadual - Creche - Vespertino */		
@8102	VTE122			6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Estadual - Pr�-Escola - Vespertino */		
@8108	VTE123			6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Estadual - 1a a 4a s�rie - Vespertino */		
@8114	VTE124          6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Estadual - 5a a 8a s�rie - Vespertino */		
@8120	VTE125          6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Estadual - Ensino M�dio - Vespertino */
@8126	VTE126			6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Estadual - EJA/Alfabetiza��o - Vespertino */
@8132	VTE127			6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Estadual - EJA/1a a 4a s�rie - Vespertino */
@8138	VTE128			6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Estadual - EJA/5a a 8a s�rie - Vespertino */
@8144	VTE129          6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Estadual - Ensino M�dio - Vespertino */
@8150	VTE12A          6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Estadual - Educa��o Especial em Classes Especiais e Escolas Exclusivas - Vespertino */
@8156	VTE131			6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Estadual - Creche - Noturno */		
@8162	VTE132			6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Estadual - Pr�-Escola - Noturno */		
@8168	VTE133			6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Estadual - 1a a 4a s�rie - Noturno */		
@8174	VTE134          6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Estadual - 5a a 8a s�rie - Noturno */		
@8180	VTE135          6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Estadual - Ensino M�dio - Noturno */
@8186	VTE136			6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Estadual - EJA/Alfabetiza��o - Noturno */
@8192	VTE137			6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Estadual - EJA/1a a 4a s�rie - Noturno */
@8198	VTE138			6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Estadual - EJA/5a a 8a s�rie - Noturno */
@8204	VTE139          6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Estadual - Ensino M�dio - Noturno */
@8210	VTE13A          6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Estadual - Educa��o Especial em Classes Especiais e Escolas Exclusivas - Noturno */
@8216	VTE141			6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Municipal - Creche - Matutino */
@8222	VTE142			6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Municipal - Pr�-Escola - Matutino */
@8228	VTE143			6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Municipal - 1a a 4a s�rie - Matutino */
@8234	VTE144          6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Municipal - 5a a 8a s�rie - Matutino */
@8240	VTE145          6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Municipal - Ensino M�dio - Matutino */
@8246	VTE146			6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Municipal - EJA/Alfabetiza��o - Matutino */
@8252	VTE147			6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Municipal - EJA/1a a 4a s�rie - Matutino */
@8258	VTE148			6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Municipal - EJA/5a a 8a s�rie - Matutino */
@8264	VTE149          6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Municipal - Ensino M�dio - Matutino */
@8270	VTE14A          6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Municipal - Educa��o Especial em Classes Especiais e Escolas Exclusivas - Matutino */
@8276	VTE151			6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Municipal - Creche - Vespertino */		
@8282	VTE152			6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Municipal - Pr�-Escola - Vespertino */		
@8288	VTE153			6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Municipal - 1a a 4a s�rie - Vespertino */		
@8294	VTE154          6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Municipal - 5a a 8a s�rie - Vespertino */		
@8300	VTE155          6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Municipal - Ensino M�dio - Vespertino */
@8306	VTE156			6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Municipal - EJA/Alfabetiza��o - Vespertino */
@8312	VTE157			6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Municipal - EJA/1a a 4a s�rie - Vespertino */
@8318	VTE158			6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Municipal - EJA/5a a 8a s�rie - Vespertino */
@8324	VTE159          6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Municipal - Ensino M�dio - Vespertino */
@8330	VTE15A          6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Municipal - Educa��o Especial em Classes Especiais e Escolas Exclusivas - Vespertino */
@8336	VTE161          6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Municipal - Creche - Noturno */		
@8342	VTE162          6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Municipal - Pr�-Escola - Noturno */		
@8348	VTE163			6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Municipal - 1a a 4a s�rie - Noturno */		
@8354	VTE164			6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Municipal - 5a a 8a s�rie - Noturno */		
@8360	VTE165			6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Municipal - Ensino M�dio - Noturno */
@8366	VTE166          6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Municipal - EJA/Alfabetiza��o - Noturno */
@8372	VTE167          6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Municipal - EJA/1a a 4a s�rie - Noturno */
@8378	VTE168			6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Municipal - EJA/5a a 8a s�rie - Noturno */
@8384	VTE169          6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Municipal - Ensino M�dio - Noturno */
@8390	VTE16A         	6.		/*	Alunos residentes em �rea rural que utilizam o Transporte Escolar oferecido pelo Poder P�blico Municipal - Educa��o Especial em Classes Especiais e Escolas Exclusivas - Noturno */
;	
RUN;