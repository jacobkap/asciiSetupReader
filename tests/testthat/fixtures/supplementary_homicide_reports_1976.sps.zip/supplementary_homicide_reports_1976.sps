*-------------------------------------------------------------------------*
 |             SPSS DATA DEFINITION STATEMENTS FOR ICPSR 9028             |
 |                                                                        |
 |        UNIFORM CRIME REPORTING PROGRAM DATA: [UNITED STATES]           |
 |                                                                        |
 |            PART 40: Supplementary Homicide Reports, 1976               |
 |                                                                        |
 |                                                                        |
 | This SPSS setup file contains the following statements:                |
 |                                                                        |
 | DATA LIST:  Specifies the input data file to be read and assigns the   |
 | name, type, decimal specification (if any), and identifies variable    |
 | beginning and ending column locations. Users must replace              |
 | "file-specification" with a complete statement of the location of the  |
 | data file.                                                             |
 |                                                                        |
 | VARIABLE LABELS:  Assigns descriptive labels to variables. Variable    |
 | labels and variable names may be identical for certain variables.      |
 |                                                                        |
 | VALUE LABELS:  Assigns descriptive labels to codes in the data file.   |
 | Value labels may not be present for all variables in the data file.    |
 |                                                                        |
 | MISSING VALUES:  Declares user-defined missing values. These values    |
 | can be treated specially in data transformations, statistical          |
 | calculations, and case selection. Missing values may not be present    |
 | for all variables in the data file.                                    |
 |                                                                        |
 | NOTE:  Users should modify this SPSS setup to suit their specific      |
 | needs. MISSING VALUES sections have been marked by SPSS comment        |
 | statements. To include these sections in a final SPSS setup, users     |
 | should remove the SPSS comment statements from the desired section(s). |
 *------------------------------------------------------------------------.
                                                                           
* SPSS DATA LIST COMMMAND.                                                 
                                                                           
DATA LIST FILE="file-specification" /                                      
   V1 1-4                   V2 5-5                   V3 6-7                
   V4 8-12                  V5 13-14                 V6 15-21 (A)          
   V7 22-22                 V8 23-24                 V9 25-25              
   V10 26-27                V11 28-35                V12 36-38             
   V13 39-41                V14 42-42                V15 43-66 (A)         
   V16 67-72 (A)            V17 73-74                V18 75-80             
   V19 81-81                V20 82-82                V21 83-85             
   V22 86-86                V23 87-88                V24 89-90             
   V25 91-92                V26 93-94                V27 95-96             
   V28 97-98                V29 99-100               V30 101-102           
   V31 103-104              V32 105-106              V33 107-108           
   V34 109-110              V35 111-111              V36 112-112           
   V37 113-113              V38 114-114              V39 115-115           
   V40 116-116              V41 117-117              V42 118-118           
   V43 119-119              V44 120-120              V45 121-121           
   V46 122-122              V47 123-123              V48 124-124           
   V49 125-125              V50 126-126              V51 127-127           
   V52 128-128              V53 129-129              V54 130-130           
   V55 131-131              V56 132-132              V57 133-133           
   V58 134-134              V59 135-135              V60 136-136           
   V61 137-137              V62 138-138              V63 139-139           
   V64 140-140              V65 141-142              V66 143-144           
   V67 145-146              V68 147-148              V69 149-150           
   V70 151-152              V71 153-154              V72 155-156           
   V73 157-158              V74 159-160              V75 161-162           
   V76 163-163              V77 164-164              V78 165-165           
   V79 166-166              V80 167-167              V81 168-168           
   V82 169-169              V83 170-170              V84 171-171           
   V85 172-172              V86 173-173              V87 174-174           
   V88 175-175              V89 176-176              V90 177-177           
   V91 178-178              V92 179-179              V93 180-180           
   V94 181-181              V95 182-182              V96 183-183           
   V97 184-184              V98 185-185              V99 186-186           
   V100 187-187             V101 188-188             V102 189-189          
   V103 190-190             V104 191-191             V105 192-192          
   V106 193-193             V107 194-194             V108 195-195          
   V109 196-197             V110 198-199             V111 200-201          
   V112 202-203             V113 204-205             V114 206-207          
   V115 208-209             V116 210-211             V117 212-213          
   V118 214-215             V119 216-217             V120 218-219          
   V121 220-221             V122 222-223             V123 224-225          
   V124 226-227             V125 228-229             V126 230-231          
   V127 232-233             V128 234-235             V129 236-237          
   V130 238-239             V131 240-241             V132 242-243          
   V133 244-245             V134 246-247             V135 248-249          
   V136 250-251             V137 252-253             V138 254-255          
   V139 256-257             V140 258-259             V141 260-261          
   V142 262-262             V143 263-263             V144 264-264          
   V145 265-265             V146 266-266             V147 267-267          
   V148 268-268             V149 269-269             V150 270-270          
   V151 271-271             V152 272-272.                                  
                                                                           
* SPSS VARIABLE LABELS COMMAND.                                            
                                                                           
VARIABLE LABELS                                                            
   V1 "ICPSR STUDY NUMBER"                                                 
   V2 "ICPSR EDITION NUMBER"                                               
   V3 "ICPSR PART NUMBER"                                                  
   V4 "ICPSR CASE ID"                                                      
   V5 "STATE CODE"                                                         
   V6 "AGENCY CODE"                                                        
   V7 "GROUP"                                                              
   V8 "SUB-GROUP"                                                          
   V9 "GEOGRAPHIC DIVISION"                                                
   V10 "YEAR"                                                              
   V11 "POPULATION"                                                        
   V12 "COUNTY"                                                            
   V13 "SMSA"                                                              
   V14 "SMSA INDICATION"                                                   
   V15 "AGENCY NAME"                                                       
   V16 "AGENCY STATE"                                                      
   V17 "MONTH OF OFFENSE"                                                  
   V18 "LAST UPDATE"                                                       
   V19 "TYPE OF ACTION"                                                    
   V20 "HOMICIDE TYPE"                                                     
   V21 "INCIDENT NUMBER"                                                   
   V22 "SITUATION"                                                         
   V23 "VICTIM COUNT"                                                      
   V24 "OFFENDER COUNT"                                                    
   V25 "VICTIM 1 AGE"                                                      
   V26 "VICTIM 2 AGE"                                                      
   V27 "VICTIM 3 AGE"                                                      
   V28 "VICTIM 4 AGE"                                                      
   V29 "VICTIM 5 AGE"                                                      
   V30 "VICTIM 6 AGE"                                                      
   V31 "VICTIM 7 AGE"                                                      
   V32 "VICTIM 8 AGE"                                                      
   V33 "VICTIM 9 AGE"                                                      
   V34 "VICTIM 10 AGE"                                                     
   V35 "VICTIM 1 GENDER"                                                   
   V36 "VICTIM 2 GENDER"                                                   
   V37 "VICTIM 3 GENDER"                                                   
   V38 "VICTIM 4 GENDER"                                                   
   V39 "VICTIM 5 GENDER"                                                   
   V40 "VICTIM 6 GENDER"                                                   
   V41 "VICTIM 7 GENDER"                                                   
   V42 "VICTIM 8 GENDER"                                                   
   V43 "VICTIM 9 GENDER"                                                   
   V44 "VICTIM 10 GENDER"                                                  
   V45 "VICTIM 1 RACE"                                                     
   V46 "VICTIM 2 RACE"                                                     
   V47 "VICTIM 3 RACE"                                                     
   V48 "VICTIM 4 RACE"                                                     
   V49 "VICTIM 5 RACE"                                                     
   V50 "VICTIM 6 RACE"                                                     
   V51 "VICTIM 7 RACE"                                                     
   V52 "VICTIM 8 RACE"                                                     
   V53 "VICTIM 9 RACE"                                                     
   V54 "VICTIM 10 RACE"                                                    
   V55 "VICTIM 1 ETHNIC"                                                   
   V56 "VICTIM 2 ETHNIC"                                                   
   V57 "VICTIM 3 ETHNIC"                                                   
   V58 "VICTIM 4 ETHNIC"                                                   
   V59 "VICTIM 5 ETHNIC"                                                   
   V60 "VICTIM 6 ETHNIC"                                                   
   V61 "VICTIM 7 ETHNIC"                                                   
   V62 "VICTIM 8 ETHNIC"                                                   
   V63 "VICTIM 9 ETHNIC"                                                   
   V64 "VICTIM 10 ETHNIC"                                                  
   V65 "OFFENDER 1 AGE"                                                    
   V66 "OFFENDER 2 AGE"                                                    
   V67 "OFFENDER 3 AGE"                                                    
   V68 "OFFENDER 4 AGE"                                                    
   V69 "OFFENDER 5 AGE"                                                    
   V70 "OFFENDER 6 AGE"                                                    
   V71 "OFFENDER 7 AGE"                                                    
   V72 "OFFENDER 8 AGE"                                                    
   V73 "OFFENDER 9 AGE"                                                    
   V74 "OFFENDER 10 AGE"                                                   
   V75 "OFFENDER 11 AGE"                                                   
   V76 "OFFENDER 1 GENDER"                                                 
   V77 "OFFENDER 2 GENDER"                                                 
   V78 "OFFENDER 3 GENDER"                                                 
   V79 "OFFENDER 4 GENDER"                                                 
   V80 "OFFENDER 5 GENDER"                                                 
   V81 "OFFENDER 6 GENDER"                                                 
   V82 "OFFENDER 7 GENDER"                                                 
   V83 "OFFENDER 8 GENDER"                                                 
   V84 "OFFENDER 9 GENDER"                                                 
   V85 "OFFENDER 10 GENDER"                                                
   V86 "OFFENDER 11 GENDER"                                                
   V87 "OFFENDER 1 RACE"                                                   
   V88 "OFFENDER 2 RACE"                                                   
   V89 "OFFENDER 3 RACE"                                                   
   V90 "OFFENDER 4 RACE"                                                   
   V91 "OFFENDER 5 RACE"                                                   
   V92 "OFFENDER 6 RACE"                                                   
   V93 "OFFENDER 7 RACE"                                                   
   V94 "OFFENDER 8 RACE"                                                   
   V95 "OFFENDER 9 RACE"                                                   
   V96 "OFFENDER 10 RACE"                                                  
   V97 "OFFENDER 11 RACE"                                                  
   V98 "OFFENDER 1 ETHNIC"                                                 
   V99 "OFFENDER 2 ETHNIC"                                                 
   V100 "OFFENDER 3 ETHNIC"                                                
   V101 "OFFENDER 4 ETHNIC"                                                
   V102 "OFFENDER 5 ETHNIC"                                                
   V103 "OFFENDER 6 ETHNIC"                                                
   V104 "OFFENDER 7 ETHNIC"                                                
   V105 "OFFENDER 8 ETHNIC"                                                
   V106 "OFFENDER 9 ETHNIC"                                                
   V107 "OFFENDER 10 ETHNIC"                                               
   V108 "OFFENDER 11 ETHNIC"                                               
   V109 "OFFENDER 1 WEAPON"                                                
   V110 "OFFENDER 2 WEAPON"                                                
   V111 "OFFENDER 3 WEAPON"                                                
   V112 "OFFENDER 4 WEAPON"                                                
   V113 "OFFENDER 5 WEAPON"                                                
   V114 "OFFENDER 6 WEAPON"                                                
   V115 "OFFENDER 7 WEAPON"                                                
   V116 "OFFENDER 8 WEAPON"                                                
   V117 "OFFENDER 9 WEAPON"                                                
   V118 "OFFENDER 10 WEAPON"                                               
   V119 "OFFENDER 11 WEAPON"                                               
   V120 "RELATIONSHIP 1"                                                   
   V121 "RELATIONSHIP 2"                                                   
   V122 "RELATIONSHIP 3"                                                   
   V123 "RELATIONSHIP 4"                                                   
   V124 "RELATIONSHIP 5"                                                   
   V125 "RELATIONSHIP 6"                                                   
   V126 "RELATIONSHIP 7"                                                   
   V127 "RELATIONSHIP 8"                                                   
   V128 "RELATIONSHIP 9"                                                   
   V129 "RELATIONSHIP 10"                                                  
   V130 "RELATIONSHIP 11"                                                  
   V131 "CIRCUMSTANCE 1"                                                   
   V132 "CIRCUMSTANCE 2"                                                   
   V133 "CIRCUMSTANCE 3"                                                   
   V134 "CIRCUMSTANCE 4"                                                   
   V135 "CIRCUMSTANCE 5"                                                   
   V136 "CIRCUMSTANCE 6"                                                   
   V137 "CIRCUMSTANCE 7"                                                   
   V138 "CIRCUMSTANCE 8"                                                   
   V139 "CIRCUMSTANCE 9"                                                   
   V140 "CIRCUMSTANCE 10"                                                  
   V141 "CIRCUMSTANCE 11"                                                  
   V142 "SUB-CIRCUMSTANCE 1"                                               
   V143 "SUB-CIRCUMSTANCE 2"                                               
   V144 "SUB-CIRCUMSTANCE 3"                                               
   V145 "SUB-CIRCUMSTANCE 4"                                               
   V146 "SUB-CIRCUMSTANCE 5"                                               
   V147 "SUB-CIRCUMSTANCE 6"                                               
   V148 "SUB-CIRCUMSTANCE 7"                                               
   V149 "SUB-CIRCUMSTANCE 8"                                               
   V150 "SUB-CIRCUMSTANCE 9"                                               
   V151 "SUB-CIRCUMSTANCE 10"                                              
   V152 "SUB-CIRCUMSTANCE 11".                                             
                                                                           
* SPSS VALUE LABELS COMMAND.                                               
                                                                           
VALUE LABELS                                                               
   V5                                                                      
   1 "ALABAMA"                                                             
   2 "ARIZONA"                                                             
   3 "ARKANSAS"                                                            
   4 "CALIFORNIA"                                                          
   5 "COLORADO"                                                            
   6 "CONNECTICUT"                                                         
   7 "DELAWARE"                                                            
   8 "WASHINGTON, D.C"                                                     
   9 "FLORIDA"                                                             
   10 "GEORGIA"                                                            
   11 "IDAHO"                                                              
   12 "ILLINOIS"                                                           
   13 "INDIANA"                                                            
   14 "IOWA"                                                               
   15 "KANSAS"                                                             
   16 "KENTUCKY"                                                           
   17 "LOUISIANA"                                                          
   18 "MAINE"                                                              
   19 "MARYLAND"                                                           
   20 "MASSACHUSETTS"                                                      
   21 "MICHIGAN"                                                           
   22 "MINNESOTA"                                                          
   23 "MISSISSIPPI"                                                        
   24 "MISSOURI"                                                           
   25 "MONTANA"                                                            
   26 "NEBRASKA"                                                           
   27 "NEVADA"                                                             
   28 "NEW HAMPSHIRE"                                                      
   29 "NEW JERSEY"                                                         
   30 "NEW MEXICO"                                                         
   31 "NEW YORK"                                                           
   32 "NORTH CAROLINA"                                                     
   33 "NORTH DAKOTA"                                                       
   34 "OHIO"                                                               
   35 "OKLAHOMA"                                                           
   36 "OREGON"                                                             
   37 "PENNSYLVANIA"                                                       
   38 "RHODE ISLAND"                                                       
   39 "SOUTH CAROLINA"                                                     
   40 "SOUTH DAKOTA"                                                       
   41 "TENNESSEE"                                                          
   42 "TEXAS"                                                              
   43 "UTAH"                                                               
   44 "VERMONT"                                                            
   45 "VIRGINIA"                                                           
   46 "WASHINGTON"                                                         
   47 "WEST VIRGINIA"                                                      
   48 "WISCONSIN"                                                          
   49 "WYOMING"                                                            
   50 "ALASKA"                                                             
   51 "HAWAII" /                                                           
   V7                                                                      
   1 "ALL CITIES 250K+"                                                    
   2 "CIT BET 100-249K"                                                    
   3 "CITIE BET 50-99K"                                                    
   4 "CITIE BET 25-49K"                                                    
   5 "CITIE BET 10-24K"                                                    
   6 "CIT BET 2.5-9.9K"                                                    
   7 "CITIE UNDER 2.5K"                                                    
   8 "NON-SMSA COUNTIE"                                                    
   9 "SMSA COUNTIES" /                                                     
   V8                                                                      
   11 "ALL CITIES 1M+"                                                     
   12 "CIT BET 500-999K"                                                   
   13 "CIT BET 250-499K"                                                   
   20 "CIT BET 100-249K"                                                   
   30 "CITIE BET 50-99K"                                                   
   40 "CITIE BET 25-49K"                                                   
   50 "CITIE BET 10-24K"                                                   
   60 "CIT BET 2.5-9.9K"                                                   
   70 "CITIE UNDER 2.5K"                                                   
   81 "NON-SMSA 100K+"                                                     
   82 "NON-SMSA 25-99K"                                                    
   83 "NON-SMSA 10-24K"                                                    
   84 "NON-SMSA <10K"                                                      
   91 "SMSA 100K+"                                                         
   92 "SMSA 25-99K"                                                        
   93 "SMSA 10-24.9K"                                                      
   94 "SMSA COUNT <10K" /                                                  
   V12                                                                     
   0 "NO COUNTY" /                                                         
   V13                                                                     
   0 "NO SMSA NUMBER" /                                                    
   V14                                                                     
   0 "NON-SUBURBAN"                                                        
   1 "SUBURBAN" /                                                          
   V17                                                                     
   1 "JANUARY"                                                             
   2 "FEBRUARY"                                                            
   3 "MARCH"                                                               
   4 "APRIL"                                                               
   5 "MAY"                                                                 
   6 "JUNE"                                                                
   7 "JULY"                                                                
   8 "AUGUST"                                                              
   9 "SEPTEMBER"                                                           
   10 "OCTOBER"                                                            
   11 "NOVEMBER"                                                           
   12 "DECEMBER" /                                                         
   V19                                                                     
   0 "NORMAL UPDATE"                                                       
   1 "ADJUSTMENT" /                                                        
   V20                                                                     
   1 "MURDER NONNEGLIG"                                                    
   2 "MANSL BY NEGLIG" /                                                   
   V22                                                                     
   1 "SINGLE VICT-OFFE"                                                    
   2 "SINGLE VIC UN OF"                                                    
   3 "SINGL VIC-MUL OF"                                                    
   4 "MULT VIC-SIN OFF"                                                    
   5 "MULTIPLE VIC-OFF"                                                    
   6 "MULT VIC-UNK OFF" /                                                  
   V25                                                                     
   0 "AGE UNKNOWN"                                                         
   1 "BIRTH TO 1 YR OL"                                                    
   99 "99 YRS OLD - MOR" /                                                 
   V26                                                                     
   0 "AGE UNKNOWN"                                                         
   1 "BIRTH TO 1 YR OL"                                                    
   99 "99 YRS OLD - MOR" /                                                 
   V27                                                                     
   0 "AGE UNKNOWN"                                                         
   1 "BIRTH TO 1 YR OL"                                                    
   99 "99 YRS OLD - MOR" /                                                 
   V28                                                                     
   0 "AGE UNKNOWN"                                                         
   1 "BIRTH TO 1 YR OL"                                                    
   99 "99 YRS OLD - MOR" /                                                 
   V29                                                                     
   0 "AGE UNKNOWN"                                                         
   1 "BIRTH TO 1 YR OL"                                                    
   99 "99 YRS OLD - MOR" /                                                 
   V30                                                                     
   0 "AGE UNKNOWN"                                                         
   1 "BIRTH TO 1 YR OL"                                                    
   99 "99 YRS OLD - MOR" /                                                 
   V31                                                                     
   0 "AGE UNKNOWN"                                                         
   1 "BIRTH TO 1 YR OL"                                                    
   99 "99 YRS OLD - MOR" /                                                 
   V32                                                                     
   0 "AGE UNKNOWN"                                                         
   1 "BIRTH TO 1 YR OL"                                                    
   99 "99 YRS OLD - MOR" /                                                 
   V33                                                                     
   0 "AGE UNKNOWN"                                                         
   1 "BIRTH TO 1 YR OL"                                                    
   99 "99 YRS OLD - MOR" /                                                 
   V34                                                                     
   0 "AGE UNKNOWN"                                                         
   1 "BIRTH TO 1 YR OL"                                                    
   99 "99 YRS OLD - MOR" /                                                 
   V35                                                                     
   1 "MALE"                                                                
   2 "FEMALE"                                                              
   9 "UNKNOWN" /                                                           
   V36                                                                     
   1 "MALE"                                                                
   2 "FEMALE"                                                              
   9 "UNKNOWN" /                                                           
   V37                                                                     
   1 "MALE"                                                                
   2 "FEMALE"                                                              
   9 "UNKNOWN" /                                                           
   V38                                                                     
   1 "MALE"                                                                
   2 "FEMALE"                                                              
   9 "UNKNOWN" /                                                           
   V39                                                                     
   1 "MALE"                                                                
   2 "FEMALE"                                                              
   9 "UNKNOWN" /                                                           
   V40                                                                     
   1 "MALE"                                                                
   2 "FEMALE"                                                              
   9 "UNKNOWN" /                                                           
   V41                                                                     
   1 "MALE"                                                                
   2 "FEMALE"                                                              
   9 "UNKNOWN" /                                                           
   V42                                                                     
   1 "MALE"                                                                
   2 "FEMALE"                                                              
   9 "UNKNOWN" /                                                           
   V43                                                                     
   1 "MALE"                                                                
   2 "FEMALE"                                                              
   9 "UNKNOWN" /                                                           
   V44                                                                     
   1 "MALE"                                                                
   2 "FEMALE"                                                              
   9 "UNKNOWN" /                                                           
   V45                                                                     
   1 "WHITE -CHICANO"                                                      
   2 "BLACK"                                                               
   3 "AMER INDI-ESKIMO"                                                    
   4 "ASIAN-PAC ISLAND"                                                    
   9 "UNKNOWN" /                                                           
   V46                                                                     
   1 "WHITE -CHICANO"                                                      
   2 "BLACK"                                                               
   3 "AMER INDI-ESKIMO"                                                    
   4 "ASIAN-PAC ISLAND"                                                    
   9 "UNKNOWN" /                                                           
   V47                                                                     
   1 "WHITE -CHICANO"                                                      
   2 "BLACK"                                                               
   3 "AMER INDI-ESKIMO"                                                    
   4 "ASIAN-PAC ISLAND"                                                    
   9 "UNKNOWN" /                                                           
   V48                                                                     
   1 "WHITE -CHICANO"                                                      
   2 "BLACK"                                                               
   3 "AMER INDI-ESKIMO"                                                    
   4 "ASIAN-PAC ISLAND"                                                    
   9 "UNKNOWN" /                                                           
   V49                                                                     
   1 "WHITE -CHICANO"                                                      
   2 "BLACK"                                                               
   3 "AMERI INDI-ESKIMO"                                                   
   4 "ASIAN-PAC ISLAND"                                                    
   9 "UNKNOWN" /                                                           
   V50                                                                     
   1 "WHITE -CHICANO"                                                      
   2 "BLACK"                                                               
   3 "AMERI INDI-ESKIMO"                                                   
   4 "ASIAN-PAC ISLAND"                                                    
   9 "UNKNOWN" /                                                           
   V51                                                                     
   1 "WHITE -CHICANO"                                                      
   2 "BLACK"                                                               
   3 "AMERI INDI-ESKIMO"                                                   
   4 "ASIAN-PAC ISLAND"                                                    
   9 "UNKNOWN" /                                                           
   V52                                                                     
   1 "WHITE -CHICANO"                                                      
   2 "BLACK"                                                               
   3 "AMERI INDI-ESKIMO"                                                   
   4 "ASIAN-PAC ISLAND"                                                    
   9 "UNKNOWN" /                                                           
   V53                                                                     
   1 "WHITE -CHICANO"                                                      
   2 "BLACK"                                                               
   3 "AMERI INDI-ESKIMO"                                                   
   4 "ASIAN-PAC ISLAND"                                                    
   9 "UNKNOWN" /                                                           
   V54                                                                     
   1 "WHITE -CHICANO"                                                      
   2 "BLACK"                                                               
   3 "AMERI INDI-ESKIMO"                                                   
   4 "ASIAN-PAC ISLAND"                                                    
   9 "UNKNOWN" /                                                           
   V55                                                                     
   1 "HISPANIC ORIGIN"                                                     
   2 "NOT OF HISPANIC"                                                     
   9 "UNKNOWN" /                                                           
   V56                                                                     
   1 "HISPANIC ORIGIN"                                                     
   2 "NOT OF HISPANIC"                                                     
   9 "UNKNOWN" /                                                           
   V57                                                                     
   1 "HISPANIC ORIGIN"                                                     
   2 "NOT OF HISPANIC"                                                     
   9 "UNKNOWN" /                                                           
   V58                                                                     
   1 "HISPANIC ORIGIN"                                                     
   2 "NOT OF HISPANIC"                                                     
   9 "UNKNOWN" /                                                           
   V59                                                                     
   1 "HISPANIC ORIGIN"                                                     
   2 "NOT OF HISPANIC"                                                     
   9 "UNKNOWN" /                                                           
   V60                                                                     
   1 "HISPANIC ORIGIN"                                                     
   2 "NOT OF HISPANIC"                                                     
   9 "UNKNOWN" /                                                           
   V61                                                                     
   1 "HISPANIC ORIGIN"                                                     
   2 "NOT OF HISPANIC"                                                     
   9 "UNKNOWN" /                                                           
   V62                                                                     
   1 "HISPANIC ORIGIN"                                                     
   2 "NOT OF HISPANIC"                                                     
   9 "UNKNOWN" /                                                           
   V63                                                                     
   1 "HISPANIC ORIGIN"                                                     
   2 "NOT OF HISPANIC"                                                     
   9 "UNKNOWN" /                                                           
   V64                                                                     
   1 "HISPANIC ORIGIN"                                                     
   2 "NOT OF HISPANIC"                                                     
   9 "UNKNOWN" /                                                           
   V65                                                                     
   0 "AGE UNKNOWN"                                                         
   1 "BIRTH TO 1 YR OL"                                                    
   99 "99 YRS OLD - MOR" /                                                 
   V66                                                                     
   0 "AGE UNKNOWN"                                                         
   1 "BIRTH TO 1 YR OL"                                                    
   99 "99 YRS OLD - MOR" /                                                 
   V67                                                                     
   0 "AGE UNKNOWN"                                                         
   1 "BIRTH TO 1 YR OL"                                                    
   99 "99 YRS OLD - MOR" /                                                 
   V68                                                                     
   0 "AGE UNKNOWN"                                                         
   1 "BIRTH TO 1 YR OL"                                                    
   99 "99 YRS OLD - MOR" /                                                 
   V69                                                                     
   0 "AGE UNKNOWN"                                                         
   1 "BIRTH TO 1 YR OL"                                                    
   99 "99 YRS OLD - MOR" /                                                 
   V70                                                                     
   0 "AGE UNKNOWN"                                                         
   1 "BIRTH TO 1 YR OL"                                                    
   99 "99 YRS OLD - MOR" /                                                 
   V71                                                                     
   0 "AGE UNKNOWN"                                                         
   1 "BIRTH TO 1 YR OL"                                                    
   99 "99 YRS OLD - MOR" /                                                 
   V72                                                                     
   0 "AGE UNKNOWN"                                                         
   1 "BIRTH TO 1 YR OL"                                                    
   99 "99 YRS OLD - MOR" /                                                 
   V73                                                                     
   0 "AGE UNKNOWN"                                                         
   1 "BIRTH TO 1 YR OL"                                                    
   99 "99 YRS OLD - MOR" /                                                 
   V74                                                                     
   0 "AGE UNKNOWN"                                                         
   1 "BIRTH TO 1 YR OL"                                                    
   99 "99 YRS OLD - MOR" /                                                 
   V75                                                                     
   0 "AGE UNKNOWN"                                                         
   1 "BIRTH TO 1 YR OL"                                                    
   99 "99 YRS OLD - MOR" /                                                 
   V76                                                                     
   1 "MALE"                                                                
   2 "FEMALE"                                                              
   9 "UNKNOWN" /                                                           
   V77                                                                     
   1 "MALE"                                                                
   2 "FEMALE"                                                              
   9 "UNKNOWN" /                                                           
   V78                                                                     
   1 "MALE"                                                                
   2 "FEMALE"                                                              
   9 "UNKNOWN" /                                                           
   V79                                                                     
   1 "MALE"                                                                
   2 "FEMALE"                                                              
   9 "UNKNOWN" /                                                           
   V80                                                                     
   1 "MALE"                                                                
   2 "FEMALE"                                                              
   9 "UNKNOWN" /                                                           
   V81                                                                     
   1 "MALE"                                                                
   2 "FEMALE"                                                              
   9 "UNKNOWN" /                                                           
   V82                                                                     
   1 "MALE"                                                                
   2 "FEMALE"                                                              
   9 "UNKNOWN" /                                                           
   V83                                                                     
   1 "MALE"                                                                
   2 "FEMALE"                                                              
   9 "UNKNOWN" /                                                           
   V84                                                                     
   1 "MALE"                                                                
   2 "FEMALE"                                                              
   9 "UNKNOWN" /                                                           
   V85                                                                     
   1 "MALE"                                                                
   2 "FEMALE"                                                              
   9 "UNKNOWN" /                                                           
   V86                                                                     
   1 "MALE"                                                                
   2 "FEMALE"                                                              
   9 "UNKNOWN" /                                                           
   V87                                                                     
   1 "WHITE -CHICANO"                                                      
   2 "BLACK"                                                               
   3 "AMER INDI-ESKIMO"                                                    
   4 "ASIAN-PAC ISLAND"                                                    
   9 "UNKNOWN" /                                                           
   V88                                                                     
   1 "WHITE -CHICANO"                                                      
   2 "BLACK"                                                               
   3 "AMER INDI-ESKIMO"                                                    
   4 "ASIAN-PAC ISLAND"                                                    
   9 "UNKNOWN" /                                                           
   V89                                                                     
   1 "WHITE -CHICANO"                                                      
   2 "BLACK"                                                               
   3 "AMER INDI-ESKIMO"                                                    
   4 "ASIAN-PAC ISLAND"                                                    
   9 "UNKNOWN" /                                                           
   V90                                                                     
   1 "WHITE -CHICANO"                                                      
   2 "BLACK"                                                               
   3 "AMER INDI-ESKIMO"                                                    
   4 "ASIAN-PAC ISLAND"                                                    
   9 "UNKNOWN" /                                                           
   V91                                                                     
   1 "WHITE -CHICANO"                                                      
   2 "BLACK"                                                               
   3 "AMER INDI-ESKIMO"                                                    
   4 "ASIAN-PAC ISLAND"                                                    
   9 "UNKNOWN" /                                                           
   V92                                                                     
   1 "WHITE -CHICANO"                                                      
   2 "BLACK"                                                               
   3 "AMER INDI-ESKIMO"                                                    
   4 "ASIAN-PAC ISLAND"                                                    
   9 "UNKNOWN" /                                                           
   V93                                                                     
   1 "WHITE -CHICANO"                                                      
   2 "BLACK"                                                               
   3 "AMER INDI-ESKIMO"                                                    
   4 "ASIAN-PAC ISLAND"                                                    
   9 "UNKNOWN" /                                                           
   V94                                                                     
   1 "WHITE -CHICANO"                                                      
   2 "BLACK"                                                               
   3 "AMER INDI-ESKIMO"                                                    
   4 "ASIAN-PAC ISLAND"                                                    
   9 "UNKNOWN" /                                                           
   V95                                                                     
   1 "WHITE -CHICANO"                                                      
   2 "BLACK"                                                               
   3 "AMER INDI-ESKIMO"                                                    
   4 "ASIAN-PAC ISLAND"                                                    
   9 "UNKNOWN" /                                                           
   V96                                                                     
   1 "WHITE -CHICANO"                                                      
   2 "BLACK"                                                               
   3 "AMER INDI-ESKIMO"                                                    
   4 "ASIAN-PAC ISLAND"                                                    
   9 "UNKNOWN" /                                                           
   V97                                                                     
   1 "WHITE -CHICANO"                                                      
   2 "BLACK"                                                               
   3 "AMER INDI-ESKIMO"                                                    
   4 "ASIAN-PAC ISLAND"                                                    
   9 "UNKNOWN" /                                                           
   V98                                                                     
   1 "HISPANIC ORIGIN"                                                     
   2 "NOT OF HISPANIC"                                                     
   9 "UNKNOWN" /                                                           
   V99                                                                     
   1 "HISPANIC ORIGIN"                                                     
   2 "NOT OF HISPANIC"                                                     
   9 "UNKNOWN" /                                                           
   V100                                                                    
   1 "HISPANIC ORIGIN"                                                     
   2 "NOT OF HISPANIC"                                                     
   9 "UNKNOWN" /                                                           
   V101                                                                    
   1 "HISPANIC ORIGIN"                                                     
   2 "NOT OF HISPANIC"                                                     
   9 "UNKNOWN" /                                                           
   V102                                                                    
   1 "HISPANIC ORIGIN"                                                     
   2 "NOT OF HISPANIC"                                                     
   9 "UNKNOWN" /                                                           
   V103                                                                    
   1 "HISPANIC ORIGIN"                                                     
   2 "NOT OF HISPANIC"                                                     
   9 "UNKNOWN" /                                                           
   V104                                                                    
   1 "HISPANIC ORIGIN"                                                     
   2 "NOT OF HISPANIC"                                                     
   9 "UNKNOWN" /                                                           
   V105                                                                    
   1 "HISPANIC ORIGIN"                                                     
   2 "NOT OF HISPANIC"                                                     
   9 "UNKNOWN" /                                                           
   V106                                                                    
   1 "HISPANIC ORIGIN"                                                     
   2 "NOT OF HISPANIC"                                                     
   9 "UNKNOWN" /                                                           
   V107                                                                    
   1 "HISPANIC ORIGIN"                                                     
   2 "NOT OF HISPANIC"                                                     
   9 "UNKNOWN" /                                                           
   V108                                                                    
   1 "HISPANIC ORIGIN"                                                     
   2 "NOT OF HISPANIC"                                                     
   9 "UNKNOWN" /                                                           
   V109                                                                    
   11 "FIREARM,TYPE DK"                                                    
   12 "HANDGUN -PISTOL,"                                                   
   13 "RIFLE"                                                              
   14 "SHOTGUN"                                                            
   15 "OTH GUN-UNKNOWN"                                                    
   20 "KNIFE - CUTTING"                                                    
   30 "BLUNT OBJECT"                                                       
   40 "PERSONAL WEAPONS"                                                   
   50 "POISON - NOT GAS"                                                   
   55 "PUSHED - THROWN"                                                    
   60 "EXPLOSIVES"                                                         
   65 "FIRE"                                                               
   70 "NARCOTICS DRUGS"                                                    
   75 "DROWNING"                                                           
   80 "STRANGULAT -HANG"                                                   
   85 "ASPHYXIATION-GAS"                                                   
   90 "OTH -TYPE DK" /                                                     
   V110                                                                    
   11 "FIREARM,TYPE DK"                                                    
   12 "HANDGUN -PISTOL,"                                                   
   13 "RIFLE"                                                              
   14 "SHOTGUN"                                                            
   15 "OTH GUN-UNKNOWN"                                                    
   20 "KNIFE - CUTTING"                                                    
   30 "BLUNT OBJECT"                                                       
   40 "PERSONAL WEAPONS"                                                   
   50 "POISON - NOT GAS"                                                   
   55 "PUSHED - THROWN"                                                    
   60 "EXPLOSIVES"                                                         
   65 "FIRE"                                                               
   70 "NARCOTICS DRUGS"                                                    
   75 "DROWNING"                                                           
   80 "STRANGULATION"                                                      
   85 "ASPHYXIATION-GAS"                                                   
   90 "OTH -TYPE DK" /                                                     
   V111                                                                    
   11 "FIREARM,TYPE DK"                                                    
   12 "HANDGUN -PISTOL,"                                                   
   13 "RIFLE"                                                              
   14 "SHOTGUN"                                                            
   15 "OTH GUN-UNKNOWN"                                                    
   20 "KNIFE - CUTTING"                                                    
   30 "BLUNT OBJECT"                                                       
   40 "PERSONAL WEAPONS"                                                   
   50 "POISON -NOT GAS"                                                    
   55 "PUSHED - THROWN"                                                    
   60 "EXPLOSIVES"                                                         
   65 "FIRE"                                                               
   70 "NARCOTICS DRUGS"                                                    
   75 "DROWNING"                                                           
   80 "STRANGULAT-HANG"                                                    
   85 "ASPHYXIATION-GAS"                                                   
   90 "OTH -TYPE DK" /                                                     
   V112                                                                    
   11 "FIREARM,TYPE"                                                       
   12 "HANDGUN -PISTOL,"                                                   
   13 "RIFLE"                                                              
   14 "SHOTGUN"                                                            
   15 "OTH GUN-UNKNOWN"                                                    
   20 "KNIFE - CUTTING"                                                    
   30 "BLUNT OBJECT"                                                       
   40 "PERSONAL WEAPONS"                                                   
   50 "POISON -NOT GAS"                                                    
   55 "PUSHED - THROWN"                                                    
   60 "EXPLOSIVES"                                                         
   65 "FIRE"                                                               
   70 "NARCOTICS DRUGS"                                                    
   75 "DROWNING"                                                           
   80 "STRANGULAT-HANG"                                                    
   85 "ASPHYXIATION-GAS"                                                   
   90 "OTH -TYPE DK" /                                                     
   V113                                                                    
   11 "FIREARM,TYPE DK"                                                    
   12 "HANDGUN -PISTOL,"                                                   
   13 "RIFLE"                                                              
   14 "SHOTGUN"                                                            
   15 "OTH GUN-UNKNOWN"                                                    
   20 "KNIFE - CUTTING"                                                    
   30 "BLUNT OBJECT"                                                       
   40 "PERSONAL WEAPONS"                                                   
   50 "POISON -NOT GAS"                                                    
   55 "PUSHED - THROWN"                                                    
   60 "EXPLOSIVES"                                                         
   65 "FIRE"                                                               
   70 "NARCOTICS DRUGS"                                                    
   75 "DROWNING"                                                           
   80 "STRANGULAT-HANG"                                                    
   85 "ASPHYXIATION-GAS"                                                   
   90 "OTH -TYPE DK" /                                                     
   V114                                                                    
   11 "FIREARM,TYPE DK"                                                    
   12 "HANDGUN -PISTOL,"                                                   
   13 "RIFLE"                                                              
   14 "SHOTGUN"                                                            
   15 "OTH GUN-UNKNOWN"                                                    
   20 "KNIFE - CUTTING"                                                    
   30 "BLUNT OBJECT"                                                       
   40 "PERSONAL WEAPONS"                                                   
   50 "POISON -NOT GAS"                                                    
   55 "PUSHED - THROWN"                                                    
   60 "EXPLOSIVES"                                                         
   65 "FIRE"                                                               
   70 "NARCOTICS DRUGS"                                                    
   75 "DROWNING"                                                           
   80 "STRANGULAT-HANG"                                                    
   85 "ASPHYXIATION-GAS"                                                   
   90 "OTH -TYPE DK" /                                                     
   V115                                                                    
   11 "FIREARM,TYPE DK"                                                    
   12 "HANDGUN -PISTOL,"                                                   
   13 "RIFLE"                                                              
   14 "SHOTGUN"                                                            
   15 "OTH GUN-UNKNOWN"                                                    
   20 "KNIFE - CUTTING"                                                    
   30 "BLUNT OBJECT"                                                       
   40 "PERSONAL WEAPONS"                                                   
   50 "POISON -NOT GAS"                                                    
   55 "PUSHED - THROWN"                                                    
   60 "EXPLOSIVES"                                                         
   65 "FIRE"                                                               
   70 "NARCOTICS DRUGS"                                                    
   75 "DROWNING"                                                           
   80 "STRANGULAT-HANG"                                                    
   85 "ASPHYXIATION-GAS"                                                   
   90 "OTH -TYPE DK" /                                                     
   V116                                                                    
   11 "FIREARM,TYPE DK"                                                    
   12 "HANDGUN -PISTOL,"                                                   
   13 "RIFLE"                                                              
   14 "SHOTGUN"                                                            
   15 "OTH GUN-UNKNOWN"                                                    
   20 "KNIFE - CUTTING"                                                    
   30 "BLUNT OBJECT"                                                       
   40 "PERSONAL WEAPONS"                                                   
   50 "POISON -NOT GAS"                                                    
   55 "PUSHED - THROWN"                                                    
   60 "EXPLOSIVES"                                                         
   65 "FIRE"                                                               
   70 "NARCOTICS DRUGS"                                                    
   75 "DROWNING"                                                           
   80 "STRANGULAT-HANG"                                                    
   85 "ASPHYXIATION-GAS"                                                   
   90 "OTH -TYPE DK" /                                                     
   V117                                                                    
   11 "FIREARM,TYPE DK"                                                    
   12 "HANDGUN -PISTOL,"                                                   
   13 "RIFLE"                                                              
   14 "SHOTGUN"                                                            
   15 "OTH GUN-UNKNOWN"                                                    
   20 "KNIFE - CUTTING"                                                    
   30 "BLUNT OBJECT"                                                       
   40 "PERSONAL WEAPONS"                                                   
   50 "POISON -NOT GAS"                                                    
   55 "PUSHED - THROWN"                                                    
   60 "EXPLOSIVES"                                                         
   65 "FIRE"                                                               
   70 "NARCOTICS DRUGS"                                                    
   75 "DROWNING"                                                           
   80 "STRANGULAT-HANG"                                                    
   85 "ASPHYXIATION-GAS"                                                   
   90 "OTH -TYPE DK" /                                                     
   V118                                                                    
   11 "FIREARM,TYPE DK"                                                    
   12 "HANDGUN -PISTOL,"                                                   
   13 "RIFLE"                                                              
   14 "SHOTGUN"                                                            
   15 "OTH GUN-UNKNOWN"                                                    
   20 "KNIFE - CUTTING"                                                    
   30 "BLUNT OBJECT"                                                       
   40 "PERSONAL WEAPONS"                                                   
   50 "POISON -NOT GAS"                                                    
   55 "PUSHED - THROWN"                                                    
   60 "EXPLOSIVES"                                                         
   65 "FIRE"                                                               
   70 "NARCOTICS DRUGS"                                                    
   75 "DROWNING"                                                           
   80 "STRANGULAT-HANG"                                                    
   85 "ASPHYXIATION-GAS"                                                   
   90 "OTH -TYPE DK" /                                                     
   V119                                                                    
   11 "FIREARM,TYPE DK"                                                    
   12 "HANDGUN -PISTOL,"                                                   
   13 "RIFLE"                                                              
   14 "SHOTGUN"                                                            
   15 "OTH GUN-UNKNOWN"                                                    
   20 "KNIFE - CUTTING"                                                    
   30 "BLUNT OBJECT"                                                       
   40 "PERSONAL WEAPONS"                                                   
   50 "POISON -NOT GAS"                                                    
   55 "PUSHED - THROWN"                                                    
   60 "EXPLOSIVES"                                                         
   65 "FIRE"                                                               
   70 "NARCOTICS DRUGS"                                                    
   75 "DROWNING"                                                           
   80 "STRANGULAT-HANG"                                                    
   85 "ASPHYXIATION-GAS"                                                   
   90 "OTH -TYPE DK" /                                                     
   V120                                                                    
   1 "HUSBAND"                                                             
   2 "WIFE"                                                                
   3 "COMMON-LAW HUSBA"                                                    
   4 "COMMON-LAW WIFE"                                                     
   5 "MOTHER"                                                              
   6 "FATHER"                                                              
   7 "SON"                                                                 
   8 "DAUGHTER"                                                            
   9 "BROTHER"                                                             
   10 "SISTER"                                                             
   11 "IN-LAW"                                                             
   12 "STEPFATHER"                                                         
   13 "STEPMOTHER"                                                         
   14 "STEPSON"                                                            
   15 "STEPDAUGHTER"                                                       
   16 "OTHER FAMILY"                                                       
   17 "NEIGHBOR"                                                           
   18 "ACQUAINTANCE"                                                       
   19 "BOYFRIEND"                                                          
   20 "GIRLFRIEND"                                                         
   21 "EX-HUSBAND"                                                         
   22 "EX-WIFE"                                                            
   23 "EMPLOYEE"                                                           
   24 "EMPLOYER"                                                           
   25 "FRIEND"                                                             
   26 "HOMOSEXUAL RELAT"                                                   
   27 "OTH -KNOWN TO VI"                                                   
   28 "STRANGER"                                                           
   99 "DK,ALL INSTANCES" /                                                 
   V121                                                                    
   1 "HUSBAND"                                                             
   2 "WIFE"                                                                
   3 "COMMON-LAW HUSBA"                                                    
   4 "COMMON-LAW WIFE"                                                     
   5 "MOTHER"                                                              
   6 "FATHER"                                                              
   7 "SON"                                                                 
   8 "DAUGHTER"                                                            
   9 "BROTHER"                                                             
   10 "SISTER"                                                             
   11 "IN-LAW"                                                             
   12 "STEPFATHER"                                                         
   13 "STEPMOTHER"                                                         
   14 "STEPSON"                                                            
   15 "STEPDAUGHTER"                                                       
   16 "OTHER FAMILY"                                                       
   17 "NEIGHBOR"                                                           
   18 "ACQUAINTANCE"                                                       
   19 "BOYFRIEND"                                                          
   20 "GIRLFRIEND"                                                         
   21 "EX-HUSBAND"                                                         
   22 "EX-WIFE"                                                            
   23 "EMPLOYEE"                                                           
   24 "EMPLOYER"                                                           
   25 "FRIEND"                                                             
   26 "HOMOSEXUAL RELAT"                                                   
   27 "OTH -KNOWN TO VI"                                                   
   28 "STRANGER"                                                           
   99 "DK,ALL INSTANCES" /                                                 
   V122                                                                    
   1 "HUSBAND"                                                             
   2 "WIFE"                                                                
   3 "COMMON-LAW HUSBA"                                                    
   4 "COMMON-LAW WIFE"                                                     
   5 "MOTHER"                                                              
   6 "FATHER"                                                              
   7 "SON"                                                                 
   8 "DAUGHTER"                                                            
   9 "BROTHER"                                                             
   10 "SISTER"                                                             
   11 "IN-LAW"                                                             
   12 "STEPFATHER"                                                         
   13 "STEPMOTHER"                                                         
   14 "STEPSON"                                                            
   15 "STEPDAUGHTER"                                                       
   16 "OTHER FAMILY"                                                       
   17 "NEIGHBOR"                                                           
   18 "ACQUAINTANCE"                                                       
   19 "BOYFRIEND"                                                          
   20 "GIRLFRIEND"                                                         
   21 "EX-HUSBAND"                                                         
   22 "EX-WIFE"                                                            
   23 "EMPLOYEE"                                                           
   24 "EMPLOYER"                                                           
   25 "FRIEND"                                                             
   26 "HOMOSEXUAL RELAT"                                                   
   27 "OTH -KNOWN TO VI"                                                   
   28 "STRANGER"                                                           
   99 "DK,ALL INSTANCES" /                                                 
   V123                                                                    
   1 "HUSBAND"                                                             
   2 "WIFE"                                                                
   3 "COMMON-LAW HUSBA"                                                    
   4 "COMMON-LAW WIFE"                                                     
   5 "MOTHER"                                                              
   6 "FATHER"                                                              
   7 "SON"                                                                 
   8 "DAUGHTER"                                                            
   9 "BROTHER"                                                             
   10 "SISTER"                                                             
   11 "IN-LAW"                                                             
   12 "STEPFATHER"                                                         
   13 "STEPMOTHER"                                                         
   14 "STEPSON"                                                            
   15 "STEPDAUGHTER"                                                       
   16 "OTHER FAMILY"                                                       
   17 "NEIGHBOR"                                                           
   18 "ACQUAINTANCE"                                                       
   19 "BOYFRIEND"                                                          
   20 "GIRLFRIEND"                                                         
   21 "EX-HUSBAND"                                                         
   22 "EX-WIFE"                                                            
   23 "EMPLOYEE"                                                           
   24 "EMPLOYER"                                                           
   25 "FRIEND"                                                             
   26 "HOMOSEXUAL RELAT"                                                   
   27 "OTH -KNOWN TO VI"                                                   
   28 "STRANGER"                                                           
   99 "DK,ALL INSTANCES" /                                                 
   V124                                                                    
   1 "HUSBAND"                                                             
   2 "WIFE"                                                                
   3 "COMMON-LAW HUSBA"                                                    
   4 "COMMON-LAW WIFE"                                                     
   5 "MOTHER"                                                              
   6 "FATHER"                                                              
   7 "SON"                                                                 
   8 "DAUGHTER"                                                            
   9 "BROTHER"                                                             
   10 "SISTER"                                                             
   11 "IN-LAW"                                                             
   12 "STEPFATHER"                                                         
   13 "STEPMOTHER"                                                         
   14 "STEPSON"                                                            
   15 "STEPDAUGHTER"                                                       
   16 "OTHER FAMILY"                                                       
   17 "NEIGHBOR"                                                           
   18 "ACQUAINTANCE"                                                       
   19 "BOYFRIEND"                                                          
   20 "GIRLFRIEND"                                                         
   21 "EX-HUSBAND"                                                         
   22 "EX-WIFE"                                                            
   23 "EMPLOYEE"                                                           
   24 "EMPLOYER"                                                           
   25 "FRIEND"                                                             
   26 "HOMOSEXUAL RELAT"                                                   
   27 "OTH -KNOWN TO VI"                                                   
   28 "STRANGER"                                                           
   99 "DK,ALL INSTANCES" /                                                 
   V125                                                                    
   1 "HUSBAND"                                                             
   2 "WIFE"                                                                
   3 "COMMON-LAW HUSBA"                                                    
   4 "COMMON-LAW WIFE"                                                     
   5 "MOTHER"                                                              
   6 "FATHER"                                                              
   7 "SON"                                                                 
   8 "DAUGHTER"                                                            
   9 "BROTHER"                                                             
   10 "SISTER"                                                             
   11 "IN-LAW"                                                             
   12 "STEPFATHER"                                                         
   13 "STEPMOTHER"                                                         
   14 "STEPSON"                                                            
   15 "STEPDAUGHTER"                                                       
   16 "OTHER FAMILY"                                                       
   17 "NEIGHBOR"                                                           
   18 "ACQUAINTANCE"                                                       
   19 "BOYFRIEND"                                                          
   20 "GIRLFRIEND"                                                         
   21 "EX-HUSBAND"                                                         
   22 "EX-WIFE"                                                            
   23 "EMPLOYEE"                                                           
   24 "EMPLOYER"                                                           
   25 "FRIEND"                                                             
   26 "HOMOSEXUAL RELAT"                                                   
   27 "OTH -KNOWN TO VI"                                                   
   28 "STRANGER"                                                           
   99 "DK,ALL INSTANCES" /                                                 
   V126                                                                    
   1 "HUSBAND"                                                             
   2 "WIFE"                                                                
   3 "COMMON-LAW HUSBA"                                                    
   4 "COMMON-LAW WIFE"                                                     
   5 "MOTHER"                                                              
   6 "FATHER"                                                              
   7 "SON"                                                                 
   8 "DAUGHTER"                                                            
   9 "BROTHER"                                                             
   10 "SISTER"                                                             
   11 "IN-LAW"                                                             
   12 "STEPFATHER"                                                         
   13 "STEPMOTHER"                                                         
   14 "STEPSON"                                                            
   15 "STEPDAUGHTER"                                                       
   16 "OTHER FAMILY"                                                       
   17 "NEIGHBOR"                                                           
   18 "ACQUAINTANCE"                                                       
   19 "BOYFRIEND"                                                          
   20 "GIRLFRIEND"                                                         
   21 "EX-HUSBAND"                                                         
   22 "EX-WIFE"                                                            
   23 "EMPLOYEE"                                                           
   24 "EMPLOYER"                                                           
   25 "FRIEND"                                                             
   26 "HOMOSEXUAL RELAT"                                                   
   27 "OTH -KNOWN TO VI"                                                   
   28 "STRANGER"                                                           
   99 "DK,ALL INSTANCES" /                                                 
   V127                                                                    
   1 "HUSBAND"                                                             
   2 "WIFE"                                                                
   3 "COMMON-LAW HUSBA"                                                    
   4 "COMMON-LAW WIFE"                                                     
   5 "MOTHER"                                                              
   6 "FATHER"                                                              
   7 "SON"                                                                 
   8 "DAUGHTER"                                                            
   9 "BROTHER"                                                             
   10 "SISTER"                                                             
   11 "IN-LAW"                                                             
   12 "STEPFATHER"                                                         
   13 "STEPMOTHER"                                                         
   14 "STEPSON"                                                            
   15 "STEPDAUGHTER"                                                       
   16 "OTHER FAMILY"                                                       
   17 "NEIGHBOR"                                                           
   18 "ACQUAINTANCE"                                                       
   19 "BOYFRIEND"                                                          
   20 "GIRLFRIEND"                                                         
   21 "EX-HUSBAND"                                                         
   22 "EX-WIFE"                                                            
   23 "EMPLOYEE"                                                           
   24 "EMPLOYER"                                                           
   25 "FRIEND"                                                             
   26 "HOMOSEXUAL RELAT"                                                   
   27 "OTH -KNOWN TO VI"                                                   
   28 "STRANGER"                                                           
   99 "DK,ALL INSTANCES" /                                                 
   V128                                                                    
   1 "HUSBAND"                                                             
   2 "WIFE"                                                                
   3 "COMMON-LAW HUSBA"                                                    
   4 "COMMON-LAW WIFE"                                                     
   5 "MOTHER"                                                              
   6 "FATHER"                                                              
   7 "SON"                                                                 
   8 "DAUGHTER"                                                            
   9 "BROTHER"                                                             
   10 "SISTER"                                                             
   11 "IN-LAW"                                                             
   12 "STEPFATHER"                                                         
   13 "STEPMOTHER"                                                         
   14 "STEPSON"                                                            
   15 "STEPDAUGHTER"                                                       
   16 "OTHER FAMILY"                                                       
   17 "NEIGHBOR"                                                           
   18 "ACQUAINTANCE"                                                       
   19 "BOYFRIEND"                                                          
   20 "GIRLFRIEND"                                                         
   21 "EX-HUSBAND"                                                         
   22 "EX-WIFE"                                                            
   23 "EMPLOYEE"                                                           
   24 "EMPLOYER"                                                           
   25 "FRIEND"                                                             
   26 "HOMOSEXUAL RELAT"                                                   
   27 "OTH -KNOWN TO VI"                                                   
   28 "STRANGER"                                                           
   99 "DK,ALL INSTANCES" /                                                 
   V129                                                                    
   1 "HUSBAND"                                                             
   2 "WIFE"                                                                
   3 "COMMON-LAW HUSBA"                                                    
   4 "COMMON-LAW WIFE"                                                     
   5 "MOTHER"                                                              
   6 "FATHER"                                                              
   7 "SON"                                                                 
   8 "DAUGHTER"                                                            
   9 "BROTHER"                                                             
   10 "SISTER"                                                             
   11 "IN-LAW"                                                             
   12 "STEPFATHER"                                                         
   13 "STEPMOTHER"                                                         
   14 "STEPSON"                                                            
   15 "STEPDAUGHTER"                                                       
   16 "OTHER FAMILY"                                                       
   17 "NEIGHBOR"                                                           
   18 "ACQUAINTANCE"                                                       
   19 "BOYFRIEND"                                                          
   20 "GIRLFRIEND"                                                         
   21 "EX-HUSBAND"                                                         
   22 "EX-WIFE"                                                            
   23 "EMPLOYEE"                                                           
   24 "EMPLOYER"                                                           
   25 "FRIEND"                                                             
   26 "HOMOSEXUAL RELAT"                                                   
   27 "OTH -KNOWN TO VI"                                                   
   28 "STRANGER"                                                           
   99 "DK,ALL INSTANCES" /                                                 
   V130                                                                    
   1 "HUSBAND"                                                             
   2 "WIFE"                                                                
   3 "COMMON-LAW HUSBA"                                                    
   4 "COMMON-LAW WIFE"                                                     
   5 "MOTHER"                                                              
   6 "FATHER"                                                              
   7 "SON"                                                                 
   8 "DAUGHTER"                                                            
   9 "BROTHER"                                                             
   10 "SISTER"                                                             
   11 "IN-LAW"                                                             
   12 "STEPFATHER"                                                         
   13 "STEPMOTHER"                                                         
   14 "STEPSON"                                                            
   15 "STEPDAUGHTER"                                                       
   16 "OTHER FAMILY"                                                       
   17 "NEIGHBOR"                                                           
   18 "ACQUAINTANCE"                                                       
   19 "BOYFRIEND"                                                          
   20 "GIRLFRIEND"                                                         
   21 "EX-HUSBAND"                                                         
   22 "EX-WIFE"                                                            
   23 "EMPLOYEE"                                                           
   24 "EMPLOYER"                                                           
   25 "FRIEND"                                                             
   26 "HOMOSEXUAL RELAT"                                                   
   27 "OTH -KNOWN TO VI"                                                   
   28 "STRANGER"                                                           
   99 "DK,ALL INSTANCES" /                                                 
   V131                                                                    
   2 "RAPE"                                                                
   3 "ROBBERY"                                                             
   5 "BURGLARY"                                                            
   6 "LARCENY"                                                             
   7 "MOTOR VEHI THEFT"                                                    
   9 "ARSON"                                                               
   10 "PROSTITUTIO-VICE"                                                   
   17 "OTH SEX OFFENSE"                                                    
   18 "NARCOTIC DRUG"                                                      
   19 "GAMBLING"                                                           
   20 "ABORTION"                                                           
   26 "OTH -FELONY TYPE"                                                   
   40 "LOVER-S TRIANGLE"                                                   
   41 "KID KILL-SITTER"                                                    
   42 "BRAWL - ALCHOL"                                                     
   43 "BRAWL-NARCOTICS"                                                    
   44 "ARGUMENT - MONEY"                                                   
   45 "OTHER ARGUMENTS"                                                    
   46 "GANGLAND KILLING"                                                   
   47 "JUV GANG KILLING"                                                   
   48 "INSTITUTION KILL"                                                   
   49 "SNIPER ATTACK"                                                      
   50 "VIC SHOT HUNT AC"                                                   
   51 "GUNCLEANIN DEATH"                                                   
   52 "KIDS PLAY WITHGUN"                                                  
   53 "OTH NEGLIGEN GUN"                                                   
   59 "ALL OTH MANSLAUG"                                                   
   60 "OTH NON-FEL TYPE"                                                   
   70 "ALL SUSPECT FELO"                                                   
   80 "JUSTIF HOMI CIVIL"                                                  
   81 "JUSTIF HOMI POLI"                                                   
   99 "ALL INSTANCES" /                                                    
   V132                                                                    
   2 "RAPE"                                                                
   3 "ROBBERY"                                                             
   5 "BURGLARY"                                                            
   6 "LARCENY"                                                             
   7 "MOTOR VEHI THEFT"                                                    
   9 "ARSON"                                                               
   10 "PROSTITUTIO-VICE"                                                   
   17 "OTH SEX OFFENSE"                                                    
   18 "NARCOTIC DRUG"                                                      
   19 "GAMBLING"                                                           
   20 "ABORTION"                                                           
   26 "OTH -FELONY TYPE"                                                   
   40 "LOVER-S TRIANGLE"                                                   
   41 "KID KILL-SITTER"                                                    
   42 "BRAWL - ALCOHOL"                                                    
   43 "BRAWL-NARCOTICS"                                                    
   44 "ARGUMENT - MONEY"                                                   
   45 "OTHER ARGUMENTS"                                                    
   46 "GANGLAND KILLING"                                                   
   47 "JUV GANG KILLING"                                                   
   48 "INSTITUTION KILL"                                                   
   49 "SNIPER ATTACK"                                                      
   50 "VIC SHOT HUNT AC"                                                   
   51 "GUNCLEANIN DEATH"                                                   
   52 "KIDS PLAY WITHGUN"                                                  
   53 "OTH NEGLIGEN GUN"                                                   
   59 "ALL OTH MANSLAUG"                                                   
   60 "OTH NON-FEL TYPE"                                                   
   70 "ALL SUSPEC FELON"                                                   
   80 "JUSTI HOMI CIVIL"                                                   
   81 "JUSTI HOMI POLIC"                                                   
   99 "ALL INSTANCES" /                                                    
   V133                                                                    
   2 "RAPE"                                                                
   3 "ROBBERY"                                                             
   5 "BURGLARY"                                                            
   6 "LARCENY"                                                             
   7 "MOTOR VEHI THEFT"                                                    
   9 "ARSON"                                                               
   10 "PROSTITUTIO-VICE"                                                   
   17 "OTH SEX OFFENSE"                                                    
   18 "NARCOTIC DRUG"                                                      
   19 "GAMBLING"                                                           
   20 "ABORTION"                                                           
   26 "OTH -FELONY TYPE"                                                   
   40 "LOVER-S TRIANGLE"                                                   
   41 "KID KILL-SITTER"                                                    
   42 "BRAWL - ALCHOL"                                                     
   43 "BRAWL-NARCOTICS"                                                    
   44 "ARGUMENT - MONEY"                                                   
   45 "OTHER ARGUMENTS"                                                    
   46 "GANGLAND KILLING"                                                   
   47 "JUV GANG KILLING"                                                   
   48 "INSTITUTION KILL"                                                   
   49 "SNIPER ATTACK"                                                      
   50 "VIC SHOT HUNT AC"                                                   
   51 "GUNCLEANIN DEATH"                                                   
   52 "KIDS PLAY WITHGUN"                                                  
   53 "OTH NEGLIGEN GUN"                                                   
   59 "ALL OTH MANSLAUG"                                                   
   60 "OTH NON-FEL TYPE"                                                   
   70 "ALL SUSPECT FELO"                                                   
   80 "JUSTIF HOMI CIVIL"                                                  
   81 "JUSTIF HOMI POLI"                                                   
   99 "ALL INSTANCES" /                                                    
   V134                                                                    
   2 "RAPE"                                                                
   3 "ROBBERY"                                                             
   5 "BURGLARY"                                                            
   6 "LARCENY"                                                             
   7 "MOTOR VEHI THEFT"                                                    
   9 "ARSON"                                                               
   10 "PROSTITUTIO-VICE"                                                   
   17 "OTH SEX OFFENSE"                                                    
   18 "NARCOTIC DRUG"                                                      
   19 "GAMBLING"                                                           
   20 "ABORTION"                                                           
   26 "OTH -FELONY TYPE"                                                   
   40 "LOVER-S TRIANGLE"                                                   
   41 "KID KILL-SITTER"                                                    
   42 "BRAWL - ALCHOL"                                                     
   43 "BRAWL-NARCOTICS"                                                    
   44 "ARGUMENT - MONEY"                                                   
   45 "OTHER ARGUMENTS"                                                    
   46 "GANGLAND KILLING"                                                   
   47 "JUV GANG KILLING"                                                   
   48 "INSTITUTION KILL"                                                   
   49 "SNIPER ATTACK"                                                      
   50 "VIC SHOT HUNT AC"                                                   
   51 "GUNCLEANIN DEATH"                                                   
   52 "KIDS PLAY WITHGUN"                                                  
   53 "OTH NEGLIGEN GUN"                                                   
   59 "ALL OTH MANSLAUG"                                                   
   60 "OTH NON-FEL TYPE"                                                   
   70 "ALL SUSPECT FELO"                                                   
   80 "JUSTIF HOMI CIVIL"                                                  
   81 "JUSTIF HOMI POLI"                                                   
   99 "ALL INSTANCES" /                                                    
   V135                                                                    
   2 "RAPE"                                                                
   3 "ROBBERY"                                                             
   5 "BURGLARY"                                                            
   6 "LARCENY"                                                             
   7 "MOTOR VEHI THEFT"                                                    
   9 "ARSON"                                                               
   10 "PROSTITUTIO-VICE"                                                   
   17 "OTH SEX OFFENSE"                                                    
   18 "NARCOTIC DRUG"                                                      
   19 "GAMBLING"                                                           
   20 "ABORTION"                                                           
   26 "OTH -FELONY TYPE"                                                   
   40 "LOVER-S TRIANGLE"                                                   
   41 "KID KILL-SITTER"                                                    
   42 "BRAWL - ALCHOL"                                                     
   43 "BRAWL-NARCOTICS"                                                    
   44 "ARGUMENT - MONEY"                                                   
   45 "OTHER ARGUMENTS"                                                    
   46 "GANGLAND KILLING"                                                   
   47 "JUV GANG KILLING"                                                   
   48 "INSTITUTION KILL"                                                   
   49 "SNIPER ATTACK"                                                      
   50 "VIC SHOT HUNT AC"                                                   
   51 "GUNCLEANIN DEATH"                                                   
   52 "KIDS PLAY WITHGUN"                                                  
   53 "OTH NEGLIGEN GUN"                                                   
   59 "ALL OTH MANSLAUG"                                                   
   60 "OTH NON-FEL TYPE"                                                   
   70 "ALL SUSPECT FELO"                                                   
   80 "JUSTIF HOMI CIVIL"                                                  
   81 "JUSTIF HOMI POLI"                                                   
   99 "ALL INSTANCES" /                                                    
   V136                                                                    
   2 "RAPE"                                                                
   3 "ROBBERY"                                                             
   5 "BURGLARY"                                                            
   6 "LARCENY"                                                             
   7 "MOTOR VEHI THEFT"                                                    
   9 "ARSON"                                                               
   10 "PROSTITUTIO-VICE"                                                   
   17 "OTH SEX OFFENSE"                                                    
   18 "NARCOTIC DRUG"                                                      
   19 "GAMBLING"                                                           
   20 "ABORTION"                                                           
   26 "OTH -FELONY TYPE"                                                   
   40 "LOVER-S TRIANGLE"                                                   
   41 "KID KILL-SITTER"                                                    
   42 "BRAWL - ALCHOL"                                                     
   43 "BRAWL-NARCOTICS"                                                    
   44 "ARGUMENT - MONEY"                                                   
   45 "OTHER ARGUMENTS"                                                    
   46 "GANGLAND KILLING"                                                   
   47 "JUV GANG KILLING"                                                   
   48 "INSTITUTION KILL"                                                   
   49 "SNIPER ATTACK"                                                      
   50 "VIC SHOT HUNT AC"                                                   
   51 "GUNCLEANIN DEATH"                                                   
   52 "KIDS PLAY WITHGUN"                                                  
   53 "OTH NEGLIGEN GUN"                                                   
   59 "ALL OTH MANSLAUG"                                                   
   60 "OTH NON-FEL TYPE"                                                   
   70 "ALL SUSPECT FELO"                                                   
   80 "JUSTIF HOMI CIVIL"                                                  
   81 "JUSTIF HOMI POLI"                                                   
   99 "ALL INSTANCES" /                                                    
   V137                                                                    
   2 "RAPE"                                                                
   3 "ROBBERY"                                                             
   5 "BURGLARY"                                                            
   6 "LARCENY"                                                             
   7 "MOTOR VEHI THEFT"                                                    
   9 "ARSON"                                                               
   10 "PROSTITUTIO-VICE"                                                   
   17 "OTH SEX OFFENSE"                                                    
   18 "NARCOTIC DRUG"                                                      
   19 "GAMBLING"                                                           
   20 "ABORTION"                                                           
   26 "OTH -FELONY TYPE"                                                   
   40 "LOVER-S TRIANGLE"                                                   
   41 "KID KILL-SITTER"                                                    
   42 "BRAWL - ALCHOL"                                                     
   43 "BRAWL-NARCOTICS"                                                    
   44 "ARGUMENT - MONEY"                                                   
   45 "OTHER ARGUMENTS"                                                    
   46 "GANGLAND KILLING"                                                   
   47 "JUV GANG KILLING"                                                   
   48 "INSTITUTION KILL"                                                   
   49 "SNIPER ATTACK"                                                      
   50 "VIC SHOT HUNT AC"                                                   
   51 "GUNCLEANIN DEATH"                                                   
   52 "KIDS PLAY WITHGUN"                                                  
   53 "OTH NEGLIGEN GUN"                                                   
   59 "ALL OTH MANSLAUG"                                                   
   60 "OTH NON-FEL TYPE"                                                   
   70 "ALL SUSPECT FELO"                                                   
   80 "JUSTIF HOMI CIVIL"                                                  
   81 "JUSTIF HOMI POLI"                                                   
   99 "ALL INSTANCES" /                                                    
   V138                                                                    
   2 "RAPE"                                                                
   3 "ROBBERY"                                                             
   5 "BURGLARY"                                                            
   6 "LARCENY"                                                             
   7 "MOTOR VEHI THEFT"                                                    
   9 "ARSON"                                                               
   10 "PROSTITUTIO-VICE"                                                   
   17 "OTH SEX OFFENSE"                                                    
   18 "NARCOTIC DRUG"                                                      
   19 "GAMBLING"                                                           
   20 "ABORTION"                                                           
   26 "OTH -FELONY TYPE"                                                   
   40 "LOVER-S TRIANGLE"                                                   
   41 "KID KILL-SITTER"                                                    
   42 "BRAWL - ALCHOL"                                                     
   43 "BRAWL-NARCOTICS"                                                    
   44 "ARGUMENT - MONEY"                                                   
   45 "OTHER ARGUMENTS"                                                    
   46 "GANGLAND KILLING"                                                   
   47 "JUV GANG KILLING"                                                   
   48 "INSTITUTION KILL"                                                   
   49 "SNIPER ATTACK"                                                      
   50 "VIC SHOT HUNT AC"                                                   
   51 "GUNCLEANIN DEATH"                                                   
   52 "KIDS PLAY WITHGUN"                                                  
   53 "OTH NEGLIGEN GUN"                                                   
   59 "ALL OTH MANSLAUG"                                                   
   60 "OTH NON-FEL TYPE"                                                   
   70 "ALL SUSPECT FELO"                                                   
   80 "JUSTIF HOMI CIVIL"                                                  
   81 "JUSTIF HOMI POLI"                                                   
   99 "ALL INSTANCES" /                                                    
   V139                                                                    
   2 "RAPE"                                                                
   3 "ROBBERY"                                                             
   5 "BURGLARY"                                                            
   6 "LARCENY"                                                             
   7 "MOTOR VEHI THEFT"                                                    
   9 "ARSON"                                                               
   10 "PROSTITUTIO-VICE"                                                   
   17 "OTH SEX OFFENSE"                                                    
   18 "NARCOTIC DRUG"                                                      
   19 "GAMBLING"                                                           
   20 "ABORTION"                                                           
   26 "OTH -FELONY TYPE"                                                   
   40 "LOVER-S TRIANGLE"                                                   
   41 "KID KILL-SITTER"                                                    
   42 "BRAWL - ALCHOL"                                                     
   43 "BRAWL-NARCOTICS"                                                    
   44 "ARGUMENT - MONEY"                                                   
   45 "OTHER ARGUMENTS"                                                    
   46 "GANGLAND KILLING"                                                   
   47 "JUV GANG KILLING"                                                   
   48 "INSTITUTION KILL"                                                   
   49 "SNIPER ATTACK"                                                      
   50 "VIC SHOT HUNT AC"                                                   
   51 "GUNCLEANIN DEATH"                                                   
   52 "KIDS PLAY WITHGUN"                                                  
   53 "OTH NEGLIGEN GUN"                                                   
   59 "ALL OTH MANSLAUG"                                                   
   60 "OTH NON-FEL TYPE"                                                   
   70 "ALL SUSPECT FELO"                                                   
   80 "JUSTIF HOMI CIVIL"                                                  
   81 "JUSTIF HOMI POLI"                                                   
   99 "ALL INSTANCES" /                                                    
   V140                                                                    
   2 "RAPE"                                                                
   3 "ROBBERY"                                                             
   5 "BURGLARY"                                                            
   6 "LARCENY"                                                             
   7 "MOTOR VEHI THEFT"                                                    
   9 "ARSON"                                                               
   10 "PROSTITUTIO-VICE"                                                   
   17 "OTH SEX OFFENSE"                                                    
   18 "NARCOTIC DRUG"                                                      
   19 "GAMBLING"                                                           
   20 "ABORTION"                                                           
   26 "OTH -FELONY TYPE"                                                   
   40 "LOVER-S TRIANGLE"                                                   
   41 "KID KILL-SITTER"                                                    
   42 "BRAWL - ALCHOL"                                                     
   43 "BRAWL-NARCOTICS"                                                    
   44 "ARGUMENT - MONEY"                                                   
   45 "OTHER ARGUMENTS"                                                    
   46 "GANGLAND KILLING"                                                   
   47 "JUV GANG KILLING"                                                   
   48 "INSTITUTION KILL"                                                   
   49 "SNIPER ATTACK"                                                      
   50 "VIC SHOT HUNT AC"                                                   
   51 "GUNCLEANIN DEATH"                                                   
   52 "KIDS PLAY WITHGUN"                                                  
   53 "OTH NEGLIGEN GUN"                                                   
   59 "ALL OTH MANSLAUG"                                                   
   60 "OTH NON-FEL TYPE"                                                   
   70 "ALL SUSPECT FELO"                                                   
   80 "JUSTIF HOMI CIVIL"                                                  
   81 "JUSTIF HOMI POLI"                                                   
   99 "ALL INSTANCES" /                                                    
   V141                                                                    
   2 "RAPE"                                                                
   3 "ROBBERY"                                                             
   5 "BURGLARY"                                                            
   6 "LARCENY"                                                             
   7 "MOTOR VEHI THEFT"                                                    
   9 "ARSON"                                                               
   10 "PROSTITUTIO-VICE"                                                   
   17 "OTH SEX OFFENSE"                                                    
   18 "NARCOTIC DRUG"                                                      
   19 "GAMBLING"                                                           
   20 "ABORTION"                                                           
   26 "OTH -FELONY TYPE"                                                   
   40 "LOVER-S TRIANGLE"                                                   
   41 "KID KILL-SITTER"                                                    
   42 "BRAWL - ALCHOL"                                                     
   43 "BRAWL-NARCOTICS"                                                    
   44 "ARGUMENT - MONEY"                                                   
   45 "OTHER ARGUMENTS"                                                    
   46 "GANGLAND KILLING"                                                   
   47 "JUV GANG KILLING"                                                   
   48 "INSTITUTION KILL"                                                   
   49 "SNIPER ATTACK"                                                      
   50 "VIC SHOT HUNT AC"                                                   
   51 "GUNCLEANIN DEATH"                                                   
   52 "KIDS PLAY WITHGUN"                                                  
   53 "OTH NEGLIGEN GUN"                                                   
   59 "ALL OTH MANSLAUG"                                                   
   60 "OTH NON-FEL TYPE"                                                   
   70 "ALL SUSPECT FELO"                                                   
   80 "JUSTIF HOMI CIVIL"                                                  
   81 "JUSTIF HOMI POLI"                                                   
   99 "ALL INSTANCES" /                                                    
   V142                                                                    
   1 "FEL ATTACK POLIC"                                                    
   2 "FEL ATT FEL OFFE"                                                    
   3 "FEL ATTACK CIVIL"                                                    
   4 "FEL ATTEM FLIGHT"                                                    
   5 "FEL KIL COM CRIM"                                                    
   6 "FEL RESISTED ARR"                                                    
   9 "NOT ENOUGH INFOR" /                                                  
   V143                                                                    
   1 "FEL ATTACK POLIC"                                                    
   2 "FEL ATT FEL OFFE"                                                    
   3 "FEL ATTACK CIVIL"                                                    
   4 "FEL ATTEM FLIGHT"                                                    
   5 "FEL KIL COM CRIM"                                                    
   6 "FEL RESISTED ARR"                                                    
   9 "NOT ENOUGH INFOR" /                                                  
   V144                                                                    
   1 "FEL ATTACK POLIC"                                                    
   2 "FEL ATT FEL OFFE"                                                    
   3 "FEL ATTACK CIVIL"                                                    
   4 "FEL ATTEM FLIGHT"                                                    
   5 "FEL KIL COM CRIM"                                                    
   6 "FEL RESISTED ARR"                                                    
   9 "NOT ENOUGH INFOR" /                                                  
   V145                                                                    
   1 "FEL ATTACK POLIC"                                                    
   2 "FEL ATT FEL OFFE"                                                    
   3 "FEL ATTACK CIVIL"                                                    
   4 "FEL ATTEM FLIGHT"                                                    
   5 "FEL KIL COM CRIM"                                                    
   6 "FEL RESISTED ARR"                                                    
   9 "NOT ENOUGH INFOR" /                                                  
   V146                                                                    
   1 "FEL ATTACK POLIC"                                                    
   2 "FEL ATT FEL OFFE"                                                    
   3 "FEL ATTACK CIVIL"                                                    
   4 "FEL ATTEM FLIGHT"                                                    
   5 "FEL KIL COM CRIM"                                                    
   6 "FEL RESISTED ARR"                                                    
   9 "NOT ENOUGH INFOR" /                                                  
   V147                                                                    
   1 "FEL ATTACK POLIC"                                                    
   2 "FEL ATT FEL OFFE"                                                    
   3 "FEL ATTACK CIVIL"                                                    
   4 "FEL ATTEM FLIGHT"                                                    
   5 "FEL KIL COM CRIM"                                                    
   6 "FEL RESISTED ARR"                                                    
   9 "NOT ENOUGH INFOR" /                                                  
   V148                                                                    
   1 "FEL ATTACK POLIC"                                                    
   2 "FEL ATT FEL OFFE"                                                    
   3 "FEL ATTACK CIVIL"                                                    
   4 "FEL ATTEM FLIGHT"                                                    
   5 "FEL KIL COM CRIM"                                                    
   6 "FEL RESISTED ARR"                                                    
   9 "NOT ENOUGH INFOR" /                                                  
   V149                                                                    
   1 "FEL ATTACK POLIC"                                                    
   2 "FEL ATT FEL OFFE"                                                    
   3 "FEL ATTACK CIVIL"                                                    
   4 "FEL ATTEM FLIGHT"                                                    
   5 "FEL KIL COM CRIM"                                                    
   6 "FEL RESISTED ARR"                                                    
   9 "NOT ENOUGH INFOR" /                                                  
   V150                                                                    
   1 "FEL ATTACK POLIC"                                                    
   2 "FEL ATT FEL OFFE"                                                    
   3 "FEL ATTACK CIVIL"                                                    
   4 "FEL ATTEM FLIGHT"                                                    
   5 "FEL KIL COM CRIM"                                                    
   6 "FEL RESISTED ARR"                                                    
   9 "NOT ENOUGH INFOR" /                                                  
   V151                                                                    
   1 "FEL ATTACK POLIC"                                                    
   2 "FEL ATT FEL OFFE"                                                    
   3 "FEL ATTACK CIVIL"                                                    
   4 "FEL ATTEM FLIGHT"                                                    
   5 "FEL KIL COM CRIM"                                                    
   6 "FEL RESISTED ARR"                                                    
   9 "NOT ENOUGH INFOR" /                                                  
   V152                                                                    
   1 "FEL ATTACK POLIC"                                                    
   2 "FEL ATT FEL OFFE"                                                    
   3 "FEL ATTACK CIVIL"                                                    
   4 "FEL ATTEM FLIGHT"                                                    
   5 "FEL KIL COM CRIM"                                                    
   6 "FEL RESISTED ARR"                                                    
   9 "NOT ENOUGH INFOR" /.                                                 
                                                                           
* SPSS MISSING VALUES COMMAND.                                             
                                                                           
* MISSING VALUES                                                           
   V25 (0)                             V26 (0)                             
   V27 (0)                             V28 (0)                             
   V29 (0)                             V30 (0)                             
   V31 (0)                             V32 (0)                             
   V33 (0)                             V34 (0)                             
   V35 (9)                             V36 (9)                             
   V37 (9)                             V38 (9)                             
   V39 (9)                             V40 (9)                             
   V41 (9)                             V42 (9)                             
   V43 (9)                             V44 (9)                             
   V45 (9)                             V46 (9)                             
   V47 (9)                             V48 (9)                             
   V49 (9)                             V50 (9)                             
   V51 (9)                             V52 (9)                             
   V53 (9)                             V54 (9)                             
   V55 (9)                             V56 (9)                             
   V57 (9)                             V58 (9)                             
   V59 (9)                             V60 (9)                             
   V61 (9)                             V62 (9)                             
   V63 (9)                             V64 (9)                             
   V65 (0)                             V66 (0)                             
   V67 (0)                             V68 (0)                             
   V69 (0)                             V70 (0)                             
   V71 (0)                             V72 (0)                             
   V73 (0)                             V74 (0)                             
   V75 (0)                             V76 (9)                             
   V77 (9)                             V78 (9)                             
   V79 (9)                             V80 (9)                             
   V81 (9)                             V82 (9)                             
   V83 (9)                             V84 (9)                             
   V85 (9)                             V86 (9)                             
   V87 (9)                             V88 (9)                             
   V89 (9)                             V90 (9)                             
   V91 (9)                             V92 (9)                             
   V93 (9)                             V94 (9)                             
   V95 (9)                             V96 (9)                             
   V97 (9)                             V98 (9)                             
   V99 (9)                             V100 (9)                            
   V101 (9)                            V102 (9)                            
   V103 (9)                            V104 (9)                            
   V105 (9)                            V106 (9)                            
   V107 (9)                            V108 (9)                            
   V109 (90)                           V110 (90)                           
   V111 (90)                           V112 (90)                           
   V113 (90)                           V114 (90)                           
   V115 (90)                           V116 (90)                           
   V117 (90)                           V118 (90)                           
   V119 (90)                           V120 (99)                           
   V121 (99)                           V122 (99)                           
   V123 (99)                           V124 (99)                           
   V125 (99)                           V126 (99)                           
   V127 (99)                           V128 (99)                           
   V129 (99)                           V130 (99)                           
   V131 (99)                           V132 (99)                           
   V133 (99)                           V134 (99)                           
   V135 (99)                           V136 (99)                           
   V137 (99)                           V138 (99)                           
   V139 (99)                           V140 (99)                           
   V141 (99)                           V142 (0, 9)                         
   V143 (0, 9)                         V144 (0, 9)                         
   V145 (0, 9)                         V146 (0, 9)                         
   V147 (0, 9)                         V148 (0, 9)                         
   V149 (0, 9)                         V150 (0, 9)                         
   V151 (0, 9)                         V152 (0, 9).                        
                                                                           
                                                                           
